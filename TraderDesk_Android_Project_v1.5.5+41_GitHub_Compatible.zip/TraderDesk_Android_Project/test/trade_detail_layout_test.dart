import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/screens/trades_screen.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';

void main() {
  testWidgets('saved trade details preserve the Windows panel separation and review art', (
    tester,
  ) async {
    final trade = Trade(
      id: 'detail-layout-test',
      accountId: 'account-test',
      market: 'US100',
      reason: 'RBS Touch 2',
      result: 12.5,
      expectedLoss: 5,
      riskPercent: 1.25,
      side: TradeSide.buy,
      confirmation: 'confirmBreakoutPullback',
      entrySetups: const [
        TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '5MIN'),
        TradeEntrySetup(reason: 'SBR Touch 2', timeframe: '1MIN'),
      ],
      confirmationSetups: const [
        TradeConfirmationSetup(type: 'confirmBreakoutPullback', timeframe: '15MIN'),
      ],
      sequence: 'Session opening',
      mood: 'moodCalm',
      tradedAt: DateTime(2026, 11, 5, 11, 21),
      executionReviewKeys: const [
        'enteredEarly',
        'missedHigherTimeframeBounceArea',
        'stopLossIncreasedForLiquiditySafety',
        'fullPlanCompliance',
      ],
      noEntryReasons: const ['fearLossNoHistory'],
    );

    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(Brightness.dark),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: TradeDetailScreen(trade: trade, currency: 'USD'),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('trade-detail-result-panel')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-data-panel')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-result-expected-loss-pair')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-risk-reward-pair')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-market-direction-pair')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-review-panel')), findsOneWidget);
    expect(find.text('النتيجة والمخاطرة'), findsOneWidget);
    expect(find.text('بيانات الصفقة'), findsOneWidget);
    expect(find.text('مراجعة الصفقة'), findsOneWidget);
    expect(find.text('مخالفات التنفيذ'), findsOneWidget);
    expect(find.text('جودة التحليل والإعداد'), findsOneWidget);
    expect(find.text('قرارات الدخول وإدارة المخاطرة'), findsOneWidget);
    expect(find.text('الالتزام'), findsOneWidget);
    expect(find.text('أسباب عدم الدخول'), findsOneWidget);
    expect(find.text('US100'), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-entry-reasons')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-confirmations')), findsOneWidget);
    expect(find.text('RBS Touch 2 · 5MIN'), findsOneWidget);
    expect(find.text('SBR Touch 2 · 1MIN'), findsOneWidget);
    expect(find.text('Breakout–Pullback · 15MIN'), findsOneWidget);

    // Three decision artworks + one commitment + one no-entry artwork.
    expect(find.byType(TradeReviewOptionEmoji), findsNWidgets(5));

    // Compact metric/identity fields occupy half-width slots instead of full rows.
    final resultWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-result-value')),
    ).width;
    final expectedLossWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-expected-loss-value')),
    ).width;
    final marketWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-data-row-0')),
    ).width;
    final directionWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-data-row-1')),
    ).width;
    expect((resultWidth - expectedLossWidth).abs(), lessThan(1));
    expect((marketWidth - directionWidth).abs(), lessThan(1));

    final detailList = tester.widget<ListView>(
      find.byKey(const ValueKey('trade-detail-scroll-view')),
    );
    expect(detailList.padding, const EdgeInsetsDirectional.fromSTEB(8, 10, 8, 24));
  });
}
