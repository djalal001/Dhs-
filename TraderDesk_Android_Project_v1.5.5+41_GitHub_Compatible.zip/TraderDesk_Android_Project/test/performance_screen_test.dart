import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/main.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/performance_screen.dart';
import 'package:trader_desk/state/app_controller.dart';

void main() {
  testWidgets(
    'performance tab recalculates results for week, month and all time',
    (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final directory = Directory.systemTemp.createTempSync(
        'trader_desk_performance_',
      );
      final app = await tester.runAsync(
        () => AppController.create(
          store: LocalStore(documentsDirectory: () async => directory),
        ),
      );
      if (app == null)
        throw StateError('Could not initialize test controller.');

      final now = DateTime.now();
      final firstOfMonth = DateTime(now.year, now.month, 1);
      final weekStart = DateTime(
        now.year,
        now.month,
        now.day,
      ).subtract(Duration(days: now.weekday - 1));
      final otherMonthDay = firstOfMonth.isBefore(weekStart)
          ? firstOfMonth
          : DateTime(now.year, now.month, now.day);
      final tradesThisWeek = otherMonthDay.isBefore(weekStart) ? 1 : 2;
      final account = TradingAccount(
        id: 'performance-account',
        name: 'Main account',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(now.year, now.month, 1),
      );
      app.accounts = [account];
      app.selectedAccountId = account.id;
      app.trades = [
        Trade(
          id: 'this-week',
          accountId: account.id,
          market: 'EURUSD',
          reason: 'SBR',
          result: 50,
          riskPercent: 1,
          expectedLoss: 25,
          side: TradeSide.buy,
          confirmation: '',
          sequence: '',
          mood: 'moodConfident',
          tradedAt: now,
        ),
        Trade(
          id: 'this-month',
          accountId: account.id,
          market: 'EURUSD',
          reason: 'RBS',
          result: -20,
          riskPercent: 0.5,
          expectedLoss: 20,
          side: TradeSide.sell,
          confirmation: '',
          sequence: '',
          mood: 'moodAnxious',
          tradedAt: DateTime(
            otherMonthDay.year,
            otherMonthDay.month,
            otherMonthDay.day,
            12,
          ),
        ),
        Trade(
          id: 'older',
          accountId: account.id,
          market: 'EURUSD',
          reason: 'SBR',
          result: 5,
          riskPercent: 1,
          expectedLoss: 10,
          side: TradeSide.buy,
          confirmation: '',
          sequence: '',
          mood: 'moodCalm',
          tradedAt: DateTime(
            now.year,
            now.month,
            1,
          ).subtract(const Duration(days: 1)),
        ),
      ];

      await tester.pumpWidget(TraderDeskApp(controller: app));
      await tester.pump(const Duration(milliseconds: 450));
      expect(tester.takeException(), isNull);
      await tester.tap(find.text('تحليل الأداء').last);
      await tester.pump(const Duration(milliseconds: 450));
      expect(tester.takeException(), isNull);

      final totalTradesCard = find.byKey(
        const ValueKey('performance-total-trades'),
      );
      expect(
        find.descendant(
          of: totalTradesCard,
          matching: find.text('$tradesThisWeek'),
        ),
        findsOneWidget,
      );
      await tester.tap(find.byKey(const ValueKey('performance-period-month')));
      await tester.pump(const Duration(milliseconds: 350));
      expect(
        find.descendant(of: totalTradesCard, matching: find.text('2')),
        findsOneWidget,
      );
      await tester.tap(find.byKey(const ValueKey('performance-period-all')));
      await tester.pump(const Duration(milliseconds: 350));
      expect(
        find.descendant(of: totalTradesCard, matching: find.text('3')),
        findsOneWidget,
      );
      await tester.tap(find.text('مختبر السلوك').last);
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.byKey(const ValueKey('behavior-lab-root')), findsOneWidget);
      expect(find.text('مرآة لعادات التنفيذ المسجلة'), findsOneWidget);
      expect(find.textContaining('سجلات تنفيذ'), findsOneWidget);
      expect(find.text('الحالة النفسية مع سيناريو الدخول'), findsOneWidget);
      expect(find.textContaining('متوسط وحدات المخاطرة'), findsWidgets);
      expect(
        tester
            .widget<Text>(find.byKey(const ValueKey('behavior-trade-count')))
            .data,
        'عدد الصفقات: 3',
      );

      app.trades = [
        ...app.trades,
        Trade(
          id: 'added-after-open',
          accountId: account.id,
          market: 'EURUSD',
          reason: 'SBR',
          result: 25,
          riskPercent: 0.5,
          expectedLoss: 50,
          side: TradeSide.buy,
          confirmation: '',
          sequence: '',
          mood: 'moodConfident',
          tradedAt: now,
        ),
      ];
      app.notifyListeners();
      await tester.pump();
      expect(
        tester
            .widget<Text>(find.byKey(const ValueKey('behavior-trade-count')))
            .data,
        'عدد الصفقات: 4',
      );
      await tester.tap(find.text('الأداء المالي').last);
      await tester.pumpAndSettle();
      final performanceScroll = find
          .descendant(
            of: find.byType(PerformanceScreen),
            matching: find.byType(Scrollable),
          )
          .first;
      await tester.scrollUntilVisible(
        find.text('هادئ'),
        280,
        scrollable: performanceScroll,
      );
      expect(find.text('هادئ'), findsOneWidget);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(() => directory.delete(recursive: true));
    },
  );
}
