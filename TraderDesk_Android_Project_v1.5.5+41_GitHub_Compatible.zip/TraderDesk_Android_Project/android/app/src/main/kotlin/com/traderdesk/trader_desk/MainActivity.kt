package com.traderdesk.trader_desk

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
