#!/usr/bin/env python3
"""Static regression checks for the requested TraderDesk 1.7.74+130 refinements."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
ANCHOR_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
TOUCH_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
DETAIL_TEST = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

# 1. The Arabic text changed, while the stable storage key is unchanged.
check("repeat-loss reason has the requested Arabic wording", "TradeEntryOption('fearRepeatLossAfterLoss', 'الخوف من تكرار الخسارة بعد خسارة سابقة'" in CATALOG)
check("old repeat-loss wording is absent from the active catalog", "الخوف من تكرار خسارة سابقة." not in CATALOG)
check("repeat-loss reason retains its existing key", "'fearRepeatLossAfterLoss'" in CATALOG and "key == 'fearRepeatLossAfterLoss'" in CATALOG_TEST)

# 2. Exactly 15 decision items + 5 commitment items, with no terminal periods.
def section(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[1].split(end, 1)[0]

review = section(CATALOG, "const tradeReviewGroups", "const tradeCommitmentOptions")
commitment = section(CATALOG, "const tradeCommitmentOptions", "const tradeNoEntryOptions")
behavior_items = re.findall(r"TradeEntryOption\([^\n]*\)", review + commitment)
check("behavior catalog contains exactly 20 options", len(behavior_items) == 20)
terminal_periods = []
for index, item in enumerate(behavior_items, start=1):
    labels = re.findall(r"'((?:[^'\\]|\\.)*)'", item)
    if len(labels) >= 3:
        for label in labels[1:3]:
            if label.endswith("."):
                terminal_periods.append((index, label))
    else:
        terminal_periods.append((index, "unparsed label"))
check("all Arabic and English behavior labels omit terminal periods", not terminal_periods)
check("catalog test asserts count and both locale endings", "hasLength(20)" in CATALOG_TEST and "option.ar.endsWith('.')" in CATALOG_TEST and "option.en.endsWith('.')" in CATALOG_TEST)

# 3. Keep the two card headings and values, but no heading icon arguments.
conditions_card = section(TRADES, "key: const ValueKey('trade-detail-entry-conditions-panel')", "if (trade.executionJournal.isNotEmpty)")
reverse_field = section(conditions_card, "key: const ValueKey('trade-detail-reverse-signals')", "if (reverseSignalLabels.isNotEmpty && bounceZoneLabels.isNotEmpty)")
bounce_field = section(conditions_card, "key: const ValueKey('trade-detail-bounce-zone')", "if (trade.executionJournal.isNotEmpty)")
check("saved-card headings and values remain", "إشارات عكسية" in reverse_field and "منطقة الارتداد" in bounce_field and "values: reverseSignalLabels" in reverse_field and "values: bounceZoneLabels" in bounce_field)
check("saved-card opposing-signal and bounce fields omit decorative icons", "icon:" not in reverse_field and "icon:" not in bounce_field)
check("widget tests assert no icons in either saved field", "saved opposing-signals field should not show a decorative logo" in DETAIL_TEST and "saved bounce-area field should not show a decorative logo" in DETAIL_TEST)

# 4. Use the new prompt copy only for SBR/RBS; preserve S/R-bounce wording.
check("SBR/RBS invokes the compact Touch 2 wording", "compactLabels: true" in FORM)
check("compact prompt shows Touch 2 and متابعة", "_copy('Touch 2', 'Touch 2')" in FORM and "_copy('متابعة', 'Continue')" in FORM)
check("S/R-bounce prompt keeps its original Arabic copy", "'لمسة 2'" in FORM and "'تجاوزها والمتابعة إلى الفريم الزمني'" in FORM and "'Skip and choose timeframe'" in FORM)
check("SBR/RBS tests cover the new exact labels", "find.text('Touch 2')" in TOUCH_TEST and "find.text('متابعة')" in TOUCH_TEST)
check("S/R-bounce widget test covers the retained copy", "expect(find.text('لمسة 2'), findsOneWidget)" in ANCHOR_TEST and "expect(find.text('تجاوزها والمتابعة إلى الفريم الزمني'), findsOneWidget)" in ANCHOR_TEST)

# 5. Anchor picker follows the restrained entry-reason list markers without changing multi-select.
anchor_picker = section(FORM, "Future<void> _pickAnchors()", "Future<void> _editAnchorTimeframe")
check("anchor selected rows use circular check markers", "Icons.check_circle_rounded" in anchor_picker)
check("anchor unselected rows use chevrons", "Icons.chevron_left_rounded" in anchor_picker)
check("anchor picker no longer uses checkbox-square icons", "check_box_" not in anchor_picker)
check("anchor still opens a timeframe picker per selected option", "_showTimeframeSheet(" in anchor_picker and "_anchorTimeframes[option.key] = timeframe" in anchor_picker)
check("anchor test covers both marker states", "Icons.check_circle_rounded" in ANCHOR_TEST and "Icons.chevron_left_rounded" in ANCHOR_TEST)

# Release metadata.
check("pubspec release is 1.7.74+130", "version: 1.7.74+130" in PUBSPEC)
check("GitHub workflow artifact names are 1.7.74 build 130", "TraderDesk 1.7.74+130" in WORKFLOW and "traderdesk-1.7.74-build130" in WORKFLOW)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed), file=sys.stderr)
    if terminal_periods:
        print("Terminal periods found:", terminal_periods, file=sys.stderr)
    raise SystemExit(1)
