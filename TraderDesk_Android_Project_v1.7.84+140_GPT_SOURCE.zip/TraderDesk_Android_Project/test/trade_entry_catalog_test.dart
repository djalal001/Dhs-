import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';

void main() {
  test('opposing-signal selector exposes the four requested categories', () {
    expect(
      tradeReverseSignalOptions.map((option) => option.key).toList(),
      ['reverseSr', 'reverseSdZone', 'reverseHns', 'reverseLongCandleWick'],
    );
    expect(
      tradeReverseSignalOptions.map((option) => option.ar).toList(),
      ['S/R عكسي', 'S - D Zone عكسي', 'HNS عكسي', 'ذيل شمعة طويل عكسي'],
    );
  });

  test(
    'reverse S/R role reversal and S-D categories resolve from trade direction',
    () {
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.buy,
        ),
        'Support عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Resistance عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSdZone',
          arabic: true,
          side: TradeSide.buy,
        ),
        'Supply Zone',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSdZone',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Demand Zone',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.buy,
        ),
        'Reverse Support',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.sell,
        ),
        'Reverse Resistance',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseHns',
          arabic: true,
          side: TradeSide.buy,
        ),
        'HNS عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseLongCandleWick',
          arabic: true,
          side: TradeSide.sell,
        ),
        'ذيل شمعة طويل عكسي',
      );
    },
  );

  test('legacy opposing-signal records remain readable', () {
    expect(
      tradeReverseSignalDisplayLabel(
        optionKey: 'negativeCloseAgainstDirection', arabic: true,
      ),
      'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول',
    );
    expect(
      tradeReverseSignalDisplayLabel(
        optionKey: 'strongRejectionWickAgainstDirection', arabic: true,
      ),
      'نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة',
    );
  });

  test('updates the no-entry reason text without changing its saved key', () {
    final option = tradeNoEntryOptions.singleWhere(
      (item) => item.key == 'waitedDeeperRetestDespiteConfirmation',
    );
    expect(
      option.ar,
      'الخوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة.',
    );
    expect(
      option.en,
      'Fear of a deep correction because the entry confirmation was far from the zone.',
    );
  });

  test('updates repeat-loss wording without changing the saved key', () {
    final option = tradeNoEntryOptions.singleWhere(
      (item) => item.key == 'fearRepeatLossAfterLoss',
    );
    expect(option.ar, 'الخوف من تكرار الخسارة بعد خسارة سابقة');
    expect(option.en, 'Fear of repeating a loss after a previous loss');
  });

  test('the 20 trading-behavior options have no terminal periods', () {
    final behaviorOptions = [
      ...tradeReviewGroups.expand((group) => group.options),
      ...tradeCommitmentOptions,
    ];
    expect(behaviorOptions, hasLength(20));
    for (final option in behaviorOptions) {
      expect(option.ar.endsWith('.'), isFalse, reason: option.key);
      expect(option.en.endsWith('.'), isFalse, reason: option.key);
    }
  });

  test('uses the revised Trendline names while preserving legacy stored keys', () {
    final byKey = {for (final option in tradeEntryReasons) option.key: option};

    expect(byKey['Trend Line SELL']?.en, 'Trendline Sell 3 Touch');
    expect(byKey['Trend Line BUY']?.en, 'Trendline Buy 3 Touch');
    expect(
      byKey['Trend Line BREAKOUT SELL']?.en,
      'Trend Line Touch 3 Sell Breakout',
    );
    expect(
      byKey['Trend Line BREAKOUT BUY']?.en,
      'Trend Line Touch 3 Buy Breakout',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'Trend Line SELL'),
      'Trendline Sell 3 Touch',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'Trend Line BUY'),
      'Trendline Buy 3 Touch',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'Trend Line BREAKOUT SELL'),
      'Trend Line Touch 3 Sell Breakout',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'Trend Line BREAKOUT BUY'),
      'Trend Line Touch 3 Buy Breakout',
    );
  });

  test('Zone S/D is direction-aware and retains legacy Supply Zone records', () {
    final zoneOption = tradeEntryReasons.singleWhere(
      (option) => option.key == 'zoneSd',
    );
    expect(zoneOption.ar, 'Zone S/D');
    expect(zoneOption.en, 'Zone S/D');
    expect(
      tradeEntryReasons.any((option) => option.key == 'Supply Zone'),
      isFalse,
    );
    expect(tradeEntryReasonSelectionKey('Supply Zone'), 'zoneSd');
    expect(tradeEntryReasonSelectionKey('zoneSd'), 'zoneSd');
    expect(
      formatTradeEntryReasonLabel(reason: 'zoneSd', side: TradeSide.buy),
      'Demand Zone',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'zoneSd', side: TradeSide.sell),
      'Supply Zone',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'zoneSd'),
      'Zone S/D',
    );
    // Existing records which literally stored Supply Zone keep their
    // historical fixed label until the trader edits that entry.
    expect(
      formatTradeEntryReasonLabel(reason: 'Supply Zone', side: TradeSide.buy),
      'Supply Zone',
    );
    const setup = TradeEntrySetup(reason: 'zoneSd', timeframe: '15MIN');
    expect(TradeEntrySetup.fromJson(setup.toJson()), setup);
  });

  test('uses one direction-aware BREAKOUT row instead of separate SBR/RBS rows', () {
    final keys = tradeEntryReasons.map((option) => option.key).toSet();

    expect(keys, containsAll(['directionalBreakout', 'RFS', 'SFR']));
    expect(keys, isNot(contains('SBR')));
    expect(keys, isNot(contains('RBS')));
    expect(tradeEntryReasons.singleWhere((item) => item.key == 'directionalBreakout').en, 'BREAKOUT');
    expect(tradeEntryReasonSelectionKey('SBR'), 'directionalBreakout');
    expect(tradeEntryReasonSelectionKey('RBS'), 'directionalBreakout');
    expect(tradeEntryReasonSelectionKey('SBR Touch 2'), 'directionalBreakout');
    expect(tradeEntryReasonSelectionKey('RBS Touch 2'), 'directionalBreakout');
    expect(formatTradeEntryReasonLabel(reason: 'SBR'), 'SBR',
        reason: 'legacy saved SBR records preserve their historical label');
    expect(formatTradeEntryReasonLabel(reason: 'RBS'), 'RBS',
        reason: 'legacy saved RBS records preserve their historical label');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout', side: TradeSide.buy), 'RBS');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout', side: TradeSide.sell), 'SBR');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout'), 'BREAKOUT');
  });

  test('defines the reverse-signal and bounce-area option lists independently', () {
    expect(tradeReverseSignalOptions.map((item) => item.key), [
      'reverseSr',
      'reverseSdZone',
      'reverseHns',
      'reverseLongCandleWick',
    ]);
    expect(tradeBounceZoneOptions.map((item) => item.key), [
      'bounceFromSrZone',
      'internalLiquiditySweep',
      'majorStructureLiquiditySweep',
      'bounceFromTrendline',
      'bounceFromTrendlineAndSupplyZone',
    ]);
  });

  test('uses the approved concise Arabic and English liquidity labels', () {
    final internal = tradeBounceZoneOptions.singleWhere(
      (item) => item.key == 'internalLiquiditySweep',
    );
    final external = tradeBounceZoneOptions.singleWhere(
      (item) => item.key == 'majorStructureLiquiditySweep',
    );
    expect(internal.ar, 'سحب سيولة داخلي');
    expect(internal.en, 'Internal liquidity sweep');
    expect(external.ar, 'سحب السيولة خارجي');
    expect(external.en, 'External liquidity sweep');
  });

  test('uses one direction-aware Zone S/D anchor instead of separate Supply/Demand rows', () {
    expect(
      tradeAnchorOptions.map((item) => item.en).toList(),
      [
        'Key Level',
        'Zone S/D',
        'Bullish Engulfing',
        'Bearish engulfing',
        'Base',
      ],
    );
    expect(tradeAnchorOptions.map((item) => item.key).toSet().length, 5);
    expect(tradeAnchorOptions.any((item) => item.key == 'supplyZone' || item.key == 'demandZone'), isFalse);
    expect(formatTradeAnchorLabel(anchorKey: 'zoneSd', arabic: false, side: TradeSide.buy), 'Demand Zone');
    expect(formatTradeAnchorLabel(anchorKey: 'zoneSd', arabic: false, side: TradeSide.sell), 'Supply Zone');
    expect(formatTradeAnchorLabel(anchorKey: 'zoneSd', arabic: false), 'Zone S/D');
    expect(formatTradeAnchorLabel(anchorKey: 'supplyZone', arabic: false, side: TradeSide.buy), 'Supply Zone',
        reason: 'legacy records keep their historical concrete label');
    expect(formatTradeAnchorLabel(anchorKey: 'demandZone', arabic: false, side: TradeSide.sell), 'Demand Zone',
        reason: 'legacy records keep their historical concrete label');
    final base = tradeAnchorOptions.singleWhere((item) => item.key == 'base');
    expect(base.ar, 'Base');
    expect(base.en, 'Base');
  });


  test('Base anchor and timeframe round-trip through the existing trade JSON shape', () {
    final original = Trade(
      id: 'base-anchor-json-test',
      accountId: 'account',
      market: 'NQ',
      reason: 'RFS',
      result: 25,
      riskPercent: 1,
      side: TradeSide.buy,
      confirmation: '',
      sequence: '',
      mood: '',
      tradedAt: DateTime(2026, 1, 1),
      anchors: const ['base'],
      anchorTimeframes: const {'base': '1H'},
    );

    final restored = Trade.fromJson(original.toJson());
    expect(restored.effectiveAnchors, ['base']);
    expect(restored.anchorTimeframes, {'base': '1H'});
  });

  test('new opposing signal categories use the existing setup JSON shape', () {
    for (final key in [
      'reverseSr',
      'reverseSdZone',
      'reverseHns',
      'reverseLongCandleWick',
    ]) {
      final selected = TradeEntryConditionSetup(
        optionKey: key,
        timeframe: '15MIN',
      );
      expect(TradeEntryConditionSetup.fromJson(selected.toJson()), selected);
      expect(selected.toJson().keys, containsAll(['optionKey', 'timeframe']));
    }
  });

  test('reverse labels in saved setup follow the selected direction', () {
    const srSetup = TradeEntryConditionSetup(
      optionKey: 'reverseSr',
      timeframe: '15MIN',
    );
    const sdSetup = TradeEntryConditionSetup(
      optionKey: 'reverseSdZone',
      timeframe: '30MIN',
    );

    expect(
      formatTradeEntryConditionSetupLabel(
        setup: srSetup, optionLabel: 'S/R عكسي', arabic: true, side: TradeSide.buy,
      ),
      'Support عكسي 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: srSetup, optionLabel: 'S/R عكسي', arabic: true, side: TradeSide.sell,
      ),
      'Resistance عكسي 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: sdSetup, optionLabel: 'S - D Zone عكسي', arabic: true, side: TradeSide.buy,
      ),
      'Supply Zone 30MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: sdSetup, optionLabel: 'S - D Zone عكسي', arabic: true, side: TradeSide.sell,
      ),
      'Demand Zone 30MIN',
    );
  });

  test('formats entry-condition labels without separator dots or duplicated names', () {
    const combined = TradeEntryConditionSetup(
      optionKey: 'bounceFromTrendlineAndSupplyZone',
      timeframe: '30MIN',
      secondaryTimeframe: '5MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: combined,
        optionLabel: 'ارتداد من ترند لاين و Supply Zone',
        arabic: true,
      ),
      'ارتداد من Trend Line 30MIN - Supply Zone 5MIN',
    );
    const regular = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regular,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
      ),
      'ارتداد من منطقة S/R 15MIN',
    );
  });

  test('S/R bounce label follows direction only after a side is selected', () {
    const setup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );

    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
      ),
      'ارتداد من منطقة S/R 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من Support 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistance 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'Bounce from an S/R zone',
        arabic: false,
        side: TradeSide.buy,
      ),
      'Bounce from Support 15MIN',
    );
  });

  test('S/R bounce Touch 2 is shown as an optional saved qualifier', () {
    const setup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
      touch2: true,
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistance Touch 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'Bounce from an S/R zone',
        arabic: false,
        side: TradeSide.buy,
      ),
      'Bounce from Support Touch 15MIN',
    );
  });

  test('S/R bounce chip uses the exact Support/Resistance Touch timeframe order', () {
    const touchSetup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
      touch2: true,
    );
    const regularSetup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: touchSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من Support Touch 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regularSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من Support 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: touchSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistance Touch 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regularSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistance 15MIN',
    );
  });

  test('S/R Touch 2 survives model JSON and older records default to false', () {
    const selected = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '30MIN',
      touch2: true,
    );
    expect(TradeEntryConditionSetup.fromJson(selected.toJson()), selected);
    expect(
      TradeEntryConditionSetup.fromJson({
        'optionKey': 'bounceFromSrZone',
        'timeframe': '30MIN',
      }).touch2,
      isFalse,
    );
  });

  test(
    'entry reason and confirmation labels place timeframe with a plain space',
    () {
      expect(
        const TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '5MIN').label,
        'RBS Touch 2 5MIN',
      );
      expect(
        const TradeConfirmationSetup(
          type: 'Breakout–Pullback',
          timeframe: '15MIN',
        ).label,
        'Breakout–Pullback 15MIN',
      );
    },
  );

  test('Touch 2 qualifier is supported only for SBR and RBS', () {
    expect(tradeEntryTouch2EligibleReasons, {'SBR', 'RBS'});
    expect(tradeEntryBaseReason('SBR Touch 2'), 'SBR');
    expect(tradeEntryBaseReason('RBS Touch 2'), 'RBS');
    expect(tradeEntryUsesTouch2('SBR Touch 2'), isTrue);
    expect(tradeEntryUsesTouch2('RBS'), isFalse);
    expect(tradeEntryReasonWithTouch2('SBR', true), 'SBR Touch 2');
    expect(tradeEntryReasonWithTouch2('RBS', false), 'RBS');
    expect(tradeEntryReasonWithTouch2('RFS', true), 'RFS');
    expect(tradeEntryReasonWithTouch2('SFR', true), 'SFR');
  });
}
