import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';
import 'package:trader_desk/widgets/decision_section_logo.dart';

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_entry_v150_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'entry-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'entry-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('adds Windows entry reason, custom confirmation and review selections', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketSelector = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    await tester.tap(marketSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-market-option-NQ')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const ValueKey('trade-result-input')), '42.5');
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(find.byKey(const ValueKey('trade-risk-input'))).controller!.text, '1.00');
    expect(tester.widget<TextFormField>(find.byKey(const ValueKey('trade-reward-risk-input'))).controller!.text, '0.43');

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Zone S/D'), findsOneWidget);
    expect(find.text('Trendline Sell 3 Touch'), findsOneWidget);
    expect(find.text('Trendline Buy 3 Touch'), findsOneWidget);
    expect(find.text('Trend Line Touch 3 Sell Breakout'), findsOneWidget);
    expect(find.text('Trend Line Touch 3 Buy Breakout'), findsOneWidget);
    expect(find.text('Supply Zone'), findsNothing,
        reason: 'Supply Zone is no longer a direct Entry Reason choice');
    await tester.tap(find.text('Zone S/D').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D resolves to Demand Zone for BUY');

    // The same saved semantic Zone S/D key follows direction changes.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Supply Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D resolves to Supply Zone for SELL');
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget);

    // A single BREAKOUT choice resolves to the correct scenario from direction.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('BREAKOUT'), findsOneWidget);
    expect(find.text('SBR'), findsNothing);
    expect(find.text('RBS'), findsNothing);
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('سبب الدخول · RBS'), findsOneWidget,
        reason: 'BUY resolves the single BREAKOUT choice to RBS in the timeframe header');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS 15MIN'), findsOneWidget);

    // The same semantic Breakout resolves to SBR after changing to SELL.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SBR 15MIN'), findsOneWidget);
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · SBR'), findsOneWidget);
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('SBR 30MIN'), findsOneWidget);

    // Return to BUY for the remaining reason, confirmation and review checks.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    // RFS and SFR go straight to the existing timeframe picker.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('RFS'), findsOneWidget);
    await tester.tap(find.text('RFS').last);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('touch2-choice-RFS')), findsNothing);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 5MIN'), findsOneWidget);

    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('SFR').last);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('touch2-choice-SFR')), findsNothing);
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();
    expect(find.text('SFR 1H'), findsOneWidget);

    // Editing the semantic Breakout choice keeps BREAKOUT selected in its picker.
    final savedBreakout = find.text('RBS 15MIN');
    await tester.ensureVisible(savedBreakout);
    await tester.tap(savedBreakout);
    await tester.pumpAndSettle();
    expect(find.text('BREAKOUT'), findsOneWidget);
    final breakoutOption = find.text('BREAKOUT').last;
    await tester.tap(breakoutOption);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · RBS'), findsOneWidget);
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS 2MIN'), findsOneWidget);

    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    await tester.ensureVisible(addConfirmation);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Reject ᴷᵉʸ ᴸᵉᵛᵉˡ'), findsOneWidget);
    await tester.tap(find.text('مخصص').last);
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField).last, 'ارتداد من مستوى يومي');
    await tester.tap(find.text('تأكيد').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من مستوى يومي 2MIN'), findsOneWidget);

    await tester.ensureVisible(find.text('القرارات'));
    await tester.tap(find.text('القرارات'));
    await tester.pumpAndSettle();
    final decisionOption = find.byKey(const ValueKey('review-enteredEarly'));
    final decisionOptionText = find.descendant(
      of: decisionOption,
      matching: find.byType(Text),
    );
    expect(
      tester.widget<Text>(decisionOptionText).style?.fontSize,
      14.5,
      reason: 'trading behavior option text should be comfortably readable',
    );
    expect(
      find.byType(DecisionSectionLogo),
      findsNothing,
      reason: 'the decisions mark is reserved for the saved trade details',
    );
    await tester.tap(find.byKey(const ValueKey('review-enteredEarly')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-enteredEarly')), findsOneWidget);

    await tester.ensureVisible(find.text('الالتزام'));
    await tester.tap(find.text('الالتزام'));
    await tester.pumpAndSettle();
    final commitmentOption = find.byKey(
      const ValueKey('review-fullPlanCompliance'),
    );
    expect(
      tester.widget<Text>(find.descendant(
        of: commitmentOption,
        matching: find.byType(Text),
      )).style?.fontSize,
      14.5,
    );
    await tester.tap(commitmentOption);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-fullPlanCompliance')), findsOneWidget);
    expect(find.byType(TradeReviewOptionEmoji), findsNWidgets(20));

    await tester.ensureVisible(find.text('أسباب عدم الدخول'));
    await tester.tap(find.text('أسباب عدم الدخول'));
    await tester.pumpAndSettle();
    final noEntryOption = find.byKey(
      const ValueKey('no-entry-fearRepeatLossAfterLoss'),
    );
    expect(
      tester.widget<Text>(find.descendant(
        of: noEntryOption,
        matching: find.byType(Text),
      )).style?.fontSize,
      14.5,
    );
    await tester.tap(noEntryOption);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-fearRepeatLossAfterLoss')), findsOneWidget);
    expect(find.byType(TradeReviewOptionEmoji), findsNWidgets(25));

    final classify = find.byKey(
      const ValueKey('choose-trade-classification-button'),
    );
    await tester.ensureVisible(classify);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-classification-option-win')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-loss')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-breakEven')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-missed')),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-classification-option-win')),
    );
    await tester.pumpAndSettle();
    expect(classify, findsNothing);

    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.win);
    expect(savedTrade!.effectiveClassification, TradeClassification.win);
    expect(savedTrade!.market, 'NQ');
    expect(savedTrade!.entrySetups, const [
      TradeEntrySetup(reason: 'zoneSd', timeframe: '15MIN'),
      TradeEntrySetup(reason: 'directionalBreakout', timeframe: '2MIN'),
      TradeEntrySetup(reason: 'directionalBreakout', timeframe: '30MIN'),
      TradeEntrySetup(reason: 'RFS', timeframe: '5MIN'),
      TradeEntrySetup(reason: 'SFR', timeframe: '1H'),
    ]);
    expect(savedTrade!.confirmationSetups, const [TradeConfirmationSetup(type: 'ارتداد من مستوى يومي', timeframe: '2MIN')]);
    expect(savedTrade!.executionReviewKeys, containsAll(['enteredEarly', 'fullPlanCompliance']));
    expect(savedTrade!.noEntryReasons, ['fearRepeatLossAfterLoss']);
    expect(savedTrade!.expectedLoss, 100);
    expect(savedTrade!.riskPercent, 1);
    expect(savedTrade!.result / savedTrade!.expectedLoss!, closeTo(.425, .001));
  });
}
