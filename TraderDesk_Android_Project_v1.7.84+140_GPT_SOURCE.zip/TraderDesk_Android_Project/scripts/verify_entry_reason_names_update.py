#!/usr/bin/env python3
"""Static regression checks for direction-aware Breakout and Zone S/D labels."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / 'lib/domain/trade_entry_catalog.dart').read_text(encoding='utf-8')
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
DAYS = (ROOT / 'lib/screens/days_screen.dart').read_text(encoding='utf-8')
CHIPS = (ROOT / 'lib/widgets/trade_entry_setup_chips.dart').read_text(encoding='utf-8')
CATALOG_TEST = (ROOT / 'test/trade_entry_catalog_test.dart').read_text(encoding='utf-8')
WIDGET_TEST = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

expected = {
    'Trend Line SELL': 'Trendline Sell 3 Touch',
    'Trend Line BUY': 'Trendline Buy 3 Touch',
    'Trend Line BREAKOUT SELL': 'Trend Line Touch 3 Sell Breakout',
    'Trend Line BREAKOUT BUY': 'Trend Line Touch 3 Buy Breakout',
}
for key, label in expected.items():
    check(f'catalog keeps legacy key {key}', f"'{key}'," in CATALOG)
    check(f'catalog shows new label {label}', label in CATALOG)
    check(f'formatter maps legacy {key}', f"case '{key}':" in CATALOG and f"return '{label}';" in CATALOG)

reason_block = CATALOG.split('const tradeEntryReasons', 1)[1].split('tradeEntryTouch2EligibleReasons', 1)[0]
check('entry reason list has one BREAKOUT row', "TradeEntryOption('directionalBreakout', 'BREAKOUT', 'BREAKOUT')" in reason_block)
check('separate SBR and RBS list rows are absent', "TradeEntryOption('SBR'" not in reason_block and "TradeEntryOption('RBS'" not in reason_block)
check('legacy SBR/RBS values map to the semantic Breakout option when edited', "base == 'SBR' || base == 'RBS'" in CATALOG and "return 'directionalBreakout';" in CATALOG)
check('BUY displays RBS for the semantic Breakout choice', "if (side == TradeSide.buy) return 'RBS';" in CATALOG)
check('SELL displays SBR for the semantic Breakout choice', "if (side == TradeSide.sell) return 'SBR';" in CATALOG)
check('no-direction fallback remains BREAKOUT', "return 'BREAKOUT';" in CATALOG)
check('legacy Touch 2 records remain parseable', "const tradeEntryTouch2EligibleReasons = <String>{'SBR', 'RBS'};" in CATALOG and "tradeEntryBaseReason(currentReason)" in FORM)
check('new Breakout flow goes directly to timeframe selection', "if (!tradeEntryTouch2EligibleReasons.contains(baseReason)) return baseReason;" in FORM)
check('add/edit timeframe header receives the resolved scenario', FORM.count("formatTradeEntryReasonLabel(reason: reason, side: _side)") >= 2)
check('selected entry field resolves the label through direction', "label: formatTradeEntryReasonLabel(" in FORM)
check('saved trade details resolve semantic Breakout by direction', "formatTradeEntryReasonLabel(" in TRADES and "side: trade.side" in TRADES)
check('saved entry chips resolve the label by direction', "formatTradeEntryReasonLabel(" in CHIPS and "final TradeSide side;" in CHIPS)
check('day summary resolves semantic Breakout by direction', "formatTradeEntryReasonLabel(" in DAYS and "side: trade.side" in DAYS)
check('catalog tests cover BREAKOUT -> RBS/SBR and legacy selection mapping', all(x in CATALOG_TEST for x in ["'directionalBreakout'", "TradeSide.buy), 'RBS'", "TradeSide.sell), 'SBR'", "tradeEntryReasonSelectionKey('SBR')", "tradeEntryReasonSelectionKey('RBS')"]))
check('widget tests verify BREAKOUT only and direction-aware timeframe context', all(x in WIDGET_TEST for x in ["find.text('BREAKOUT')", "سبب الدخول · RBS", "سبب الدخول · SBR", "RBS 15MIN", "SBR 30MIN"]))
check('entry-reason Zone S/D remains direction-aware', "if (side == TradeSide.buy) return 'Demand Zone';" in CATALOG and "if (side == TradeSide.sell) return 'Supply Zone';" in CATALOG)

check('pubspec version is 1.7.84+140', 'version: 1.7.84+140' in PUBSPEC)
check('workflow metadata is 1.7.84+140', 'TraderDesk 1.7.84+140' in WORKFLOW and 'traderdesk-1.7.84-build140-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.84-build140-arm64-dart-symbols' in WORKFLOW)
check('release notes describe Breakout and Zone S/D', 'BREAKOUT' in RELEASE and 'Zone S/D' in RELEASE and 'RBS' in RELEASE and 'SBR' in RELEASE)
check('build info identifies the exact 1.7.83+139 source', '1.7.83+139' in BUILD_INFO and 'TraderDesk_Android_Project_v1.7.83+139_GPT_SOURCE.zip' in BUILD_INFO)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
