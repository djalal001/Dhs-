import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';

void main() {
  test('includes RFS and SFR as direct timeframe-based entry reasons', () {
    final keys = tradeEntryReasons.map((option) => option.key).toSet();

    expect(keys, containsAll(['SBR', 'RBS', 'RFS', 'SFR']));
    expect(keys, isNot(contains('SBR Touch 2')));
    expect(keys, isNot(contains('RBS Touch 2')));
  });

  test('Touch 2 qualifier is supported only for SBR and RBS', () {
    expect(tradeEntryTouch2EligibleReasons, {'SBR', 'RBS'});
    expect(tradeEntryBaseReason('SBR Touch 2'), 'SBR');
    expect(tradeEntryBaseReason('RBS Touch 2'), 'RBS');
    expect(tradeEntryUsesTouch2('SBR Touch 2'), isTrue);
    expect(tradeEntryUsesTouch2('RBS'), isFalse);
    expect(tradeEntryReasonWithTouch2('SBR', true), 'SBR Touch 2');
    expect(tradeEntryReasonWithTouch2('RBS', false), 'RBS');
    expect(tradeEntryReasonWithTouch2('RFS', true), 'RFS');
    expect(tradeEntryReasonWithTouch2('SFR', true), 'SFR');
  });
}
