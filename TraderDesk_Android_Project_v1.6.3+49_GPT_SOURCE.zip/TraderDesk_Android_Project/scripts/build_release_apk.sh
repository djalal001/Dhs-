#!/usr/bin/env bash
# Build the actual distributable app: one optimized ARM64 Release APK.
# This script changes build outputs only; it does not edit app source or assets.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

command -v flutter >/dev/null 2>&1 || {
  echo "ERROR: Flutter SDK is required. Install the pinned Flutter version from the GitHub workflow." >&2
  exit 1
}

flutter clean
rm -rf build/app/outputs/flutter-apk build/symbols
flutter pub get

# Release = Dart AOT compilation + release optimizations.
# ARM64 target + Gradle abiFilters = one 64-bit ARM APK, not a universal APK.
# Tree-shaken icons remove only unused Material icons.
# Split debug info keeps symbol data outside the installable APK.
flutter build apk \
  --release \
  --target-platform android-arm64 \
  --tree-shake-icons \
  --split-debug-info=build/symbols

APK="build/app/outputs/flutter-apk/app-release.apk"
bash scripts/verify_arm64_apk.sh "$APK"

BYTES="$(stat -c '%s' "$APK")"
DECIMAL_MB="$(awk -v n="$BYTES" 'BEGIN { printf "%.2f", n/1000000 }')"
MIB="$(awk -v n="$BYTES" 'BEGIN { printf "%.2f", n/1048576 }')"
echo "Release APK size: ${BYTES} bytes (${DECIMAL_MB} MB decimal / ${MIB} MiB)"
echo "APK path: $ROOT_DIR/$APK"
