#!/usr/bin/env bash
# Verify that the distributable is one Release APK containing ARM64 only.
# Intentionally does not impose an arbitrary size ceiling.
set -euo pipefail

APK_PATH="${1:-build/app/outputs/flutter-apk/app-release.apk}"
OUTPUT_DIR="$(dirname "$APK_PATH")"

if [[ "$(basename "$APK_PATH")" != "app-release.apk" ]]; then
  echo "ERROR: Only app-release.apk is distributable; do not publish Debug/Profile APKs: $APK_PATH" >&2
  exit 1
fi

if [[ ! -f "$APK_PATH" ]]; then
  echo "ERROR: Expected Release APK was not found: $APK_PATH" >&2
  exit 1
fi

for tool in unzip sha256sum stat; do
  command -v "$tool" >/dev/null 2>&1 || {
    echo "ERROR: Required tool not found: $tool" >&2
    exit 1
  }
done

mapfile -t APK_FILES < <(find "$OUTPUT_DIR" -maxdepth 1 -type f -iname '*.apk' -print | sort)
if [[ "${#APK_FILES[@]}" -ne 1 || "${APK_FILES[0]}" != "$APK_PATH" ]]; then
  echo "ERROR: Expected exactly one APK ($APK_PATH), found ${#APK_FILES[@]}:" >&2
  printf '  %s\n' "${APK_FILES[@]}" >&2
  exit 1
fi

mapfile -t APK_ABIS < <(unzip -Z1 "$APK_PATH" | awk -F/ '$1 == "lib" && NF >= 3 { print $2 }' | sort -u)
if [[ "${#APK_ABIS[@]}" -ne 1 || "${APK_ABIS[0]}" != "arm64-v8a" ]]; then
  echo "ERROR: APK must contain ARM64 libraries only. Found ABI directories:" >&2
  printf '  %s\n' "${APK_ABIS[@]:-<none>}" >&2
  exit 1
fi

APK_ENTRIES="$(unzip -Z1 "$APK_PATH")"
for REQUIRED_ENTRY in 'lib/arm64-v8a/libapp.so' 'lib/arm64-v8a/libflutter.so'; do
  if ! grep -Fqx "$REQUIRED_ENTRY" <<< "$APK_ENTRIES"; then
    echo "ERROR: Required ARM64 Flutter library is missing: $REQUIRED_ENTRY" >&2
    exit 1
  fi
done

APK_BYTES="$(stat -c '%s' "$APK_PATH")"
echo "OK: one Release APK, ARM64 (arm64-v8a) only."
echo "Exact size: ${APK_BYTES} bytes"
echo "Human-readable size: $(du -h "$APK_PATH" | cut -f1)"
sha256sum "$APK_PATH"
