# TraderDesk repository instructions

The user requires the same full application. Do not remove or rewrite any application feature, Dart source, model, storage behavior, localization, UI, test, or required asset to reduce package size.

## For every Android build, follow this exact process

Run:

```bash
bash scripts/build_release_apk.sh
```

This produces exactly:

```text
build/app/outputs/flutter-apk/app-release.apk
```

The build is **Release**, optimized by Flutter's AOT compiler, and targets **arm64-v8a only**. It also tree-shakes unused Material icons and stores Dart symbol information outside the APK under `build/symbols`.

Never use `flutter run`, `assembleDebug`, `flutter build apk --debug`, or any command that creates a `*-debug.apk` as the distributable. Never use `--split-per-abi` / `--splits-per-abi`; never build or publish `armeabi-v7a`, `x86`, or `x86_64` variants. Preserve the ARM64 ABI filter and non-ARM64 JNI exclusions in `android/app/build.gradle.kts`.

Do not add a 30 MB (or other arbitrary) hard failure threshold. Report the actual APK size. If a Release build is still unexpectedly large, create a diagnostic build with `flutter build apk --release --target-platform android-arm64 --analyze-size`, inspect its JSON breakdown, and explain the dominant components before proposing any application-content change.

The GitHub Actions workflow runs the same official build script. On a `v*` tag, publish only `app-release.apk`; keep Dart symbols as a separate private workflow artifact.
