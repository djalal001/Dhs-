# تعليمات البناء المعتمدة — نفس التطبيق، Release ARM64 واحدة

## الهدف

إنتاج نسخة تثبيت واحدة من **التطبيق الكامل نفسه**، دون حذف ميزات أو تغيير واجهة أو بيانات أو موارد التطبيق لمجرد خفض الحجم.

## السبب الذي عالجناه

ملف GitHub الذي ظهر في الصورة اسمه `...debug.apk`. هذا ناتج بناء تطوير، وليس نسخة توزيع. بناء Debug يحتفظ بأدوات التصحيح وبيئة التطوير ويكون أكبر بكثير. لا تستخدم `flutter run` أو `assembleDebug` للحصول على ملف التسليم.

يوجد في سجل مشروع الإصدار السابق `1.5.8+44` قياس بناء Release ARM64 بلغ **24.5 MB**. هذا قياس تاريخي لنفس خط التطبيق، وليس وعداً بحجم ثابت للإصدار الحالي؛ يجب قراءة الحجم الفعلي الذي يطبعه Workflow بعد البناء.

## أمر البناء الوحيد

```bash
bash scripts/build_release_apk.sh
```

ينفذ السكربت:

```bash
flutter clean
flutter pub get
flutter build apk --release --target-platform android-arm64 --tree-shake-icons --split-debug-info=build/symbols
bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk
```

الناتج:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## لماذا هذا لا يغيّر التطبيق؟

- `--release`: يبني نسخة AOT محسّنة للتشغيل والتوزيع، بدلاً من أدوات Debug.
- `--target-platform android-arm64`: يحصر المكتبات الأصلية في `arm64-v8a`.
- `--tree-shake-icons`: يزيل أيقونات Material غير المستخدمة فقط.
- `--split-debug-info`: يضع رموز تشخيص Dart خارج APK؛ يرفعها Workflow منفصلة كي يمكن تحليل الأعطال لاحقاً.
- تبقى ملفات `lib/` و`assets/` ومنطق التطبيق والبيانات كما هي.

## ممنوعات

- `flutter build apk --debug` أو `assembleDebug` أو نشر أي ملف `*-debug.apk`.
- `--split-per-abi` أو `--splits-per-abi`.
- تضمين `armeabi-v7a` أو `x86` أو `x86_64`.
- حذف الصور أو الخطوط أو الأكواد أو الوظائف للوصول إلى رقم حجمي اعتباطي.
- فرض سقف 30 MB أو أي سقف آخر يجعل عملية البناء تفشل بدلاً من تشخيص السبب.

## التحقق وقياس الحجم

```bash
bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk
```

يتأكد التحقق من أن الملف Release واحد وأن مكتباته تخص ARM64 فقط، ثم يطبع الحجم الفعلي بالبايت وMB وMiB وبصمة SHA-256. لا يوجد حد حجم يفشل البناء.

إذا كانت نسخة Release الفعلية كبيرة على نحو غير متوقع، نفّذ تحليلاً تشخيصياً منفصلاً:

```bash
flutter build apk --release --target-platform android-arm64 --analyze-size
```

ثم استخدم ملف `*-code-size-analysis_*.json` الناتج في Flutter DevTools App Size، وحدد أولاً هل الحجم من محرك Flutter أو كود Dart أو مكتبات Android أو الأصول. لا تغيّر موارد التطبيق قبل وجود دليل من التقرير.
