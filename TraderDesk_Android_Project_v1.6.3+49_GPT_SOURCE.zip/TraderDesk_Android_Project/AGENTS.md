# Mandatory TraderDesk build rules

Before changing build configuration or generating an Android package, read this file and `BUILD_INSTRUCTIONS_AR.md`.

## Preserve the application

- Do not edit `lib/`, `assets/`, app models, business logic, storage formats, localization, UI, or tests merely to change APK size.
- The requested output is the same TraderDesk application, not a reduced-feature edition.
- Package-size work must be done through the build mode, target ABI, compiler/linker optimizations, and exclusion of build-only symbols—not by deleting application features or required assets.

## Android build policy

- The only supported and distributable Android ABI is `arm64-v8a`.
- Produce exactly one APK: `build/app/outputs/flutter-apk/app-release.apk`.
- Use the official build script: `bash scripts/build_release_apk.sh`.
- The script runs `flutter build apk --release --target-platform android-arm64 --tree-shake-icons --split-debug-info=build/symbols`.
- Never use `flutter run` as the distribution build, `assembleDebug`, `flutter build apk --debug`, or publish any `*-debug.apk`.
- Never pass `--split-per-abi` or `--splits-per-abi`; do not build `armeabi-v7a`, `x86`, or `x86_64` variants.
- Keep `android/app/build.gradle.kts` `defaultConfig.ndk.abiFilters` restricted to `arm64-v8a` and retain the non-ARM64 JNI exclusions.
- Do not create a universal/multi-ABI APK or an AAB instead of the requested ARM64 APK.
- Do not introduce an arbitrary APK size ceiling that fails a valid build. Always report the actual output size. If it is unexpectedly large, inspect a Flutter `--analyze-size` report before proposing app or asset changes.
- Upload/publish only the verified `app-release.apk`. Keep `build/symbols` separate from the installable APK.

## Exact build behavior

A Debug APK is only for development and hot reload. It is not the deliverable. Release uses Flutter's optimized AOT build. Preserve the same Dart application and packaged assets; the build system must produce the Release APK rather than changing the application to force a smaller file.
