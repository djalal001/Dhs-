import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/main.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/state/app_controller.dart';

void main() {
  late Directory temp;
  late AppController app;
  late TradingAccount account;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp(
      'trader_desk_trades_filter_',
    );
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    account = TradingAccount(
      id: 'trades-filter-account',
      name: 'Filter account',
      type: AccountType.demo,
      startingBalance: 10000,
      currency: 'USD',
      createdAt: DateTime(2024, 1, 1),
    );
    app.accounts = [account];
    app.selectedAccountId = account.id;
    app.trades = [
      _trade(id: 'winner', result: 25),
      _trade(id: 'loser', result: -12),
      // A grey/neutral card with an entirely empty result-and-risk record.
      _trade(
        id: 'missed-empty-grey',
        result: 0,
        classification: TradeClassification.missed,
        riskPercent: 0,
        expectedLoss: 0,
      ),
      // The card remains grey when risk metadata exists. The Missed filter
      // must match the displayed card outcome, not apply a second rule.
      _trade(
        id: 'neutral-with-risk',
        result: 0,
        classification: TradeClassification.breakEven,
        riskPercent: 0.25,
        expectedLoss: 25,
      ),
      // Empty risk alone is not enough when a profit or loss is recorded.
      _trade(
        id: 'profit-without-risk',
        result: 7,
        riskPercent: 0,
        expectedLoss: null,
      ),
      _trade(
        id: 'loss-without-risk',
        result: -3,
        riskPercent: 0,
        expectedLoss: null,
      ),
      // Review selections do not change a positive-result card's category.
      _trade(
        id: 'executed-with-review-flags',
        result: 9,
        riskPercent: 0.2,
        expectedLoss: 20,
        noEntryReasons: const ['fearLossNoHistory'],
        executionStatuses: const [TradeExecutionStatus.avoidedEntryBecauseFear],
        executionReviewKeys: const ['noBreakoutPositiveClose'],
      ),
    ];
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(390, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }

  Future<void> openTrades(WidgetTester tester) async {
    await tester.pumpWidget(TraderDeskApp(controller: app));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الصفقات').last);
    await tester.pumpAndSettle();
  }

  Future<void> expectFilterLabel(
    WidgetTester tester,
    String key,
    String label,
    String count,
  ) async {
    final chip = find.byKey(ValueKey(key));
    await tester.ensureVisible(chip);
    expect(
      find.descendant(of: chip, matching: find.text(label)),
      findsOneWidget,
    );
    expect(
      find.descendant(of: chip, matching: find.text(count)),
      findsOneWidget,
    );
    expect(
      find.descendant(of: chip, matching: find.textContaining('(')),
      findsNothing,
    );
  }

  testWidgets(
    'five compact category filters and period selector stay visible without horizontal scrolling',
    (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await openTrades(tester);

      final filterKeys = [
        'trades-filter-all',
        'trades-filter-wins',
        'trades-filter-losses',
        'trades-filter-break-even',
        'trades-filter-missed',
        'trades-period-selector',
      ];
      final row = find.byKey(const ValueKey('trades-filter-row'));
      final rowRect = tester.getRect(row);
      expect(rowRect.left, greaterThanOrEqualTo(0));
      expect(rowRect.right, lessThanOrEqualTo(360));

      for (final key in filterKeys) {
        expect(
          find.descendant(of: row, matching: find.byKey(ValueKey(key))),
          findsOneWidget,
        );
      }
      expect(
        find.descendant(of: row, matching: find.byType(Scrollable)),
        findsNothing,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('break-even and missed filters separate zero-result records', (
    tester,
  ) async {
    usePhoneViewport(tester);
    await openTrades(tester);

    expect(find.byKey(const ValueKey('trades-filter-all')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-wins')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-losses')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-break-even')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-missed')), findsOneWidget);
    await expectFilterLabel(tester, 'trades-filter-wins', 'رابحة', '3');
    await expectFilterLabel(tester, 'trades-filter-losses', 'خاسرة', '2');
    await expectFilterLabel(tester, 'trades-filter-break-even', 'تعادل', '1');
    await expectFilterLabel(tester, 'trades-filter-missed', 'ضائعة', '1');

    await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-summary-missed-empty-grey')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-neutral-with-risk')),
      findsNothing,
    );
    for (final excludedId in [
      'winner',
      'loser',
      'profit-without-risk',
      'loss-without-risk',
      'executed-with-review-flags',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$excludedId')), findsNothing);
    }

    await tester.tap(find.byKey(const ValueKey('trades-filter-break-even')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-neutral-with-risk')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed-empty-grey')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('trades-filter-wins')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-summary-winner')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-empty-grey')),
      findsNothing,
    );

    await tester.tap(find.byKey(const ValueKey('trades-filter-losses')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-summary-loser')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-empty-grey')),
      findsNothing,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('19 grey zero-result cards are all counted as missed', (
    tester,
  ) async {
    usePhoneViewport(tester);
    app.trades = List.generate(
      19,
      (index) => _trade(
        id: 'grey-missed-${index.toString().padLeft(2, "0")}',
        result: 0,
        classification: TradeClassification.missed,
        riskPercent: index < 11 ? 0 : 0.25,
        expectedLoss: index < 11 ? 0 : 25,
      ),
    );
    await openTrades(tester);
    await expectFilterLabel(tester, 'trades-filter-all', 'الكل', '19');
    await expectFilterLabel(tester, 'trades-filter-wins', 'رابحة', '0');
    await expectFilterLabel(tester, 'trades-filter-losses', 'خاسرة', '0');
    await expectFilterLabel(tester, 'trades-filter-break-even', 'تعادل', '0');
    await expectFilterLabel(tester, 'trades-filter-missed', 'ضائعة', '19');

    await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
    await tester.pumpAndSettle();
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trades-filter-missed')),
        matching: find.text('19'),
      ),
      findsOneWidget,
    );
    await tester.drag(
      find.byKey(const ValueKey('trades-list')),
      const Offset(0, -6000),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-summary-grey-missed-00')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'one selected period filters All, Wins, Losses, Break-even and Missed together',
    (tester) async {
      usePhoneViewport(tester);
      final today = DateTime.now();
      app.trades = [
        _trade(id: 'recent-win', result: 12, tradedAt: today),
        _trade(
          id: 'old-win',
          result: 18,
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(
          id: 'recent-loss',
          result: -8,
          tradedAt: today.subtract(const Duration(days: 1)),
        ),
        _trade(
          id: 'old-loss',
          result: -5,
          tradedAt: DateTime(2020, 1, 4),
        ),
        _trade(
          id: 'recent-missed',
          result: 0,
          classification: TradeClassification.missed,
          riskPercent: 0,
          expectedLoss: null,
          noEntryReasons: const ['fearLossNoHistory'],
          tradedAt: today.subtract(const Duration(days: 2)),
        ),
        _trade(
          id: 'old-missed-journal',
          result: 0,
          classification: TradeClassification.missed,
          riskPercent: 0,
          expectedLoss: null,
          executionStatuses: const [
            TradeExecutionStatus.missedHigherTimeframeBounceArea,
          ],
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(
          id: 'mid-month-win-missed-key',
          result: 5,
          executionReviewKeys: const ['noTrendlineSupportsEntryZone'],
          tradedAt: today.subtract(const Duration(days: 15)),
        ),
        _trade(
          id: 'exactly-seven-days-old-loss',
          result: -4,
          tradedAt: today.subtract(const Duration(days: 7)),
        ),
      ];
      await openTrades(tester);

      final periodMenu = find.byKey(const ValueKey('trades-period-menu'));
      await tester.ensureVisible(periodMenu);
      await tester.tap(periodMenu);
      await tester.pumpAndSettle();
      for (final period in ['all', 'week', 'month', 'year', 'custom']) {
        expect(find.byKey(ValueKey('trades-period-$period')), findsOneWidget);
      }

      // Choosing a date range does not force a category; it is shared by
      // whichever category the trader selects next.
      await tester.tap(find.byKey(const ValueKey('trades-period-week')));
      await tester.pumpAndSettle();
      // The numbers shown on every category chip and the cards in each list
      // come from the same seven-calendar-day data set.
      await expectFilterLabel(tester, 'trades-filter-all', 'الكل', '3');
      await expectFilterLabel(tester, 'trades-filter-wins', 'رابحة', '1');
      await expectFilterLabel(tester, 'trades-filter-losses', 'خاسرة', '1');
      await expectFilterLabel(tester, 'trades-filter-break-even', 'تعادل', '0');
      await expectFilterLabel(tester, 'trades-filter-missed', 'ضائعة', '1');
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-net-profit-metric')),
          matching: find.text('USD 4.00'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-win-rate-metric')),
          matching: find.text('50.0%'),
        ),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trades-filter-all')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-win')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-win')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-loss')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-loss')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-missed-journal')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-exactly-seven-days-old-loss')),
        findsNothing,
      );

      // Changing the shared period updates the currently visible category too.
      await tester.tap(find.byKey(const ValueKey('trades-period-menu')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('trades-period-month')));
      await tester.pumpAndSettle();
      await expectFilterLabel(tester, 'trades-filter-all', 'الكل', '5');
      await expectFilterLabel(tester, 'trades-filter-wins', 'رابحة', '2');
      await expectFilterLabel(tester, 'trades-filter-losses', 'خاسرة', '2');
      await expectFilterLabel(tester, 'trades-filter-break-even', 'تعادل', '0');
      await expectFilterLabel(tester, 'trades-filter-missed', 'ضائعة', '1');
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-net-profit-metric')),
          matching: find.text('USD 5.00'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-win-rate-metric')),
          matching: find.text('50.0%'),
        ),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-exactly-seven-days-old-loss')),
        findsOneWidget,
      );

      await tester.tap(find.byKey(const ValueKey('trades-filter-wins')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('trade-summary-recent-win')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-win')), findsNothing);
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsOneWidget,
      );

      await tester.tap(find.byKey(const ValueKey('trades-filter-losses')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('trade-summary-recent-loss')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-loss')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-exactly-seven-days-old-loss')),
        findsOneWidget,
      );

      await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('trade-summary-recent-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-missed-journal')),
        findsNothing,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'floating add button fades while scrolling and becomes clear at rest',
    (tester) async {
      usePhoneViewport(tester);
      app.trades = List.generate(
        24,
        (index) => _trade(
          id: 'scroll-$index',
          result: index.isEven ? 10 : -5,
        ),
      );
      await openTrades(tester);

      final button = find.byKey(const ValueKey('trades-add-floating'));
      final opacity = find.byKey(
        const ValueKey('trades-add-floating-opacity'),
      );
      expect(button, findsOneWidget);
      expect(find.byKey(const ValueKey('trades-list')), findsOneWidget);
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);

      await tester.drag(
        find.byKey(const ValueKey('trades-list')),
        const Offset(0, -380),
      );
      await tester.pump();
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.30);

      await tester.pump(const Duration(milliseconds: 800));
      await tester.pump(const Duration(milliseconds: 200));
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);
      final listRect = tester.getRect(
        find.byKey(const ValueKey('trades-list')),
      );
      final navRect = tester.getRect(
        find.byKey(const ValueKey('td-bottom-navigation')),
      );
      final fabRect = tester.getRect(button);
      expect(listRect.bottom, closeTo(navRect.top, 1));
      expect(fabRect.left, lessThan(listRect.left + 60));
      expect(fabRect.bottom, lessThanOrEqualTo(listRect.bottom));
      expect(tester.takeException(), isNull);
    },
  );
}

Trade _trade({
  required String id,
  required double result,
  List<String> noEntryReasons = const [],
  List<TradeExecutionStatus> executionStatuses = const [],
  List<String> executionReviewKeys = const [],
  TradeClassification? classification,
  double riskPercent = 0.25,
  double? expectedLoss = 25,
  DateTime? tradedAt,
}) => Trade(
  id: id,
  accountId: 'trades-filter-account',
  market: 'EURUSD',
  reason: 'Breakout',
  result: result,
  riskPercent: riskPercent,
  expectedLoss: expectedLoss,
  side: TradeSide.buy,
  confirmation: 'confirmTechnical',
  sequence: '',
  mood: 'moodCalm',
  tradedAt: tradedAt ?? DateTime(2024, 1, 1),
  noEntryReasons: noEntryReasons,
  executionReviewKeys: executionReviewKeys,
  classification: classification,
  executionJournal: executionStatuses
      .map((status) => TradeExecutionJournalEntry(status: status))
      .toList(growable: false),
);
