#!/usr/bin/env python3
"""Static checks for TraderDesk 1.7.111+167 trade workspace tabs."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
form = (root / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
pubspec = (root / "pubspec.yaml").read_text(encoding="utf-8")
checks = {
    "release is 1.7.111+167": "version: 1.7.111+167" in pubspec,
    "workspace has horizontal tabs": "trade-workspace-tabs" in form and "for (var i = 0; i < tabs.length; i++)" in form,
    "workspace has exactly three categories": all(x in form for x in ["بيانات الصفقة", "ظروف الدخول", "سلوك التداول"]),
    "inactive labels use short names": all(x in form for x in ["shortAr: 'بيانات'", "shortAr: 'ظروف'", "shortAr: 'سلوك'"]),
    "active tab expands to original full label": "? _copy(definition.fullAr, definition.fullEn)" in form,
    "existing category icons are retained": all(x in form for x in ["Icons.receipt_long_outlined", "Icons.radar_rounded", "Icons.fact_check_outlined"]),
    "selected state uses restrained tonal fill": "definition.tone.withValues(alpha: isDark ? .19 : .12)" in form,
    "content preserves all three existing builders": all(x in form for x in ["_buildTradeDataCard(context)", "_buildLinkedEntryBehaviorSections(context)", "_buildBehaviorCard(context)"]),
    "state is preserved with IndexedStack": "IndexedStack(" in form and "trade-workspace-content" in form,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{sum(checks.values())}/{len(checks)} checks passed")
if not all(checks.values()): raise SystemExit(1)
