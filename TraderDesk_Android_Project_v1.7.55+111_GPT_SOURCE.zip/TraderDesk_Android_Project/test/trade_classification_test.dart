import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_analytics.dart';
import 'package:trader_desk/models/trade.dart';

Trade _trade({
  required String id,
  required double result,
  TradeClassification? classification,
  List<String> noEntryReasons = const [],
  List<String> executionReviewKeys = const [],
}) => Trade(
  id: id,
  accountId: 'account',
  market: 'US100',
  reason: 'RFS',
  result: result,
  riskPercent: 0,
  side: TradeSide.buy,
  confirmation: 'confirmTechnical',
  sequence: '',
  mood: 'moodCalm',
  tradedAt: DateTime(2026, 1, 1),
  classification: classification,
  noEntryReasons: noEntryReasons,
  executionReviewKeys: executionReviewKeys,
);

void main() {
  group('Trade classification', () {
    test('persists an explicit break-even classification through JSON', () {
      final trade = _trade(
        id: 'break-even',
        result: 0,
        classification: TradeClassification.breakEven,
      );
      final restored = Trade.fromJson(
        Map<String, dynamic>.from(trade.toJson()),
      );
      expect(restored.classification, TradeClassification.breakEven);
      expect(restored.effectiveClassification, TradeClassification.breakEven);
      expect(restored.isExecuted, isTrue);
      expect(restored.isMissed, isFalse);
    });

    test('resolves only unambiguous zero-result legacy records', () {
      expect(
        _trade(id: 'legacy-missed', result: 0, noEntryReasons: const ['fearLossNoHistory'])
            .effectiveClassification,
        TradeClassification.missed,
      );
      expect(
        _trade(id: 'legacy-be', result: 0, executionReviewKeys: const ['breakevenStopToEntry'])
            .effectiveClassification,
        TradeClassification.breakEven,
      );
      expect(
        _trade(id: 'legacy-unknown', result: 0).effectiveClassification,
        isNull,
      );
      expect(
        _trade(
          id: 'legacy-conflict',
          result: 0,
          noEntryReasons: const ['fearLossNoHistory'],
          executionReviewKeys: const ['breakevenStopToEntry'],
        ).effectiveClassification,
        isNull,
      );
    });

    test('rejects a stored classification that conflicts with the result sign', () {
      expect(
        _trade(
          id: 'wrong-win',
          result: -5,
          classification: TradeClassification.win,
        ).effectiveClassification,
        isNull,
      );
      expect(
        _trade(
          id: 'wrong-break-even',
          result: 5,
          classification: TradeClassification.breakEven,
        ).effectiveClassification,
        isNull,
      );
    });

    test('analytics exclude missed and unresolved rows from win rate and equity', () {
      final analytics = TradeAnalytics.calculate([
        _trade(id: 'win', result: 20),
        _trade(id: 'loss', result: -10),
        _trade(id: 'be', result: 0, classification: TradeClassification.breakEven),
        _trade(id: 'missed', result: 0, classification: TradeClassification.missed),
        _trade(id: 'unknown', result: 0),
      ], startingBalance: 100);
      expect(analytics.recordCount, 5);
      expect(analytics.tradeCount, 3);
      expect(analytics.wins, 1);
      expect(analytics.losses, 1);
      expect(analytics.breakEven, 1);
      expect(analytics.missedTradeCount, 1);
      expect(analytics.unclassifiedTradeCount, 1);
      expect(analytics.winRatePercent, closeTo(100 / 3, 1e-9));
      expect(analytics.netProfit, 10);
    });
  });
}
