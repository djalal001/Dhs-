import 'package:flutter/material.dart';

/// A restrained indigo-slate reserved for executed break-even trades.
/// Light and dark variants keep readable contrast on the app's neutral card
/// surfaces and stay distinct from the brighter cyan/blue section accents.
abstract final class TradeOutcomePalette {
  static Color breakEven(Brightness brightness) => brightness == Brightness.dark
      ? const Color(0xFF8994B4)
      : const Color(0xFF65708D);
}
