$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot '..\src\TradeEntryChecklist\TradeEntryChecklist.csproj'
$publishDir = Join-Path $PSScriptRoot '..\artifacts\publish'
$zipPath = Join-Path $PSScriptRoot '..\artifacts\TradeEntryChecklist_Windows_x64.zip'

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'The .NET 10 SDK is required. Install it before running this script.'
}

$version = (& dotnet --version).Trim()
if ([version]$version -lt [version]'10.0.100') {
    throw "This project targets .NET 10. The detected SDK is $version."
}

if (Test-Path $publishDir) { Remove-Item $publishDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $publishDir | Out-Null
& dotnet publish $project -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -o $publishDir

if ($LASTEXITCODE -ne 0) { throw 'dotnet publish failed.' }

$artifactDir = Split-Path $zipPath -Parent
New-Item -ItemType Directory -Force -Path $artifactDir | Out-Null
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path (Join-Path $publishDir '*') -DestinationPath $zipPath -Force
Write-Host "Created: $zipPath"
