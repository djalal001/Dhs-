using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using TradeEntryChecklist.Models;

namespace TradeEntryChecklist;

public partial class MainWindow : Window
{
    private readonly string _settingsFile = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "TradeEntryChecklist",
        "settings.json");

    private bool _isUpdating;
    private bool _reviewConfirmed;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        RestoreWindowSettings();
        UpdateChecklistUi();
        Activate();
    }

    private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.LeftButton == MouseButtonState.Pressed)
        {
            try
            {
                DragMove();
            }
            catch (InvalidOperationException)
            {
                // The mouse can be released between the state check and DragMove.
            }
        }
    }

    private void PinToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (PinToggle is null)
        {
            return;
        }

        Topmost = PinToggle.IsChecked == true;
        if (Topmost && IsLoaded)
        {
            Activate();
        }
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void ZoneSelection_Changed(object sender, RoutedEventArgs e)
    {
        if (_isUpdating || !IsLoaded)
        {
            return;
        }

        // A different region requires the user to re-check the trendline relationship.
        _isUpdating = true;
        TrendlineReviewed.IsChecked = false;
        _isUpdating = false;

        string zone = GetSelectedZoneName();
        ZoneHint.Text = string.IsNullOrWhiteSpace(zone)
            ? "اختر المنطقة أولاً، ثم أكّد أنك تحققت من التوافق."
            : $"المنطقة المحددة: {zone}. تحقّق من التوافق قبل وضع علامة الفحص.";

        InvalidateFinalConfirmation();
        UpdateChecklistUi();
    }

    private void ChecklistItem_Changed(object sender, RoutedEventArgs e)
    {
        if (_isUpdating || !IsLoaded)
        {
            return;
        }

        if (TrendlineReviewed.IsChecked == true && string.IsNullOrWhiteSpace(GetSelectedZoneName()))
        {
            _isUpdating = true;
            TrendlineReviewed.IsChecked = false;
            _isUpdating = false;
            ZoneHint.Text = "لا يمكن تأكيد هذا البند قبل اختيار SBR أو RBS أو Supply Zone أو Demand Zone.";
        }

        InvalidateFinalConfirmation();
        UpdateChecklistUi();
    }

    private void ConfirmReviewButton_Click(object sender, RoutedEventArgs e)
    {
        if (GetReviewedCount() != 3)
        {
            return;
        }

        _reviewConfirmed = true;
        ConfirmReviewButton.Content = "تم تأكيد الفحص ✓";
        ConfirmReviewButton.IsEnabled = false;
        ProgressStatusText.Text = "اكتملت مراجعة العناصر الثلاثة";
        ProgressStatusText.Foreground = (Brush)FindResource("SuccessBrush");
        FooterStatusTitle.Text = "تم تأكيد اكتمال الفحص";
        FooterStatusTitle.Foreground = (Brush)FindResource("SuccessBrush");
        FooterStatusNote.Text = "تمت مراجعة البنود الثلاثة. هذا التأكيد يوثّق الفحص فقط ولا يصدر إشارة تداول.";
        ReviewProgress.Foreground = (Brush)FindResource("SuccessBrush");
    }

    private void ResetButton_Click(object sender, RoutedEventArgs e)
    {
        ResetConfirmPanel.Visibility = Visibility.Visible;
    }

    private void ConfirmReset_Click(object sender, RoutedEventArgs e)
    {
        _isUpdating = true;
        SBRZone.IsChecked = false;
        RBSZone.IsChecked = false;
        SupplyZone.IsChecked = false;
        DemandZone.IsChecked = false;
        TrendlineReviewed.IsChecked = false;
        EngulfingInsideReviewed.IsChecked = false;
        EngulfingNearbyReviewed.IsChecked = false;
        _isUpdating = false;

        ZoneHint.Text = "اختر المنطقة أولاً، ثم أكّد أنك تحققت من التوافق.";
        ResetConfirmPanel.Visibility = Visibility.Collapsed;
        InvalidateFinalConfirmation();
        UpdateChecklistUi();
    }

    private void CancelReset_Click(object sender, RoutedEventArgs e)
    {
        ResetConfirmPanel.Visibility = Visibility.Collapsed;
    }

    private int GetReviewedCount()
    {
        int count = 0;
        if (TrendlineReviewed.IsChecked == true && !string.IsNullOrWhiteSpace(GetSelectedZoneName()))
        {
            count++;
        }

        if (EngulfingInsideReviewed.IsChecked == true)
        {
            count++;
        }

        if (EngulfingNearbyReviewed.IsChecked == true)
        {
            count++;
        }

        return count;
    }

    private string GetSelectedZoneName()
    {
        if (SBRZone.IsChecked == true) return "SBR";
        if (RBSZone.IsChecked == true) return "RBS";
        if (SupplyZone.IsChecked == true) return "Supply Zone";
        if (DemandZone.IsChecked == true) return "Demand Zone";
        return string.Empty;
    }

    private void UpdateChecklistUi()
    {
        if (!IsLoaded)
        {
            return;
        }

        int count = GetReviewedCount();
        ReviewProgress.Value = count;
        ProgressCountText.Text = $"{count} من 3 عناصر تم فحصها";

        SetItemStatus(Item1Status, TrendlineReviewed.IsChecked == true && !string.IsNullOrWhiteSpace(GetSelectedZoneName()));
        SetItemStatus(Item2Status, EngulfingInsideReviewed.IsChecked == true);
        SetItemStatus(Item3Status, EngulfingNearbyReviewed.IsChecked == true);

        bool allReviewed = count == 3;
        ConfirmReviewButton.IsEnabled = allReviewed && !_reviewConfirmed;
        if (!_reviewConfirmed)
        {
            ConfirmReviewButton.Content = "تأكيد اكتمال الفحص";
            ProgressStatusText.Text = allReviewed ? "تمت مراجعة جميع العناصر" : "الفحص لم يكتمل";
            ProgressStatusText.Foreground = (Brush)FindResource("TextPrimaryBrush");
            FooterStatusTitle.Text = allReviewed ? "جميع العناصر تمت مراجعتها" : "أكمل فحص العناصر الثلاثة";
            FooterStatusTitle.Foreground = (Brush)FindResource("TextPrimaryBrush");
            FooterStatusNote.Text = allReviewed
                ? "يمكنك الآن تأكيد اكتمال المراجعة."
                : "اكتمال الفحص لا يعني تلقائياً أن شروط الدخول متحققة. القرار النهائي لك.";
            ReviewProgress.Foreground = (Brush)FindResource("AccentBrush");
        }

        if (TrendlineReviewed.IsChecked != true && string.IsNullOrWhiteSpace(GetSelectedZoneName()))
        {
            ZoneHint.Text = "اختر المنطقة أولاً، ثم أكّد أنك تحققت من التوافق.";
        }
    }

    private static void SetItemStatus(TextBlock status, bool reviewed)
    {
        status.Text = reviewed ? "تم الفحص" : "لم يُفحص";
        status.Foreground = reviewed
            ? new SolidColorBrush(Color.FromRgb(112, 184, 154))
            : new SolidColorBrush(Color.FromRgb(135, 145, 156));
    }

    private void InvalidateFinalConfirmation()
    {
        if (!_reviewConfirmed)
        {
            return;
        }

        _reviewConfirmed = false;
        ConfirmReviewButton.Content = "تأكيد اكتمال الفحص";
        ConfirmReviewButton.IsEnabled = false;
        FooterStatusTitle.Foreground = (Brush)FindResource("TextPrimaryBrush");
        ProgressStatusText.Foreground = (Brush)FindResource("TextPrimaryBrush");
    }

    private void RestoreWindowSettings()
    {
        try
        {
            if (!File.Exists(_settingsFile))
            {
                PinToggle.IsChecked = true;
                Topmost = true;
                return;
            }

            string json = File.ReadAllText(_settingsFile);
            AppSettings? settings = JsonSerializer.Deserialize<AppSettings>(json);
            if (settings is null)
            {
                return;
            }

            if (settings.Width is >= 430 and <= 1000) Width = settings.Width.Value;
            if (settings.Height is >= 540 and <= 1200) Height = settings.Height.Value;

            double minLeft = SystemParameters.VirtualScreenLeft;
            double minTop = SystemParameters.VirtualScreenTop;
            double maxLeft = minLeft + SystemParameters.VirtualScreenWidth - Width;
            double maxTop = minTop + SystemParameters.VirtualScreenHeight - Height;

            if (settings.Left.HasValue && settings.Top.HasValue && maxLeft >= minLeft && maxTop >= minTop)
            {
                Left = Math.Clamp(settings.Left.Value, minLeft, maxLeft);
                Top = Math.Clamp(settings.Top.Value, minTop, maxTop);
                WindowStartupLocation = WindowStartupLocation.Manual;
            }

            PinToggle.IsChecked = settings.AlwaysOnTop;
            Topmost = settings.AlwaysOnTop;
        }
        catch (Exception)
        {
            // Corrupt or inaccessible settings must never prevent the checklist from opening.
            PinToggle.IsChecked = true;
            Topmost = true;
        }
    }

    private void Window_Closed(object? sender, EventArgs e)
    {
        try
        {
            string? directory = Path.GetDirectoryName(_settingsFile);
            if (!string.IsNullOrWhiteSpace(directory))
            {
                Directory.CreateDirectory(directory);
            }

            var settings = new AppSettings
            {
                Left = Left,
                Top = Top,
                Width = Width,
                Height = Height,
                AlwaysOnTop = Topmost
            };

            File.WriteAllText(_settingsFile, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (IOException)
        {
            // Settings are optional; an I/O issue must not interfere with closing the app.
        }
        catch (UnauthorizedAccessException)
        {
            // Settings are optional; an access issue must not interfere with closing the app.
        }
    }
}
