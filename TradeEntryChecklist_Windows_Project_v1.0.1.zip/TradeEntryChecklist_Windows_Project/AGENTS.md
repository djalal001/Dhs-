# Agent instructions

- Preserve the three checklist items and their Arabic wording unless the user explicitly requests a change.
- This is a Windows WPF always-on-top companion window, not a NinjaTrader add-on.
- Do not add trading automation, chart scraping, broker connectivity, indicators, or order placement.
- Keep the visual language restrained and professional: near-black surfaces, subtle borders, muted neutral accents, readable typography, and no cartoon styling or neon glow.
- Keep the window draggable, resizable, and optionally topmost. Do not make it click-through; its controls must remain interactive.
- Never persist checked checklist items or the chosen zone between app sessions. Persist only safe window preferences (position, size, topmost state).
- Changing the selected region must clear the review confirmation for item 1.
- The final confirmation must require all three checklist items to have been reviewed and must not be represented as an automated trade signal.
- Keep the GitHub Actions Windows x64 self-contained publish workflow working.
