# ابدأ من هنا

هذه نسخة مصححة من مشروع **Trade Entry Checklist**.

1. استخدم ملفات هذا الإصدار بدل ملفات الإصدار السابق في مستودع GitHub.
2. تأكد من وجود ملف سير العمل `.github/workflows/build-windows.yml` المرفق بهذا الإصدار، واحذف أي Workflow قديم يحتوي على خطوة `Verify and extract project` أو `Unexpected source archive SHA1`.
3. افتح تبويب **Actions** وشغّل **Build Windows Overlay**.
4. بعد نجاح البناء، نزّل Artifact باسم `TradeEntryChecklist_Windows_x64`.
5. فك ضغطه وشغّل `TradeEntryChecklist.exe` على Windows 64-bit.

**سبب الإصلاح:** لم يعد سير العمل يفحص بصمة SHA1 ثابتة لأرشيف ZIP المصدر. GitHub Actions يأخذ ملفات المشروع مباشرة من المستودع عبر `actions/checkout`، ثم يبنيها باستخدام .NET SDK.

هذا ZIP يحتوي على الشيفرة المصدرية وملفات البناء، وليس ملف EXE جاهزًا.
