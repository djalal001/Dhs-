# Trade Entry Checklist — Windows Overlay

A small, dark, always-on-top Windows checklist window intended to sit beside NinjaTrader.

See [README_AR.md](README_AR.md) for the full Arabic feature guide and build instructions.

- Target: Windows 10/11 x64
- Framework: .NET 10 WPF
- No NinjaTrader API integration or chart-reading logic in this version
- GitHub Actions publishes a self-contained Windows x64 artifact
