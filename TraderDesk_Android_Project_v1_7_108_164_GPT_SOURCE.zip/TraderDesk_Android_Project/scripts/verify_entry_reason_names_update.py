#!/usr/bin/env python3
"""Static regression checks for direction-aware Breakout and Zone S/D labels."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / 'lib/domain/trade_entry_catalog.dart').read_text(encoding='utf-8')
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
DAYS = (ROOT / 'lib/screens/days_screen.dart').read_text(encoding='utf-8')
CHIPS = (ROOT / 'lib/widgets/trade_entry_setup_chips.dart').read_text(encoding='utf-8')
CATALOG_TEST = (ROOT / 'test/trade_entry_catalog_test.dart').read_text(encoding='utf-8')
WIDGET_TEST = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

reason_block = CATALOG.split('const tradeEntryReasons', 1)[1].split('tradeEntryTouch2EligibleReasons', 1)[0]
check('single SFR/RFS option exists', "TradeEntryOption('directionalSfrRfs', 'SFR / RFS', 'SFR / RFS')" in reason_block)
check('BUY resolves combined SFR/RFS to RFS', "case 'directionalSfrRfs':" in CATALOG and "if (side == TradeSide.buy) return 'RFS';" in CATALOG)
check('SELL resolves combined SFR/RFS to SFR', "if (side == TradeSide.sell) return 'SFR';" in CATALOG)
check('separate SFR and RFS rows are absent', "TradeEntryOption('RFS'" not in reason_block and "TradeEntryOption('SFR'" not in reason_block)

check('one generic Trendline Touch 3 row exists', "TradeEntryOption(\n    'directionalTrendlineTouch3',\n    'Trendline Touch 3',\n    'Trendline Touch 3',\n  )" in reason_block)
check('BUY resolves generic Trendline Touch 3 to Buy', "if (side == TradeSide.buy) return 'Trendline Touch 3 Buy';" in CATALOG)
check('SELL resolves generic Trendline Touch 3 to Sell', "if (side == TradeSide.sell) return 'Trendline Touch 3 Sell';" in CATALOG)
check('old separate Trendline Touch 3 keys map to one picker row', all(x in CATALOG for x in ["'Trend Line SELL'", "'Trend Line BUY'", "return 'directionalTrendlineTouch3';"]))

check('one generic Trendline Touch 3 Breakout row exists', "TradeEntryOption(\n    'directionalTrendlineTouch3Breakout',\n    'Trend Line Touch 3 Breakout',\n    'Trend Line Touch 3 Breakout',\n  )" in reason_block)
check('BUY resolves to Sell Breakout as specified', "if (side == TradeSide.buy) return 'Trend Line Touch 3 Sell Breakout';" in CATALOG)
check('SELL resolves to Buy Breakout as specified', "if (side == TradeSide.sell) return 'Trend Line Touch 3 Buy Breakout';" in CATALOG)
check('legacy Trendline breakout records migrate to one picker row', all(x in CATALOG for x in ["'Trend Line BREAKOUT SELL'", "'Trend Line BREAKOUT BUY'", "return 'directionalTrendlineTouch3Breakout';"]))

check('one direction-aware BREAKOUT row remains', "TradeEntryOption('directionalBreakout', 'BREAKOUT', 'BREAKOUT')" in reason_block)
check('legacy SBR/RBS map to semantic BREAKOUT', "base == 'SBR'" in CATALOG and "base == 'RBS'" in CATALOG and "return 'directionalBreakout';" in CATALOG)
check('BREAKOUT invokes optional Touch 2 chooser while other reasons bypass it', "final isDirectionalBreakout = baseReason == 'directionalBreakout';" in FORM and "return tradeEntryReasonWithTouch2(baseReason, touch2);" in FORM)
check('selected entry field formats direction-aware label', "formatTradeEntryReasonLabel(" in FORM and "side: _side" in FORM)
check('add/edit duplicate checks compare merged semantic rows to prevent duplicate SFR/RFS or Trendline equivalents', '_hasEquivalentEntrySetup' in FORM and 'tradeEntryReasonSelectionKey(entry.value.reason)' in FORM)
check('saved surfaces format semantic labels using trade side', all(all(x in text for x in ["formatTradeEntryReasonLabel(", "side: trade.side"]) for text in [TRADES, DAYS]))
check('chips format semantic labels using trade side', "formatTradeEntryReasonLabel(" in CHIPS and "required this.side" in CHIPS)
check('catalog tests cover the three new semantic options', all(x in CATALOG_TEST for x in ['directionalSfrRfs', 'directionalTrendlineTouch3', 'directionalTrendlineTouch3Breakout']))
check('widget test covers BUY/SELL transitions for new options', all(x in WIDGET_TEST for x in ["SFR / RFS", "Trendline Touch 3", "Trend Line Touch 3 Breakout", "Trendline Touch 3 Sell 30MIN", "Trendline Touch 3 Buy 30MIN", "Trend Line Touch 3 Sell Breakout 4H", "Trend Line Touch 3 Buy Breakout 4H"]))

check('entry-reason Zone S/D remains direction-aware', "if (side == TradeSide.buy) return 'Demand Zone';" in CATALOG and "if (side == TradeSide.sell) return 'Supply Zone';" in CATALOG)

check('pubspec version is 1.7.108+164', 'version: 1.7.108+164' in PUBSPEC)
check('workflow metadata is 1.7.108+164', 'TraderDesk 1.7.108+164' in WORKFLOW and 'traderdesk-1.7.108-build164-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.108-build164-arm64-dart-symbols' in WORKFLOW)
check('release notes describe Breakout and Zone S/D', 'BREAKOUT' in RELEASE and 'Zone S/D' in RELEASE and 'RBS' in RELEASE and 'SBR' in RELEASE)
check('build info identifies the exact 1.7.97+153 parent source', '1.7.108+164' in BUILD_INFO and 'TraderDesk_Android_Project_v1.7.99+155_GPT_SOURCE.zip' in BUILD_INFO)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
