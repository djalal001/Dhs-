import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../domain/trade_entry_catalog.dart';
import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../models/trading_account.dart';
import '../state/app_controller.dart';
import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../theme/trade_detail_palette.dart';
import '../theme/trade_outcome_palette.dart';
import '../widgets/common.dart';
import '../widgets/decision_option_emoji.dart';
import '../widgets/trade_decision_zones.dart';
import '../widgets/trade_no_entry_zones.dart';

enum _TradeImageSlot { before, after, confirmation }

// Market / Direction and Mindset are intentionally equal-height companion fields.
const double _tradeDataControlHeight = 72;
// Inner content height shared by Market / Direction and Mindset. An
// InputDecorator paints its outline from its CONTENT height (the outer 72dp
// box only reserves space), so both companion fields must hold content of the
// same height for their visible rectangles to be identical.
const double _tradeDataContentHeight = 30;
// Flutter scales a floating InputDecorator label to 75% of its configured size.
// 17.5dp therefore renders at about 13.1dp: readable without competing with
// the selected value or changing the inline/empty-state label size.
const double _tradeFieldLabelFontSize = 14;
const double _tradeFloatingLabelFontSize = 17.5;
// One consistent size for selected values and all trade-data popup rows.
const double _tradeDataItemFontSize = 14.5;

/// Minimum width of the Symbol / Direction popups. Their fields are only about
/// a quarter of the screen wide, which cut «SELL» down to «S…».
const double _shortChoiceMenuWidth = 104;

// Muted, product-grade tones inspired by the Windows trade-entry panels.
const _resultTone = Color(0xFF9BA9B9);
const _dataTone = Color(0xFF76AEE8);
const _imagesTone = Color(0xFF9AA3AD);
const _behaviorTone = Color(0xFFB7A2EC);
const _decisionTone = Color(0xFFC6A071);
const _commitmentTone = Color(0xFF55C99A);
const _noEntryTone = Color(0xFFB69AF0);
const _entryConditionsTone = Color(0xFF78AFC3);
const _reverseSignalsTone = Color(0xFF6E9FB6);

/// Single source for the Entry Conditions surface tint. The timeframe / choice
/// popups of this section and the Opposing signals and Bounce area fields use
/// the same blend, so a field reads as the closed state of its own popup.
Color _entryConditionsSurface({
  required TdTokens tokens,
  required Color tone,
  required Brightness brightness,
}) => Color.alphaBlend(
  tone.withValues(alpha: brightness == Brightness.dark ? .14 : .08),
  tokens.surface2,
);

/// Draws the relationship in a dedicated side gutter, never over card content.
/// Only the short connector ticks meet the card edge; the vertical rail stays
/// entirely outside the interactive surfaces.
class _LinkedSectionConnectorPainter extends CustomPainter {
  const _LinkedSectionConnectorPainter({
    required this.hostKey,
    required this.fromKey,
    required this.toKey,
    required this.color,
    required this.textDirection,
  });

  final GlobalKey hostKey;
  final GlobalKey fromKey;
  final GlobalKey toKey;
  final Color color;
  final TextDirection textDirection;

  double? _centerYInHost(GlobalKey key, RenderBox host) {
    final renderObject = key.currentContext?.findRenderObject();
    if (renderObject is! RenderBox || !renderObject.hasSize || !host.hasSize) {
      return null;
    }
    final globalCenter = renderObject.localToGlobal(
      Offset(renderObject.size.width / 2, renderObject.size.height / 2),
    );
    return host.globalToLocal(globalCenter).dy;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final hostObject = hostKey.currentContext?.findRenderObject();
    if (hostObject is! RenderBox || !hostObject.hasSize || size.isEmpty) return;

    final fromY = _centerYInHost(fromKey, hostObject);
    final toY = _centerYInHost(toKey, hostObject);
    if (fromY == null || toY == null) return;

    final top = fromY < toY ? fromY : toY;
    final bottom = fromY < toY ? toY : fromY;
    if (bottom - top < 8 || top < 0 || bottom > size.height) return;

    // The rail is centered in its own reserved gutter. It is not painted over
    // either card, and the small horizontal ticks stop at the card boundary.
    final railX = size.width / 2;
    final cardEdgeX = textDirection == TextDirection.rtl ? 0.0 : size.width;
    final railPaint = Paint()
      ..color = color.withValues(alpha: .62)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    final tickPaint = Paint()
      ..color = color.withValues(alpha: .48)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(Offset(railX, top), Offset(railX, bottom), railPaint);
    canvas
      ..drawLine(Offset(cardEdgeX, fromY), Offset(railX, fromY), tickPaint)
      ..drawLine(Offset(cardEdgeX, toY), Offset(railX, toY), tickPaint);
  }

  @override
  bool shouldRepaint(covariant _LinkedSectionConnectorPainter oldDelegate) =>
      true;
}

class TradeFormScreen extends StatefulWidget {
  const TradeFormScreen({super.key, this.trade});
  final Trade? trade;

  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _anchorMenuAnchorKey = GlobalKey();
  final _marketPopupAnchorKey = GlobalKey();
  final _directionPopupAnchorKey = GlobalKey();
  final _moodPopupAnchorKey = GlobalKey();
  final _linkedSectionsRailKey =
      GlobalKey(debugLabel: 'linked-entry-sections-side-rail');
  final _reverseSignalConnectorAnchorKey =
      GlobalKey(debugLabel: 'reverse-signal-connector-anchor');
  final _noEntryConnectorAnchorKey =
      GlobalKey(debugLabel: 'no-entry-connector-anchor');
  final _bounceZoneFieldAnchorKey =
      GlobalKey(debugLabel: 'bounce-zone-field-anchor');
  // Marks the bottom action slot (save button / break-even type prompt). The
  // break-even type popup is anchored to this exact slot.
  final _saveSlotKey = GlobalKey(debugLabel: 'trade-save-slot');
  bool _breakEvenPopupOpen = false;
  late final TextEditingController _result;
  late final TextEditingController _expectedLoss;
  late final TextEditingController _risk;
  late final TextEditingController _rewardRisk;
  final FocusNode _resultFocusNode = FocusNode();
  late String _accountId;
  String? _symbol;
  TradeSide? _side;
  late Set<String> _anchors;
  late Map<String, String> _anchorTimeframes;
  late String _mood;
  late DateTime _tradedAt;
  late List<TradeEntrySetup> _entrySetups;
  late List<TradeConfirmationSetup> _confirmationSetups;
  late List<TradeEntryConditionSetup> _reverseSignalSetups;
  late List<TradeEntryConditionSetup> _bounceZoneSetups;
  late Set<String> _executionReviewKeys;
  // Decisions area UI state: open zone and whether the analysis list is folded.
  int _decisionZoneIndex = 0;
  bool _decisionAnalysisCollapsed = false;
  int _noEntryZoneIndex = 0;
  Set<String> _noEntryCollapsedZones = <String>{};
  late Set<String> _noEntryReasons;
  late List<TradeEntryConditionSetup> _practicalNoEntryReverseSignalSetups;
  TradeClassification? _classification;
  MissedTradeOutcome? _missedOutcome;
  BreakEvenType? _breakEvenType;
  /// +1 means a positive result, -1 means a negative result. Null represents
  /// a zero-result / missed setup until the trader explicitly chooses a sign.
  int? _resultSign;
  bool _showResultSignChoices = false;
  String? _beforePath;
  String? _afterPath;
  String? _confirmationImagePath;
  bool _busy = false;
  bool _seededExpectedLoss = false;
  final _picker = ImagePicker();

  bool get _ar => AppStrings.isArabic(context);
  String _copy(String ar, String en) => _ar ? ar : en;
  bool get _hasTradeDirection => _side != null;
  bool get _hasPracticalNoEntryReason =>
      _practicalNoEntryReverseSignalSetups.any(_reverseSignalSetups.contains);
  bool get _hasEntryConditionsNoEntryLink =>
      _noEntryReasons.isNotEmpty || _hasPracticalNoEntryReason;
  // Keep the established contextual accent for the opposing-signal picker;
  // the outer Entry Conditions card and its connector use the separate
  // practical long-press state below.
  Color get _currentReverseSignalTone =>
      _hasEntryConditionsNoEntryLink ? _noEntryTone : _reverseSignalsTone;

  List<TradeClassification> get _availableClassifications {
    if (_hasEntryConditionsNoEntryLink) {
      return const [TradeClassification.missed];
    }
    if (_resultSign == 1) return const [TradeClassification.win];
    if (_resultSign == -1) return const [TradeClassification.loss];
    return const [
      TradeClassification.breakEven,
      TradeClassification.missed,
    ];
  }

  @override
  void initState() {
    super.initState();
    final trade = widget.trade;
    _symbol = trade?.market.isNotEmpty == true ? trade!.market : null;
    _resultSign = trade == null || trade.result == 0
        ? null
        : trade.result > 0
            ? 1
            : -1;
    _result = TextEditingController(
      text: trade == null || trade.result == 0
          ? ''
          : '${trade.result > 0 ? '+' : '−'}${trade.result.abs()}',
    );
    _expectedLoss = TextEditingController(text: trade?.expectedLoss?.toString() ?? '');
    _risk = TextEditingController(text: trade?.riskPercent.toStringAsFixed(2) ?? '');
    _rewardRisk = TextEditingController();
    _accountId = trade?.accountId ?? '';
    _side = trade?.side;
    _anchors = {...?trade?.effectiveAnchors};
    _anchorTimeframes = {...?trade?.anchorTimeframes};
    _mood = trade?.mood.isNotEmpty == true ? trade!.mood : 'moodUnknown';
    _tradedAt = trade?.tradedAt ?? DateTime.now();
    _entrySetups = [...?trade?.effectiveEntrySetups];
    _confirmationSetups = [...?trade?.effectiveConfirmationSetups];
    _reverseSignalSetups = [...?trade?.reverseSignalSetups];
    _bounceZoneSetups = [...?trade?.bounceZoneSetups];
    _executionReviewKeys = {...?trade?.executionReviewKeys};
    _noEntryReasons = {...?trade?.noEntryReasons};
    // Editing a trade that only has structural reasons opens that section.
    final firstNoEntryZone = tradeNoEntryGroups.indexWhere(
      (group) => group.options.any((option) => _noEntryReasons.contains(option.key)),
    );
    _noEntryZoneIndex = firstNoEntryZone < 0 ? 0 : firstNoEntryZone;
    _practicalNoEntryReverseSignalSetups = [
      ...?trade?.practicalNoEntryReverseSignalSetups,
    ].where(_reverseSignalSetups.contains).toList();
    _classification = trade?.effectiveClassification;
    _missedOutcome = trade?.missedOutcome;
    _breakEvenType = trade?.breakEvenType;
    // A psychological reason or an explicitly linked opposing signal means
    // the record is a missed setup. Normalize older contradictory drafts in
    // the editor without changing the saved record until the user saves it.
    if (_hasEntryConditionsNoEntryLink) {
      _result.clear();
      _resultSign = null;
      _showResultSignChoices = false;
      if (_classification != TradeClassification.missed) {
        _classification = null;
        _missedOutcome = null;
        _breakEvenType = null;
      }
    } else if (_classification != null &&
        !_availableClassifications.contains(_classification)) {
      _classification = null;
      _missedOutcome = null;
      _breakEvenType = null;
    } else if (_classification != TradeClassification.missed) {
      _missedOutcome = null;
    }
    _beforePath = trade?.beforeImagePath;
    _afterPath = trade?.afterImagePath;
    _confirmationImagePath = trade?.confirmationImagePath;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final app = AppScope.of(context);
    if (_accountId.isEmpty && app.accounts.isNotEmpty) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    if (!_seededExpectedLoss && widget.trade != null) {
      _seededExpectedLoss = true;
      final balance = _accountBalanceBeforeTrade(app);
      final trade = widget.trade!;
      final amount = trade.expectedLoss ??
          (trade.result >= 0 && balance > 0
              ? balance * trade.riskPercent / 100
              : 0);
      _expectedLoss.text = trade.expectedLoss != null || amount > 0
          ? amount.toString()
          : '';
    }
    _updateComputedFields();
  }

  @override
  void dispose() {
    _result.dispose();
    _resultFocusNode.dispose();
    _expectedLoss.dispose();
    _risk.dispose();
    _rewardRisk.dispose();
    super.dispose();
  }

  double? _parse(TextEditingController controller) =>
      double.tryParse(controller.text.trim().replaceAll(',', '.'));

  double? _parseResult() {
    if (_hasEntryConditionsNoEntryLink) return 0;
    final raw = _result.text.trim();
    if (raw.isEmpty) return null;
    final sign = raw.startsWith('+')
        ? 1
        : (raw.startsWith('-') || raw.startsWith('−'))
            ? -1
            : null;
    if (sign == null) return null;
    final magnitudeText = raw.substring(1).trim();
    if (magnitudeText.isEmpty) return null;
    final magnitude =
        double.tryParse(magnitudeText.replaceAll(',', '.'));
    if (magnitude == null || !magnitude.isFinite) return null;
    return magnitude.abs() * sign;
  }

  void _enforceMissedOnlyOutcome() {
    if (!_hasEntryConditionsNoEntryLink) return;
    _result.clear();
    _resultSign = null;
    _showResultSignChoices = false;
    _resultFocusNode.unfocus();
    if (_classification != TradeClassification.missed) {
      _classification = null;
      _missedOutcome = null;
      _breakEvenType = null;
    }
    _updateComputedFields();
  }

  void _selectResultSign(int sign) {
    if (_hasEntryConditionsNoEntryLink) return;
    setState(() {
      // The sign is a real editable character in the amount field. Preserve
      // any digits when the user deletes a sign and chooses it again.
      final magnitudeText = _result.text.trim().replaceFirst(
        RegExp(r'^[+\-−]'),
        '',
      );
      final signCharacter = sign > 0 ? '+' : '−';
      final nextText = '$signCharacter$magnitudeText';
      _result.value = TextEditingValue(
        text: nextText,
        selection: TextSelection.collapsed(offset: nextText.length),
      );
      _resultSign = sign;
      _showResultSignChoices = false;
      if (_classification != null &&
          !_availableClassifications.contains(_classification)) {
        _classification = null;
        _missedOutcome = null;
        _breakEvenType = null;
      }
      _updateComputedFields();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _resultFocusNode.requestFocus();
    });
  }

  void _handleResultChanged(String value) {
    final trimmed = value.trimLeft();
    final nextSign = trimmed.startsWith('+')
        ? 1
        : (trimmed.startsWith('-') || trimmed.startsWith('−'))
            ? -1
            : null;
    setState(() {
      _resultSign = nextSign;
      // Removing the sign leaves the magnitude intact and makes the sign
      // chooser available again; the trader can then select + or − anew.
      _showResultSignChoices = nextSign == null &&
          !_hasEntryConditionsNoEntryLink;
      if (_classification != null &&
          !_availableClassifications.contains(_classification)) {
        _classification = null;
        _missedOutcome = null;
        _breakEvenType = null;
      }
      _updateComputedFields();
    });
    if (nextSign == null) {
      // Close the numeric keyboard after the sign is removed so the sign
      // choices can be selected cleanly from the field decoration.
      _resultFocusNode.unfocus();
    }
  }

  String? _resultValidator(String? value) {
    if (_hasEntryConditionsNoEntryLink) return null;
    final raw = value?.trim() ?? '';
    if (raw.isEmpty) {
      return _resultSign == null ? null : tr(context, 'requiredField');
    }
    final hasSign = raw.startsWith('+') ||
        raw.startsWith('-') ||
        raw.startsWith('−');
    if (!hasSign) {
      return _copy(
        'اختر موجب أو سالب أولاً.',
        'Choose + or − before entering the amount.',
      );
    }
    final magnitudeText = raw.substring(1).trim();
    if (magnitudeText.isEmpty) return tr(context, 'requiredField');
    final invalid = _number(magnitudeText, min: 0);
    if (invalid != null) return invalid;
    final magnitude =
        double.tryParse(magnitudeText.replaceAll(',', '.')) ?? 0;
    if (magnitude == 0) return tr(context, 'invalidNumber');
    return null;
  }

  TradingAccount? get _account {
    final app = AppScope.of(context);
    for (final item in app.accounts) {
      if (item.id == _accountId) return item;
    }
    return app.accounts.firstOrNull;
  }

  double _accountBalanceBeforeTrade(AppController app) {
    TradingAccount? account;
    for (final candidate in app.accounts) {
      if (candidate.id == _accountId) {
        account = candidate;
        break;
      }
    }
    if (account == null) return 0;
    final selectedAccount = account;
    return app.trades
        .where((trade) => trade.accountId == selectedAccount.id &&
            trade.id != widget.trade?.id && trade.isExecuted &&
            trade.tradedAt.isBefore(_tradedAt))
        .fold<double>(selectedAccount.startingBalance, (balance, trade) {
      final next = balance + trade.result;
      return next.isFinite ? next : balance;
    });
  }

  void _updateComputedFields() {
    final app = AppScope.of(context);
    final balance = _accountBalanceBeforeTrade(app);
    var parsedLoss = _parse(_expectedLoss);
    final result = _parseResult();
    final isLosingResult = result != null && result < 0;
    if (isLosingResult &&
        _expectedLoss.text.trim().isNotEmpty &&
        (widget.trade == null ||
            parsedLoss == null ||
            !parsedLoss.isFinite ||
            parsedLoss < 0)) {
      _expectedLoss.clear();
      parsedLoss = null;
    }
    final recordedLoss = parsedLoss != null &&
            parsedLoss.isFinite &&
            parsedLoss >= 0
        ? parsedLoss
        : null;
    // For a losing trade with no previously recorded planned risk, use the
    // realized loss as the risk amount for derived percentages and R-multiple.
    // It is not added to the trade result or stored as a second cash loss.
    final loss = isLosingResult &&
            (recordedLoss == null || recordedLoss == 0)
        ? result!.abs()
        : recordedLoss;
    final risk = loss == null || loss < 0
        ? null
        : loss == 0
            ? 0.0
            : balance > 0
                ? loss / balance * 100
                : null;
    _risk.text = risk != null && risk.isFinite ? risk.toStringAsFixed(2) : '';
    _rewardRisk.text = loss != null && loss > 0 && result != null && result.isFinite
        ? (result / loss).toStringAsFixed(2)
        : '';
  }

  String _formattedTradeDateTime(BuildContext context) {
    final localTradeTime = _tradedAt.toLocal();
    final time = TimeOfDay.fromDateTime(localTradeTime).format(context);
    return '${shortDate(localTradeTime)} · $time';
  }

  Future<void> _pickDateTime() async {
    if (!_hasTradeDirection) return;
    final date = await showDatePicker(
      context: context,
      initialDate: _tradedAt,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_tradedAt));
    if (time == null || !mounted) return;
    setState(() {
      _tradedAt = DateTime(date.year, date.month, date.day, time.hour, time.minute);
      _updateComputedFields();
    });
  }

  Future<void> _pickImage(_TradeImageSlot slot) async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 92);
      if (picked == null || !mounted) return;
      setState(() => _busy = true);
      final saved = await AppScope.of(context).persistImage(picked.path);
      if (!mounted) return;
      setState(() {
        switch (slot) {
          case _TradeImageSlot.before:
            _beforePath = saved;
          case _TradeImageSlot.after:
            _afterPath = saved;
          case _TradeImageSlot.confirmation:
            _confirmationImagePath = saved;
        }
        _busy = false;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _busy = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  /// Shows centered choices in the shared popup style. Standard selectors keep
  /// the established blue surface; semantic selectors can inherit their
  /// category tone for a continuous visual state. Long catalogs scroll inside
  /// the dialog without stretching it across the screen.
  Future<T?> _showCenteredTradeChoiceDialog<T>({
    required String title,
    String? subtitle,
    required List<({String label, T value})> options,
    required String keyPrefix,
    T? selectedValue,
    List<Key?>? optionKeys,
    Color? accentTone,
  }) =>
      showDialog<T>(
        context: context,
        barrierDismissible: true,
        builder: (dialogContext) {
          final brightness = Theme.of(dialogContext).brightness;
          final tokens = TdTokens.of(dialogContext);
          final isDark = brightness == Brightness.dark;
          final semanticAccent = accentTone ?? tokens.accent;
          // Preserve the original contextual surfaces for Entry Conditions:
          // opposing-signal and bounce pickers inherit their semantic tone,
          // while ordinary Trade Data selectors retain the shared blue surface.
          final dialogBorderColor = accentTone == null
              ? tdTradeDataPopupMenuBorderColor(brightness)
              : accentTone.withValues(alpha: isDark ? .17 : .13);
          final dialogSurfaceColor = accentTone == null
              ? tdPopupMenuColor(brightness)
              : _entryConditionsSurface(
                  tokens: tokens,
                  tone: accentTone,
                  brightness: brightness,
                );
          final screen = MediaQuery.sizeOf(dialogContext);
          final dialogWidth =
              (screen.width - 56).clamp(240.0, 360.0).toDouble();
          final dialogMaxHeight =
              (screen.height * .68).clamp(160.0, 560.0).toDouble();

          return Dialog(
            key: ValueKey('trade-centered-choice-$keyPrefix'),
            backgroundColor: dialogSurfaceColor,
            surfaceTintColor: Colors.transparent,
            elevation: 9,
            shape: accentTone == null
                ? tdTradeDataPopupMenuShape(brightness)
                : RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: dialogBorderColor, width: .8),
                  ),
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            child: SizedBox(
              width: dialogWidth,
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: dialogMaxHeight),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 13, 12, 12),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(5, 0, 5, 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              title,
                              textAlign: TextAlign.start,
                              style: Theme.of(dialogContext)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                    color: tokens.text1,
                                    fontWeight: FontWeight.w800,
                                  ),
                            ),
                            if (subtitle != null &&
                                subtitle.trim().isNotEmpty) ...[
                              const SizedBox(height: 4),
                              Text(
                                subtitle,
                                textAlign: TextAlign.start,
                                softWrap: true,
                                style: Theme.of(dialogContext)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: tokens.text2,
                                      fontWeight: FontWeight.w600,
                                      height: 1.25,
                                    ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      Divider(
                        height: 1,
                        color: accentTone == null
                            ? tdTradeDataPopupMenuBorderColor(brightness)
                                .withValues(alpha: .48)
                            : dialogBorderColor.withValues(alpha: .56),
                      ),
                      const SizedBox(height: 5),
                      Flexible(
                        child: ListView.separated(
                          shrinkWrap: true,
                          padding: EdgeInsets.zero,
                          itemCount: options.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(height: 2),
                          itemBuilder: (itemContext, index) {
                            final option = options[index];
                            final isSelected = option.value == selectedValue;
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 1),
                              child: ListTile(
                                key: optionKeys != null && index < optionKeys.length
                                    ? optionKeys[index]
                                    : ValueKey('$keyPrefix-option-$index'),
                                minTileHeight: 48,
                                minVerticalPadding: 8,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 11,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                selected: isSelected,
                                selectedTileColor:
                                    semanticAccent.withValues(
                                      alpha: accentTone == null
                                          ? .09
                                          : isDark
                                              ? .16
                                              : .10,
                                    ),
                                title: Text(
                                  option.label,
                                  softWrap: true,
                                  style: Theme.of(itemContext)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                        color: tokens.text1,
                                        fontSize: _tradeDataItemFontSize,
                                        fontWeight: isSelected
                                            ? FontWeight.w700
                                            : FontWeight.w500,
                                      ),
                                ),
                                trailing: Icon(
                                  isSelected
                                      ? Icons.check_circle_rounded
                                      : Icons.chevron_left_rounded,
                                  size: 18,
                                  color: isSelected
                                      ? semanticAccent
                                      : tokens.text3,
                                ),
                                onTap: () =>
                                    Navigator.pop(dialogContext, option.value),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );

  Future<String?> _showChoiceSheet({
    required String title,
    required List<TradeEntryOption> options,
    String? selectedKey,
    bool centered = false,
    Color? accentTone,
    String? subtitle,
  }) {
    if (centered) {
      return _showCenteredTradeChoiceDialog<String>(
        title: title,
        subtitle: subtitle,
        keyPrefix: 'single-choice',
        selectedValue: selectedKey,
        accentTone: accentTone,
        options: [
          for (final option in options)
            (label: _ar ? option.ar : option.en, value: option.key),
        ],
      );
    }

    final tokens = TdTokens.of(context);
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: tdPopupMenuColor(Theme.of(context).brightness),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(sheetContext).height * .72,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                child: Text(
                  title,
                  style: Theme.of(sheetContext)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(4, 0, 4, 16),
                  itemCount: options.length,
                  separatorBuilder: (_, _) =>
                      Divider(height: 1, color: tokens.lineSubtle),
                  itemBuilder: (itemContext, index) {
                    final option = options[index];
                    final isSelected = option.key == selectedKey;
                    return ListTile(
                      dense: false,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 8,
                      ),
                      selected: isSelected,
                      selectedTileColor: tokens.accent.withValues(alpha: .08),
                      title: Text(
                        _ar ? option.ar : option.en,
                        style: Theme.of(itemContext)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(
                              fontSize: _tradeDataItemFontSize,
                              fontWeight: isSelected
                                  ? FontWeight.w800
                                  : FontWeight.w500,
                            ),
                      ),
                      trailing: Icon(
                        isSelected
                            ? Icons.check_circle
                            : Icons.chevron_left,
                        size: 19,
                        color: isSelected ? tokens.accent : tokens.text3,
                      ),
                      onTap: () => Navigator.pop(sheetContext, option.key),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// All timeframe pickers share one concise heading and one contextual line.
  /// The contextual line identifies both the section and the selected item,
  /// while the established centered dialog, row list, and selection styling
  /// remain unchanged.
  Future<String?> _showTimeframeSheet({
    required String contextLabel,
    String? selectedFrame,
    Color? accentTone,
  }) =>
      _showCenteredTradeChoiceDialog<String>(
        title: _copy('اختيار الفريم الزمني', 'Select timeframe'),
        subtitle: contextLabel,
        keyPrefix: 'single-choice',
        selectedValue: selectedFrame,
        accentTone: accentTone,
        options: [
          for (final frame in tradeEntryTimeframes)
            (label: frame, value: frame),
        ],
      );

  /// Bounce area and Opposing signals share this flow:
  /// choice list → (optional sub-choice popup / S/R Touch 2) → timeframe list.
  /// Grouped rows («سحب سيولة», «إرتداد من Trendline») open a small popup with
  /// their concrete choices before the timeframe picker; «ارتداد من Zone S/D»
  /// goes straight to the timeframe list and resolves Supply/Demand Zone from
  /// the trade direction.
  Future<TradeEntryConditionSetup?> _showEntryConditionSetup({
    required String title,
    required String categoryLabel,
    required List<TradeEntryOption> options,
    TradeEntryConditionSetup? current,
    Color? choiceTone,
  }) async {
    if (!_hasTradeDirection) return null;
    final entryConditionsPrefix =
        '${_copy('ظروف الدخول', 'Entry conditions')} · $categoryLabel';
    final menuKey = await _showChoiceSheet(
      title: title,
      options: options,
      selectedKey:
          current == null ? null : tradeBounceZoneMenuKey(current.optionKey),
      centered: true,
      accentTone: choiceTone,
    );
    if (menuKey == null || !mounted) return null;

    var optionKey = menuKey;
    final subOptions = tradeBounceZoneSubOptions(menuKey);
    if (subOptions != null) {
      final menuOption = options.where((item) => item.key == menuKey).first;
      final subKey = await _showChoiceSheet(
        title: _ar ? menuOption.ar : menuOption.en,
        subtitle: entryConditionsPrefix,
        options: subOptions,
        selectedKey: current != null &&
                subOptions.any((item) => item.key == current.optionKey)
            ? current.optionKey
            : null,
        centered: true,
        accentTone: choiceTone,
      );
      if (subKey == null || !mounted) return null;
      optionKey = subKey;
    }

    var touch2 = false;
    if (optionKey == 'bounceFromSrZone') {
      final selectedTouch2 = await _showTouch2Sheet(
        baseReason: 'bounceFromSrZone',
        // A false Touch 2 flag means no qualifier is stored, not that the
        // user explicitly selected Continue. Keep both choices neutral until
        // the user makes a selection; restore only an explicitly stored Touch 2.
        selected: current?.optionKey == 'bounceFromSrZone' &&
                current?.touch2 == true
            ? true
            : null,
        side: _side,
        accentTone: choiceTone,
      );
      if (selectedTouch2 == null || !mounted) return null;
      touch2 = selectedTouch2;
    }
    final selectedOption = [...options, ...tradeBounceZoneLabelOptions]
        .where((option) => option.key == optionKey)
        .firstOrNull;
    final selectedOptionLabel = selectedOption == null
        ? optionKey
        : (_ar ? selectedOption.ar : selectedOption.en);
    final selectedContextLabel = formatTradeEntryConditionSetupLabel(
      setup: TradeEntryConditionSetup(
        optionKey: optionKey,
        timeframe: '',
        touch2: touch2,
      ),
      optionLabel: selectedOptionLabel,
      arabic: _ar,
      side: _side,
    );
    final timeframe = await _showTimeframeSheet(
      contextLabel: '$entryConditionsPrefix · $selectedContextLabel',
      selectedFrame: current?.timeframe,
      // Preserve the semantic tone when the timeframe picker follows an
      // opposing-signal selection. Other entry-condition pickers pass null
      // and therefore retain the established neutral/blue styling.
      accentTone: choiceTone,
    );
    if (timeframe == null || !mounted) return null;

    return TradeEntryConditionSetup(
      optionKey: optionKey,
      timeframe: timeframe,
      touch2: touch2,
    );
  }

  String _touch2DialogTitle({
    required String baseReason,
    required TradeSide? side,
  }) {
    if (baseReason == 'directionalBreakout') {
      final scenario = switch (side) {
        TradeSide.buy => 'RBS',
        TradeSide.sell => 'SBR',
        null => 'BREAKOUT',
      };
      return _ar
          ? '$scenario Touch — اختياري'
          : '$scenario Touch — Optional';
    }
    if (baseReason == 'bounceFromSrZone') {
      final scenario = switch (side) {
        TradeSide.buy => 'Support',
        TradeSide.sell => 'Resistan',
        null => 'S/R',
      };
      return _ar
          ? (side == null
              ? 'ارتداد من S/R Touch — اختياري'
              : 'ارتداد من $scenario Touch — اختياري')
          : (side == null
              ? 'S/R Bounce Touch — Optional'
              : 'Bounce from $scenario Touch — Optional');
    }
    return _copy('تفصيل $baseReason Touch — اختياري', '$baseReason Touch — Optional');
  }

  Future<bool?> _showTouch2Sheet({
    required String baseReason,
    required TradeSide? side,
    bool? selected,
    bool compactLabels = false,
    Color? accentTone,
  }) {
    return _showCenteredTradeChoiceDialog<bool>(
      title: _touch2DialogTitle(baseReason: baseReason, side: side),
      keyPrefix: 'touch2-$baseReason',
      selectedValue: selected,
      accentTone: accentTone,
      optionKeys: [
        ValueKey('touch2-choice-$baseReason'),
        ValueKey('skip-touch2-$baseReason'),
      ],
      options: [
        (
          label: baseReason == 'bounceFromSrZone'
              ? '2 Touch'
              : compactLabels
                  ? _copy('Touch 2', 'Touch 2')
                  : _copy('لمسة 2', 'Touch 2'),
          value: true,
        ),
        (
          label: _copy('متابعة', 'Continue'),
          value: false,
        ),
      ],
    );
  }

  Future<String?> _showEntryReasonSheet({String? currentReason, bool editing = false}) async {
    final currentBase = currentReason == null ? null : tradeEntryBaseReason(currentReason);
    final baseReason = await _showChoiceSheet(
      title: editing
          ? _copy('تعديل سبب الدخول', 'Edit entry reason')
          : _copy('سبب الدخول', 'Entry reason'),
      options: tradeEntryReasons,
      selectedKey: currentBase == null
          ? null
          : tradeEntryReasonSelectionKey(currentBase),
      centered: true,
    );
    if (baseReason == null || !mounted) return null;
    final isDirectionalBreakout = baseReason == 'directionalBreakout';
    if (!isDirectionalBreakout &&
        !tradeEntryTouch2EligibleReasons.contains(baseReason)) {
      return baseReason;
    }

    final isEditingSameBreakout = currentReason != null &&
        tradeEntryReasonSelectionKey(currentReason) == 'directionalBreakout';
    final touch2 = await _showTouch2Sheet(
      baseReason: baseReason,
      // Preserve the current choice when editing. Legacy SBR/RBS Touch 2
      // values migrate into the same semantic BREAKOUT + Touch 2 selection.
      selected: isEditingSameBreakout && tradeEntryUsesTouch2(currentReason)
          ? true
          : null,
      side: _side,
      compactLabels: true,
    );
    if (touch2 == null || !mounted) return null;
    return tradeEntryReasonWithTouch2(baseReason, touch2);
  }

  Future<String?> _showCustomConfirmationDialog({String initialValue = ''}) async {
    final controller = TextEditingController(text: initialValue);
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_copy('تأكيد مخصص', 'Custom confirmation')),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 80,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(labelText: _copy('اكتب نوع التأكيد', 'Enter confirmation type')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(tr(context, 'cancel'))),
          FilledButton(onPressed: () {
            final text = controller.text.trim();
            if (text.isNotEmpty) Navigator.pop(dialogContext, text);
          }, child: Text(tr(context, 'confirm'))),
        ],
      ),
    );
    controller.dispose();
    return value;
  }

  bool _hasEquivalentEntrySetup(String reason, String timeframe, {int? exceptIndex}) =>
      _entrySetups.asMap().entries.any((entry) =>
          entry.key != exceptIndex &&
          entry.value.timeframe == timeframe &&
          tradeEntryReasonSelectionKey(entry.value.reason) ==
              tradeEntryReasonSelectionKey(reason));

  Future<void> _addEntrySetup() async {
    if (!_hasTradeDirection) return;
    final reason = await _showEntryReasonSheet();
    if (reason == null || !mounted) return;
    final timeframe = await _showTimeframeSheet(
      contextLabel: '${_copy('سبب الدخول', 'Entry reason')} · ${formatTradeEntryReasonLabel(reason: reason, side: _side)}',
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      if (!_hasEquivalentEntrySetup(reason, timeframe)) {
        _entrySetups.add(TradeEntrySetup(reason: reason, timeframe: timeframe));
      }
    });
  }

  Future<void> _addConfirmationSetup() async {
    if (!_hasTradeDirection) return;
    final type = await _showChoiceSheet(
      title: _copy('تأكيد الدخول', 'Entry confirmation'),
      options: tradeConfirmationOptions,
      centered: true,
    );
    if (type == null || !mounted) return;
    String finalType = type;
    if (type == '__custom__') {
      final custom = await _showCustomConfirmationDialog();
      if (custom == null || !mounted) return;
      finalType = custom;
    }
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '${_copy('تأكيد الدخول', 'Entry confirmation')} · ${_confirmationLabel(finalType)}',
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      if (!_confirmationSetups.any((item) =>
          tradeConfirmationSelectionKey(item.type) ==
              tradeConfirmationSelectionKey(finalType) &&
          item.timeframe == timeframe)) {
        _confirmationSetups.add(TradeConfirmationSetup(type: finalType, timeframe: timeframe));
      }
    });
  }

  Future<void> _editEntrySetup(TradeEntrySetup current) async {
    if (!_hasTradeDirection) return;
    final reason = await _showEntryReasonSheet(currentReason: current.reason, editing: true);
    if (reason == null || !mounted) return;
    final timeframe = await _showTimeframeSheet(
      contextLabel: '${_copy('سبب الدخول', 'Entry reason')} · ${formatTradeEntryReasonLabel(reason: reason, side: _side)}',
      selectedFrame: current.timeframe,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _entrySetups.indexOf(current);
      if (index < 0) return;
      final replacement = TradeEntrySetup(reason: reason, timeframe: timeframe);
      if (_hasEquivalentEntrySetup(reason, timeframe, exceptIndex: index)) {
        _entrySetups.removeAt(index);
      } else {
        _entrySetups[index] = replacement;
      }
    });
  }

  Future<void> _editConfirmationSetup(TradeConfirmationSetup current) async {
    if (!_hasTradeDirection) return;
    final type = await _showChoiceSheet(
      title: _copy('تعديل تأكيد الدخول', 'Edit entry confirmation'),
      options: tradeConfirmationOptions,
      selectedKey: tradeConfirmationOptions.any(
        (item) => item.key == tradeConfirmationSelectionKey(current.type),
      )
          ? tradeConfirmationSelectionKey(current.type)
          : '__custom__',
      centered: true,
    );
    if (type == null || !mounted) return;
    String finalType = type;
    if (type == '__custom__') {
      final custom = await _showCustomConfirmationDialog(initialValue: current.type == '__custom__' ? '' : current.type);
      if (custom == null || !mounted) return;
      finalType = custom;
    }
    final timeframe = await _showTimeframeSheet(
      contextLabel:
          '${_copy('تأكيد الدخول', 'Entry confirmation')} · ${_confirmationLabel(finalType)}',
      selectedFrame: current.timeframe,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _confirmationSetups.indexOf(current);
      if (index < 0) return;
      final replacement = TradeConfirmationSetup(type: finalType, timeframe: timeframe);
      if (_confirmationSetups.asMap().entries.any((entry) =>
          entry.key != index &&
          tradeConfirmationSelectionKey(entry.value.type) ==
              tradeConfirmationSelectionKey(replacement.type) &&
          entry.value.timeframe == replacement.timeframe)) {
        _confirmationSetups.removeAt(index);
      } else {
        _confirmationSetups[index] = replacement;
      }
    });
  }

  Future<void> _addReverseSignalSetup() async {
    if (_side == null) {
      _showValidationMessage(
        _copy(
          'حدد اتجاه الصفقة شراء أو بيع أولاً حتى تُعرض الإشارة العكسية الصحيحة.',
          'Choose Buy or Sell first so the opposing signal can be resolved correctly.',
        ),
      );
      return;
    }
    final setup = await _showEntryConditionSetup(
      title: _copy('إشارات عكسية', 'Opposing signals'),
      categoryLabel: _copy('إشارات عكسية', 'Opposing signals'),
      options: tradeReverseSignalOptions,
      choiceTone: _currentReverseSignalTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      if (!_reverseSignalSetups.contains(setup)) _reverseSignalSetups.add(setup);
    });
  }

  Future<void> _editReverseSignalSetup(TradeEntryConditionSetup current) async {
    if (_side == null) {
      _showValidationMessage(
        _copy(
          'حدد اتجاه الصفقة شراء أو بيع أولاً حتى تُعرض الإشارة العكسية الصحيحة.',
          'Choose Buy or Sell first so the opposing signal can be resolved correctly.',
        ),
      );
      return;
    }
    final setup = await _showEntryConditionSetup(
      title: _copy('تعديل الإشارة العكسية', 'Edit opposing signal'),
      categoryLabel: _copy('إشارات عكسية', 'Opposing signals'),
      options: tradeReverseSignalOptions,
      current: current,
      choiceTone: _currentReverseSignalTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      final index = _reverseSignalSetups.indexOf(current);
      if (index < 0) return;
      final wasMarkedPractical =
          _practicalNoEntryReverseSignalSetups.remove(current);
      final duplicateIndex = _reverseSignalSetups.indexWhere(
        (value) => value == setup && value != current,
      );
      if (duplicateIndex >= 0) {
        _reverseSignalSetups.removeAt(index);
        if (wasMarkedPractical &&
            !_practicalNoEntryReverseSignalSetups.contains(setup)) {
          _practicalNoEntryReverseSignalSetups.add(setup);
        }
      } else {
        _reverseSignalSetups[index] = setup;
        if (wasMarkedPractical) {
          _practicalNoEntryReverseSignalSetups.add(setup);
        }
      }
    });
  }

  Future<void> _addBounceZoneSetup() async {
    if (!_hasTradeDirection) return;
    final setup = await _showEntryConditionSetup(
      title: _copy('منطقة الارتداد', 'Bounce area'),
      categoryLabel: _copy('منطقة الارتداد', 'Bounce area'),
      options: tradeBounceZoneOptions,
      choiceTone: _entryConditionsTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      if (!_bounceZoneSetups.contains(setup)) _bounceZoneSetups.add(setup);
    });
  }

  Future<void> _editBounceZoneSetup(TradeEntryConditionSetup current) async {
    if (!_hasTradeDirection) return;
    final setup = await _showEntryConditionSetup(
      title: _copy('تعديل منطقة الارتداد', 'Edit bounce area'),
      categoryLabel: _copy('منطقة الارتداد', 'Bounce area'),
      options: tradeBounceZoneOptions,
      current: current,
      choiceTone: _entryConditionsTone,
    );
    if (setup == null || !mounted) return;
    setState(() {
      final index = _bounceZoneSetups.indexOf(current);
      if (index < 0) return;
      if (_bounceZoneSetups.asMap().entries.any(
        (entry) => entry.key != index && entry.value == setup,
      )) {
        _bounceZoneSetups.removeAt(index);
      } else {
        _bounceZoneSetups[index] = setup;
      }
    });
  }

  void _removeReverseSignalSetup(TradeEntryConditionSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() {
      _reverseSignalSetups.remove(setup);
      _practicalNoEntryReverseSignalSetups.remove(setup);
    });
  }

  void _togglePracticalNoEntryReverseSignal(TradeEntryConditionSetup setup) {
    if (!_hasTradeDirection || !_reverseSignalSetups.contains(setup)) return;
    final wasMarked = _practicalNoEntryReverseSignalSetups.contains(setup);
    setState(() {
      if (wasMarked) {
        _practicalNoEntryReverseSignalSetups.remove(setup);
      } else {
        _practicalNoEntryReverseSignalSetups.add(setup);
        _enforceMissedOnlyOutcome();
      }
    });
    HapticFeedback.selectionClick();
    final message = wasMarked
        ? _copy('تم إلغاء ربط الإشارة كسبب عملي', 'Practical reason link removed')
        : _copy('تم ربط الإشارة كسبب عملي لعدم الدخول', 'Opposing signal linked as a practical no-entry reason');
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(milliseconds: 1500),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  void _removeBounceZoneSetup(TradeEntryConditionSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _bounceZoneSetups.remove(setup));
  }

  void _removeEntrySetup(TradeEntrySetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _entrySetups.remove(setup));
  }

  void _removeConfirmationSetup(TradeConfirmationSetup setup) {
    if (!_hasTradeDirection) return;
    setState(() => _confirmationSetups.remove(setup));
  }

  bool get _hasExecutionFlaw =>
      _executionReviewKeys.any(tradeExecutionFlawKeys.contains);

  /// «التزمت بالخطة كاملة» and «التزمت بشروط الدخول…» are locked while any
  /// violation or analysis-quality item is chosen. A commitment that is already
  /// selected (an older saved trade) stays tappable so it can be cleared.
  bool _commitmentLocked(String key) =>
      tradeCommitmentExclusiveKeys.contains(key) &&
      _hasExecutionFlaw &&
      !_executionReviewKeys.contains(key);

  void _toggleSet(Set<String> values, String key, bool selected) {
    if (!_hasTradeDirection) return;
    setState(() {
      if (selected) {
        values.add(key);
      } else {
        values.remove(key);
      }
      if (identical(values, _executionReviewKeys) &&
          selected &&
          tradeExecutionFlawKeys.contains(key)) {
        // A mistake and a "followed the plan / entry conditions" commitment
        // contradict each other, so the commitment is released.
        values.removeAll(tradeCommitmentExclusiveKeys);
      }
      if (identical(values, _noEntryReasons) && selected) {
        _enforceMissedOnlyOutcome();
      }
    });
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? tr(context, 'requiredField') : null;

  String? _number(String? value, {double? min}) {
    if (value == null || value.trim().isEmpty) return tr(context, 'requiredField');
    final parsed = double.tryParse(value.trim().replaceAll(',', '.'));
    if (parsed == null || !parsed.isFinite || (min != null && parsed < min)) return tr(context, 'invalidNumber');
    return null;
  }

  String? _expectedLossValidator(String? value) {
    // The result itself supplies the realized loss when it is negative, so
    // this separate planned-loss field is intentionally not required then.
    if (_hasEntryConditionsNoEntryLink) return null;
    final result = _parseResult();
    if (result != null && result < 0) return null;
    if ((value == null || value.trim().isEmpty) &&
        (_classification == TradeClassification.breakEven ||
            _classification == TradeClassification.missed)) {
      return null;
    }
    final invalid = _number(value, min: 0);
    if (invalid != null) return invalid;
    final loss = _parse(_expectedLoss) ?? 0;
    if (result != 0 && loss <= 0) return tr(context, 'expectedLossNeeded');
    return null;
  }

  Future<void> _chooseClassification() async {
    final selected = await showModalBottomSheet<TradeClassification>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      backgroundColor: TdTokens.of(context).surface1,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        final tokens = TdTokens.of(sheetContext);
        Color colorFor(TradeClassification value) => switch (value) {
          TradeClassification.win => tokens.profit,
          TradeClassification.loss => tokens.loss,
          TradeClassification.breakEven => TradeOutcomePalette.breakEven(Theme.of(sheetContext).brightness),
          TradeClassification.missed => tokens.neutral,
        };
        String labelFor(TradeClassification value) => switch (value) {
          TradeClassification.win => tr(sheetContext, 'classificationWin'),
          TradeClassification.loss => tr(sheetContext, 'classificationLoss'),
          TradeClassification.breakEven => tr(sheetContext, 'classificationBreakEven'),
          TradeClassification.missed => tr(sheetContext, 'classificationMissed'),
        };
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                tr(sheetContext, 'chooseTradeClassification'),
                style: Theme.of(sheetContext).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              for (final value in _availableClassifications)
                Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: Material(
                    color: tokens.surface2,
                    borderRadius: BorderRadius.circular(13),
                    child: InkWell(
                      key: ValueKey('trade-classification-option-${value.name}'),
                      borderRadius: BorderRadius.circular(13),
                      onTap: () => Navigator.of(sheetContext).pop(value),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                        child: Row(
                          children: [
                            Container(
                              width: 9,
                              height: 9,
                              decoration: BoxDecoration(
                                color: colorFor(value),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Text(
                                labelFor(value),
                                style: Theme.of(sheetContext).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            Icon(Icons.chevron_left_rounded, size: 19, color: tokens.text3),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
    if (selected != null && mounted) {
      setState(() {
        _classification = selected;
        if (selected != TradeClassification.missed) _missedOutcome = null;
        if (selected != TradeClassification.breakEven) _breakEvenType = null;
      });
      // Break-even needs a subtype before the trade can be saved. Open the
      // subtype popup right where the save button will appear, once the new
      // layout (and therefore the slot position) has been built.
      if (selected == TradeClassification.breakEven && _breakEvenType == null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted &&
              _classification == TradeClassification.breakEven &&
              _breakEvenType == null) {
            _chooseBreakEvenType();
          }
        });
      }
    }
  }

  String _breakEvenTypeLabel(BreakEvenType value) => switch (value) {
    BreakEvenType.balanced => _copy('متساوي', 'Balanced'),
    BreakEvenType.atEntry => _copy('عند منطقة الدخول', 'At entry area'),
  };

  /// Pops the two break-even subtypes up in place of the save button. The card
  /// grows upward from the bottom edge of the save slot, so both choices sit
  /// inside thumb reach with no scrolling, and one tap selects and closes it.
  Future<void> _chooseBreakEvenType() async {
    if (_busy || _breakEvenPopupOpen) return;
    _breakEvenPopupOpen = true;
    // Bring the slot fully on screen first (the layout just grew by one row),
    // so the popup always opens directly over the save button's own position.
    final slotContext = _saveSlotKey.currentContext;
    if (slotContext != null) {
      await Scrollable.ensureVisible(
        slotContext,
        alignmentPolicy: ScrollPositionAlignmentPolicy.keepVisibleAtEnd,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
      );
      if (!mounted) return;
    }
    final slotBox = _saveSlotKey.currentContext?.findRenderObject();
    final Rect? slotRect =
        slotBox is RenderBox && slotBox.hasSize && slotBox.attached
            ? slotBox.localToGlobal(Offset.zero) & slotBox.size
            : null;
    final selected = await showGeneralDialog<BreakEvenType>(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: TdTokens.of(context).scrim.withValues(alpha: .34),
      transitionDuration: const Duration(milliseconds: 190),
      pageBuilder: (dialogContext, _, _) {
        final tokens = TdTokens.of(dialogContext);
        final brightness = Theme.of(dialogContext).brightness;
        final isDark = brightness == Brightness.dark;
        final media = MediaQuery.of(dialogContext);
        final accent = TradeOutcomePalette.breakEven(brightness);
        const horizontalMargin = 16.0;
        final screenHeight = media.size.height;
        final minBottom = media.padding.bottom + media.viewInsets.bottom + 12;
        // Card bottom edge == slot bottom edge; fall back to the screen bottom
        // when the slot has not been laid out.
        final bottom = slotRect == null
            ? minBottom
            : (screenHeight - slotRect.bottom)
                .clamp(minBottom, screenHeight)
                .toDouble();
        final left = slotRect == null
            ? horizontalMargin
            : slotRect.left
                .clamp(horizontalMargin, media.size.width / 2)
                .toDouble();
        final right = slotRect == null
            ? horizontalMargin
            : (media.size.width - slotRect.right)
                .clamp(horizontalMargin, media.size.width / 2)
                .toDouble();

        Widget option(BreakEvenType value) {
          final isSelected = _breakEvenType == value;
          return Material(
            color: isSelected
                ? accent.withValues(alpha: isDark ? .16 : .11)
                : tokens.surface3.withValues(alpha: isDark ? .62 : .9),
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              key: ValueKey('break-even-type-${value.name}'),
              borderRadius: BorderRadius.circular(12),
              onTap: () => Navigator.of(dialogContext).pop(value),
              child: Container(
                constraints: const BoxConstraints(minHeight: 52),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected
                        ? accent.withValues(alpha: .72)
                        : tokens.lineSubtle.withValues(alpha: .62),
                    width: isSelected ? 1 : .8,
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        _breakEvenTypeLabel(value),
                        style: Theme.of(dialogContext).textTheme.bodyMedium
                            ?.copyWith(
                              color: isSelected ? tokens.text1 : tokens.text2,
                              fontWeight: isSelected
                                  ? FontWeight.w800
                                  : FontWeight.w600,
                            ),
                      ),
                    ),
                    Icon(
                      isSelected
                          ? Icons.check_circle_rounded
                          : Icons.chevron_left_rounded,
                      size: 19,
                      color: isSelected ? accent : tokens.text3,
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        return Stack(
          children: [
            Positioned(
              left: left,
              right: right,
              bottom: bottom,
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: screenHeight * .6),
                child: Material(
                  key: const ValueKey('break-even-type-popup'),
                  color: tdPopupMenuColor(brightness),
                  elevation: 10,
                  shadowColor: Colors.black.withValues(alpha: .5),
                  surfaceTintColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(
                      color: tdTradeDataPopupMenuBorderColor(brightness),
                      width: .8,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(4, 0, 4, 9),
                          child: Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: accent,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 9),
                              Expanded(
                                child: Text(
                                  _copy('نوع التعادل', 'Break-even type'),
                                  style: Theme.of(dialogContext)
                                      .textTheme
                                      .titleSmall
                                      ?.copyWith(
                                        color: tokens.text1,
                                        fontWeight: FontWeight.w800,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        option(BreakEvenType.balanced),
                        const SizedBox(height: 8),
                        option(BreakEvenType.atEntry),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
      transitionBuilder: (context, animation, _, child) {
        final curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            alignment: Alignment.bottomCenter,
            scale: Tween<double>(begin: .94, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
    _breakEvenPopupOpen = false;
    if (selected != null && mounted) {
      setState(() => _breakEvenType = selected);
    }
  }

  void _cycleMissedOutcome() {
    if (_classification != TradeClassification.missed || _busy) return;
    setState(() {
      _missedOutcome = switch (_missedOutcome) {
        null => MissedTradeOutcome.loss,
        MissedTradeOutcome.loss => MissedTradeOutcome.win,
        MissedTradeOutcome.win => null,
      };
    });
  }

  String _classificationLabel(TradeClassification value) => switch (value) {
    TradeClassification.win => tr(context, 'classificationWin'),
    TradeClassification.loss => tr(context, 'classificationLoss'),
    TradeClassification.breakEven => tr(context, 'classificationBreakEven'),
    TradeClassification.missed => tr(context, 'classificationMissed'),
  };

  bool _classificationMatchesResult(TradeClassification value, double result) =>
      switch (value) {
        TradeClassification.win => result > 0,
        TradeClassification.loss => result < 0,
        TradeClassification.breakEven || TradeClassification.missed => result == 0,
      };

  /// Compact chip showing the chosen break-even subtype; tapping it reopens
  /// the same popup so the subtype can still be changed.
  Widget _buildBreakEvenTypeChip(TdTokens tokens) {
    final brightness = Theme.of(context).brightness;
    final accent = TradeOutcomePalette.breakEven(brightness);
    final type = _breakEvenType;
    return Tooltip(
      message: _copy('تغيير نوع التعادل', 'Change break-even type'),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          key: const ValueKey('trade-break-even-type-chip'),
          borderRadius: BorderRadius.circular(9),
          onTap: _busy ? null : _chooseBreakEvenType,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: accent.withValues(
                alpha: brightness == Brightness.dark ? .13 : .10,
              ),
              border: Border.all(color: accent.withValues(alpha: .7), width: .9),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  type == null ? '' : _breakEvenTypeLabel(type),
                  key: const ValueKey('trade-break-even-type-chip-label'),
                  maxLines: 1,
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: tokens.text1,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 3),
                Icon(Icons.unfold_more_rounded, size: 14, color: tokens.text3),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMissedOutcomeChip(TdTokens tokens) {
    final activeColor = switch (_missedOutcome) {
      MissedTradeOutcome.win => tokens.profit,
      MissedTradeOutcome.loss => tokens.loss,
      null => tokens.text3,
    };
    final fillColor = _missedOutcome == null
        ? Colors.transparent
        : activeColor.withValues(alpha: .10);
    final stateLabel = switch (_missedOutcome) {
      MissedTradeOutcome.win => _copy(
        'الفرصة كانت رابحة',
        'Missed opportunity would win',
      ),
      MissedTradeOutcome.loss => _copy(
        'الفرصة كانت خاسرة',
        'Missed opportunity would lose',
      ),
      null => _copy('ضائعة: غير محددة', 'Missed: not classified'),
    };
    return Tooltip(
      message: stateLabel,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          key: const ValueKey('trade-missed-outcome-chip-tap'),
          borderRadius: BorderRadius.circular(9),
          onTap: _cycleMissedOutcome,
          child: AnimatedContainer(
            key: const ValueKey('trade-missed-outcome-chip'),
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: fillColor,
              border: Border.all(
                color: activeColor.withValues(
                  alpha: _missedOutcome == null ? .68 : .88,
                ),
                width: .9,
              ),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Text(
              _classificationLabel(TradeClassification.missed),
              key: const ValueKey('trade-missed-outcome-chip-label'),
              maxLines: 1,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: _missedOutcome == null ? tokens.text2 : activeColor,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final selectedClassification = _classification;
    if (selectedClassification == null) {
      _showValidationMessage(tr(context, 'tradeClassificationRequired'));
      return;
    }
    if (selectedClassification == TradeClassification.breakEven &&
        _breakEvenType == null) {
      _showValidationMessage(_copy(
        'اختر نوع التعادل قبل حفظ الصفقة.',
        'Choose the break-even type before saving.',
      ));
      return;
    }
    if (selectedClassification == TradeClassification.missed &&
        _missedOutcome == null) {
      _showValidationMessage(
        _copy(
          'حدد ما إذا كانت الفرصة الضائعة رابحة أم خاسرة قبل حفظ الصفقة.',
          'Choose whether the missed opportunity was a win or loss before saving.',
        ),
      );
      return;
    }
    final enteredResult = _parseResult() ?? 0.0;
    if (!_availableClassifications.contains(selectedClassification) ||
        !_classificationMatchesResult(selectedClassification, enteredResult)) {
      _showValidationMessage(tr(context, 'tradeClassificationResultMismatch'));
      return;
    }
    if (_symbol == null || _symbol!.trim().isEmpty) {
      _showValidationMessage(_copy('اختر الرمز: NQ أو ES أو GC.', 'Choose a symbol: NQ, ES, or GC.'));
      return;
    }
    if (_side == null) {
      _showValidationMessage(_copy('حدد اتجاه الصفقة: شراء أو بيع.', 'Choose the trade direction: buy or sell.'));
      return;
    }
    if (_entrySetups.isEmpty) {
      _showValidationMessage(_copy('أضف سبب دخول واحدًا على الأقل مع الفريم الزمني.', 'Add at least one entry reason with its timeframe.'));
      return;
    }
    if (_confirmationSetups.isEmpty) {
      _showValidationMessage(_copy('أضف تأكيد دخول واحدًا على الأقل مع فريمه الزمني.', 'Add at least one entry confirmation with its timeframe.'));
      return;
    }
    final app = AppScope.of(context);
    if (app.accounts.isEmpty) return;
    final balance = _accountBalanceBeforeTrade(app);
    final result = _parseResult() ?? 0.0;
    final parsedLoss = _parse(_expectedLoss);
    final recordedLoss = parsedLoss != null &&
            parsedLoss.isFinite &&
            parsedLoss >= 0
        ? parsedLoss
        : null;
    final loss = result < 0 &&
            (recordedLoss == null || recordedLoss == 0)
        ? result.abs()
        : recordedLoss ?? 0.0;
    final risk = loss == 0 ? 0.0 : (balance > 0 ? loss / balance * 100 : null);
    if (risk == null || !risk.isFinite) {
      _showValidationMessage(tr(context, 'riskBalanceUnavailable'));
      return;
    }
    final setups = [..._entrySetups];
    final confirmations = [..._confirmationSetups];
    final trade = Trade(
      id: widget.trade?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      accountId: app.accounts.any((item) => item.id == _accountId) ? _accountId : (app.selectedAccountId ?? app.accounts.first.id),
      market: _symbol!.trim().toUpperCase(),
      reason: setups.first.reason,
      result: result,
      riskPercent: risk,
      // Keep this optional when the loss amount was derived solely from the
      // realized result. Existing or explicitly entered planned risk is kept.
      expectedLoss: recordedLoss ?? (result < 0 ? null : loss),
      side: _side!,
      confirmation: '',
      confirmationSetups: confirmations,
      reverseSignalSetups: [..._reverseSignalSetups],
      bounceZoneSetups: [..._bounceZoneSetups],
      executionJournal: widget.trade?.executionJournal ?? const [],
      executionReviewKeys: _executionReviewKeys.toList(growable: false),
      noEntryReasons: _noEntryReasons.toList(growable: false),
      practicalNoEntryReverseSignalSetups: _practicalNoEntryReverseSignalSetups
          .where(_reverseSignalSetups.contains)
          .toList(growable: false),
      sequence: widget.trade?.sequence ?? '',
      mood: _mood,
      tradedAt: _tradedAt,
      entryTimeframe: setups.first.timeframe,
      entrySetups: setups,
      beforeImagePath: _beforePath,
      afterImagePath: _afterPath,
      confirmationImagePath: _confirmationImagePath,
      notes: widget.trade?.notes ?? '',
      strategyAdherence: widget.trade?.strategyAdherence,
      classification: selectedClassification,
      missedOutcome: selectedClassification == TradeClassification.missed
          ? _missedOutcome
          : null,
      breakEvenType: selectedClassification == TradeClassification.breakEven
          ? _breakEvenType
          : null,
      anchor: _orderedAnchorKeys.firstOrNull,
      anchors: _orderedAnchorKeys,
      anchorTimeframes: {
        for (final key in _orderedAnchorKeys)
          if (_anchorTimeframes[key] != null) key: _anchorTimeframes[key]!,
      },
    );
    Navigator.of(context).pop(trade);
  }

  void _showValidationMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  InputDecoration _blueSelectorDecoration({
    required String label,
    Widget? labelWidget,
    IconData? icon,
    IconData? trailingIcon,
    Color? tone,
    Color? fillColorOverride,
    Color? borderColorOverride,
    EdgeInsetsGeometry? contentPadding,
    FloatingLabelAlignment? floatingLabelAlignment,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectorTone = tone ?? _dataTone;
    final fieldFill = fillColorOverride ??
        (isDark
            ? (tone == null
                ? const Color(0xFF071834)
                : Color.alphaBlend(
                    selectorTone.withValues(alpha: .10),
                    const Color(0xFF071834),
                  ))
            : Color.alphaBlend(
                selectorTone.withValues(alpha: .10),
                tokens.inset,
              ));
    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(
        color: borderColorOverride ??
            (isDark
                ? (tone == null
                    ? const Color(0xFF21405B).withValues(alpha: .52)
                    : selectorTone.withValues(alpha: .30))
                : tokens.lineSubtle.withValues(alpha: .68)),
        width: .78,
      ),
    );
    final fieldLabelStyle = Theme.of(context)
        .textTheme
        .labelMedium
        ?.copyWith(
          color: tokens.text2,
          fontSize: _tradeFieldLabelFontSize,
          fontWeight: FontWeight.w600,
          height: 1.15,
        );
    return InputDecoration(
      labelText: labelWidget == null ? label : null,
      label: labelWidget,
      labelStyle: fieldLabelStyle,
      floatingLabelStyle: fieldLabelStyle?.copyWith(
        fontSize: _tradeFloatingLabelFontSize,
      ),
      prefixIcon: icon == null
          ? null
          : Icon(icon, size: 17, color: tokens.text2),
      prefixIconConstraints: icon == null
          ? null
          : const BoxConstraints(minWidth: 36, minHeight: 48),
      suffixIcon: trailingIcon == null
          ? null
          : Icon(trailingIcon, size: 18, color: tokens.text3),
      suffixIconConstraints: trailingIcon == null
          ? null
          : const BoxConstraints(minWidth: 38, minHeight: 42),
      filled: true,
      fillColor: fieldFill,
      border: fieldBorder,
      enabledBorder: fieldBorder,
      focusedBorder: fieldBorder.copyWith(
        borderSide: BorderSide(
          color: selectorTone.withValues(alpha: .78),
          width: 1.05,
        ),
      ),
      contentPadding: contentPadding ??
          const EdgeInsetsDirectional.fromSTEB(10, 13, 10, 13),
      floatingLabelBehavior: FloatingLabelBehavior.auto,
      floatingLabelAlignment: floatingLabelAlignment,
    );
  }

  Future<void> _showCompactPopupChoice<T>({
    required GlobalKey anchorKey,
    required List<T> values,
    required String itemKeyPrefix,
    required T? selectedValue,
    required String Function(T value) labelFor,
    required ValueChanged<T> onSelected,
    double itemHeight = 48,
    double minMenuWidth = 0,
  }) async {
    final anchorContext = anchorKey.currentContext;
    final anchorRenderObject = anchorContext?.findRenderObject();
    final overlay = Overlay.of(context);
    final overlayRenderObject = overlay.context.findRenderObject();
    if (anchorRenderObject is! RenderBox ||
        overlayRenderObject is! RenderBox ||
        !anchorRenderObject.hasSize ||
        !overlayRenderObject.hasSize) {
      return;
    }

    final anchorTopLeft = anchorRenderObject.localToGlobal(
      Offset.zero,
      ancestor: overlayRenderObject,
    );
    final anchorRect = anchorTopLeft & anchorRenderObject.size;
    final overlayRect = Offset.zero & overlayRenderObject.size;
    final screenWidthLimit = overlayRenderObject.size.width - 24;
    // The popup width follows its own field exactly. This keeps the mindset
    // menu inside its control and prevents market/direction menus from
    // spilling beyond their half-width selector columns.
    // [minMenuWidth] keeps short labels such as SELL fully readable when the
    // field is narrower than the text needs; the menu then widens evenly
    // around its field instead of truncating the label.
    final wantedWidth = anchorRenderObject.size.width < minMenuWidth
        ? minMenuWidth
        : anchorRenderObject.size.width;
    final menuWidth =
        wantedWidth > screenWidthLimit ? screenWidthLimit : wantedWidth;
    final widenBy = menuWidth - anchorRect.width;
    final menuAnchorRect = widenBy > 0
        ? Rect.fromLTRB(
            anchorRect.left - widenBy / 2,
            anchorRect.top,
            anchorRect.right + widenBy / 2,
            anchorRect.bottom,
          )
        : anchorRect;

    final selected = await showMenu<T>(
      context: context,
      position: RelativeRect.fromRect(
        menuAnchorRect.shift(const Offset(0, 7)),
        overlayRect,
      ),
      color: tdPopupMenuColor(Theme.of(context).brightness),
      surfaceTintColor: Colors.transparent,
      elevation: 9,
      shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness),
      menuPadding: const EdgeInsets.symmetric(vertical: 5),
      constraints: BoxConstraints.tightFor(width: menuWidth),
      popUpAnimationStyle: tdPopupMenuAnimationStyle,
      items: [
        for (final value in values)
          PopupMenuItem<T>(
            key: ValueKey(
              '$itemKeyPrefix-${value is Enum ? value.name : value.toString()}',
            ),
            value: value,
            height: itemHeight,
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            child: Container(
              width: double.infinity,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(
                color: value == selectedValue
                    ? TdTokens.of(context).accent.withValues(alpha: .11)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  labelFor(value),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  softWrap: false,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: value == selectedValue
                        ? TdTokens.of(context).text1
                        : TdTokens.of(context).text2,
                    fontSize: _tradeDataItemFontSize,
                    fontWeight: value == selectedValue
                        ? FontWeight.w700
                        : FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
      ],
    );

    if (selected != null && mounted) onSelected(selected);
  }

  Widget _compactPopupChoice<T>({
    required Key key,
    required GlobalKey popupAnchorKey,
    required String itemKeyPrefix,
    required String caption,
    TextDirection valueDirection = TextDirection.ltr,
    bool centerContent = false,
    bool enabled = true,
    required T? selectedValue,
    required List<T> values,
    required String Function(T value) labelFor,
    required ValueChanged<T> onSelected,
    double minMenuWidth = 0,
  }) {
    final hasSelectedValue = selectedValue != null;
    final selectedLabel =
        hasSelectedValue ? labelFor(selectedValue as T) : caption;
    final selectedValueKey = hasSelectedValue
        ? '$itemKeyPrefix-${selectedValue is Enum ? selectedValue.name : selectedValue.toString()}-selected-value'
        : null;
    final displayedValue = Text(
      selectedLabel,
      key: selectedValueKey == null ? null : ValueKey(selectedValueKey),
      textAlign: centerContent ? TextAlign.center : TextAlign.start,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      textDirection: hasSelectedValue
          ? valueDirection
          : (_ar ? TextDirection.rtl : TextDirection.ltr),
      style: (hasSelectedValue
              ? Theme.of(context).textTheme.labelMedium
              : Theme.of(context).textTheme.labelSmall)
          ?.copyWith(
        color: hasSelectedValue
            ? TdTokens.of(context).text1
            : TdTokens.of(context).text2,
        fontSize: hasSelectedValue ? _tradeDataItemFontSize : 10.5,
        fontWeight: hasSelectedValue ? FontWeight.w700 : FontWeight.w600,
      ),
    );
    return Opacity(
      opacity: enabled ? 1 : .52,
      child: InkWell(
        key: key,
        borderRadius: BorderRadius.circular(12),
        onTap: enabled
            ? () => _showCompactPopupChoice<T>(
                  anchorKey: popupAnchorKey,
                  values: values,
                  itemKeyPrefix: itemKeyPrefix,
                  selectedValue: selectedValue,
                  labelFor: labelFor,
                  onSelected: onSelected,
                  minMenuWidth: minMenuWidth,
                )
            : null,
        child: SizedBox(
          key: popupAnchorKey,
          height: _tradeDataContentHeight,
          child: Row(
            children: [
              Expanded(
                child: Align(
                  alignment: centerContent
                      ? Alignment.center
                      : AlignmentDirectional.centerStart,
                  child: displayedValue,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final tokens = TdTokens.of(context);
    final softenedTokens = tokens.copyWith(
      lineSubtle: tokens.lineSubtle.withValues(alpha: .68),
      lineStrong: tokens.lineStrong.withValues(alpha: .54),
    );
    final baseTheme = Theme.of(context);
    final formFieldLabelStyle = (baseTheme.textTheme.labelMedium ??
            const TextStyle())
        .copyWith(
      color: tokens.text2,
      fontSize: _tradeFieldLabelFontSize,
      fontWeight: FontWeight.w600,
      height: 1.15,
    );
    final formFieldFloatingLabelStyle = formFieldLabelStyle.copyWith(
      fontSize: _tradeFloatingLabelFontSize,
    );
    final defaultFieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: softenedTokens.lineSubtle, width: 0.78),
    );
    final focusedFieldBorder = defaultFieldBorder.copyWith(
      borderSide: BorderSide(
        color: tokens.accent.withValues(alpha: .78),
        width: 1.05,
      ),
    );
    if (app.accounts.isEmpty) {
      return Scaffold(appBar: AppBar(), body: Center(child: Text(tr(context, 'addFirstAccount'))));
    }
    if (!app.accounts.any((item) => item.id == _accountId)) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    final account = _account ?? app.accounts.first;
    return Theme(
      data: baseTheme.copyWith(
        popupMenuTheme: baseTheme.popupMenuTheme.copyWith(
          color: tdPopupMenuColor(baseTheme.brightness),
          surfaceTintColor: Colors.transparent,
          shape: tdTradeDataPopupMenuShape(baseTheme.brightness),
          textStyle: baseTheme.textTheme.bodySmall?.copyWith(
            fontSize: _tradeDataItemFontSize,
            color: tokens.text1,
          ),
        ),
        dividerColor: softenedTokens.lineSubtle,
        inputDecorationTheme: baseTheme.inputDecorationTheme.copyWith(
          border: defaultFieldBorder,
          enabledBorder: defaultFieldBorder,
          focusedBorder: focusedFieldBorder,
          disabledBorder: defaultFieldBorder,
          labelStyle: formFieldLabelStyle,
          floatingLabelStyle: formFieldFloatingLabelStyle,
        ),
        chipTheme: baseTheme.chipTheme.copyWith(
          side: BorderSide(color: softenedTokens.lineStrong, width: 0.8),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: baseTheme.outlinedButtonTheme.style?.copyWith(
            side: WidgetStatePropertyAll(
              BorderSide(color: softenedTokens.lineStrong, width: 0.8),
            ),
          ),
        ),
        extensions: [softenedTokens],
      ),
      child: Scaffold(
        appBar: AppBar(
          title: Text(tr(context, widget.trade == null ? 'addTrade' : 'editTrade')),
          actions: [
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 14),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: tokens.surface2,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: softenedTokens.lineSubtle,
                      width: 0.8,
                    ),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.account_balance_wallet_outlined, size: 15, color: tokens.text2),
                    const SizedBox(width: 6),
                    ConstrainedBox(constraints: const BoxConstraints(maxWidth: 120), child: Text(account.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.labelMedium)),
                  ]),
                ),
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: Stack(
            children: [
              ListView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 34),
                children: [
                  _sectionCard(
                    context,
                    title: _copy('النتيجة والمخاطرة', 'Result & risk'),
                    icon: Icons.query_stats_outlined,
                    tone: _resultTone,
                    gradientColors: const [Color(0xFF343D4A), Color(0xFF29323E), Color(0xFF222B36), Color(0xFF181F29)],
                    borderTone: const Color(0xFF5B6471),
                    children: [
                      Row(children: [
                        Expanded(child: _resultAmountField(suffix: account.currency)),
                        const SizedBox(width: 10),
                        Expanded(child: _numericField(controller: _expectedLoss, key: const ValueKey('trade-expected-loss-input'), label: _copy('الخسارة المتوقعة', 'Expected loss'), suffix: account.currency, validator: _expectedLossValidator, readOnly: (_parseResult() ?? 0) < 0, onChanged: (_) => setState(_updateComputedFields))),
                      ]),
                      const SizedBox(height: 12),
                      Row(children: [
                        Expanded(child: _readoutField(controller: _risk, key: const ValueKey('trade-risk-input'), label: _copy('نسبة المخاطرة', 'Risk %'), suffix: '%')),
                        const SizedBox(width: 10),
                        Expanded(child: _readoutField(controller: _rewardRisk, key: const ValueKey('trade-reward-risk-input'), label: _copy('العائد / المخاطرة', 'Reward / risk'), suffix: 'R')),
                      ]),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _sectionCard(
                    context,
                    title: _copy('بيانات الصفقة', 'Trade details'),
                    icon: Icons.receipt_long_outlined,
                    tone: _dataTone,
                    gradientColors: const [Color(0xFF123C75), Color(0xFF0F3166), Color(0xFF0B2750), Color(0xFF071529)],
                    borderTone: const Color(0xFF2B64A6),
                    tint: .15,
                    children: [
                      LayoutBuilder(
                        builder: (context, constraints) {
                          // Pair market/direction with mindset in equal columns;
                          // the multi-row anchor selector sits full-width below.
                          const identifierGap = 8.0;
                          final marketControlWidth =
                              (constraints.maxWidth - identifierGap) / 2;
                          return SizedBox(
                            key: const ValueKey('trade-entry-identifiers-available'),
                            width: constraints.maxWidth,
                            child: SizedBox(
                              key: const ValueKey('trade-entry-identifiers-row'),
                              width: constraints.maxWidth,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: marketControlWidth,
                                    child: SizedBox(
                                      height: _tradeDataControlHeight,
                                      child: InputDecorator(
                                        key: const ValueKey('trade-market-direction-field'),
                                        decoration: _blueSelectorDecoration(
                                          label: _copy('السوق / الاتجاه', 'Market / Direction'),
                                          labelWidget: Row(
                                            key: const ValueKey('trade-market-direction-label'),
                                            textDirection: _ar
                                                ? TextDirection.rtl
                                                : TextDirection.ltr,
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  _copy('السوق', 'Market'),
                                                  textAlign: TextAlign.center,
                                                  textDirection: _ar
                                                      ? TextDirection.rtl
                                                      : TextDirection.ltr,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .labelMedium
                                                      ?.copyWith(
                                                        color: TdTokens.of(context).text2,
                                                        fontSize: _tradeFloatingLabelFontSize,
                                                        fontWeight: FontWeight.w600,
                                                        height: 1.15,
                                                      ),
                                                ),
                                              ),
                                              Text(
                                                '/',
                                                key: const ValueKey(
                                                  'trade-market-direction-label-divider',
                                                ),
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .labelMedium
                                                    ?.copyWith(
                                                      color: TdTokens.of(context).text2,
                                                      fontSize: _tradeFloatingLabelFontSize,
                                                      fontWeight: FontWeight.w600,
                                                      height: 1.15,
                                                    ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  _copy('الاتجاه', 'Direction'),
                                                  textAlign: TextAlign.center,
                                                  textDirection: _ar
                                                      ? TextDirection.rtl
                                                      : TextDirection.ltr,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .labelMedium
                                                      ?.copyWith(
                                                        color: TdTokens.of(context).text2,
                                                        fontSize: _tradeFloatingLabelFontSize,
                                                        fontWeight: FontWeight.w600,
                                                        height: 1.15,
                                                      ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          floatingLabelAlignment:
                                              FloatingLabelAlignment.center,
                                          contentPadding: const EdgeInsetsDirectional.fromSTEB(10, 8, 10, 8),
                                        ),
                                        isEmpty: false,
                                        child: Row(
                                          key: const ValueKey(
                                            'trade-market-direction-choices-row',
                                          ),
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            Expanded(
                                              child: _compactPopupChoice<String>(
                                                key: const ValueKey(
                                                  'trade-market-input',
                                                ),
                                                popupAnchorKey:
                                                    _marketPopupAnchorKey,
                                                itemKeyPrefix:
                                                    'trade-market-option',
                                                caption: _copy('الرمز', 'Symbol'),
                                                centerContent: true,
                                                enabled: _hasTradeDirection,
                                                valueDirection: TextDirection.ltr,
                                                selectedValue: _symbol,
                                                values: const ['NQ', 'ES', 'GC'],
                                                labelFor: (value) => value,
                                                minMenuWidth: _shortChoiceMenuWidth,
                                                onSelected: (value) => setState(
                                                  () => _symbol = value,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 1,
                                              height: _tradeDataContentHeight,
                                              child: DecoratedBox(
                                                key: const ValueKey(
                                                  'trade-market-direction-divider',
                                                ),
                                                decoration: BoxDecoration(
                                                  color: TdTokens.of(context)
                                                      .accent
                                                      .withValues(alpha: .38),
                                                  borderRadius:
                                                      BorderRadius.circular(1),
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              child: _compactPopupChoice<TradeSide>(
                                                key: const ValueKey(
                                                  'trade-direction-selector',
                                                ),
                                                popupAnchorKey:
                                                    _directionPopupAnchorKey,
                                                itemKeyPrefix:
                                                    'trade-direction-option',
                                                caption: _copy(
                                                  'الاتجاه',
                                                  'Direction',
                                                ),
                                                centerContent: true,
                                                  enabled: true,
                                                valueDirection: _ar
                                                    ? TextDirection.rtl
                                                    : TextDirection.ltr,
                                                selectedValue: _side,
                                                values: TradeSide.values,
                                                labelFor: (value) => tr(
                                                  context,
                                                  value == TradeSide.buy
                                                      ? 'buy'
                                                      : 'sell',
                                                ),
                                                minMenuWidth: _shortChoiceMenuWidth,
                                                onSelected: (value) => setState(
                                                  () => _side = _side == value ? null : value,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: identifierGap),
                                  SizedBox(
                                    width: marketControlWidth,
                                    child: _buildMindsetSelector(
                                      enabled: _hasTradeDirection,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 12),
                      _setupSelectionField(
                        title: _copy('سبب الدخول', 'Entry reason'),
                        enabled: _hasTradeDirection,
                        setups: _entrySetups
                            .map((item) => (
                                  label: formatTradeEntryReasonLabel(
                                    reason: item.reason,
                                    side: _side,
                                  ),
                                  timeframe: item.timeframe,
                                  item: item,
                                ))
                            .toList(),
                        onAdd: _addEntrySetup,
                        onRemove: (item) => _removeEntrySetup(item as TradeEntrySetup),
                        onEdit: (item) => _editEntrySetup(item as TradeEntrySetup),
                        fieldKey: const ValueKey('add-entry-setup'),
                        fieldId: 'entry-reason',
                        surfaceKey: const ValueKey('entry-reason-field-surface'),
                        decoratorKey: const ValueKey('entry-reason-field-input'),
                      ),
                      const SizedBox(height: 12),
                      _anchorMultiSelector(),
                      const SizedBox(height: 12),
                      _setupSelectionField(
                        title: _copy('تأكيد الدخول', 'Entry confirmation'),
                        enabled: _hasTradeDirection,
                        setups: _confirmationSetups
                            .map((item) => (
                                  label: _confirmationLabel(item.type),
                                  timeframe: item.timeframe,
                                  item: item,
                                ))
                            .toList(),
                        onAdd: _addConfirmationSetup,
                        onRemove: (item) => _removeConfirmationSetup(item as TradeConfirmationSetup),
                        onEdit: (item) => _editConfirmationSetup(item as TradeConfirmationSetup),
                        fieldKey: const ValueKey('add-confirmation-setup'),
                        fieldId: 'confirmation',
                        surfaceKey: const ValueKey('confirmation-field-surface'),
                        decoratorKey: const ValueKey('confirmation-field-input'),
                      ),
                      const SizedBox(height: 14),
                      Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: Semantics(
                          label: _copy(
                            'تاريخ / الوقت: ${_formattedTradeDateTime(context)}',
                            'Date / time: ${_formattedTradeDateTime(context)}',
                          ),
                          button: true,
                          child: Tooltip(
                            message: _copy('تاريخ / الوقت', 'Date / time'),
                            child: OutlinedButton(
                              key: const ValueKey('trade-date-time-picker-button'),
                              onPressed: _hasTradeDirection ? _pickDateTime : null,
                              style: OutlinedButton.styleFrom(
                                minimumSize: const Size(136, 48),
                                padding: const EdgeInsetsDirectional.symmetric(
                                  horizontal: 12,
                                  vertical: 10,
                                ),
                                foregroundColor: tokens.text2,
                                backgroundColor: Colors.transparent,
                                side: BorderSide(
                                  color: tokens.lineStrong.withValues(alpha: .55),
                                  width: .8,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    _copy('تاريخ / الوقت', 'Date / time'),
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelMedium
                                        ?.copyWith(
                                          color: tokens.text2,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                  const SizedBox(width: 9),
                                  Flexible(
                                    child: Text(
                                      _formattedTradeDateTime(context),
                                      key: const ValueKey('trade-date-time-value'),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      textDirection: TextDirection.ltr,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: tokens.text1,
                                            fontWeight: FontWeight.w700,
                                          ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _buildLinkedEntryBehaviorSections(context),
                  const SizedBox(height: 14),
                  _sectionCard(
                    context,
                    title: _copy('صور الصفقة', 'Trade images'),
                    icon: Icons.photo_library_outlined,
                    tone: _imagesTone,
                    gradientColors: const [Color(0xFF232A33), Color(0xFF1A2029), Color(0xFF141920)],
                    borderTone: const Color(0xFF626B74),
                    children: [
                      Row(children: [
                        Expanded(child: ImageAttachmentTile(label: _copy('قبل الدخول', 'Before entry'), path: _beforePath, onTap: () => _pickImage(_TradeImageSlot.before), onRemove: _beforePath == null ? null : () => setState(() => _beforePath = null))),
                        const SizedBox(width: 10),
                        Expanded(child: ImageAttachmentTile(label: _copy('بعد الدخول', 'After entry'), path: _afterPath, onTap: () => _pickImage(_TradeImageSlot.after), onRemove: _afterPath == null ? null : () => setState(() => _afterPath = null))),
                      ]),
                      const SizedBox(height: 12),
                      ImageAttachmentTile(key: const ValueKey('confirmation-image-attachment'), label: _copy('تأكيد الدخول', 'Entry confirmation'), path: _confirmationImagePath, onTap: () => _pickImage(_TradeImageSlot.confirmation), onRemove: _confirmationImagePath == null ? null : () => setState(() => _confirmationImagePath = null)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  if (_classification == null)
                    OutlinedButton.icon(
                      key: const ValueKey('choose-trade-classification-button'),
                      onPressed: _busy ? null : _chooseClassification,
                      icon: const Icon(Icons.tune_rounded, size: 19),
                      label: Text(tr(context, 'classifyTrade')),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                        backgroundColor: tokens.surface2,
                        foregroundColor: tokens.text1,
                        side: BorderSide(color: tokens.lineStrong.withValues(alpha: .72), width: .9),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                    )
                  else ...[
                    Row(
                      children: [
                        Expanded(
                          child: _classification == TradeClassification.missed
                              ? Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Flexible(
                                      child: Text(
                                        '${tr(context, 'tradeClassification')}: ',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context).textTheme.labelMedium?.copyWith(
                                          color: tokens.text2,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                    _buildMissedOutcomeChip(tokens),
                                  ],
                                )
                              : _classification == TradeClassification.breakEven &&
                                      _breakEvenType != null
                                  ? Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Flexible(
                                          child: Text(
                                            '${tr(context, 'tradeClassification')}: ${_classificationLabel(_classification!)}',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: Theme.of(context).textTheme.labelMedium?.copyWith(
                                              color: tokens.text2,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        _buildBreakEvenTypeChip(tokens),
                                      ],
                                    )
                                  : Text(
                                      '${tr(context, 'tradeClassification')}: ${_classificationLabel(_classification!)}',
                                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                                        color: tokens.text2,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                        ),
                        TextButton(
                          key: const ValueKey('change-trade-classification-button'),
                          onPressed: _busy ? null : _chooseClassification,
                          style: TextButton.styleFrom(
                            foregroundColor: tokens.text2,
                            visualDensity: VisualDensity.compact,
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          ),
                          child: Text(tr(context, 'changeClassification')),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    // One fixed slot: the save button's usual place. Until a
                    // break-even subtype exists it holds the prompt that
                    // reopens the popup; afterwards the save button returns.
                    SizedBox(
                      key: _saveSlotKey,
                      height: 52,
                      child: _classification == TradeClassification.breakEven &&
                              _breakEvenType == null
                          ? OutlinedButton.icon(
                              key: const ValueKey('choose-break-even-type-button'),
                              onPressed: _busy ? null : _chooseBreakEvenType,
                              icon: const Icon(Icons.unfold_more_rounded, size: 19),
                              label: Text(_copy('اختر نوع التعادل', 'Choose break-even type')),
                              style: OutlinedButton.styleFrom(
                                minimumSize: const Size.fromHeight(52),
                                backgroundColor: tokens.surface2,
                                foregroundColor: tokens.text1,
                                side: BorderSide(
                                  color: TradeOutcomePalette.breakEven(
                                    Theme.of(context).brightness,
                                  ).withValues(alpha: .62),
                                  width: .9,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                            )
                          : FilledButton.icon(
                              key: const ValueKey('save-trade-button'),
                              onPressed: _busy ? null : _save,
                              icon: _busy
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : const Icon(Icons.save_outlined),
                              label: Text(tr(context, 'save')),
                              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                            ),
                    ),
                  ],
                ],
              ),
              if (_busy) Positioned.fill(child: ColoredBox(color: tokens.scrim.withValues(alpha: .26), child: const Center(child: CircularProgressIndicator()))),
            ],
          ),
        ),
      ),
    );
  }

  String _confirmationLabel(String type) {
    final displayKey = tradeConfirmationDisplayKey(type: type, side: _side);
    if (displayKey == 'confirmBullishEngulfing') return 'Bullish Engulfing';
    if (displayKey == 'confirmBearishEngulfing') return 'Bearish Engulfing';
    if (displayKey == 'confirmEngulfing') return 'Engulfing';
    final known = tradeConfirmationOptions
        .where((item) => item.key == displayKey)
        .firstOrNull;
    if (known != null) return _ar ? known.ar : known.en;
    return type;
  }

  Widget _sectionCard(
    BuildContext context, {
    Key? key,
    required String title,
    required IconData icon,
    required List<Widget> children,
    Color? tone,
    Color? borderTone,
    List<Color>? gradientColors,
    double tint = .10,
    double bodyHorizontalPadding = 16,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // A smaller body padding widens the section's content; the header keeps
    // its original inset so the title does not move.
    final headerInset = 16 - bodyHorizontalPadding;
    final headerRow = Row(children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: tone == null ? tokens.surface3 : tone.withValues(alpha: isDark ? .16 : .11),
            borderRadius: BorderRadius.circular(10),
            border: tone == null ? null : Border.all(color: tone.withValues(alpha: .14), width: 0.8),
          ),
          child: Icon(icon, size: 18, color: tone ?? tokens.accent),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
      ]);
    final content = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      headerInset == 0
          ? headerRow
          : Padding(padding: EdgeInsets.symmetric(horizontal: headerInset), child: headerRow),
      const SizedBox(height: 16),
      ...children,
    ]);

    if (tone == null) {
      return AppCard(padding: const EdgeInsets.all(16), sheen: false, child: content);
    }
    Widget sectionContent = content;
    if (identical(tone, _dataTone) || tone == _dataTone) {
      final baseTheme = Theme.of(context);
      final fieldFill = isDark
          ? const Color(0xFF071834)
          : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);
      final fieldBorder = OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(
          color: isDark
              ? const Color(0xFF21405B).withValues(alpha: .52)
              : tokens.lineSubtle.withValues(alpha: .68),
          width: 0.78,
        ),
      );
      final sectionFieldLabelStyle = baseTheme.textTheme.labelMedium?.copyWith(
        color: tokens.text2,
        fontSize: _tradeFieldLabelFontSize,
        fontWeight: FontWeight.w600,
        height: 1.15,
      );
      final sectionFieldFloatingLabelStyle = sectionFieldLabelStyle?.copyWith(
        fontSize: _tradeFloatingLabelFontSize,
      );
      sectionContent = Theme(
        data: baseTheme.copyWith(
          inputDecorationTheme: baseTheme.inputDecorationTheme.copyWith(
            filled: true,
            fillColor: fieldFill,
            enabledBorder: fieldBorder,
            border: fieldBorder,
            focusedBorder: fieldBorder.copyWith(
              borderSide: BorderSide(
                color: _dataTone.withValues(alpha: .78),
                width: 1.05,
              ),
            ),
            labelStyle: sectionFieldLabelStyle,
            floatingLabelStyle: sectionFieldFloatingLabelStyle,
          ),
        ),
        child: content,
      );
    }
    final neutralSurface = tone == _resultTone || tone == _imagesTone;
    return Container(
      key: key,
      padding: EdgeInsets.fromLTRB(bodyHorizontalPadding, 16, bodyHorizontalPadding, 16),
      decoration: BoxDecoration(
        color: Color.alphaBlend(tone.withValues(alpha: isDark ? tint : tint * .58), tokens.surface1),
        gradient: !isDark || gradientColors == null
            ? null
            : neutralSurface
                ? LinearGradient(
                    begin: AlignmentDirectional.topStart,
                    end: AlignmentDirectional.bottomEnd,
                    colors: [tokens.surface2, tokens.surface1],
                  )
                : LinearGradient(
                    begin: AlignmentDirectional.topStart,
                    end: AlignmentDirectional.bottomEnd,
                    colors: gradientColors,
                    stops: gradientColors.length == 4
                        ? const [0, .32, .68, 1]
                        : null,
                  ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: neutralSurface && isDark
              ? tokens.lineSubtle
              : (borderTone ?? tone).withValues(alpha: isDark ? .17 : .13),
          width: 0.8,
        ),
      ),
      child: sectionContent,
    );
  }

  Widget _resultSignChoiceButton(int sign) {
    final tokens = TdTokens.of(context);
    final positive = sign > 0;
    return Material(
      color: tokens.surface2,
      borderRadius: BorderRadius.circular(7),
      child: InkWell(
        key: ValueKey(
          positive ? 'trade-result-sign-positive' : 'trade-result-sign-negative',
        ),
        borderRadius: BorderRadius.circular(7),
        onTap: () => _selectResultSign(sign),
        child: SizedBox(
          width: 29,
          height: 30,
          child: Center(
            child: Text(
              positive ? '+' : '−',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: tokens.text2,
                    fontWeight: FontWeight.w700,
                    height: 1,
                  ),
            ),
          ),
        ),
      ),
    );
  }

  Widget? _resultSignPrefix() {
    if (_resultSign != null ||
        !_showResultSignChoices ||
        _hasEntryConditionsNoEntryLink) {
      return null;
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _resultSignChoiceButton(1),
        const SizedBox(width: 5),
        _resultSignChoiceButton(-1),
        const SizedBox(width: 7),
      ],
    );
  }

  Widget _resultAmountField({required String suffix}) => TextFormField(
        key: const ValueKey('trade-result-input'),
        controller: _result,
        focusNode: _resultFocusNode,
        validator: _resultValidator,
        readOnly: _resultSign == null || _hasEntryConditionsNoEntryLink,
        onTap: () {
          if (_resultSign == null && !_hasEntryConditionsNoEntryLink) {
            setState(() => _showResultSignChoices = true);
          }
        },
        keyboardType: const TextInputType.numberWithOptions(
          decimal: true,
          signed: true,
        ),
        inputFormatters: [
          TextInputFormatter.withFunction((oldValue, newValue) {
            // Allow one optional leading sign. Because it is part of the
            // controller text, the trader can delete it with the keyboard.
            final valid = RegExp(r'^[+\-−]?[0-9]*[.,]?[0-9]*$');
            return valid.hasMatch(newValue.text) ? newValue : oldValue;
          }),
        ],
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.start,
        onChanged: _handleResultChanged,
        decoration: InputDecoration(
          labelText: _copy('الربح / الخسارة', 'Profit / loss'),
          // The +/− character is editable as part of the numeric text. The
          // currency stays on the opposite edge in both Arabic and English.
          prefix: _ar ? null : _resultSignPrefix(),
          prefixText: _ar ? suffix : null,
          suffix: _ar ? _resultSignPrefix() : null,
          suffixText: _ar ? null : suffix,
        ),
      );

  Widget _numericField({required TextEditingController controller, required Key key, required String label, required String suffix, required String? Function(String?) validator, bool signed = false, bool readOnly = false, ValueChanged<String>? onChanged}) => TextFormField(
        key: key,
        controller: controller,
        validator: validator,
        readOnly: readOnly,
        onChanged: onChanged,
        keyboardType: TextInputType.numberWithOptions(decimal: true, signed: signed),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.start,
        decoration: InputDecoration(labelText: label, suffixText: suffix),
      );

  Widget _readoutField({required TextEditingController controller, required Key key, required String label, required String suffix}) => TextFormField(
        key: key,
        controller: controller,
        readOnly: true,
        textDirection: TextDirection.ltr,
        decoration: InputDecoration(labelText: label, suffixText: suffix, filled: true, fillColor: TdTokens.of(context).inset),
      );

  Widget _fieldLabel(String label) => Text(label, style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w700));

  List<String> get _orderedAnchorKeys {
    final known = tradeAnchorOptions
        .where((option) => _anchors.contains(option.key))
        .map((option) => option.key);
    final knownSet = known.toSet();
    final legacyOrUnknown = _anchors.where((key) => !knownSet.contains(key));
    return [...known, ...legacyOrUnknown].toList(growable: false);
  }

  String _anchorSelectionLabel(String anchorKey) => formatTradeAnchorLabel(
        anchorKey: anchorKey,
        arabic: _ar,
        side: _side,
      );

  String? _selectedAnchorStorageKey(String optionKey, Set<String> selected) {
    if (selected.contains(optionKey)) return optionKey;
    if (optionKey == 'zoneSd') {
      // Old trades may contain the two former concrete choices. Treat the
      // direction-matching legacy key as the selected Zone S/D row.
      final preferredLegacyKey = _side == TradeSide.buy
          ? 'demandZone'
          : _side == TradeSide.sell
              ? 'supplyZone'
              : 'demandZone';
      if (selected.contains(preferredLegacyKey)) return preferredLegacyKey;
      if (selected.contains('demandZone')) return 'demandZone';
      if (selected.contains('supplyZone')) return 'supplyZone';
    }
    if (optionKey == 'engulfing') {
      // Existing trades keep their historical concrete anchor label, but
      // both keys are represented by the single Engulfing picker row.
      final preferredLegacyKey = _side == TradeSide.buy
          ? 'bullishEngulfing'
          : _side == TradeSide.sell
              ? 'bearishEngulfing'
              : 'bullishEngulfing';
      if (selected.contains(preferredLegacyKey)) return preferredLegacyKey;
      if (selected.contains('bullishEngulfing')) return 'bullishEngulfing';
      if (selected.contains('bearishEngulfing')) return 'bearishEngulfing';
    }
    return null;
  }

  String _anchorTimeframeContextLabel(String anchorKey) =>
      '${_copy('الارتكاز', 'Anchor')} · ${_anchorSelectionLabel(anchorKey)}';

  Future<void> _pickAnchors() async {
    if (!_hasTradeDirection) return;
    final selected = {..._anchors};
    final brightness = Theme.of(context).brightness;
    final tokens = TdTokens.of(context);
    final screen = MediaQuery.sizeOf(context);
    final dialogWidth = (screen.width - 56).clamp(240.0, 360.0).toDouble();
    final dialogMaxHeight =
        (screen.height * .68).clamp(220.0, 560.0).toDouble();

    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => Dialog(
          key: const ValueKey('trade-centered-multi-choice-anchor'),
          backgroundColor: tdPopupMenuColor(brightness),
          surfaceTintColor: Colors.transparent,
          elevation: 9,
          shape: tdTradeDataPopupMenuShape(brightness),
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: SizedBox(
            width: dialogWidth,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: dialogMaxHeight),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 13, 12, 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(5, 0, 5, 10),
                      child: Text(
                        _copy('الارتكاز', 'Anchor'),
                        style: Theme.of(dialogContext)
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              color: tokens.text1,
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: tdTradeDataPopupMenuBorderColor(brightness)
                          .withValues(alpha: .48),
                    ),
                    const SizedBox(height: 5),
                    Flexible(
                      child: ListView.separated(
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        itemCount: tradeAnchorOptions.length,
                        separatorBuilder: (_, _) =>
                            const SizedBox(height: 2),
                        itemBuilder: (itemContext, index) {
                          final option = tradeAnchorOptions[index];
                          final selectedStorageKey =
                              _selectedAnchorStorageKey(option.key, selected);
                          final isSelected = selectedStorageKey != null;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 1),
                            child: ListTile(
                              key: ValueKey(
                                'trade-anchor-option-${option.key}',
                              ),
                              minTileHeight: 48,
                              minVerticalPadding: 8,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 11,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9),
                              ),
                              selected: isSelected,
                              selectedTileColor:
                                  tokens.accent.withValues(alpha: .09),
                              title: Text(
                                _ar ? option.ar : option.en,
                                softWrap: true,
                                style: Theme.of(itemContext)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: tokens.text1,
                                      fontSize: _tradeDataItemFontSize,
                                      fontWeight: isSelected
                                          ? FontWeight.w700
                                          : FontWeight.w500,
                                    ),
                              ),
                              trailing: Icon(
                                isSelected
                                    ? Icons.check_circle_rounded
                                    : Icons.chevron_left_rounded,
                                size: 18,
                                color: isSelected
                                    ? tokens.accent
                                    : tokens.text3,
                              ),
                              onTap: () async {
                                if (isSelected) {
                                  // Older saved anchors can lack a timeframe.
                                  // Complete that metadata instead of silently
                                  // removing the anchor on the first tap.
                                  final storageKey = selectedStorageKey!;
                                  if (_anchorTimeframes[storageKey] == null) {
                                    final timeframe = await _showTimeframeSheet(
                                      contextLabel:
                                          _anchorTimeframeContextLabel(option.key),
                                    );
                                    if (timeframe == null || !mounted) return;
                                    final equivalentKeys = option.key == 'zoneSd'
                                        ? <String>{'zoneSd', 'supplyZone', 'demandZone'}
                                        : option.key == 'engulfing'
                                            ? <String>{'engulfing', 'bullishEngulfing', 'bearishEngulfing'}
                                            : <String>{storageKey};
                                    setDialogState(() {
                                      selected.removeAll(equivalentKeys);
                                      selected.add(option.key);
                                    });
                                    setState(() {
                                      _anchors.removeAll(equivalentKeys);
                                      for (final key in equivalentKeys) {
                                        _anchorTimeframes.remove(key);
                                      }
                                      _anchors.add(option.key);
                                      _anchorTimeframes[option.key] = timeframe;
                                    });
                                  } else {
                                    final keysToRemove = option.key == 'zoneSd'
                                        ? <String>{'zoneSd', 'supplyZone', 'demandZone'}
                                        : option.key == 'engulfing'
                                            ? <String>{'engulfing', 'bullishEngulfing', 'bearishEngulfing'}
                                            : <String>{storageKey};
                                    setDialogState(
                                      () => selected.removeAll(keysToRemove),
                                    );
                                    if (mounted) {
                                      setState(() {
                                        _anchors.removeAll(keysToRemove);
                                        for (final key in keysToRemove) {
                                          _anchorTimeframes.remove(key);
                                        }
                                      });
                                    }
                                  }
                                  return;
                                }

                                final timeframe = await _showTimeframeSheet(
                                  contextLabel:
                                      _anchorTimeframeContextLabel(option.key),
                                );
                                if (timeframe == null || !mounted) return;
                                setDialogState(
                                  () => selected.add(option.key),
                                );
                                setState(() {
                                  if (option.key == 'zoneSd') {
                                    _anchors.removeAll({'supplyZone', 'demandZone'});
                                    _anchorTimeframes.remove('supplyZone');
                                    _anchorTimeframes.remove('demandZone');
                                  } else if (option.key == 'engulfing') {
                                    _anchors.removeAll({'bullishEngulfing', 'bearishEngulfing'});
                                    _anchorTimeframes.remove('bullishEngulfing');
                                    _anchorTimeframes.remove('bearishEngulfing');
                                  }
                                  _anchors.add(option.key);
                                  _anchorTimeframes[option.key] = timeframe;
                                });
                              },
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _editAnchorTimeframe(String anchorKey) async {
    if (!_hasTradeDirection) return;
    final timeframe = await _showTimeframeSheet(
      contextLabel: _anchorTimeframeContextLabel(anchorKey),
      selectedFrame: _anchorTimeframes[anchorKey],
    );
    if (timeframe == null || !mounted) return;
    setState(() => _anchorTimeframes[anchorKey] = timeframe);
  }

  void _removeAnchor(String anchorKey) {
    if (!_hasTradeDirection) return;
    setState(() {
      _anchors.remove(anchorKey);
      _anchorTimeframes.remove(anchorKey);
    });
  }

  Widget _anchorMultiSelector() {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectedKeys = _orderedAnchorKeys;
    final dataFieldFill = isDark
        ? const Color(0xFF071834)
        : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);

    return Opacity(
      opacity: _hasTradeDirection ? 1 : .52,
      child: KeyedSubtree(
        key: const ValueKey('trade-anchor-selector'),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
          key: _anchorMenuAnchorKey,
          onTap: _hasTradeDirection ? _pickAnchors : null,
          borderRadius: BorderRadius.circular(14),
          child: InputDecorator(
            key: const ValueKey('trade-anchor-field-input'),
            decoration: _blueSelectorDecoration(
              label: _copy('الارتكاز', 'Anchor'),
              tone: _dataTone,
              fillColorOverride: dataFieldFill,
              floatingLabelAlignment: FloatingLabelAlignment.start,
              trailingIcon: Icons.keyboard_arrow_down_rounded,
              contentPadding: const EdgeInsetsDirectional.fromSTEB(
                12,
                14,
                10,
                12,
              ),
            ),
            isEmpty: selectedKeys.isEmpty,
            child: selectedKeys.isEmpty
                ? const SizedBox(height: 30)
                : Column(
                    key: const ValueKey('trade-anchor-selected-values'),
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      for (var index = 0; index < selectedKeys.length; index++) ...[
                        if (index > 0)
                          Divider(
                            height: 8,
                            thickness: .6,
                            color: _dataTone.withValues(alpha: .22),
                          ),
                        Builder(
                          builder: (rowContext) {
                            final anchorKey = selectedKeys[index];
                            final label = _anchorSelectionLabel(anchorKey);
                            final timeframe = _anchorTimeframes[anchorKey];
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Material(
                                    color: Colors.transparent,
                                    child: InkWell(
                                      key: ValueKey(
                                        'trade-anchor-value-$anchorKey',
                                      ),
                                      borderRadius: BorderRadius.circular(6),
                                      onTap: _hasTradeDirection
                                          ? () => _editAnchorTimeframe(anchorKey)
                                          : null,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: 6,
                                        ),
                                        child: Text(
                                          timeframe == null
                                              ? label
                                              : '$label $timeframe',
                                          softWrap: true,
                                          textAlign: _ar
                                              ? TextAlign.right
                                              : TextAlign.left,
                                          textDirection: TextDirection.ltr,
                                          style: Theme.of(rowContext)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: tokens.text1,
                                                fontSize: _tradeDataItemFontSize,
                                                fontWeight: FontWeight.w700,
                                                height: 1.35,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                IconButton(
                                  key: ValueKey(
                                    'trade-anchor-remove-$anchorKey',
                                  ),
                                  tooltip: _copy(
                                    'حذف الارتكاز',
                                    'Remove anchor',
                                  ),
                                  visualDensity: VisualDensity.compact,
                                  constraints: const BoxConstraints.tightFor(
                                    width: 32,
                                    height: 32,
                                  ),
                                  padding: EdgeInsets.zero,
                                  onPressed: _hasTradeDirection
                                      ? () => _removeAnchor(anchorKey)
                                      : null,
                                  icon: Icon(
                                    Icons.close_rounded,
                                    size: 16,
                                    color: tokens.text3,
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ],
                  ),
          ),
          ),
        ),
      ),
    );
  }

  Widget _buildMindsetSelector({required bool enabled}) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mood = tradeMoodOptions.firstWhere(
          (item) => item.key == _mood,
          orElse: () => tradeMoodOptions.firstWhere(
            (item) => item.key == 'moodUnknown',
          ),
        );
        final popupWidth = constraints.maxWidth < 180
            ? 180.0
            : constraints.maxWidth;

        // Keep the exact 1.7.92+148 reference hierarchy: PopupMenuButton owns
        // the entire field hit target; its child is the fixed 72dp SizedBox,
        // whose InputDecorator is laid out directly beside Market/Direction.
        return PopupMenuButton<String>(
          key: const ValueKey('trade-mood-dropdown'),
          enabled: enabled,
          tooltip: _copy('الحالة النفسية', 'Mindset'),
          padding: EdgeInsets.zero,
          position: PopupMenuPosition.under,
          popUpAnimationStyle: tdPopupMenuAnimationStyle,
          color: tdPopupMenuColor(Theme.of(context).brightness),
          surfaceTintColor: Colors.transparent,
          elevation: 9,
          shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness),
          menuPadding: const EdgeInsets.symmetric(vertical: 5),
          constraints: BoxConstraints.tightFor(width: popupWidth),
          onSelected: (value) => setState(() => _mood = value),
          itemBuilder: (menuContext) => [
            for (final item in tradeMoodOptions)
              PopupMenuItem<String>(
                key: ValueKey('trade-mood-option-${item.key}'),
                value: item.key,
                height: 42,
                padding: const EdgeInsets.symmetric(
                  horizontal: 7,
                  vertical: 2,
                ),
                child: Container(
                  width: double.infinity,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: item.key == _mood
                        ? TdTokens.of(menuContext).accent.withValues(alpha: .11)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _ar ? item.ar : item.en,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(menuContext).textTheme.bodySmall?.copyWith(
                      color: item.key == _mood
                          ? TdTokens.of(menuContext).text1
                          : TdTokens.of(menuContext).text2,
                      fontSize: _tradeDataItemFontSize,
                      fontWeight: item.key == _mood
                          ? FontWeight.w700
                          : FontWeight.w500,
                    ),
                  ),
                ),
              ),
          ],
          child: SizedBox(
            key: const ValueKey('trade-mood-field'),
            height: _tradeDataControlHeight,
            child: InputDecorator(
              key: const ValueKey('trade-mood-field-surface'),
              decoration: _blueSelectorDecoration(
                label: _copy('الحالة النفسية', 'Mindset'),
                contentPadding: const EdgeInsetsDirectional.fromSTEB(
                  10,
                  8,
                  10,
                  8,
                ),
              ),
              isEmpty: false,
              child: Opacity(
                // As in the reference selector, disabling dims only the
                // content; the outline and fill keep their original geometry.
                opacity: enabled ? 1 : .52,
                child: SizedBox(
                  key: const ValueKey('trade-mood-content'),
                  // Same inner height as the Market / Direction content row,
                  // so the painted rectangle is identical in height.
                  height: _tradeDataContentHeight,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: Text(
                            _ar ? mood.ar : mood.en,
                            key: const ValueKey('trade-mood-selected-value'),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: _mood == 'moodUnknown'
                                  ? TdTokens.of(context).text2
                                  : TdTokens.of(context).text1,
                              fontSize: _tradeDataItemFontSize,
                              fontWeight: _mood == 'moodUnknown'
                                  ? FontWeight.w600
                                  : FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      Icon(
                        Icons.keyboard_arrow_down_rounded,
                        size: 18,
                        color: TdTokens.of(context).text3,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _setupSelectionField({
    required String title,
    required bool enabled,
    required List<({String label, String timeframe, Object item})> setups,
    required Future<void> Function() onAdd,
    required void Function(Object) onRemove,
    required void Function(Object) onEdit,
    required Key fieldKey,
    required String fieldId,
    required Key surfaceKey,
    required Key decoratorKey,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final hasSelection = setups.isNotEmpty;
    final dataFieldFill = isDark
        ? const Color(0xFF071834)
        : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);

    return Opacity(
      opacity: enabled ? 1 : .52,
      child: Container(
        key: surfaceKey,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            key: fieldKey,
            onTap: enabled ? onAdd : null,
            borderRadius: BorderRadius.circular(14),
            child: InputDecorator(
            key: decoratorKey,
            decoration: _blueSelectorDecoration(
              label: title,
              tone: _dataTone,
              fillColorOverride: dataFieldFill,
              floatingLabelAlignment: FloatingLabelAlignment.start,
              trailingIcon: Icons.keyboard_arrow_down_rounded,
              contentPadding: const EdgeInsetsDirectional.fromSTEB(
                12,
                14,
                10,
                12,
              ),
            ),
            isEmpty: !hasSelection,
            child: hasSelection
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      for (var index = 0; index < setups.length; index++) ...[
                        if (index > 0)
                          Divider(
                            height: 8,
                            thickness: .6,
                            color: _dataTone.withValues(alpha: .22),
                          ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  key: ValueKey(
                                    'trade-setup-edit-$fieldId-$index',
                                  ),
                                  borderRadius: BorderRadius.circular(6),
                                  onTap: enabled
                                      ? () => onEdit(setups[index].item)
                                      : null,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 5,
                                    ),
                                    child: Text(
                                      '${setups[index].label} ${setups[index].timeframe.isEmpty ? _copy('دون فريم', 'No timeframe') : setups[index].timeframe}',
                                      key: ValueKey(
                                        'trade-setup-value-$fieldId-$index',
                                      ),
                                      softWrap: true,
                                      textAlign: _ar ? TextAlign.right : TextAlign.left,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: tokens.text1,
                                            fontSize: _tradeDataItemFontSize,
                                            fontWeight: FontWeight.w700,
                                            height: 1.4,
                                          ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            IconButton(
                              key: ValueKey(
                                'trade-setup-remove-$fieldId-$index',
                              ),
                              tooltip: _copy('حذف الاختيار', 'Remove selection'),
                              visualDensity: VisualDensity.compact,
                              constraints: const BoxConstraints.tightFor(
                                width: 32,
                                height: 32,
                              ),
                              padding: EdgeInsets.zero,
                              onPressed: enabled
                                  ? () => onRemove(setups[index].item)
                                  : null,
                              icon: Icon(
                                Icons.close_rounded,
                                size: 16,
                                color: tokens.text3,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  )
                : const SizedBox(height: 30),
            ),
          ),
        ),
      ),
    );
  }

  Widget _entryConditionField({
    required Key key,
    required Key addKey,
    required Key surfaceKey,
    required GlobalKey headerKey,
    required Key wrapperKey,
    required String title,
    required List<TradeEntryConditionSetup> setups,
    required List<TradeEntryOption> options,
    required Color tone,
    required bool enabled,
    required Future<void> Function() onAdd,
    required void Function(TradeEntryConditionSetup) onRemove,
    required void Function(TradeEntryConditionSetup) onEdit,
    Set<TradeEntryConditionSetup> practicalNoEntrySetups = const {},
    ValueChanged<TradeEntryConditionSetup>? onLongPressSetup,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isPracticallyLinked = practicalNoEntrySetups.isNotEmpty;
    final entryConditionFieldFill = isPracticallyLinked
        ? (isDark
            ? TradeDetailPalette.linkedEntryConditionsFieldDark
            : Color.alphaBlend(_noEntryTone.withValues(alpha: .075), tokens.surface2))
        // Unlinked Opposing signals / Bounce area fields carry the same tint
        // as the Entry Conditions timeframe list instead of neutral grey.
        : _entryConditionsSurface(
            tokens: tokens,
            tone: tone,
            brightness: Theme.of(context).brightness,
          );

    String optionLabel(String optionKey) => options
        .where((option) => option.key == optionKey)
        .map((option) => _ar ? option.ar : option.en)
        .firstOrNull ?? optionKey;

    String setupLabel(TradeEntryConditionSetup setup) =>
        formatTradeEntryConditionSetupLabel(
          setup: setup,
          optionLabel: optionLabel(setup.optionKey),
          arabic: _ar,
          side: _side,
        );

    final hasSelection = setups.isNotEmpty;
    return Opacity(
      opacity: enabled ? 1 : .52,
      child: KeyedSubtree(
        key: addKey,
        child: KeyedSubtree(
          key: wrapperKey,
          child: Container(
            key: surfaceKey,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
              key: key,
              borderRadius: BorderRadius.circular(14),
              onTap: enabled ? onAdd : null,
              child: KeyedSubtree(
                key: headerKey,
                child: InputDecorator(
                  decoration: _blueSelectorDecoration(
                    label: title,
                    tone: tone,
                    fillColorOverride: entryConditionFieldFill,
                    borderColorOverride: isPracticallyLinked
                        ? (isDark
                            ? TradeDetailPalette.linkedEntryConditionsFieldEdge
                                .withValues(alpha: .18)
                            : _noEntryTone.withValues(alpha: .17))
                        : null,
                    trailingIcon: Icons.keyboard_arrow_down_rounded,
                    contentPadding:
                        const EdgeInsetsDirectional.fromSTEB(12, 14, 10, 12),
                  ),
                  isEmpty: !hasSelection,
                  child: hasSelection
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            for (var index = 0; index < setups.length; index++) ...[
                              if (index > 0)
                                Divider(
                                  height: 8,
                                  thickness: .6,
                                  color: tone.withValues(alpha: .17),
                                ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(6),
                                        onTap: enabled
                                            ? () => onEdit(setups[index])
                                            : null,
                                        onLongPress: enabled && onLongPressSetup != null
                                            ? () => onLongPressSetup!(setups[index])
                                            : null,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 5,
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  setupLabel(setups[index]),
                                                  key: ValueKey(
                                                    'entry-condition-label-${setups[index].optionKey}-${setups[index].timeframe}-${setups[index].secondaryTimeframe ?? ''}-${setups[index].touch2}',
                                                  ),
                                                  softWrap: true,
                                                  maxLines: null,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodySmall
                                                      ?.copyWith(
                                                        color: tokens.text1,
                                                        fontSize: _tradeDataItemFontSize,
                                                        fontWeight: FontWeight.w700,
                                                        height: 1.4,
                                                      ),
                                                ),
                                              ),
                                              if (practicalNoEntrySetups.contains(setups[index]))
                                                Padding(
                                                  padding: const EdgeInsetsDirectional.only(start: 7),
                                                  child: Tooltip(
                                                    message: _copy(
                                                      'سبب عملي لعدم الدخول — اضغط مطولاً لإلغاء الربط',
                                                      'Practical no-entry reason — long-press to unlink',
                                                    ),
                                                    child: Icon(
                                                      Icons.link_rounded,
                                                      key: ValueKey('practical-no-entry-link-${setups[index].optionKey}-${setups[index].timeframe}'),
                                                      size: 15,
                                                      color: _noEntryTone,
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: _copy(
                                      'حذف الاختيار',
                                      'Remove selection',
                                    ),
                                    visualDensity: VisualDensity.compact,
                                    constraints: const BoxConstraints.tightFor(
                                      width: 32,
                                      height: 32,
                                    ),
                                    padding: EdgeInsets.zero,
                                    onPressed: enabled
                                        ? () => onRemove(setups[index])
                                        : null,
                                    icon: Icon(
                                      Icons.close_rounded,
                                      size: 16,
                                      color: tokens.text3,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        )
                      : const SizedBox(height: 30),
                ),
              ),
            ),
          ),
        ),
      ),
      ),
    );
  }

  Widget _buildLinkedEntryBehaviorSections(BuildContext context) {
    // A generic no-entry reason still affects trade classification, but it
    // must not visually connect the sections. Purple/connector state is only
    // activated by an explicit long-press on a selected opposing signal.
    final hasPracticalReverseSignalLink = _hasPracticalNoEntryReason;
    final reverseSignalTone = hasPracticalReverseSignalLink
        ? _noEntryTone
        : _reverseSignalsTone;
    final sectionTone = hasPracticalReverseSignalLink
        ? _noEntryTone
        : _entryConditionsTone;
    final sectionGradient = hasPracticalReverseSignalLink
        ? const [
            Color(0xFF312A57),
            Color(0xFF2B2549),
            Color(0xFF241F3E),
            Color(0xFF1D1933),
          ]
        : const [
            Color(0xFF1B3948),
            Color(0xFF162F3D),
            Color(0xFF122936),
            Color(0xFF0E202B),
          ];

    return KeyedSubtree(
      key: const ValueKey('linked-entry-behavior-stack'),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              key: _linkedSectionsRailKey,
              width: 12,
              child: hasPracticalReverseSignalLink
                  ? IgnorePointer(
                      child: CustomPaint(
                        key: const ValueKey(
                          'no-entry-reverse-signal-connector',
                        ),
                        size: const Size(12, 1),
                        painter: _LinkedSectionConnectorPainter(
                          hostKey: _linkedSectionsRailKey,
                          fromKey: _reverseSignalConnectorAnchorKey,
                          toKey: _noEntryConnectorAnchorKey,
                          color: _noEntryTone,
                          textDirection: Directionality.of(context),
                        ),
                      ),
                    )
                  : const SizedBox.shrink(),
            ),
            Expanded(
              child: Column(
                key: const ValueKey('linked-entry-behavior-content'),
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _sectionCard(
                    context,
                    key: const ValueKey('entry-conditions-section-card'),
                    title: _copy('ظروف الدخول', 'Entry conditions'),
                    icon: Icons.radar_rounded,
                    tone: sectionTone,
                    gradientColors: sectionGradient,
                    borderTone: hasPracticalReverseSignalLink
                        ? const Color(0xFF7863C4)
                        : const Color(0xFF456F82),
                    tint: hasPracticalReverseSignalLink ? .14 : .12,
                    children: [
                      _entryConditionField(
                        key: const ValueKey('reverse-signal-category-trigger'),
                        addKey: const ValueKey('add-reverse-signal-setup'),
                        surfaceKey: const ValueKey(
                          'reverse-signal-category-surface',
                        ),
                        headerKey: _reverseSignalConnectorAnchorKey,
                        wrapperKey: const ValueKey(
                          'reverse-signal-category-wrapper',
                        ),
                        title: _copy('إشارات عكسية', 'Opposing signals'),
                        setups: _reverseSignalSetups,
                        options: tradeReverseSignalOptions,
                        tone: reverseSignalTone,
                        enabled: _hasTradeDirection,
                        onAdd: _addReverseSignalSetup,
                        onRemove: _removeReverseSignalSetup,
                        onEdit: _editReverseSignalSetup,
                        practicalNoEntrySetups: _practicalNoEntryReverseSignalSetups.toSet(),
                        onLongPressSetup: _togglePracticalNoEntryReverseSignal,
                      ),
                      const SizedBox(height: 9),
                      _entryConditionField(
                        key: const ValueKey('bounce-zone-category-trigger'),
                        addKey: const ValueKey('add-bounce-zone-setup'),
                        surfaceKey: const ValueKey(
                          'bounce-zone-category-surface',
                        ),
                        headerKey: _bounceZoneFieldAnchorKey,
                        wrapperKey: const ValueKey(
                          'bounce-zone-category-wrapper',
                        ),
                        title: _copy('منطقة الارتداد', 'Bounce area'),
                        setups: _bounceZoneSetups,
                        options: tradeBounceZoneLabelOptions,
                        // Bounce area keeps its original blue field palette even
                        // when the opposing-signal field carries a practical link.
                        tone: _entryConditionsTone,
                        enabled: _hasTradeDirection,
                        onAdd: _addBounceZoneSetup,
                        onRemove: _removeBounceZoneSetup,
                        onEdit: _editBounceZoneSetup,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _buildBehaviorCard(context),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBehaviorCard(BuildContext context) {
    final decisionCount = tradeReviewGroups
        .expand((group) => group.options)
        .where((option) => _executionReviewKeys.contains(option.key))
        .length;
    final noEntryCount = _noEntryReasons.length;
    return _sectionCard(
      context,
      title: _copy('سلوك التداول', 'Trading behavior'),
      icon: Icons.fact_check_outlined,
      tone: _behaviorTone,
      gradientColors: const [Color(0xFF312A57), Color(0xFF2B2549), Color(0xFF241F3E), Color(0xFF1D1933)],
      borderTone: const Color(0xFF7863C4),
      tint: .14,
      // The Decisions area uses almost the full card width; the other two
      // sections below are re-inset so they keep their original geometry.
      bodyHorizontalPadding: 6,
      children: [
        _behaviorExpansion(
          title: _copy('القرارات', 'Decisions'),
          count: decisionCount,
          tone: _decisionTone,
          childrenPadding: const EdgeInsets.fromLTRB(2, 2, 2, 10),
          child: TradeDecisionZones(
            key: const ValueKey('trade-decision-zones'),
            groups: tradeReviewGroups,
            selected: _executionReviewKeys,
            enabled: _hasTradeDirection,
            arabic: _ar,
            tone: _decisionTone,
            initialZone: _decisionZoneIndex,
            initialAnalysisCollapsed: _decisionAnalysisCollapsed,
            onZoneChanged: (index) => setState(() => _decisionZoneIndex = index),
            onAnalysisCollapsedChanged: (value) => setState(() => _decisionAnalysisCollapsed = value),
            onToggle: (key) => _toggleSet(
              _executionReviewKeys,
              key,
              !_executionReviewKeys.contains(key),
            ),
            listRowBuilder: (option) => _selectionRow(
              option,
              _executionReviewKeys,
              keyPrefix: 'review',
              accent: _decisionTone,
              enabled: _hasTradeDirection,
            ),
          ),
        ),
        const SizedBox(height: 8),
        _insetBehaviorSection(_behaviorExpansion(
          title: _copy('الالتزام', 'Plan commitment'),
          count: tradeCommitmentOptions.where((item) => _executionReviewKeys.contains(item.key)).length,
          tone: _commitmentTone,
          childrenPadding: const EdgeInsets.fromLTRB(2, 2, 2, 10),
          child: Column(
            children: [
              for (var i = 0; i < tradeCommitmentOptions.length; i++) ...[
                if (i > 0) const SizedBox(height: 6),
                _selectionRow(
                  tradeCommitmentOptions[i],
                  _executionReviewKeys,
                  keyPrefix: 'review',
                  accent: _commitmentTone,
                  enabled: _hasTradeDirection &&
                      !_commitmentLocked(tradeCommitmentOptions[i].key),
                  showArtwork: false,
                ),
              ],
            ],
          ),
        )),
        const SizedBox(height: 8),
        _insetBehaviorSection(_behaviorExpansion(
          title: _copy('أسباب عدم الدخول', 'Reasons for not entering'),
          count: noEntryCount,
          tone: _noEntryTone,
          headerKey: _noEntryConnectorAnchorKey,
          headerWrapperKey: const ValueKey('no-entry-connector-anchor'),
          childrenPadding: const EdgeInsets.fromLTRB(2, 2, 2, 10),
          child: TradeNoEntryZones(
            key: const ValueKey('trade-no-entry-zones'),
            groups: tradeNoEntryGroups,
            selected: _noEntryReasons,
            enabled: _hasTradeDirection,
            arabic: _ar,
            tone: _noEntryTone,
            initialZone: _noEntryZoneIndex,
            initialCollapsed: _noEntryCollapsedZones,
            onZoneChanged: (index) => setState(() => _noEntryZoneIndex = index),
            onCollapsedChanged: (value) => setState(() => _noEntryCollapsedZones = value),
            onToggle: (key) => _toggleSet(
              _noEntryReasons,
              key,
              !_noEntryReasons.contains(key),
            ),
          ),
        )),
      ],
    );
  }

  /// Keeps the commitment / no-entry sections at their original width inside
  /// the behavior card, whose body padding was reduced for the Decisions area.
  Widget _insetBehaviorSection(Widget child) =>
      Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: child);

  Widget _behaviorExpansion({
    required String title,
    required int count,
    required Color tone,
    required Widget child,
    Widget? leading,
    Key? headerKey,
    Key? headerWrapperKey,
    EdgeInsetsGeometry childrenPadding = const EdgeInsets.fromLTRB(4, 0, 4, 12),
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: Color.alphaBlend(tone.withValues(alpha: isDark ? .14 : .08), tokens.surface2),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: tone.withValues(alpha: isDark ? .17 : .13), width: 0.8),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 2),
          childrenPadding: childrenPadding,
          title: KeyedSubtree(
            key: headerWrapperKey,
            child: Row(
              key: headerKey,
              children: [
                if (leading != null) ...[leading, const SizedBox(width: 7)],
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: isDark ? Colors.white : tokens.text1,
                      fontSize: 15.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: count > 0 ? tone.withValues(alpha: .16) : tokens.surface3,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: tone.withValues(
                        alpha: count > 0 ? .20 : .10,
                      ),
                      width: 0.8,
                    ),
                  ),
                  child: Text(
                    '$count',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: count > 0 ? tone : tokens.text3,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          children: [child],
        ),
      ),
    );
  }

  /// One selectable row of the Decisions and Commitment sections. Uses the same
  /// tonal tile as «أسباب عدم الدخول» so the three behavior areas read alike:
  /// full width, one item per line, a tonal step (no border, glow or check
  /// mark) when selected. The commitment illustrations stay, as the leading
  /// element of their own tile.
  Widget _selectionRow(
    TradeEntryOption option,
    Set<String> selected, {
    required String keyPrefix,
    required Color accent,
    required bool enabled,
    bool showArtwork = true,
  }) {
    final isSelected = selected.contains(option.key);
    final hasReviewArtwork =
        showArtwork && tradeReviewOptionEmojiAssets.containsKey(option.key);
    return DecisionOptionTile(
      inkKey: ValueKey('$keyPrefix-${option.key}'),
      surfaceKey: ValueKey('trade-behavior-option-surface-${option.key}'),
      label: _ar ? option.ar : option.en,
      selected: isSelected,
      enabled: enabled,
      tone: accent,
      fontSize: _tradeDataItemFontSize,
      leading: hasReviewArtwork
          ? TradeReviewOptionEmoji(
              key: ValueKey('review-art-${option.key}'),
              optionKey: option.key,
              size: 28,
            )
          : null,
      onTap: () => _toggleSet(selected, option.key, !isSelected),
    );
  }
}

