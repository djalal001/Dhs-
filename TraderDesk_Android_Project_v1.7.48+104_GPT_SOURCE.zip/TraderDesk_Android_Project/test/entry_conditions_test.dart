import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_conditions_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'conditions-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'conditions-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('keeps market and direction compact and stores both entry-condition lists', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketField = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.ensureVisible(marketField);
    final marketRect = tester.getRect(marketField);
    final directionRect = tester.getRect(directionSelector);
    expect(
      (directionRect.top - marketRect.top).abs(),
      lessThan(20),
      reason: 'direction should share the compact market row, not move below it',
    );
    expect(
      directionRect.left >= marketRect.right || marketRect.left >= directionRect.right,
      isTrue,
      reason: 'direction and market fields should be horizontally adjacent',
    );
    expect((directionRect.width - marketRect.width).abs(), lessThan(1));
    final marketDirectionRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    final anchorRect = tester.getRect(
      find.byKey(const ValueKey('trade-anchor-selector')),
    );
    expect(marketDirectionRect.width, closeTo(104, 1));
    expect(
      anchorRect.width,
      greaterThan(marketDirectionRect.width + 40),
      reason: 'the anchor field must receive most of the available row width',
    );
    final availableIdentifiers = tester.getRect(
      find.byKey(const ValueKey('trade-entry-identifiers-available')),
    );
    final identifiersRow = tester.getRect(
      find.byKey(const ValueKey('trade-entry-identifiers-row')),
    );
    expect(identifiersRow.width, closeTo(availableIdentifiers.width, 1));
    expect(
      (marketDirectionRect.right - identifiersRow.right).abs(),
      lessThan(1),
      reason: 'the slim market/direction selector must align to the right edge of the card content',
    );

    expect(find.text('السوق / الاتجاه'), findsOneWidget);
    expect(find.text('الارتكاز'), findsOneWidget);
    expect(find.text('اختر الرمز'), findsNothing);
    expect(find.text('اختر الارتكاز'), findsNothing);
    final marketInput = tester.widget<InputDecorator>(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    expect(marketInput.decoration.fillColor, const Color(0xFF071834));
    final marketBorder = marketInput.decoration.border as OutlineInputBorder;
    expect(marketBorder.borderRadius, BorderRadius.circular(14));
    expect(marketBorder.borderSide.width, .78);
    final popupTheme = Theme.of(tester.element(marketField)).popupMenuTheme;
    expect(popupTheme.color, const Color(0xFF102846));
    expect(popupTheme.surfaceTintColor, Colors.transparent);
    final popupShape = popupTheme.shape as RoundedRectangleBorder;
    expect(popupShape.borderRadius, BorderRadius.circular(12));
    expect(popupShape.side.color, const Color(0xFF315C8C));
    expect(popupShape.side.width, .85);
    expect(tdPopupMenuAnimationStyle.duration, const Duration(milliseconds: 105));
    expect(
      tdPopupMenuAnimationStyle.reverseDuration,
      const Duration(milliseconds: 85),
    );
    expect(
      find.descendant(of: marketField, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    expect(
      find.descendant(of: directionSelector, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    final anchorSelector = find.byKey(const ValueKey('trade-anchor-selector'));
    final anchorInputFinder = find.descendant(
      of: anchorSelector,
      matching: find.byType(InputDecorator),
    );
    expect(anchorInputFinder, findsOneWidget);
    final anchorInput = tester.widget<InputDecorator>(anchorInputFinder);
    expect(anchorInput.decoration.fillColor, const Color(0xFF071834));
    final anchorBorder = anchorInput.decoration.border as OutlineInputBorder;
    expect(anchorBorder.borderRadius, BorderRadius.circular(14));
    expect(anchorBorder.borderSide.width, .78);
    for (final symbol in const ['NQ', 'ES', 'GC']) {
      await tester.tap(marketField);
      await tester.pumpAndSettle();
      expect(
        find.byType(PopupMenuItem<String>),
        findsNWidgets(3),
        reason: 'the symbol popup must render all three options at once',
      );
      expect(tester.widget<Text>(find.text('NQ')).style?.fontSize, 14.5);
      for (final availableSymbol in const ['NQ', 'ES', 'GC']) {
        final optionFinder = find.byKey(
          ValueKey('trade-market-option-$availableSymbol'),
        );
        expect(
          optionFinder,
          findsOneWidget,
          reason: 'all supported market symbols must remain visible in the popup',
        );
        final optionRect = tester.getRect(optionFinder);
        expect(optionRect.width, greaterThan(160));
        expect(optionRect.left, greaterThanOrEqualTo(0));
        expect(optionRect.right, lessThanOrEqualTo(tester.view.physicalSize.width / tester.view.devicePixelRatio));
      }
      await tester.tap(find.byKey(ValueKey('trade-market-option-$symbol')));
      await tester.pumpAndSettle();
      expect(
        find.descendant(of: marketField, matching: find.text(symbol)),
        findsOneWidget,
      );
      expect(
        find.descendant(of: marketField, matching: find.text('الرمز')),
        findsNothing,
        reason: 'the symbol caption must disappear after a symbol is selected',
      );
    }

    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    final buyOption = find.byKey(const ValueKey('trade-direction-option-buy'));
    expect(
      find.byType(PopupMenuItem<TradeSide>),
      findsNWidgets(2),
      reason: 'the direction popup must display both choices together',
    );
    expect(find.text('شراء'), findsOneWidget);
    expect(find.text('بيع'), findsOneWidget);
    expect(tester.widget<Text>(find.text('شراء')).style?.fontSize, 14.5);
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: directionSelector, matching: find.text('الاتجاه')),
      findsNothing,
      reason: 'the direction caption must disappear after a side is selected',
    );
    expect(
      find.descendant(of: directionSelector, matching: find.text('شراء')),
      findsOneWidget,
    );
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('شراء'), findsNothing);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('شراء'), findsOneWidget);

    await tester.tap(anchorSelector);
    await tester.pumpAndSettle();
    for (final option in [
      'Key Level',
      'Supply Zone',
      'Demand Zone',
      'Bullish Engulfing',
      'Bearish engulfing',
    ]) {
      expect(find.text(option), findsOneWidget);
    }
    expect(tester.widget<Text>(find.text('Bearish engulfing')).style?.fontSize, 14.5);
    expect(find.byKey(const ValueKey('trade-anchor-save')), findsNothing);
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-supplyZone')));
    await tester.pumpAndSettle();
    expect(find.text('فريم الارتكاز'), findsOneWidget,
        reason: 'every newly selected anchor must immediately request its timeframe');
    expect(find.byType(Dialog), findsOneWidget);
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    // The anchor menu remains available so multiple anchors can be selected;
    // each additional selection opens its own timeframe picker.
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-demandZone')));
    await tester.pumpAndSettle();
    expect(find.text('فريم الارتكاز'), findsOneWidget);
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    // A tap outside the popup dismisses it; both anchor/timeframe pairs stay selected.
    final anchorTopLeft = tester.getTopLeft(anchorSelector);
    await tester.tapAt(Offset(4, anchorTopLeft.dy + 10));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-anchor-option-supplyZone')), findsNothing);
    expect(find.byKey(const ValueKey('trade-anchor-save')), findsNothing);
    expect(find.text('Supply Zone 15MIN، Demand Zone 30MIN'), findsOneWidget);
    final moodMenu = find.byKey(const ValueKey('trade-mood-dropdown'));
    await tester.ensureVisible(moodMenu);
    final moodButton = tester.widget<PopupMenuButton<String>>(moodMenu);
    expect(moodButton.popUpAnimationStyle, tdPopupMenuAnimationStyle);
    await tester.tap(moodMenu);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-mood-option-moodCalm')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trade-mood-option-moodCalm')));
    await tester.pumpAndSettle();
    expect(tester.getSize(anchorSelector).height, greaterThan(45));
    expect(tester.getSize(anchorSelector).height, lessThan(120));
    final selectedAnchorText = tester.widget<Text>(
      find.byKey(const ValueKey('trade-anchor-selected-values')),
    );
    expect(selectedAnchorText.maxLines, isNull);
    expect(selectedAnchorText.overflow, isNull);
    expect(selectedAnchorText.softWrap, isTrue);
    expect(find.text('Supply Zone 15MIN، Demand Zone 30MIN'), findsOneWidget);
    await tester.enterText(find.byKey(const ValueKey('trade-result-input')), '42.5');
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    // The separate Entry reason/confirmation controls remain unchanged;
    // the two Entry Conditions controls below are the ones shortened to "اختيار".
    expect(find.descendant(of: addEntry, matching: find.text('إضافة')), findsOneWidget);
    expect(find.descendant(of: addConfirmation, matching: find.text('إضافة')), findsOneWidget);
    await tester.ensureVisible(addEntry);
    await tester.tap(addEntry);
    await tester.pumpAndSettle();
    final entryReasonDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(entryReasonDialog, findsOneWidget);
    final entryReasonDialogRect = tester.getRect(entryReasonDialog);
    expect(entryReasonDialogRect.width, lessThan(340));
    expect(
      (entryReasonDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the entry-reason list must be centered, not full-screen width',
    );
    final entryReasonDialogWidget = tester.widget<Dialog>(entryReasonDialog);
    expect(entryReasonDialogWidget.backgroundColor, const Color(0xFF102846));
    final entryReasonDialogShape =
        entryReasonDialogWidget.shape as RoundedRectangleBorder;
    expect(entryReasonDialogShape.borderRadius, BorderRadius.circular(12));
    expect(entryReasonDialogShape.side.color, const Color(0xFF315C8C));
    expect(
      tester.widget<Text>(find.text('RFS')).style?.fontSize,
      14.5,
      reason: 'entry-reason options should match the anchor-menu text scale',
    );
    await tester.tap(find.text('RFS').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    await tester.ensureVisible(addConfirmation);
    await tester.tap(addConfirmation);
    await tester.pumpAndSettle();
    final confirmationDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(confirmationDialog, findsOneWidget);
    final confirmationDialogRect = tester.getRect(confirmationDialog);
    expect(confirmationDialogRect.width, lessThan(340));
    expect(
      (confirmationDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the confirmation list must remain centered and compact',
    );
    final confirmationDialogWidget = tester.widget<Dialog>(confirmationDialog);
    expect(confirmationDialogWidget.backgroundColor, const Color(0xFF102846));
    final confirmationDialogShape =
        confirmationDialogWidget.shape as RoundedRectangleBorder;
    expect(confirmationDialogShape.borderRadius, BorderRadius.circular(12));
    expect(confirmationDialogShape.side.color, const Color(0xFF315C8C));
    await tester.tap(find.text('Bearish engulfing').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();

    final addReverse = find.byKey(const ValueKey('add-reverse-signal-setup'));
    final reverseHeader = find.byKey(
      const ValueKey('reverse-signal-category-trigger'),
    );
    await tester.ensureVisible(reverseHeader);
    await tester.tap(reverseHeader);
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'tapping the opposing-signals rectangle must open its centered choices immediately');
    final reverseDialogRect = tester.getRect(find.byType(Dialog));
    expect(reverseDialogRect.width, lessThan(340));
    expect(
      (reverseDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
    );
    const reverseLabel = 'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول';
    expect(find.text(reverseLabel), findsOneWidget);
    expect(find.text('نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة'), findsOneWidget);
    expect(find.textContaining('تشكّل'), findsNothing);
    expect(find.textContaining('تشكل'), findsNothing);
    await tester.tap(find.text(reverseLabel));
    await tester.pumpAndSettle();
    expect(find.text('الفريم الزمني'), findsOneWidget);
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'the timeframe list must use the same centered dialog');
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(addReverse, findsOneWidget);

    final addBounce = find.byKey(const ValueKey('add-bounce-zone-setup'));
    final bounceHeader = find.byKey(
      const ValueKey('bounce-zone-category-trigger'),
    );
    await tester.ensureVisible(bounceHeader);
    await tester.tap(bounceHeader);
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'tapping the bounce-area rectangle must open its centered choices immediately');
    await tester.tap(find.text('ارتداد من ترند لاين و Supply Zone'));
    await tester.pumpAndSettle();
    expect(find.text('فريم ترند لاين'), findsOneWidget);
    expect(find.byType(Dialog), findsOneWidget);
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();
    expect(find.text('فريم Supply Zone'), findsOneWidget,
        reason: 'the Supply Zone timeframe picker should open automatically');
    expect(find.byType(Dialog), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();

    expect(find.textContaining('ارتداد من Trend Line 1H - Supply Zone 5MIN'), findsOneWidget);
    final selectedBounceLabel = tester.widget<Text>(
      find.byKey(const ValueKey('entry-condition-label-bounceFromTrendlineAndSupplyZone-1H-5MIN-false')),
    );
    expect(selectedBounceLabel.softWrap, isTrue);
    expect(selectedBounceLabel.maxLines, isNull);
    expect(selectedBounceLabel.overflow, isNull);
    final selectedReverseLabel = tester.widget<Text>(
      find.byKey(const ValueKey('entry-condition-label-negativeCloseAgainstDirection-30MIN--false')),
    );
    expect(selectedReverseLabel.softWrap, isTrue);
    expect(selectedReverseLabel.maxLines, isNull);
    expect(selectedReverseLabel.overflow, isNull);
    expect(find.text('إضافة اختيار'), findsNothing);
    expect(find.text('اختيار'), findsNWidgets(2));
    expect(find.descendant(of: reverseHeader, matching: find.byIcon(Icons.add_rounded)), findsNothing);
    expect(find.descendant(of: bounceHeader, matching: find.byIcon(Icons.add_rounded)), findsNothing);
    expect(find.descendant(of: addReverse, matching: find.byIcon(Icons.add)), findsNothing);
    expect(find.descendant(of: addBounce, matching: find.byIcon(Icons.add)), findsNothing);

    await tester.ensureVisible(addBounce);
    await tester.tap(addBounce);
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    expect(find.text('تفصيل ارتداد S/R — اختياري'), findsOneWidget);
    final srTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(srTouch2, findsOneWidget);
    await tester.tap(srTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    final srTouch2Chip = find.text('ارتداد من دعم - لمسة 2 15MIN');
    expect(srTouch2Chip, findsOneWidget);

    // Editing an S/R bounce restores the previous Touch 2 choice.
    await tester.ensureVisible(srTouch2Chip);
    await tester.tap(srTouch2Chip);
    await tester.pumpAndSettle();
    final selectedSrTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(tester.widget<ListTile>(selectedSrTouch2).selected, isTrue);
    await tester.tap(selectedSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    // The dropdown keeps one direction selected; switching to sell and back
    // updates the directional interpretation of the S/R bounce.
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من مقاومة - لمسة 2 15MIN'), findsOneWidget);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من دعم - لمسة 2 15MIN'), findsOneWidget);

    // A second S/R bounce can explicitly skip the optional Touch 2 qualifier.
    await tester.ensureVisible(addBounce);
    await tester.tap(addBounce);
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    final skipSrTouch2 = find.byKey(
      const ValueKey('skip-touch2-bounceFromSrZone'),
    );
    expect(skipSrTouch2, findsOneWidget);
    await tester.tap(skipSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من دعم 4H'), findsOneWidget);

    final classify = find.byKey(
      const ValueKey('choose-trade-classification-button'),
    );
    await tester.ensureVisible(classify);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-classification-option-win')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-loss')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-breakEven')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-missed')),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-classification-option-win')),
    );
    await tester.pumpAndSettle();
    expect(classify, findsNothing);

    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.win);
    expect(savedTrade!.effectiveClassification, TradeClassification.win);
    expect(savedTrade!.market, 'GC');
    expect(savedTrade!.side, TradeSide.buy);
    expect(savedTrade!.anchor, 'supplyZone');
    expect(savedTrade!.effectiveAnchors, ['supplyZone', 'demandZone']);
    expect(savedTrade!.anchorTimeframes, {'supplyZone': '15MIN', 'demandZone': '30MIN'});
    expect(savedTrade!.reverseSignalSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'negativeCloseAgainstDirection',
        timeframe: '30MIN',
      ),
    ]);
    expect(savedTrade!.bounceZoneSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'bounceFromTrendlineAndSupplyZone',
        timeframe: '1H',
        secondaryTimeframe: '5MIN',
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '15MIN',
        touch2: true,
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '4H',
      ),
    ]);
    expect(savedTrade!.entrySetups.single, const TradeEntrySetup(reason: 'RFS', timeframe: '15MIN'));
    expect(savedTrade!.confirmationSetups.single, const TradeConfirmationSetup(type: 'confirmBearishEngulfing', timeframe: '5MIN'));
  });

  test('new conditions remain backward compatible with existing trade JSON', () {
    final legacy = <String, dynamic>{
      'id': 'legacy',
      'accountId': 'conditions-account',
      'market': 'EURUSD',
      'reason': 'SBR',
      'result': 5,
      'riskPercent': .5,
      'side': 'buy',
      'confirmation': 'confirmBearishEngulfing',
      'sequence': '',
      'mood': 'moodCalm',
      'tradedAt': DateTime(2025, 1, 2).toIso8601String(),
    };
    final restored = Trade.fromJson(legacy);
    expect(restored.reverseSignalSetups, isEmpty);
    expect(restored.bounceZoneSetups, isEmpty);
    expect(restored.anchor, isNull);
    expect(restored.effectiveAnchors, isEmpty);
    expect(restored.anchorTimeframes, isEmpty);
  });
}
