#!/usr/bin/env python3
"""Focused static checks for TraderDesk 1.7.101+157 UI alignment update."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
form = (root / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
trades = (root / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
form_test = (root / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
filter_test = (root / 'test/trades_screen_filter_test.dart').read_text(encoding='utf-8')
pubspec = (root / 'pubspec.yaml').read_text(encoding='utf-8')
workflow = (root / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
checks = {
    'release version is 1.7.101+157': 'version: 1.7.101+157' in pubspec,
    'mindset field width expands to the shared half-column': "key: const ValueKey('trade-mood-field')" in form and 'width: double.infinity' in form,
    'mindset field height uses the shared 72dp constant': "key: const ValueKey('trade-mood-field')" in form and 'height: _tradeDataControlHeight' in form and 'const double _tradeDataControlHeight = 72' in form,
    'mindset label alignment is centered': "floatingLabelAlignment: FloatingLabelAlignment.center" in form,
    'widget test compares actual widths and heights': 'moodSurfaceRect.width' in form_test and 'moodSurfaceRect.height' in form_test,
    'widget test compares top and bottom edges': 'moodSurfaceRect.top' in form_test and 'moodSurfaceRect.bottom' in form_test,
    'break-even and missed submenu hit areas are fixed 28x32': all(x in trades for x in ['trades-filter-break-even-submenu-hit-area','trades-filter-missed-submenu-hit-area','width: 28','height: 32']),
    'both submenu icons are centered and share neutral token': trades.count('child: Center(') >= 2 and trades.count('color: tokens.text3') >= 2,
    'widget test compares submenu hit-area sizes and icon styling': all(x in filter_test for x in ['breakEvenHitArea.width','breakEvenHitArea.height','breakEvenIcon.color, missedIcon.color']),
    'workflow release identity and artifacts use build 157': 'TraderDesk 1.7.101+157' in workflow and 'traderdesk-1.7.101-build157-arm64-v8a-release' in workflow,
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + label)
print(f'{sum(checks.values())}/{len(checks)} focused checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
