#!/usr/bin/env python3
"""Static regression checks for missed-opportunity outcome capture and filtering."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
MODEL = (ROOT / 'lib/models/trade.dart').read_text(encoding='utf-8')
STORE = (ROOT / 'lib/data/local_store.dart').read_text(encoding='utf-8')
FORM_TEST = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
MODEL_TEST = (ROOT / 'test/trade_classification_test.dart').read_text(encoding='utf-8')
FILTER_TEST = (ROOT / 'test/trades_screen_filter_test.dart').read_text(encoding='utf-8')
BACKUP_TEST = (ROOT / 'test/local_store_test.dart').read_text(encoding='utf-8')
ENTRY_TEST = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []
def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))

# 1) Mindset field geometry must not diverge from Market / Direction.
mindset = FORM.split('Widget _buildMindsetSelector', 1)[1].split('Widget _setupSelectionField', 1)[0]
check('Mindset and Market/Direction use one shared 72dp constant',
      'const double _tradeDataControlHeight = 72;' in FORM and
      'height: _tradeDataControlHeight' in mindset and
      '_mindsetControlHeight' not in FORM)
check('Widget regression asserts exact Mindset surface edges and unselected tone',
      'Mindset control bounds must match the Market / Direction rectangle exactly' in ENTRY_TEST and
      'moodSurfaceRect.top' in ENTRY_TEST and 'moodSurfaceRect.bottom' in ENTRY_TEST and
      'closeTo(marketDirectionRect.top, .1)' in ENTRY_TEST and
      'closeTo(marketDirectionRect.bottom, .1)' in ENTRY_TEST and
      'same muted tone as other unselected fields' in ENTRY_TEST)

# 2) Separate hypothetical outcome data from actual trade P/L.
check('Missed opportunity has its own win/loss enum with null-capable state',
      'enum MissedTradeOutcome' in MODEL and
      'final MissedTradeOutcome? missedOutcome;' in MODEL)
check('Missed outcome round-trips through JSON',
      "'missedOutcome': missedOutcome?.name" in MODEL and
      "MissedTradeOutcome.tryParse(json['missedOutcome'])" in MODEL)
check('Strategy-adherence copy preserves missed outcome',
      'missedOutcome: missedOutcome' in MODEL)
check('Backup restore preserves missed outcome',
      'missedOutcome: trade.missedOutcome' in STORE)
check('Form cycles neutral -> loss -> win -> neutral',
      'null => MissedTradeOutcome.loss' in FORM and
      'MissedTradeOutcome.loss => MissedTradeOutcome.win' in FORM and
      'MissedTradeOutcome.win => null' in FORM)
check('Chip uses neutral outline then restrained red/green fills',
      'alpha: _missedOutcome == null ? .68 : .88' in FORM and
      'alpha: .10' in FORM and
      'width: .9' in FORM)
check('Only missed classification saves hypothetical outcome, actual result remains independent',
      'missedOutcome: selectedClassification == TradeClassification.missed' in FORM and
      'result: result,' in FORM)
check('Form widget test verifies all three colors and persists the second-state win',
      'first tap marks the missed opportunity as a losing one' in FORM_TEST and
      'second tap marks the missed opportunity as a winning one' in FORM_TEST and
      'third tap returns the missed outcome to its neutral state' in FORM_TEST and
      'savedTrade!.missedOutcome, MissedTradeOutcome.win' in FORM_TEST)
check('Model tests verify JSON compatibility and unchanged realized zero',
      'persists missed opportunity direction separately from realized P/L' in MODEL_TEST and
      'older records without missedOutcome' in MODEL_TEST and
      'expect(restored.result, 0' in MODEL_TEST)
check('Backup test verifies missed outcome survives backup/restore',
      'preserves missed opportunity outcome through backup and restore' in BACKUP_TEST and
      'restored.trades.single.missedOutcome, MissedTradeOutcome.win' in BACKUP_TEST)

# 3) Three-way filter appears beside Missed and filters only missed opportunities.
check('Missed sub-filter offers exactly All/Wins/Losses',
      'enum _MissedTradeFilter { all, wins, losses }' in TRADES)
check('Labels map to gray/green/red semantic tokens',
      '_MissedTradeFilter.all => tokens.text3' in TRADES and
      '_MissedTradeFilter.wins => tokens.profit' in TRADES and
      '_MissedTradeFilter.losses => tokens.loss' in TRADES)
check('Main missed category label and adjacent sub-filter control have separate actions',
      'trades-filter-missed-select' in TRADES and
      'trades-filter-missed-submenu' in TRADES and
      '_missedTradeFilter = _MissedTradeFilter.all' in TRADES)
check('All includes unclassified missed trades; wins/losses compare the optional outcome',
      '_MissedTradeFilter.all => true' in TRADES and
      'trade.missedOutcome == MissedTradeOutcome.win' in TRADES and
      'trade.missedOutcome == MissedTradeOutcome.loss' in TRADES)
check('Filter widget test covers direct All selection and the three semantic colors',
      'trades-filter-missed-select' in FILTER_TEST and
      "reason: 'All is neutral gray'" in FILTER_TEST and
      "reason: 'Wins is green'" in FILTER_TEST and
      "reason: 'Losses is red'" in FILTER_TEST)
check('Filter widget test covers all/wins/losses result sets',
      'missed-potential-win' in FILTER_TEST and
      'missed-potential-loss' in FILTER_TEST and
      'missed-unknown' in FILTER_TEST and
      'trades-missed-subfilter-all' in FILTER_TEST and
      'trades-missed-subfilter-wins' in FILTER_TEST and
      'trades-missed-subfilter-losses' in FILTER_TEST)

# 4) Release metadata.
check('Pubspec release version is 1.7.101+157', 'version: 1.7.101+157' in PUBSPEC)
check('Android workflow version and artifacts use build 156',
      'TraderDesk 1.7.101+157' in WORKFLOW and
      'traderdesk-1.7.101-build157-arm64-v8a-release' in WORKFLOW and
      'traderdesk-1.7.101-build157-arm64-dart-symbols' in WORKFLOW)
check('Build info records exact parent source and source-only status',
      'TraderDesk_Android_Project_v1.7.99+155_GPT_SOURCE.zip' in BUILD_INFO and
      'لا يتضمن هذا التسليم APK' in BUILD_INFO)

for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{sum(ok for _, ok in checks)}/{len(checks)} checks passed")
if not all(ok for _, ok in checks):
    raise SystemExit(1)
