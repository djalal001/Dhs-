import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  test('dark-mode app background matches the reference screenshot', () {
    const expected = Color(0xFF111111);
    final tokens = TdTokens.forBrightness(Brightness.dark);
    final theme = buildAppTheme(Brightness.dark);

    expect(tokens.bgBase, expected);
    expect(theme.scaffoldBackgroundColor, expected);
    expect(theme.appBarTheme.backgroundColor, expected);
  });
}
