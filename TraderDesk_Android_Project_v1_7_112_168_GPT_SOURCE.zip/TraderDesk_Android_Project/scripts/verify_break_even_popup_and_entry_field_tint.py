#!/usr/bin/env python3
"""Static checks for the integrated trade-outcome/save control and entry-field tints."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
TEST_CC = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
TEST_EC = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
failed = []

def check(name, ok):
    print(('PASS' if ok else 'FAIL'), name)
    if not ok:
        failed.append(name)

def body(start_marker, end_marker):
    a = FORM.index(start_marker)
    return FORM[a:FORM.index(end_marker, a)]

check('release is 1.7.110+166', 'version: 1.7.110+166' in PUBSPEC)
check('workflow identity and both artifacts use build 166',
      'TraderDesk 1.7.110+166' in WORKFLOW and
      'traderdesk-1.7.110-build166-arm64-v8a-release' in WORKFLOW and
      'traderdesk-1.7.110-build166-arm64-dart-symbols' in WORKFLOW)

# --- One integrated control replaces the old two-step classification/save UI.
check('old separate classification and save-slot flows removed',
      all(token not in FORM for token in [
          '_saveSlotKey', '_chooseClassification', '_chooseBreakEvenType',
          '_cycleMissedOutcome', '_buildBreakEvenTypeChip',
          '_buildMissedOutcomeChip', '_availableClassifications',
      ]))
auto = body('TradeClassification get _automaticClassification', 'void _synchronizeAutomaticClassification')
check('classification is automatic from no-entry evidence and signed result',
      '_hasEntryConditionsNoEntryLink' in auto and
      'TradeClassification.missed' in auto and
      '_resultSign == 1' in auto and 'TradeClassification.win' in auto and
      '_resultSign == -1' in auto and 'TradeClassification.loss' in auto and
      'TradeClassification.breakEven' in auto)
detail = body('Widget _outcomeDetailDropdown', 'String _outcomeAmountLabel')
check('one integrated dropdown serves break-even and missed details',
      'PopupMenuButton<Object>' in detail and
      'BreakEvenType.values' in detail and
      'MissedTradeOutcome.values' in detail and
      'trade-outcome-detail-menu' in detail)
control = body('Widget _buildSaveOutcomeControl', 'void _save()')
check('single save control uses integrated status panel and action',
      'trade-save-outcome-control' in control and
      'ValueKey(\'save-trade-button\')' in control and
      'tr(context, \'save\')' in control and
      "ValueKey('trade-outcome-label-${classification.name}')" in control)
check('save label is Save only, not Save trade',
      "'save': 'حفظ'" in (ROOT / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8') and
      "'save': 'Save'" in (ROOT / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8') and
      'حفظ الصفقة' not in control)
check('save still requires explicit break-even and missed details',
      'selectedClassification == TradeClassification.breakEven' in FORM and
      '_breakEvenType == null' in FORM and
      'selectedClassification == TradeClassification.missed' in FORM and
      '_missedOutcome == null' in FORM)
check('form tests cover integrated missed and break-even menus',
      'trade-outcome-detail-menu' in TEST_CC and
      'trade-outcome-detail-win' in TEST_CC and
      'trade-outcome-detail-atEntry' in TEST_CC and
      'trade-outcome-label-missed' in TEST_EC)

# --- Request 2: contextual field surfaces remain shared and restrained.
check('shared entry-condition surface helper remains', 'Color _entryConditionsSurface({' in FORM)
dialog = body('Future<T?> _showCenteredTradeChoiceDialog<T>', 'Future<String?> _showTimeframeSheet')
check('timeframe/choice popup uses shared helper', '_entryConditionsSurface(' in dialog)
field = body('Widget _entryConditionField({', 'Widget _buildLinkedEntryBehaviorSections')
check('fields use shared helper when unlinked', '_entryConditionsSurface(' in field and ': tokens.surface2;' not in field)
check('purple linked fill remains isolated to the explicitly linked field',
      'TradeDetailPalette.linkedEntryConditionsFieldDark' in field and
      '_noEntryTone.withValues(alpha: .075)' in field)
check('entry-condition widget tests still protect both field fills',
      'reverseConditionFill' in TEST_EC and 'bounceConditionFill' in TEST_EC)
check('no localStorage/cartoon assets introduced', 'localStorage' not in FORM)

sys.exit(1 if failed else 0)
