import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/theme/trade_outcome_palette.dart';

void main() {
  test('missed and break-even outcomes use clearly separated semantic colors', () {
    for (final brightness in Brightness.values) {
      final breakEven = TradeOutcomePalette.breakEven(brightness);
      final missed = TradeOutcomePalette.missed(brightness);
      expect(missed, isNot(breakEven));
      expect(missed.computeLuminance(), greaterThan(breakEven.computeLuminance()));
      final channelDistance = (
        (missed.red - breakEven.red).abs() +
        (missed.green - breakEven.green).abs() +
        (missed.blue - breakEven.blue).abs()
      );
      expect(channelDistance, greaterThan(85));
    }
  });
}
