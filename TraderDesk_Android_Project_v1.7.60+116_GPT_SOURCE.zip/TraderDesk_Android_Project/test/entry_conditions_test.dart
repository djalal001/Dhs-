import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_conditions_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'conditions-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'conditions-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('pairs mindset with market/direction and renders anchors as a full-width selection field', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketField = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    final moodMenu = find.byKey(const ValueKey('trade-mood-dropdown'));
    await tester.ensureVisible(marketField);
    final marketRect = tester.getRect(marketField);
    final directionRect = tester.getRect(directionSelector);
    expect(
      (directionRect.top - marketRect.top).abs(),
      lessThan(20),
      reason: 'direction should share the compact market row, not move below it',
    );
    expect(
      directionRect.left >= marketRect.right || marketRect.left >= directionRect.right,
      isTrue,
      reason: 'direction and market fields should be horizontally adjacent',
    );
    expect((directionRect.width - marketRect.width).abs(), lessThan(1));
    final marketDirectionRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    final anchorRect = tester.getRect(
      find.byKey(const ValueKey('trade-anchor-selector')),
    );
    final moodRect = tester.getRect(moodMenu);
    final availableIdentifiers = tester.getRect(
      find.byKey(const ValueKey('trade-entry-identifiers-available')),
    );
    final availableRect = availableIdentifiers;
    expect(
      marketDirectionRect.width,
      closeTo((availableRect.width - 8) / 2, 1),
      reason: 'market/direction should occupy one half of the top row',
    );
    expect(
      moodRect.width,
      closeTo(marketDirectionRect.width, 1),
      reason: 'mindset must be beside market/direction with the same width',
    );
    expect(
      moodRect.left,
      lessThan(marketDirectionRect.left),
      reason: 'in RTL layout the mindset field sits to the left of market/direction',
    );
    expect(moodRect.top, closeTo(marketDirectionRect.top, .1));
    expect(moodRect.height, closeTo(marketDirectionRect.height, .1));
    expect(
      anchorRect.width,
      closeTo(availableRect.width, 1),
      reason: 'anchor selector must move below the top row and use the full content width',
    );
    final identifiersRow = tester.getRect(
      find.byKey(const ValueKey('trade-entry-identifiers-row')),
    );
    expect(identifiersRow.width, closeTo(availableIdentifiers.width, 1));
    expect(
      anchorRect.top,
      greaterThan(identifiersRow.bottom),
      reason: 'the full-width anchor field must be below market/direction and mindset',
    );
    expect(
      (marketDirectionRect.right - identifiersRow.right).abs(),
      lessThan(1),
      reason: 'the market/direction selector must align to the right edge of the card content',
    );

    expect(find.byKey(const ValueKey('trade-market-direction-label')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-market-direction-label-divider')), findsOneWidget);
    expect(find.text('السوق'), findsOneWidget);
    expect(tester.widget<Text>(find.text('السوق')).style?.fontSize, 14);
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('trade-market-direction-label-divider')),
      ).style?.fontSize,
      14,
    );
    expect(find.text('الاتجاه'), findsNWidgets(2),
        reason: 'the direction wording appears once in the top floating label and once as the empty selector caption');
    expect(find.text('الارتكاز'), findsOneWidget);
    final reverseField = find.byKey(
      const ValueKey('reverse-signal-category-trigger'),
    );
    final bounceField = find.byKey(
      const ValueKey('bounce-zone-category-trigger'),
    );
    expect(reverseField, findsOneWidget);
    expect(bounceField, findsOneWidget);
    for (final field in [reverseField, bounceField]) {
      final fieldInput = find.descendant(
        of: field,
        matching: find.byType(InputDecorator),
      );
      expect(fieldInput, findsOneWidget);
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.labelStyle?.fontSize,
        14,
        reason: 'every floating label in the trade-entry fields must use the enlarged shared label size',
      );
    }
    expect(find.text('إشارات عكسية'), findsOneWidget);
    expect(find.text('منطقة الارتداد'), findsOneWidget);
    expect(find.text('اختر الرمز'), findsNothing);
    expect(find.text('اختر الارتكاز'), findsNothing);
    // The Trade Data card has its own nested Theme. Assert that it preserves
    // the same 14dp floating-label scale as the surrounding form rather than
    // silently falling back to the application default.
    for (final fieldKey in const [
      ValueKey('trade-result-input'),
      ValueKey('trade-expected-loss-input'),
      ValueKey('trade-risk-input'),
      ValueKey('trade-reward-risk-input'),
    ]) {
      final fieldInput = find.descendant(
        of: find.byKey(fieldKey),
        matching: find.byType(InputDecorator),
      );
      expect(fieldInput, findsOneWidget);
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.labelStyle?.fontSize,
        14,
        reason: 'all Trade Data numeric/readout fields must use the enlarged common floating-label scale',
      );
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.floatingLabelStyle?.fontSize,
        14,
      );
    }

    final marketInput = tester.widget<InputDecorator>(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    expect(marketInput.decoration.fillColor, const Color(0xFF071834));
    final marketCaption = tester.widget<Text>(
      find.descendant(of: marketField, matching: find.text('الرمز')),
    );
    expect(marketCaption.textAlign, TextAlign.center);
    final directionCaption = tester.widget<Text>(
      find.descendant(of: directionSelector, matching: find.text('الاتجاه')),
    );
    expect(directionCaption.textAlign, TextAlign.center);
    expect(
      marketInput.decoration.floatingLabelAlignment,
      FloatingLabelAlignment.center,
      reason: 'the separator in the market/direction title must align with the central divider below it',
    );
    final marketBorder = marketInput.decoration.border as OutlineInputBorder;
    expect(marketBorder.borderRadius, BorderRadius.circular(14));
    expect(marketBorder.borderSide.width, .78);
    final popupTheme = Theme.of(tester.element(marketField)).popupMenuTheme;
    expect(popupTheme.color, const Color(0xFF102846));
    expect(popupTheme.surfaceTintColor, Colors.transparent);
    final popupShape = popupTheme.shape as RoundedRectangleBorder;
    expect(popupShape.borderRadius, BorderRadius.circular(12));
    expect(popupShape.side.color, const Color(0xFF315C8C));
    expect(popupShape.side.width, .85);
    expect(tdPopupMenuAnimationStyle.duration, const Duration(milliseconds: 105));
    expect(
      tdPopupMenuAnimationStyle.reverseDuration,
      const Duration(milliseconds: 85),
    );
    expect(
      find.descendant(of: marketField, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    expect(
      find.descendant(of: directionSelector, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    final anchorSelector = find.byKey(const ValueKey('trade-anchor-selector'));
    final anchorInputFinder = find.descendant(
      of: anchorSelector,
      matching: find.byType(InputDecorator),
    );
    expect(anchorInputFinder, findsOneWidget);
    final anchorInput = tester.widget<InputDecorator>(anchorInputFinder);
    expect(anchorInput.decoration.fillColor, const Color(0xFF071834));
    expect(anchorInput.decoration.labelStyle?.fontSize, 14,
        reason: 'the anchor floating label must use the enlarged common form label size');
    final anchorBorder = anchorInput.decoration.border as OutlineInputBorder;
    expect(anchorBorder.borderRadius, BorderRadius.circular(14));
    expect(anchorBorder.borderSide.width, .78);
    double? marketPopupWidth;
    for (final symbol in const ['NQ', 'ES', 'GC']) {
      await tester.tap(marketField);
      await tester.pumpAndSettle();
      expect(
        find.byType(PopupMenuItem<String>),
        findsNWidgets(3),
        reason: 'the symbol popup must render all three options at once',
      );
      expect(tester.widget<Text>(find.text('NQ')).style?.fontSize, 14.5);
      for (final availableSymbol in const ['NQ', 'ES', 'GC']) {
        final optionFinder = find.byKey(
          ValueKey('trade-market-option-$availableSymbol'),
        );
        expect(
          optionFinder,
          findsOneWidget,
          reason: 'all supported market symbols must remain visible in the popup',
        );
        final optionRect = tester.getRect(optionFinder);
        expect(optionRect.width, closeTo(120, 1));
        marketPopupWidth ??= optionRect.width;
        expect(optionRect.width, closeTo(marketPopupWidth!, .1));
        expect(optionRect.left, greaterThanOrEqualTo(0));
        expect(optionRect.right, lessThanOrEqualTo(tester.view.physicalSize.width / tester.view.devicePixelRatio));
      }
      await tester.tap(find.byKey(ValueKey('trade-market-option-$symbol')));
      await tester.pumpAndSettle();
      expect(
        find.descendant(of: marketField, matching: find.text(symbol)),
        findsOneWidget,
      );
      expect(
        find.descendant(of: marketField, matching: find.text('الرمز')),
        findsNothing,
        reason: 'the symbol caption must disappear after a symbol is selected',
      );
    }

    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    final buyOption = find.byKey(const ValueKey('trade-direction-option-buy'));
    expect(
      find.byType(PopupMenuItem<TradeSide>),
      findsNWidgets(2),
      reason: 'the direction popup must display both choices together',
    );
    expect(find.text('شراء'), findsOneWidget);
    expect(find.text('بيع'), findsOneWidget);
    final directionPopupWidth = tester.getRect(buyOption).width;
    expect(directionPopupWidth, closeTo(marketPopupWidth!, 1),
        reason: 'market and direction dropdowns must share the same compact width');
    expect(tester.widget<Text>(find.text('شراء')).style?.fontSize, 14.5);
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: directionSelector, matching: find.text('الاتجاه')),
      findsNothing,
      reason: 'the direction caption must disappear after a side is selected',
    );
    expect(
      find.descendant(of: directionSelector, matching: find.text('شراء')),
      findsOneWidget,
    );
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('شراء'), findsNothing);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('شراء'), findsOneWidget);

    await tester.tap(anchorSelector);
    await tester.pumpAndSettle();
    final anchorDialog = find.byKey(
      const ValueKey('trade-centered-multi-choice-anchor'),
    );
    expect(anchorDialog, findsOneWidget);
    expect(find.text('الارتكاز'), findsNWidgets(2),
        reason: 'the field label and centered dialog title are both visible while the anchor picker is open');
    final anchorDialogRect = tester.getRect(anchorDialog);
    expect(anchorDialogRect.width, lessThan(340));
    expect(
      (anchorDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the anchor selection list must be centered like the entry-reason dialog',
    );
    for (final option in [
      'Key Level',
      'Supply Zone',
      'Demand Zone',
      'Bullish Engulfing',
      'Bearish engulfing',
    ]) {
      expect(find.text(option), findsOneWidget);
    }
    expect(tester.widget<Text>(find.text('Bearish engulfing')).style?.fontSize, 14.5);
    expect(find.byKey(const ValueKey('trade-anchor-save')), findsNothing);
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-supplyZone')));
    await tester.pumpAndSettle();
    expect(find.text('فريم الارتكاز'), findsOneWidget,
        reason: 'every newly selected anchor must immediately request its timeframe');
    expect(find.byType(Dialog), findsNWidgets(2),
        reason: 'the timeframe selector is shown above the still-open centered multi-select anchor dialog');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    // The anchor menu remains available so multiple anchors can be selected;
    // each additional selection opens its own timeframe picker.
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-demandZone')));
    await tester.pumpAndSettle();
    expect(find.text('فريم الارتكاز'), findsOneWidget);
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    // A tap outside the popup dismisses it; both anchor/timeframe pairs stay selected.
    final anchorTopLeft = tester.getTopLeft(anchorSelector);
    await tester.tapAt(Offset(4, anchorTopLeft.dy + 10));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-anchor-option-supplyZone')), findsNothing);
    expect(find.byKey(const ValueKey('trade-anchor-save')), findsNothing);
    expect(find.byKey(const ValueKey('trade-anchor-value-supplyZone')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-anchor-value-demandZone')), findsOneWidget);
    expect(find.text('Supply Zone 15MIN'), findsOneWidget);
    expect(find.text('Demand Zone 30MIN'), findsOneWidget);
    final anchorLabelRect = tester.getRect(find.text('الارتكاز'));
    final firstAnchorValueRect = tester.getRect(
      find.byKey(const ValueKey('trade-anchor-value-supplyZone')),
    );
    expect(
      anchorLabelRect.bottom,
      lessThanOrEqualTo(firstAnchorValueRect.top + 1),
      reason: 'the enlarged anchor floating label must remain clear of selected content',
    );
    expect(find.byKey(const ValueKey('trade-anchor-remove-supplyZone')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-anchor-remove-demandZone')), findsOneWidget);
    // Tapping a selected anchor value edits its timeframe without opening the
    // multi-select list; the dropdown arrow remains the add/remove-list action.
    await tester.tap(find.byKey(const ValueKey('trade-anchor-value-supplyZone')));
    await tester.pumpAndSettle();
    expect(find.text('فريم الارتكاز'), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Supply Zone 5MIN'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trade-anchor-value-supplyZone')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Supply Zone 15MIN'), findsOneWidget);
    await tester.ensureVisible(anchorSelector);
    await tester.tap(find.byKey(const ValueKey('trade-anchor-remove-demandZone')));
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 30MIN'), findsNothing);
    await tester.tap(find.descendant(
      of: anchorSelector,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-demandZone')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 30MIN'), findsOneWidget);
    await tester.ensureVisible(moodMenu);
    final moodButton = tester.widget<PopupMenuButton<String>>(moodMenu);
    expect(moodButton.popUpAnimationStyle, tdPopupMenuAnimationStyle);
    await tester.tap(moodMenu);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-mood-option-moodCalm')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trade-mood-option-moodCalm')));
    await tester.pumpAndSettle();
    expect(tester.getSize(anchorSelector).height, greaterThan(45));
    expect(tester.getSize(anchorSelector).height, lessThan(180));
    final marketDirectionHeight = tester.getSize(
      find.byKey(const ValueKey('trade-market-direction-field')),
    ).height;
    final moodHeight = tester.getSize(moodMenu).height;
    expect(marketDirectionHeight, closeTo(moodHeight, .1),
        reason: 'market/direction and mindset fields must have the same visual height');
    final dividerRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-divider')),
    );
    expect(dividerRect.width, closeTo(1, .1));
    expect(dividerRect.height, closeTo(30, .1));
    final choicesRowFinder = find.byKey(
      const ValueKey('trade-market-direction-choices-row'),
    );
    final choicesRowRect = tester.getRect(choicesRowFinder);
    final marketTitleRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-label')),
    );
    expect(
      marketTitleRect.bottom,
      lessThanOrEqualTo(choicesRowRect.top + 1),
      reason: 'the enlarged market/direction title must not overlap the field contents',
    );
    expect(dividerRect.center.dx, closeTo(choicesRowRect.center.dx, .5),
        reason: 'the market/direction separator must sit exactly between the two equal choices');
    expect(dividerRect.center.dx, closeTo(marketDirectionRect.center.dx, .5),
        reason: 'the separator must sit at the visual midpoint of the complete market/direction rectangle');
    final marketDirectionLabelDivider = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-label-divider')),
    );
    expect(
      marketDirectionLabelDivider.center.dx,
      closeTo(dividerRect.center.dx, 1),
      reason: 'the slash in the market/direction floating title must be vertically aligned with the divider between symbol and side',
    );
    expect(dividerRect.center.dy, closeTo(choicesRowRect.center.dy, .5),
        reason: 'the separator must align vertically with the symbol and direction choices');
    expect(
      find.byKey(const ValueKey('trade-anchor-selected-values')),
      findsOneWidget,
      reason: 'selected anchors must render as separated rows inside the same outlined field',
    );
    expect(find.text('Supply Zone 15MIN'), findsOneWidget);
    expect(find.text('Demand Zone 30MIN'), findsOneWidget);
    final moodInput = tester.widget<InputDecorator>(
      find.descendant(
        of: find.byKey(const ValueKey('trade-mood-field')),
        matching: find.byType(InputDecorator),
      ),
    );
    expect(moodInput.decoration.labelStyle?.fontSize, 14);
    expect(moodInput.decoration.floatingLabelStyle?.fontSize, 14,
        reason: 'mindset floating label must use the same enlarged form label scale');
    await tester.enterText(find.byKey(const ValueKey('trade-result-input')), '42.5');
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    // Entry reason and confirmation now use the same floating-label input
    // container as Bounce area, with values rendered inside the field.
    final entryFieldInput = find.byKey(
      const ValueKey('entry-reason-field-input'),
    );
    final confirmationFieldInput = find.byKey(
      const ValueKey('confirmation-field-input'),
    );
    expect(entryFieldInput, findsOneWidget);
    expect(confirmationFieldInput, findsOneWidget);
    final emptyEntryField = tester.widget<InputDecorator>(entryFieldInput);
    final emptyConfirmationField = tester.widget<InputDecorator>(
      confirmationFieldInput,
    );
    expect(emptyEntryField.decoration.labelText, 'سبب الدخول');
    expect(emptyConfirmationField.decoration.labelText, 'تأكيد الدخول');
    expect(emptyEntryField.decoration.labelStyle?.fontSize, 14);
    expect(emptyConfirmationField.decoration.labelStyle?.fontSize, 14);
    expect(emptyEntryField.isEmpty, isTrue);
    expect(emptyConfirmationField.isEmpty, isTrue);
    expect(emptyEntryField.decoration.suffixIcon, isNotNull);
    expect(emptyConfirmationField.decoration.suffixIcon, isNotNull);
    const expectedTradeDataFieldFill = Color(0xFF071834);
    expect(
      emptyEntryField.decoration.fillColor,
      expectedTradeDataFieldFill,
      reason: 'Entry reason must use the same dark-blue selector fill as Trade Data',
    );
    expect(
      emptyConfirmationField.decoration.fillColor,
      expectedTradeDataFieldFill,
      reason: 'Entry confirmation must use the same dark-blue selector fill as Trade Data',
    );
    final entryBorder = emptyEntryField.decoration.border as OutlineInputBorder;
    final confirmationBorder = emptyConfirmationField.decoration.border as OutlineInputBorder;
    expect(entryBorder.borderRadius, BorderRadius.circular(14));
    expect(confirmationBorder.borderRadius, BorderRadius.circular(14));
    expect(entryBorder.borderSide.color, const Color(0xFF76AEE8).withValues(alpha: .30));
    expect(confirmationBorder.borderSide.color, const Color(0xFF76AEE8).withValues(alpha: .30));
    expect(emptyEntryField.decoration.floatingLabelAlignment, FloatingLabelAlignment.start);
    expect(emptyConfirmationField.decoration.floatingLabelAlignment, FloatingLabelAlignment.start);
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    final entryReasonDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(entryReasonDialog, findsOneWidget);
    final entryReasonDialogRect = tester.getRect(entryReasonDialog);
    expect(entryReasonDialogRect.width, lessThan(340));
    expect(
      (entryReasonDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the entry-reason list must be centered, not full-screen width',
    );
    final entryReasonDialogWidget = tester.widget<Dialog>(entryReasonDialog);
    expect(entryReasonDialogWidget.backgroundColor, const Color(0xFF102846));
    final entryReasonDialogShape =
        entryReasonDialogWidget.shape as RoundedRectangleBorder;
    expect(entryReasonDialogShape.borderRadius, BorderRadius.circular(12));
    expect(entryReasonDialogShape.side.color, const Color(0xFF315C8C));
    expect(
      tester.widget<Text>(find.text('RFS')).style?.fontSize,
      14.5,
      reason: 'entry-reason options should match the anchor-menu text scale',
    );
    await tester.tap(find.text('RFS').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 15MIN'), findsOneWidget);
    expect(tester.widget<InputDecorator>(entryFieldInput).isEmpty, isFalse);
    expect(
      find.descendant(
        of: entryFieldInput,
        matching: find.text('RFS 15MIN'),
      ),
      findsOneWidget,
      reason: 'the chosen entry reason and timeframe must render inside its floating-label field',
    );
    final removeEntryReason = find.byKey(
      const ValueKey('trade-setup-remove-entry-reason-0'),
    );
    expect(removeEntryReason, findsOneWidget);
    await tester.tap(removeEntryReason);
    await tester.pumpAndSettle();
    expect(find.text('RFS 15MIN'), findsNothing);
    expect(tester.widget<InputDecorator>(entryFieldInput).isEmpty, isTrue);
    // The dropdown edge remains the explicit add affordance after the field is populated.
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('RFS').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 15MIN'), findsOneWidget);

    await tester.ensureVisible(addConfirmation);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    final confirmationDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(confirmationDialog, findsOneWidget);
    final confirmationDialogRect = tester.getRect(confirmationDialog);
    expect(confirmationDialogRect.width, lessThan(340));
    expect(
      (confirmationDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the confirmation list must remain centered and compact',
    );
    final confirmationDialogWidget = tester.widget<Dialog>(confirmationDialog);
    expect(confirmationDialogWidget.backgroundColor, const Color(0xFF102846));
    final confirmationDialogShape =
        confirmationDialogWidget.shape as RoundedRectangleBorder;
    expect(confirmationDialogShape.borderRadius, BorderRadius.circular(12));
    expect(confirmationDialogShape.side.color, const Color(0xFF315C8C));
    await tester.tap(find.text('Bearish engulfing').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Bearish engulfing 5MIN'), findsOneWidget);
    expect(tester.widget<InputDecorator>(confirmationFieldInput).isEmpty, isFalse);
    expect(
      find.descendant(
        of: confirmationFieldInput,
        matching: find.text('Bearish engulfing 5MIN'),
      ),
      findsOneWidget,
      reason: 'the chosen confirmation and timeframe must render inside its floating-label field',
    );
    final removeConfirmation = find.byKey(
      const ValueKey('trade-setup-remove-confirmation-0'),
    );
    expect(removeConfirmation, findsOneWidget);
    await tester.tap(removeConfirmation);
    await tester.pumpAndSettle();
    expect(find.text('Bearish engulfing 5MIN'), findsNothing);
    expect(tester.widget<InputDecorator>(confirmationFieldInput).isEmpty, isTrue);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Bearish engulfing').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Bearish engulfing 5MIN'), findsOneWidget);

    final addReverse = find.byKey(const ValueKey('add-reverse-signal-setup'));
    final reverseHeader = find.byKey(
      const ValueKey('reverse-signal-category-trigger'),
    );
    await tester.ensureVisible(reverseHeader);
    await tester.tap(reverseHeader);
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'tapping the opposing-signals rectangle must open its centered choices immediately');
    expect(
      tester.widget<Dialog>(find.byType(Dialog)).backgroundColor,
      const Color(0xFF102846),
      reason: 'without a no-entry reason, the opposing-signals menu retains the standard popup surface',
    );
    final reverseDialogRect = tester.getRect(find.byType(Dialog));
    expect(reverseDialogRect.width, lessThan(340));
    expect(
      (reverseDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
    );
    expect(find.text('S/R عكسي'), findsOneWidget);
    expect(find.text('S - D Zone عكسي'), findsOneWidget);
    expect(find.text('HNS عكسي'), findsOneWidget);
    expect(find.text('ذيل شمعة طويل عكسي'), findsOneWidget);
    await tester.tap(find.text('S - D Zone عكسي'));
    await tester.pumpAndSettle();
    expect(find.text('الفريم الزمني'), findsOneWidget);
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'the timeframe list must use the same centered dialog');
    expect(
      tester.widget<Dialog>(find.byType(Dialog)).backgroundColor,
      const Color(0xFF102846),
      reason: 'without a no-entry reason, reverse-signal timeframes must retain the original blue dialog surface',
    );
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(addReverse, findsOneWidget);
    expect(find.text('Supply Zone 30MIN'), findsOneWidget,
        reason: 'a Buy trade maps reverse S-D Zone to Supply Zone automatically');

    // The saved category remains semantic, so a direction change immediately
    // changes its opposing price reference without requiring re-entry.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 30MIN'), findsOneWidget);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Supply Zone 30MIN'), findsOneWidget);

    // The two direct opposing signal types also lead to timeframe selection.
    await tester.ensureVisible(addReverse);
    await tester.tap(find.descendant(of: addReverse, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('HNS عكسي'));
    await tester.pumpAndSettle();
    expect(find.text('الفريم الزمني'), findsOneWidget);
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();
    expect(find.text('HNS عكسي 1H'), findsOneWidget);

    await tester.ensureVisible(addReverse);
    await tester.tap(find.descendant(of: addReverse, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ذيل شمعة طويل عكسي'));
    await tester.pumpAndSettle();
    expect(find.text('الفريم الزمني'), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('ذيل شمعة طويل عكسي 5MIN'), findsOneWidget);

    final addBounce = find.byKey(const ValueKey('add-bounce-zone-setup'));
    final bounceHeader = find.byKey(
      const ValueKey('bounce-zone-category-trigger'),
    );
    await tester.ensureVisible(bounceHeader);
    await tester.tap(bounceHeader);
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'tapping the bounce-area rectangle must open its centered choices immediately');
    final bounceChoiceDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    final bounceChoiceTokens = TdTokens.of(tester.element(bounceChoiceDialog));
    expect(
      tester.widget<Dialog>(bounceChoiceDialog).backgroundColor,
      Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        bounceChoiceTokens.surface2,
      ),
      reason: 'Bounce area choice list must match the Opposing signals color',
    );
    await tester.tap(find.text('ارتداد من ترند لاين و Supply Zone'));
    await tester.pumpAndSettle();
    expect(find.text('فريم ترند لاين'), findsOneWidget);
    expect(find.byType(Dialog), findsOneWidget);
    final bounceTimeframeDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    final bounceTimeframeTokens = TdTokens.of(tester.element(bounceTimeframeDialog));
    expect(
      tester.widget<Dialog>(bounceTimeframeDialog).backgroundColor,
      Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        bounceTimeframeTokens.surface2,
      ),
      reason: 'Bounce area timeframe list must match the Opposing signals timeframe list',
    );
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();
    expect(find.text('فريم Supply Zone'), findsOneWidget,
        reason: 'the Supply Zone timeframe picker should open automatically');
    expect(find.byType(Dialog), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();

    expect(find.textContaining('ارتداد من Trend Line 1H - Supply Zone 5MIN'), findsOneWidget);
    final selectedBounceDecorator = tester.widget<InputDecorator>(
      find.descendant(of: bounceField, matching: find.byType(InputDecorator)),
    );
    expect(selectedBounceDecorator.isEmpty, isFalse,
        reason: 'the Bounce area label must float above the selected value inside the same field');
    final selectedReverseDecorator = tester.widget<InputDecorator>(
      find.descendant(of: reverseField, matching: find.byType(InputDecorator)),
    );
    expect(selectedReverseDecorator.isEmpty, isFalse,
        reason: 'the Opposing signals label must float above the selected value inside the same field');
    final selectedBounceLabel = tester.widget<Text>(
      find.byKey(const ValueKey('entry-condition-label-bounceFromTrendlineAndSupplyZone-1H-5MIN-false')),
    );
    expect(selectedBounceLabel.softWrap, isTrue);
    expect(selectedBounceLabel.maxLines, isNull);
    expect(selectedBounceLabel.overflow, isNull);
    final selectedReverseLabel = tester.widget<Text>(
      find.byKey(const ValueKey('entry-condition-label-reverseSdZone-30MIN--false')),
    );
    expect(selectedReverseLabel.softWrap, isTrue);
    expect(selectedReverseLabel.maxLines, isNull);
    expect(selectedReverseLabel.overflow, isNull);
    expect(find.text('إضافة اختيار'), findsNothing);
    expect(find.text('اختيار'), findsNothing, reason: 'opposing and bounce selections are integrated inside their input fields');
    expect(find.descendant(of: reverseHeader, matching: find.byIcon(Icons.add_rounded)), findsNothing);
    expect(find.descendant(of: bounceHeader, matching: find.byIcon(Icons.add_rounded)), findsNothing);
    expect(find.descendant(of: addReverse, matching: find.byIcon(Icons.add)), findsNothing);
    expect(find.descendant(of: addBounce, matching: find.byIcon(Icons.add)), findsNothing);

    await tester.ensureVisible(addBounce);
    await tester.tap(find.descendant(of: addBounce, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    expect(find.text('تفصيل ارتداد S/R — اختياري'), findsOneWidget);
    final srTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(srTouch2, findsOneWidget);
    await tester.tap(srTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    final srTouch2Chip = find.text('ارتداد من دعم - لمسة 2 15MIN');
    expect(srTouch2Chip, findsOneWidget);

    // Editing an S/R bounce restores the previous Touch 2 choice.
    await tester.ensureVisible(srTouch2Chip);
    await tester.tap(srTouch2Chip);
    await tester.pumpAndSettle();
    final selectedSrTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(tester.widget<ListTile>(selectedSrTouch2).selected, isTrue);
    await tester.tap(selectedSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    // The dropdown keeps one direction selected; switching to sell and back
    // updates the directional interpretation of the S/R bounce.
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من مقاومة - لمسة 2 15MIN'), findsOneWidget);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من دعم - لمسة 2 15MIN'), findsOneWidget);

    // A second S/R bounce can explicitly skip the optional Touch 2 qualifier.
    await tester.ensureVisible(addBounce);
    await tester.tap(find.descendant(of: addBounce, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    final skipSrTouch2 = find.byKey(
      const ValueKey('skip-touch2-bounceFromSrZone'),
    );
    expect(skipSrTouch2, findsOneWidget);
    await tester.tap(skipSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من دعم 4H'), findsOneWidget);

    final classify = find.byKey(
      const ValueKey('choose-trade-classification-button'),
    );
    await tester.ensureVisible(classify);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-classification-option-win')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-loss')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-breakEven')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-missed')),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-classification-option-win')),
    );
    await tester.pumpAndSettle();
    expect(classify, findsNothing);

    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.win);
    expect(savedTrade!.effectiveClassification, TradeClassification.win);
    expect(savedTrade!.market, 'GC');
    expect(savedTrade!.side, TradeSide.buy);
    expect(savedTrade!.anchor, 'supplyZone');
    expect(savedTrade!.effectiveAnchors, ['supplyZone', 'demandZone']);
    expect(savedTrade!.anchorTimeframes, {'supplyZone': '15MIN', 'demandZone': '30MIN'});
    expect(savedTrade!.reverseSignalSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'reverseSdZone',
        timeframe: '30MIN',
      ),
      TradeEntryConditionSetup(
        optionKey: 'reverseHns',
        timeframe: '1H',
      ),
      TradeEntryConditionSetup(
        optionKey: 'reverseLongCandleWick',
        timeframe: '5MIN',
      ),
    ]);
    expect(savedTrade!.bounceZoneSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'bounceFromTrendlineAndSupplyZone',
        timeframe: '1H',
        secondaryTimeframe: '5MIN',
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '15MIN',
        touch2: true,
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '4H',
      ),
    ]);
    expect(savedTrade!.entrySetups.single, const TradeEntrySetup(reason: 'RFS', timeframe: '15MIN'));
    expect(savedTrade!.confirmationSetups.single, const TradeConfirmationSetup(type: 'confirmBearishEngulfing', timeframe: '5MIN'));
  });

  testWidgets('requires a trade direction before selecting an opposing signal', (tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final addReverse = find.byKey(const ValueKey('add-reverse-signal-setup'));
    await tester.ensureVisible(addReverse);
    await tester.tap(find.descendant(of: addReverse, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();

    expect(
      find.text('حدد اتجاه الصفقة شراء أو بيع أولاً حتى تُعرض الإشارة العكسية الصحيحة.'),
      findsOneWidget,
    );
    expect(find.byType(Dialog), findsNothing);
    expect(find.text('S/R عكسي'), findsNothing);
  });

  testWidgets(
    'a no-entry selection links opposing signals without changing field fill color',
    (tester) async {
      tester.view.setLogicalSize(const Size(360, 800));
      tester.view.devicePixelRatio = 1;
      await tester.pumpWidget(
        AppScope(
          controller: app,
          child: MaterialApp(
            theme: buildAppTheme(Brightness.dark),
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar'), Locale('en')],
            localizationsDelegates: GlobalMaterialLocalizations.delegates,
            home: const TradeFormScreen(),
          ),
        ),
      );
      await tester.pumpAndSettle();

      final reverseSurfaceFinder =
          find.byKey(const ValueKey('reverse-signal-category-surface'));
      await tester.scrollUntilVisible(reverseSurfaceFinder, 160);
      await tester.pumpAndSettle();
      final reverseSurfaceBefore =
          tester.widget<Container>(reverseSurfaceFinder);
      final reverseInputFinder = find.descendant(
        of: reverseSurfaceFinder,
        matching: find.byType(InputDecorator),
      );
      final neutralConditionFill =
          TdTokens.of(tester.element(reverseInputFinder)).surface2;

      expect(reverseSurfaceBefore.decoration, isNull,
          reason: 'the category is a single input field rather than a nested category card');
      expect(
        tester.widget<InputDecorator>(reverseInputFinder).decoration.fillColor,
        neutralConditionFill,
      );
      expect(
        find.byKey(const ValueKey('no-entry-reverse-signal-connector')),
        findsNothing,
      );

      // The three catalog group headings inside the Decisions expansion are
      // the hierarchy labels the user needs to distinguish from option rows.
      await tester.ensureVisible(find.text('القرارات'));
      await tester.tap(find.text('القرارات'));
      await tester.pumpAndSettle();
      final reviewGroupHeadings = <String, String>{
        'مخالفات التنفيذ': 'Execution violations',
        'جودة التحليل والإعداد': 'Analysis & setup quality',
        'قرارات الدخول وإدارة المخاطرة': 'Entry & risk-management decisions',
      };
      for (final entry in reviewGroupHeadings.entries) {
        final heading = tester.widget<Text>(
          find.byKey(ValueKey('trade-review-group-heading-${entry.value}')),
        );
        expect(heading.data, entry.key);
        expect(heading.style!.color, Colors.white);
        expect(heading.style!.fontSize, 16);
        expect(heading.style!.fontWeight, FontWeight.w800);
      }
      final reviewOption = find.byKey(const ValueKey('review-enteredEarly'));
      final reviewOptionLabel = tester.widget<Text>(
        find.descendant(of: reviewOption, matching: find.byType(Text)),
      );
      expect(reviewOptionLabel.style!.fontSize, 14.5);
      expect(
        16,
        greaterThan(reviewOptionLabel.style!.fontSize!),
        reason: 'group headings must read as a separate hierarchy level above options',
      );
      await tester.tap(find.text('القرارات'));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('أسباب عدم الدخول'));
      await tester.tap(find.text('أسباب عدم الدخول'));
      await tester.pumpAndSettle();
      final noEntryOption =
          find.byKey(const ValueKey('no-entry-fearRepeatLossAfterLoss'));
      final noEntryLabel = tester.widget<Text>(
        find.descendant(of: noEntryOption, matching: find.byType(Text)),
      );
      expect(noEntryLabel.style!.fontSize, 14.5);
      await tester.ensureVisible(noEntryOption);
      await tester.tap(noEntryOption);
      await tester.pumpAndSettle();

      final reverseSurfaceAfter =
          tester.widget<Container>(reverseSurfaceFinder);
      expect(reverseSurfaceAfter.decoration, isNull);
      expect(
        tester.widget<InputDecorator>(reverseInputFinder).decoration.fillColor,
        neutralConditionFill,
      );
      final bounceSurfaceFinder =
          find.byKey(const ValueKey('bounce-zone-category-surface'));
      final bounceInputFinder = find.descendant(
        of: bounceSurfaceFinder,
        matching: find.byType(InputDecorator),
      );
      expect(
        tester.widget<InputDecorator>(bounceInputFinder).decoration.fillColor,
        neutralConditionFill,
        reason: 'Bounce area field must keep the neutral surface regardless of signal accent',
      );
      final connector = find.byKey(
        const ValueKey('no-entry-reverse-signal-connector'),
      );
      expect(connector, findsOneWidget);
      final connectorPaint = tester.widget<CustomPaint>(connector);
      expect(
        connectorPaint.painter,
        isNotNull,
        reason: 'the connector must be drawn inside its dedicated side rail',
      );
      expect(
        connectorPaint.foregroundPainter,
        isNull,
        reason: 'the connector must not be layered over the cards',
      );
      final connectorRect = tester.getRect(connector);
      final contentRect = tester.getRect(
        find.byKey(const ValueKey('linked-entry-behavior-content')),
      );
      final linkedStackRect = tester.getRect(
        find.byKey(const ValueKey('linked-entry-behavior-stack')),
      );
      expect(connectorRect.width, 12);
      expect(connectorRect.height, linkedStackRect.height);
      expect(connectorRect.overlaps(contentRect), isFalse);
      expect(
        connectorRect.left,
        greaterThanOrEqualTo(contentRect.right),
        reason: 'in Arabic RTL, the connector rail must remain outside the right edge of the cards',
      );
      expect(connectorRect.height, greaterThan(100));
      final reverseAnchorRect = tester.getRect(
        find.byKey(const ValueKey('reverse-signal-connector-anchor')),
      );
      final noEntryAnchorRect = tester.getRect(
        find.byKey(const ValueKey('no-entry-connector-anchor')),
      );
      expect(reverseAnchorRect.center.dy, lessThan(noEntryAnchorRect.center.dy));

      // Reverse S/R and S-D categories are direction-aware; select Buy
      // before opening the category list.
      final directionSelector = find.byKey(
        const ValueKey('trade-direction-selector'),
      );
      await tester.ensureVisible(directionSelector);
      await tester.tap(directionSelector);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trade-direction-option-buy')),
      );
      await tester.pumpAndSettle();

      // The reverse-signals selector must inherit the same muted purple
      // semantic tone as its category while that category is linked.
      final reverseHeader = find.byKey(
        const ValueKey('reverse-signal-category-trigger'),
      );
      await tester.ensureVisible(reverseHeader);
      await tester.tap(reverseHeader);
      await tester.pumpAndSettle();
      final reverseChoiceDialog = find.byKey(
        const ValueKey('trade-centered-choice-single-choice'),
      );
      final dialogWidget = tester.widget<Dialog>(reverseChoiceDialog);
      final dialogTokens = TdTokens.of(tester.element(reverseChoiceDialog));
      expect(
        dialogWidget.backgroundColor,
        Color.alphaBlend(
          const Color(0xFFB69AF0).withValues(alpha: .14),
          dialogTokens.surface2,
        ),
      );
      final dialogShape = dialogWidget.shape as RoundedRectangleBorder;
      expect(
        dialogShape.side.color,
        const Color(0xFFB69AF0).withValues(alpha: .17),
      );
      final reverseChoiceTile = tester.widget<ListTile>(
        find.descendant(
          of: reverseChoiceDialog,
          matching: find.byType(ListTile),
        ).first,
      );
      expect(
        reverseChoiceTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
      );
      await tester.tap(find.text('S/R عكسي'));
      await tester.pumpAndSettle();
      final reverseTimeframeDialog = find.byKey(
        const ValueKey('trade-centered-choice-single-choice'),
      );
      expect(find.text('الفريم الزمني'), findsOneWidget);
      final reverseTimeframeDialogWidget = tester.widget<Dialog>(
        reverseTimeframeDialog,
      );
      final reverseTimeframeTokens = TdTokens.of(
        tester.element(reverseTimeframeDialog),
      );
      expect(
        reverseTimeframeDialogWidget.backgroundColor,
        Color.alphaBlend(
          const Color(0xFFB69AF0).withValues(alpha: .14),
          reverseTimeframeTokens.surface2,
        ),
        reason: 'the timeframe picker opened from an opposing signal must keep the linked purple surface',
      );
      final reverseTimeframeShape =
          reverseTimeframeDialogWidget.shape as RoundedRectangleBorder;
      expect(
        reverseTimeframeShape.side.color,
        const Color(0xFFB69AF0).withValues(alpha: .17),
      );
      final reverseTimeframeTile = tester.widget<ListTile>(
        find.descendant(
          of: reverseTimeframeDialog,
          matching: find.byType(ListTile),
        ).first,
      );
      expect(
        reverseTimeframeTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
        reason: 'timeframe rows must use the same purple semantic selection tint',
      );
      await tester.tap(find.text('30MIN').last);
      await tester.pumpAndSettle();
      expect(
        find.text('Support عكسي 30MIN'),
        findsOneWidget,
        reason: 'a Buy trade must show the reversed support role',
      );

      await tester.ensureVisible(directionSelector);
      await tester.tap(directionSelector);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trade-direction-option-sell')),
      );
      await tester.pumpAndSettle();
      expect(
        find.text('Resistance عكسي 30MIN'),
        findsOneWidget,
        reason: 'a Sell trade must show the reversed resistance role',
      );

      await tester.tap(directionSelector);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trade-direction-option-buy')),
      );
      await tester.pumpAndSettle();
      expect(
        find.text('Support عكسي 30MIN'),
        findsOneWidget,
        reason: 'switching back to Buy must restore the reversed support label',
      );

      // Editing an existing opposing signal keeps the active purple selection
      // state rather than reverting to the application's default blue accent.
      final selectedReverseSetup = find.byKey(
        const ValueKey('entry-condition-reverseSr-30MIN--false'),
      );
      await tester.ensureVisible(selectedReverseSetup);
      await tester.tap(selectedReverseSetup);
      await tester.pumpAndSettle();
      final selectedReverseTileFinder = find.descendant(
        of: find.byKey(const ValueKey('trade-centered-choice-single-choice')),
        matching: find.byWidgetPredicate(
          (widget) => widget is ListTile && widget.selected,
        ),
      );
      expect(selectedReverseTileFinder, findsOneWidget);
      final selectedReverseTile = tester.widget<ListTile>(
        selectedReverseTileFinder,
      );
      expect(selectedReverseTile.selected, isTrue);
      expect(
        selectedReverseTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
      );
      await tester.tap(selectedReverseTileFinder);
      await tester.pumpAndSettle();
      final editTimeframeDialog = find.byKey(
        const ValueKey('trade-centered-choice-single-choice'),
      );
      expect(find.text('الفريم الزمني'), findsOneWidget);
      final editTimeframeTile = tester.widget<ListTile>(
        find.descendant(
          of: editTimeframeDialog,
          matching: find.byWidgetPredicate(
            (widget) => widget is ListTile && widget.selected,
          ),
        ),
      );
      expect(editTimeframeTile.selected, isTrue);
      expect(
        editTimeframeTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
        reason: 'editing an opposing signal must keep the timeframe selection purple too',
      );
      final editTimeframeDialogWidget = tester.widget<Dialog>(
        editTimeframeDialog,
      );
      expect(
        editTimeframeDialogWidget.backgroundColor,
        Color.alphaBlend(
          const Color(0xFFB69AF0).withValues(alpha: .14),
          TdTokens.of(tester.element(editTimeframeDialog)).surface2,
        ),
      );
      await tester.tapAt(const Offset(6, 6));
      await tester.pumpAndSettle();

      await tester.ensureVisible(noEntryOption);
      await tester.tap(noEntryOption);
      await tester.pumpAndSettle();
      final reverseInputAfterRemoval = find.descendant(
        of: reverseSurfaceFinder,
        matching: find.byType(InputDecorator),
      );
      expect(
        tester.widget<InputDecorator>(reverseInputAfterRemoval).decoration.fillColor,
        neutralConditionFill,
        reason: 'removing the no-entry reason must restore the accent only, never recolor the field interior',
      );
      expect(connector, findsNothing);
      await tester.ensureVisible(reverseHeader);
      await tester.tap(reverseHeader);
      await tester.pumpAndSettle();
      expect(
        tester.widget<Dialog>(find.byType(Dialog)).backgroundColor,
        const Color(0xFF102846),
        reason: 'the opposing-signals menu returns to its standard surface when the last no-entry reason is removed',
      );
      await tester.tapAt(const Offset(6, 6));
      await tester.pumpAndSettle();
    },
  );

  test('new conditions remain backward compatible with existing trade JSON', () {
    final legacy = <String, dynamic>{
      'id': 'legacy',
      'accountId': 'conditions-account',
      'market': 'EURUSD',
      'reason': 'SBR',
      'result': 5,
      'riskPercent': .5,
      'side': 'buy',
      'confirmation': 'confirmBearishEngulfing',
      'sequence': '',
      'mood': 'moodCalm',
      'tradedAt': DateTime(2025, 1, 2).toIso8601String(),
    };
    final restored = Trade.fromJson(legacy);
    expect(restored.reverseSignalSetups, isEmpty);
    expect(restored.bounceZoneSetups, isEmpty);
    expect(restored.anchor, isNull);
    expect(restored.effectiveAnchors, isEmpty);
    expect(restored.anchorTimeframes, isEmpty);
  });
}
