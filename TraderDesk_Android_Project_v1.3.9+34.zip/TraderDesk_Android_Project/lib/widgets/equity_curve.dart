import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../domain/trade_ordering.dart';
import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../theme/app_theme.dart';
import 'common.dart';

enum _EquityRange { days30, days90, days365, all }

enum _PeriodSize { day, week, month }

class EquityCurve extends StatefulWidget {
  const EquityCurve({
    super.key,
    required this.trades,
    required this.currency,
    required this.startingBalance,
  });

  final List<Trade> trades;
  final String currency;
  final double startingBalance;

  @override
  State<EquityCurve> createState() => _EquityCurveState();
}

class _EquityCurveState extends State<EquityCurve> {
  _EquityRange _range = _EquityRange.all;
  int? _selectedIndex;

  String _rangeLabel(BuildContext context, _EquityRange range) =>
      switch (range) {
        _EquityRange.days30 => tr(context, 'equityRange30'),
        _EquityRange.days90 => tr(context, 'equityRange90'),
        _EquityRange.days365 => tr(context, 'equityRange365'),
        _EquityRange.all => tr(context, 'equityRangeAll'),
      };

  _EquityData _makeData(DateTime now) {
    final sorted = [...widget.trades]..sort(compareTradesAscending);
    final today = DateTime(now.year, now.month, now.day);
    final size = switch (_range) {
      _EquityRange.days30 => _PeriodSize.day,
      _EquityRange.days90 => _PeriodSize.week,
      _EquityRange.days365 || _EquityRange.all => _PeriodSize.month,
    };
    final start = switch (_range) {
      _EquityRange.days30 => today.subtract(const Duration(days: 29)),
      _EquityRange.days90 => today.subtract(const Duration(days: 89)),
      _EquityRange.days365 => today.subtract(const Duration(days: 364)),
      _EquityRange.all => DateTime(
        sorted.isEmpty ? today.year : sorted.first.tradedAt.year,
        sorted.isEmpty ? today.month : sorted.first.tradedAt.month,
      ),
    };
    final startDay = DateTime(start.year, start.month, start.day);
    final startMonth = start.year * 12 + start.month;
    var openingBalance = widget.startingBalance;
    final visible = <Trade>[];
    for (final trade in sorted) {
      final date = DateTime(
        trade.tradedAt.year,
        trade.tradedAt.month,
        trade.tradedAt.day,
      );
      if (date.isAfter(today)) continue;
      if (date.isBefore(startDay)) {
        openingBalance += trade.result;
      } else {
        visible.add(trade);
      }
    }

    int bucketIndex(DateTime date) => switch (size) {
      _PeriodSize.day => date.difference(startDay).inDays,
      _PeriodSize.week => date.difference(startDay).inDays ~/ 7,
      _PeriodSize.month => date.year * 12 + date.month - startMonth,
    };

    final count = switch (size) {
      _PeriodSize.day => 30,
      _PeriodSize.week => 13,
      _PeriodSize.month => math.max(
        1,
        today.year * 12 + today.month - startMonth + 1,
      ),
    };
    final buckets = List<_EquityBucket>.generate(
      count,
      (index) => _EquityBucket(
        start: switch (size) {
          _PeriodSize.day => startDay.add(Duration(days: index)),
          _PeriodSize.week => startDay.add(Duration(days: index * 7)),
          _PeriodSize.month => DateTime(start.year, start.month + index),
        },
      ),
    );

    var balance = openingBalance;
    var peak = openingBalance;
    var maxDrawdown = 0.0;
    var maxDrawdownPercent = 0.0;
    for (final trade in visible) {
      final index = bucketIndex(trade.tradedAt);
      if (index < 0 || index >= buckets.length) continue;
      final bucket = buckets[index];
      bucket.result += trade.result;
      bucket.tradeCount++;
      balance += trade.result;
      if (balance > peak) peak = balance;
      final drawdown = peak - balance;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
      final drawdownPercent = peak > 0 ? drawdown / peak * 100 : 0.0;
      if (drawdownPercent > maxDrawdownPercent) {
        maxDrawdownPercent = drawdownPercent;
      }
    }

    balance = openingBalance;
    for (final bucket in buckets) {
      balance += bucket.result;
      bucket.balance = balance;
    }
    return _EquityData(
      buckets: buckets,
      openingBalance: openingBalance,
      netChange: balance - openingBalance,
      maxDrawdown: maxDrawdown,
      maxDrawdownPercent: maxDrawdownPercent,
      tradeCount: visible.length,
    );
  }

  void _selectPoint(Offset position, double width, int count) {
    if (count == 0 || width <= 0) return;
    final index = ((position.dx / width).clamp(0.0, 1.0) * count).floor().clamp(
      0,
      count - 1,
    );
    if (_selectedIndex != index) setState(() => _selectedIndex = index);
  }

  @override
  void didUpdateWidget(covariant EquityCurve oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(widget.trades, oldWidget.trades) ||
        widget.startingBalance != oldWidget.startingBalance) {
      _selectedIndex = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _makeData(DateTime.now());
    final selectedIndex = _selectedIndex == null
        ? null
        : _selectedIndex!.clamp(0, data.buckets.length - 1);
    final selected = selectedIndex == null ? null : data.buckets[selectedIndex];
    final tokens = TdTokens.of(context);
    final netColor = data.netChange > 0
        ? tokens.profit
        : data.netChange < 0
        ? tokens.loss
        : tokens.neutral;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                tr(context, 'balanceHistory'),
                style: Theme.of(
                  context,
                ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                money(data.buckets.last.balance, widget.currency),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.end,
                style: TextStyle(color: netColor, fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 6,
          runSpacing: 5,
          children: [
            for (final range in _EquityRange.values)
              ChoiceChip(
                key: ValueKey('equity-period-${range.name}'),
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                label: Text(_rangeLabel(context, range)),
                selected: range == _range,
                onSelected: (_) => setState(() {
                  _range = range;
                  _selectedIndex = null;
                }),
              ),
          ],
        ),
        const SizedBox(height: 12),
        _ChartPanelTitle(
          icon: Icons.bar_chart_rounded,
          label: tr(context, 'chartPeriodResults'),
          color: tokens.accent,
        ),
        const SizedBox(height: 5),
        _ChartPanelTitle(
          icon: Icons.show_chart_rounded,
          label: tr(context, 'chartBalanceGrowth'),
          color: tokens.profit,
        ),
        const SizedBox(height: 5),
        LayoutBuilder(
          builder: (context, constraints) => SizedBox(
            height: 208,
            child: RepaintBoundary(
              child: Semantics(
                key: const ValueKey('equity-chart-semantics'),
                label: tr(context, 'equityTouchHint'),
                value: selected == null
                    ? money(data.buckets.last.balance, widget.currency)
                    : '${shortDate(selected.start)} · ${money(selected.result, widget.currency)} · ${money(selected.balance, widget.currency)}',
                child: GestureDetector(
                  key: const ValueKey('equity-curve-canvas'),
                  behavior: HitTestBehavior.opaque,
                  onTapDown: (details) => _selectPoint(
                    details.localPosition,
                    constraints.maxWidth,
                    data.buckets.length,
                  ),
                  onPanUpdate: (details) => _selectPoint(
                    details.localPosition,
                    constraints.maxWidth,
                    data.buckets.length,
                  ),
                  child: CustomPaint(
                    size: Size.infinite,
                    painter: _PerformancePainter(
                      buckets: data.buckets,
                      openingBalance: data.openingBalance,
                      selectedIndex: selectedIndex,
                      positive: tokens.profit,
                      negative: tokens.loss,
                      lineColor: tokens.accent,
                      gridColor: tokens.lineSubtle,
                      baselineColor: tokens.text3.withValues(alpha: 0.7),
                      surfaceColor: tokens.surface1,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Row(
            children: [
              Expanded(child: Text(shortDate(data.buckets.first.start))),
              Text(shortDate(data.buckets.last.start)),
            ],
          ),
        ),
        const SizedBox(height: 9),
        if (selected != null) ...[
          Container(
            padding: const EdgeInsetsDirectional.fromSTEB(10, 8, 10, 8),
            decoration: BoxDecoration(
              color: tokens.surface3,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: tokens.lineSubtle),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        shortDate(selected.start),
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${money(selected.result, widget.currency)}  ·  ${selected.tradeCount} ${tr(context, 'equityTrades')}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: selected.result > 0
                              ? tokens.profit
                              : selected.result < 0
                              ? tokens.loss
                              : tokens.text1,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '${tr(context, 'equityPeriodClosingBalance')}: ${money(selected.balance, widget.currency)}',
                        style: Theme.of(
                          context,
                        ).textTheme.labelSmall?.copyWith(color: tokens.text2),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  key: const ValueKey('equity-clear-selection'),
                  visualDensity: VisualDensity.compact,
                  tooltip: tr(context, 'clearSelection'),
                  onPressed: () => setState(() => _selectedIndex = null),
                  icon: const Icon(Icons.close, size: 17),
                ),
              ],
            ),
          ),
          const SizedBox(height: 9),
        ],
        Row(
          children: [
            Expanded(
              child: _ChartStat(
                label: tr(context, 'equityNetChange'),
                value: money(data.netChange, widget.currency),
                color: netColor,
              ),
            ),
            const SizedBox(width: 7),
            Expanded(
              child: _ChartStat(
                label: tr(context, 'maxDrawdown'),
                value:
                    '${money(data.maxDrawdown, widget.currency)} · ${data.maxDrawdownPercent.toStringAsFixed(1)}%',
                color: data.maxDrawdown > 0 ? tokens.loss : null,
              ),
            ),
            const SizedBox(width: 7),
            Expanded(
              child: _ChartStat(
                label: tr(context, 'equityTrades'),
                value: '${data.tradeCount}',
                color: tokens.accent,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Icon(Icons.touch_app_outlined, size: 17, color: tokens.text3),
            const SizedBox(width: 7),
            Expanded(
              child: Text(
                tr(context, 'equityTouchHint'),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _ChartPanelTitle extends StatelessWidget {
  const _ChartPanelTitle({
    required this.icon,
    required this.label,
    required this.color,
  });

  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Icon(icon, size: 16, color: color),
      const SizedBox(width: 5),
      Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: color,
          fontWeight: FontWeight.w700,
        ),
      ),
    ],
  );
}

class _ChartStat extends StatelessWidget {
  const _ChartStat({required this.label, required this.value, this.color});

  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsetsDirectional.fromSTEB(9, 8, 7, 8),
    decoration: BoxDecoration(
      color: TdTokens.of(context).inset,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: TdTokens.of(context).lineSubtle),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(
            context,
          ).textTheme.labelSmall?.copyWith(color: TdTokens.of(context).text3),
        ),
        const SizedBox(height: 3),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: AlignmentDirectional.centerStart,
          child: Text(
            value,
            maxLines: 1,
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
              color: color,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );
}

class _EquityData {
  const _EquityData({
    required this.buckets,
    required this.openingBalance,
    required this.netChange,
    required this.maxDrawdown,
    required this.maxDrawdownPercent,
    required this.tradeCount,
  });

  final List<_EquityBucket> buckets;
  final double openingBalance;
  final double netChange;
  final double maxDrawdown;
  final double maxDrawdownPercent;
  final int tradeCount;
}

class _EquityBucket {
  _EquityBucket({required this.start});

  final DateTime start;
  double result = 0;
  int tradeCount = 0;
  double balance = 0;
}

class _PerformancePainter extends CustomPainter {
  const _PerformancePainter({
    required this.buckets,
    required this.openingBalance,
    required this.selectedIndex,
    required this.positive,
    required this.negative,
    required this.lineColor,
    required this.gridColor,
    required this.baselineColor,
    required this.surfaceColor,
  });

  final List<_EquityBucket> buckets;
  final double openingBalance;
  final int? selectedIndex;
  final Color positive;
  final Color negative;
  final Color lineColor;
  final Color gridColor;
  final Color baselineColor;
  final Color surfaceColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (buckets.isEmpty || size.isEmpty) return;
    final width = size.width;
    final barTop = 5.0;
    final barBottom = size.height * 0.39;
    final lineTop = size.height * 0.53;
    final lineBottom = size.height - 8;
    final step = width / buckets.length;
    final centerX = (int index) => (index + 0.5) * step;
    final grid = Paint()
      ..color = gridColor
      ..strokeWidth = 1;

    for (final fraction in [0.0, 0.5, 1.0]) {
      final y = barTop + (barBottom - barTop) * fraction;
      canvas.drawLine(Offset(0, y), Offset(width, y), grid);
    }
    final largestResult = buckets.fold<double>(
      0,
      (largest, bucket) => math.max(largest, bucket.result.abs()).toDouble(),
    );
    final zeroY = (barTop + barBottom) / 2;
    final halfRange = (barBottom - barTop) * 0.43;
    canvas.drawLine(
      Offset(0, zeroY),
      Offset(width, zeroY),
      Paint()
        ..color = baselineColor
        ..strokeWidth = 1.2,
    );
    final barWidth = math.max(2.0, math.min(14.0, step * 0.62)).toDouble();
    for (var index = 0; index < buckets.length; index++) {
      final result = buckets[index].result;
      if (result == 0) continue;
      final ratio = largestResult == 0 ? 0 : result.abs() / largestResult;
      final endY = zeroY - (result.isNegative ? -1 : 1) * halfRange * ratio;
      final rect = Rect.fromLTRB(
        centerX(index) - barWidth / 2,
        math.min(zeroY, endY),
        centerX(index) + barWidth / 2,
        math.max(zeroY, endY),
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(4)),
        Paint()..color = result > 0 ? positive : negative,
      );
    }

    final balances = buckets.map((bucket) => bucket.balance).toList();
    final low = balances.reduce(math.min);
    final high = balances.reduce(math.max);
    final range = high - low;
    final pad = range.abs() < 0.000001
        ? math.max(high.abs() * 0.05, 1.0).toDouble()
        : range * 0.16;
    final minValue = low - pad;
    final maxValue = high + pad;
    double yFor(double value) =>
        lineBottom -
        (value - minValue) / (maxValue - minValue) * (lineBottom - lineTop);

    for (final fraction in [0.0, 0.5, 1.0]) {
      final y = lineTop + (lineBottom - lineTop) * fraction;
      canvas.drawLine(Offset(0, y), Offset(width, y), grid);
    }
    final balancePath = Path();
    for (var index = 0; index < buckets.length; index++) {
      final point = Offset(centerX(index), yFor(buckets[index].balance));
      if (index == 0) {
        balancePath.moveTo(point.dx, point.dy);
      } else {
        balancePath.lineTo(point.dx, point.dy);
      }
    }
    final fill = Path.from(balancePath)
      ..lineTo(centerX(buckets.length - 1), lineBottom)
      ..lineTo(centerX(0), lineBottom)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            lineColor.withValues(alpha: 0.24),
            lineColor.withValues(alpha: 0.01),
          ],
        ).createShader(Rect.fromLTWH(0, lineTop, width, lineBottom - lineTop)),
    );
    final openingY = yFor(openingBalance);
    if (openingY >= lineTop && openingY <= lineBottom) {
      _dashedLine(
        canvas,
        Offset(0, openingY),
        Offset(width, openingY),
        baselineColor,
      );
    }
    canvas.drawPath(
      balancePath,
      Paint()
        ..color = lineColor
        ..strokeWidth = 2.5
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    for (var index = 0; index < buckets.length; index++) {
      final y = yFor(buckets[index].balance);
      final radius = index == selectedIndex || index == buckets.length - 1
          ? 4.0
          : 2.2;
      canvas.drawCircle(
        Offset(centerX(index), y),
        radius + (radius > 3 ? 2 : 0),
        Paint()
          ..color = (index == selectedIndex ? lineColor : surfaceColor)
              .withValues(alpha: 0.75),
      );
      canvas.drawCircle(
        Offset(centerX(index), y),
        radius,
        Paint()..color = lineColor,
      );
    }
    if (selectedIndex != null && selectedIndex! < buckets.length) {
      final x = centerX(selectedIndex!);
      canvas.drawLine(
        Offset(x, barTop),
        Offset(x, lineBottom),
        Paint()
          ..color = lineColor.withValues(alpha: 0.45)
          ..strokeWidth = 1,
      );
    }
  }

  void _dashedLine(Canvas canvas, Offset start, Offset end, Color color) {
    final length = (end - start).distance;
    if (length == 0) return;
    final direction = (end - start) / length;
    for (var distance = 0.0; distance < length; distance += 7) {
      final last = math.min(distance + 4, length).toDouble();
      canvas.drawLine(
        start + direction * distance,
        start + direction * last,
        Paint()
          ..color = color
          ..strokeWidth = 1,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _PerformancePainter oldDelegate) =>
      !identical(oldDelegate.buckets, buckets) ||
      oldDelegate.selectedIndex != selectedIndex ||
      oldDelegate.openingBalance != openingBalance ||
      oldDelegate.positive != positive ||
      oldDelegate.negative != negative ||
      oldDelegate.lineColor != lineColor ||
      oldDelegate.gridColor != gridColor ||
      oldDelegate.baselineColor != baselineColor ||
      oldDelegate.surfaceColor != surfaceColor;
}
