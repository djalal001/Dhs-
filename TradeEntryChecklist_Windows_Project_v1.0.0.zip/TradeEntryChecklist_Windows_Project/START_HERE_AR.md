# ابدأ من هنا

هذا الملف يحتوي على **المشروع المصدري الكامل**، وليس ملف EXE جاهزًا. أُعدّ المشروع ليتم بناؤه على Windows عبر GitHub Actions.

1. فك ضغط `TradeEntryChecklist_Windows_Project_v1.0.0.zip`.
2. ارفع محتويات مجلد `TradeEntryChecklist_Windows_Project` إلى مستودع GitHub جديد، مع إبقاء مجلد `.github` وملف `AGENTS.md`.
3. بعد رفع الملفات، افتح تبويب **Actions** في المستودع.
4. اختر **Build Windows Overlay** ثم **Run workflow**.
5. بعد نجاح البناء، افتح تشغيل الـ Workflow ونزّل Artifact باسم `TradeEntryChecklist_Windows_x64`.
6. فك ضغط الـ Artifact وشغّل `TradeEntryChecklist.exe` على جهاز Windows x64.

إذا كنت تستخدم GitHub AI Agent لمراجعة المشروع، اطلب منه اتباع `AGENTS.md`، وعدم إعادة تصميم القائمة أو حذف عناصرها، ثم تشغيل Workflow والتحقق من نجاح البناء.

راجع `README_AR.md` لمعرفة وظيفة النافذة وحدودها وطريقة تشغيلها محليًا.
