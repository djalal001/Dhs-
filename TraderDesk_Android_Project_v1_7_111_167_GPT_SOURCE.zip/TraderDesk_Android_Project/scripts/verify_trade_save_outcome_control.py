#!/usr/bin/env python3
"""Focused static regression checks for release 1.7.111+167."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
read = lambda name: (ROOT / name).read_text(encoding='utf-8')
FORM = read('lib/screens/trade_form_screen.dart')
PALETTE = read('lib/theme/trade_outcome_palette.dart')
TRADES = read('lib/screens/trades_screen.dart')
DAYS = read('lib/screens/days_screen.dart')
MODEL = read('lib/models/trade.dart')
FORM_TEST = read('test/custom_confirmation_test.dart')
ENTRY_TEST = read('test/entry_conditions_test.dart')
PALETTE_TEST = read('test/trade_outcome_palette_test.dart')
PUBSPEC = read('pubspec.yaml')
WORKFLOW = read('.github/workflows/android-build.yml')
BUILD_INFO = read('BUILD_INFO_AR.md')
RELEASE = read('RELEASE_NOTES_AR.md')

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

def section(source, start, end):
    return source.split(start, 1)[1].split(end, 1)[0] if start in source and end in source else ''

# Automatic outcome state.
auto = section(FORM, 'TradeClassification get _automaticClassification', 'void _synchronizeAutomaticClassification')
check('no-entry evidence resolves to Missed', '_hasEntryConditionsNoEntryLink' in auto and 'TradeClassification.missed' in auto)
check('positive/negative result signs resolve to Win/Loss', '_resultSign == 1' in auto and 'TradeClassification.win' in auto and '_resultSign == -1' in auto and 'TradeClassification.loss' in auto)
check('zero / unresolved result defaults to Break-even', 'TradeClassification.breakEven' in auto)
check('classification sync clears incompatible detail fields',
      'if (next != TradeClassification.missed) _missedOutcome = null' in FORM and
      'if (next != TradeClassification.breakEven) _breakEvenType = null' in FORM)
check('result compatibility gate covers all four classifications',
      'TradeClassification.win => result > 0' in FORM and
      'TradeClassification.loss => result < 0' in FORM and
      'TradeClassification.breakEven || TradeClassification.missed => result == 0' in FORM)

# Integrated UI.
detail = section(FORM, 'Widget _outcomeDetailDropdown', 'String _outcomeAmountLabel')
control = section(FORM, 'Widget _buildSaveOutcomeControl', 'void _save()')
check('break-even subtype choices embedded in the status panel', 'BreakEvenType.values' in detail and 'trade-outcome-detail-menu' in detail)
check('missed hypothetical outcome choices embedded in the same menu', 'MissedTradeOutcome.values' in detail and 'trade-outcome-detail-menu' in detail)
check('one save button is present beside the status panel', FORM.count("ValueKey('save-trade-button')") == 1 and 'trade-save-outcome-control' in control)
check('button text is localized Save only', "tr(context, 'save')" in control and 'حفظ الصفقة' not in control)
check('old separate classification and chip actions are absent', all(x not in FORM for x in ['_chooseClassification', '_chooseBreakEvenType', '_cycleMissedOutcome', '_buildMissedOutcomeChip', '_buildBreakEvenTypeChip']))
check('required detail gates remain before Trade construction',
      FORM.index('_breakEvenType == null') < FORM.index('final trade = Trade(') and
      FORM.index('_missedOutcome == null') < FORM.index('final trade = Trade('))
check('saved Trade still uses the established enum and optional fields',
      'classification: selectedClassification' in FORM and
      'missedOutcome: selectedClassification == TradeClassification.missed' in FORM and
      'breakEvenType: selectedClassification == TradeClassification.breakEven' in FORM and
      "'missedOutcome': missedOutcome?.name" in MODEL and
      "'breakEvenType': breakEvenType?.name" in MODEL)

# Palette distinction in all surfaces that present the result category.
check('missed and break-even have distinct neutral vs indigo palette values',
      '0xFFB7C1CB' in PALETTE and '0xFF8D99A5' in PALETTE and
      '0xFF8994B4' in PALETTE and '0xFF65708D' in PALETTE)
check('trades list, filter marker and summary card all use missed palette',
      TRADES.count('TradeOutcomePalette.missed(Theme.of(context).brightness)') >= 3)
check('day details use the same missed palette',
      'TradeOutcomePalette.missed(Theme.of(context).brightness)' in DAYS)
check('save button fill separates Missed from Break-even',
      'TradeClassification.breakEven => const Color(0xFF9AA6C5)' in FORM and
      'TradeClassification.missed => const Color(0xFFB5C0CA)' in FORM)
check('palette test enforces visible channel separation in both themes',
      'Brightness.values' in PALETTE_TEST and 'greaterThan(85)' in PALETTE_TEST)

# Widget regression and version.
check('form widget test covers missed and break-even menus',
      'trade-outcome-detail-win' in FORM_TEST and
      'trade-outcome-detail-atEntry' in FORM_TEST and
      'trade-outcome-label-breakEven' in FORM_TEST)
check('automatic win/loss state is checked in existing widget tests',
      'trade-outcome-label-win' in ENTRY_TEST and
      'trade-outcome-label-loss' in read('test/trading_app_test.dart'))
check('package and workflow version are 1.7.111+167 / build 167',
      'version: 1.7.111+167' in PUBSPEC and
      'TraderDesk 1.7.111+167' in WORKFLOW and
      'traderdesk-1.7.111-build167-arm64-v8a-release' in WORKFLOW and
      'traderdesk-1.7.111-build167-arm64-dart-symbols' in WORKFLOW)
check('classification label helper is defined once inside trade form state',
      FORM.count('String _classificationLabel(TradeClassification value)') == 1 and
      FORM.count('_classificationLabel(') == 3)
check('classification label helper uses the existing four localization keys',
      all(key in FORM for key in ["'classificationWin'", "'classificationLoss'", "'classificationBreakEven'", "'classificationMissed'"]))
check('build info and release notes describe the current source-only update',
      '1.7.111+167' in BUILD_INFO and
      'TraderDesk_Android_Project_v1_7_110_166_GPT_SOURCE.zip' in BUILD_INFO and
      'لا يتضمن هذا التسليم APK' in BUILD_INFO and
      '1.7.111+167' in RELEASE)

for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{sum(ok for _, ok in checks)}/{len(checks)} checks passed")
raise SystemExit(0 if all(ok for _, ok in checks) else 1)
