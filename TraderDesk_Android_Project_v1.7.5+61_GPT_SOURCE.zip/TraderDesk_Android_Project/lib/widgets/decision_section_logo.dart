import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// The exact Decisions mark from TraderDesk_Decisions_Logo_Concept.html,
/// recreated as a small vector painter for crisp rendering at any size.
class DecisionSectionLogo extends StatelessWidget {
  const DecisionSectionLogo({
    super.key,
    this.size = 26,
    this.label = 'Decisions logo',
  });

  final double size;
  final String label;

  @override
  Widget build(BuildContext context) {
    final colors = TdTokens.of(context).semantic;
    return Semantics(
      image: true,
      label: label,
      child: SizedBox.square(
        dimension: size,
        child: CustomPaint(
          painter: _DecisionSectionLogoPainter(
            decision: colors.decision,
            backgroundTop: colors.decisionLogoTop,
            backgroundBottom: colors.decisionLogoBottom,
            metalLight: colors.decisionMetalLight,
            metalDeep: colors.decisionMetalDeep,
            node: colors.decisionLogoNode,
            diamondColor: colors.decisionLogoDiamond,
            checkColor: colors.decisionLogoCheck,
          ),
        ),
      ),
    );
  }
}

class _DecisionSectionLogoPainter extends CustomPainter {
  const _DecisionSectionLogoPainter({
    required this.decision,
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.metalLight,
    required this.metalDeep,
    required this.node,
    required this.diamondColor,
    required this.checkColor,
  });

  final Color decision;
  final Color backgroundTop;
  final Color backgroundBottom;
  final Color metalLight;
  final Color metalDeep;
  final Color node;
  final Color diamondColor;
  final Color checkColor;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 80, size.height / 80);

    final tileRect = RRect.fromLTRBR(
      5.5,
      5.5,
      74.5,
      74.5,
      const Radius.circular(19),
    );
    canvas.drawRRect(
      tileRect,
      Paint()
        ..shader = LinearGradient(
          begin: const Alignment(-1.0, -1.0),
          end: const Alignment(1.0, 1.0),
          colors: [backgroundTop, backgroundBottom],
        ).createShader(const Rect.fromLTWH(10, 8, 58, 64)),
    );
    canvas.drawRRect(
      tileRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = decision.withValues(alpha: .48),
    );

    final metalShader = LinearGradient(
      begin: const Alignment(-1, -1),
      end: const Alignment(1, 1),
      colors: [metalLight, metalDeep],
    ).createShader(const Rect.fromLTWH(17, 14, 45, 48));

    final stem = Path()
      ..moveTo(40, 63)
      ..lineTo(40, 51);
    canvas.drawPath(
      stem,
      Paint()
        ..shader = metalShader
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawCircle(const Offset(40, 64), 3.1, Paint()..color = decision);

    final branches = Path()
      ..moveTo(29, 33)
      ..cubicTo(23, 30, 19.5, 25.8, 17.8, 19.5)
      ..moveTo(51, 33)
      ..cubicTo(57, 30, 60.5, 25.8, 62.2, 19.5)
      ..moveTo(40, 25)
      ..lineTo(40, 15.5);
    canvas.drawPath(
      branches,
      Paint()
        ..color = decision.withValues(alpha: .78)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round,
    );

    final nodePaint = Paint()
      ..color = node
      ..style = PaintingStyle.fill;
    final nodeBorder = Paint()
      ..color = decision
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    for (final center in const [Offset(17, 16), Offset(63, 16)]) {
      canvas.drawCircle(center, 3.25, nodePaint);
      canvas.drawCircle(center, 3.25, nodeBorder);
    }
    canvas.drawCircle(
      const Offset(40, 13),
      3.1,
      Paint()..color = metalLight,
    );

    final diamond = Path()
      ..moveTo(40, 24)
      ..lineTo(52, 36.5)
      ..lineTo(40, 49)
      ..lineTo(28, 36.5)
      ..close();
    canvas.drawPath(diamond, Paint()..color = diamondColor);
    canvas.drawPath(
      diamond,
      Paint()
        ..shader = metalShader
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.35
        ..strokeJoin = StrokeJoin.round,
    );

    final check = Path()
      ..moveTo(34.7, 36.6)
      ..lineTo(38.5, 40.2)
      ..lineTo(45.6, 32.9);
    canvas.drawPath(
      check,
      Paint()
        ..color = checkColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.45
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );

    final fineDetails = Path()
      ..moveTo(12, 58.5)
      ..lineTo(16, 58.5)
      ..moveTo(64, 58.5)
      ..lineTo(68, 58.5);
    canvas.drawPath(
      fineDetails,
      Paint()
        ..color = decision.withValues(alpha: .42)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..strokeCap = StrokeCap.round,
    );

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _DecisionSectionLogoPainter oldDelegate) =>
      oldDelegate.decision != decision ||
      oldDelegate.backgroundTop != backgroundTop ||
      oldDelegate.backgroundBottom != backgroundBottom ||
      oldDelegate.metalLight != metalLight ||
      oldDelegate.metalDeep != metalDeep ||
      oldDelegate.node != node ||
      oldDelegate.diamondColor != diamondColor ||
      oldDelegate.checkColor != checkColor;
}
