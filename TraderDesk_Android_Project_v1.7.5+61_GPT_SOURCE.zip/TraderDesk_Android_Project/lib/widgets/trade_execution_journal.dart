import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../theme/app_theme.dart';

const _statuses =
    <({TradeExecutionStatus status, String animatedAsset})>[
      (
        status: TradeExecutionStatus.followedPlan,
        animatedAsset: 'assets/emojis/emoji-executed-per-plan.gif',
      ),
      (
        status: TradeExecutionStatus.avoidedEntryBecauseFear,
        animatedAsset: 'assets/emojis/emoji-avoided-entry-fear.gif',
      ),
      (
        status: TradeExecutionStatus.enteredEarly,
        animatedAsset: 'assets/emojis/emoji-entered-early.gif',
      ),
      (
        status: TradeExecutionStatus.entryConditionsNotMet,
        animatedAsset: 'assets/emojis/emoji-entry-conditions-not-met.gif',
      ),
      (
        status: TradeExecutionStatus.missedHigherTimeframeBounceArea,
        animatedAsset: 'assets/emojis/emoji-missed-htf-bounce-zone.gif',
      ),
      (
        status: TradeExecutionStatus.missedLowerTimeframeBounceArea,
        animatedAsset: 'assets/emojis/emoji-missed-ltf-bounce-zone.gif',
      ),
      (
        status: TradeExecutionStatus.missedTrendlineFromCandleWicks,
        animatedAsset: 'assets/emojis/emoji-missed-wick-trendline.gif',
      ),
      (
        status: TradeExecutionStatus.hesitationPartialSize,
        animatedAsset: 'assets/emojis/emoji-hesitation-partial-size.gif',
      ),
      (
        status: TradeExecutionStatus.lateEntry,
        animatedAsset: 'assets/emojis/emoji-late-entry.gif',
      ),
      (
        status: TradeExecutionStatus.stopLossMoved,
        animatedAsset: 'assets/emojis/emoji-stop-loss-moved.gif',
      ),
      (
        status: TradeExecutionStatus.noBreakoutPositiveClose,
        animatedAsset: 'assets/emojis/emoji-no-breakout-positive-close.gif',
      ),
      (
        status: TradeExecutionStatus.exitedEarlyBecauseFearOfLosingProfit,
        animatedAsset: 'assets/emojis/emoji-exited-early-target.gif',
      ),
    ];

Color _journalStatusColor(TdTokens tokens, TradeExecutionStatus status) {
  final colors = tokens.semantic;
  return switch (status) {
    TradeExecutionStatus.followedPlan => colors.journalSuccess,
    TradeExecutionStatus.avoidedEntryBecauseFear => colors.journalDanger,
    TradeExecutionStatus.enteredEarly => colors.journalCaution,
    TradeExecutionStatus.entryConditionsNotMet => colors.journalNeutral,
    TradeExecutionStatus.missedHigherTimeframeBounceArea => colors.journalSuccess,
    TradeExecutionStatus.missedLowerTimeframeBounceArea => colors.journalInfo,
    TradeExecutionStatus.missedTrendlineFromCandleWicks => colors.journalWarning,
    TradeExecutionStatus.hesitationPartialSize => colors.journalCaution,
    TradeExecutionStatus.lateEntry => colors.journalDanger,
    TradeExecutionStatus.stopLossMoved => colors.journalDanger,
    TradeExecutionStatus.noBreakoutPositiveClose => colors.journalDanger,
    TradeExecutionStatus.exitedEarlyBecauseFearOfLosingProfit => colors.journalDanger,
  };
}

class TradeExecutionJournalSelector extends StatelessWidget {
  const TradeExecutionJournalSelector({
    super.key,
    required this.selectedEntries,
    required this.onChanged,
  });

  final Set<TradeExecutionJournalEntry> selectedEntries;
  final ValueChanged<Set<TradeExecutionJournalEntry>> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return DecoratedBox(
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.dividerColor),
      ),
      child: Column(
        children: [
          for (var index = 0; index < _statuses.length; index++) ...[
            if (index > 0)
              Divider(
                height: 1,
                indent: 12,
                endIndent: 12,
                color: theme.dividerColor,
              ),
            _buildChoice(context, _statuses[index]),
          ],
        ],
      ),
    );
  }

  Widget _buildChoice(
    BuildContext context,
    ({TradeExecutionStatus status, String animatedAsset}) option,
  ) {
    final tokens = TdTokens.of(context);
    final optionColor = _journalStatusColor(tokens, option.status);
    final entry = TradeExecutionJournalEntry(status: option.status);
    final selected = selectedEntries.contains(entry);
    final label = tr(context, 'journalStatus_${option.status.name}');

    void toggle() {
      final updated = {...selectedEntries};
      if (selected) {
        updated.remove(entry);
      } else {
        updated.add(entry);
      }
      onChanged(updated);
    }

    final reduceMotion = MediaQuery.disableAnimationsOf(context);
    return Semantics(
      key: ValueKey('journal-option-${option.status.name}'),
      button: true,
      checked: selected,
      label: label,
      child: AnimatedContainer(
        duration: reduceMotion
            ? const Duration(milliseconds: 120)
            : const Duration(milliseconds: 140),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        decoration: BoxDecoration(
          color: selected
              ? optionColor.withValues(alpha: 0.09)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? optionColor.withValues(alpha: 0.28)
                : Colors.transparent,
          ),
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            onTap: toggle,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(10, 8, 12, 8),
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: optionColor.withValues(
                        alpha: selected ? 0.16 : 0.08,
                      ),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: optionColor.withValues(alpha: 0.22),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: _TradeJournalEmoji(
                      asset: option.animatedAsset,
                      width: 40,
                      height: 40,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      label,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: TdTokens.of(context).text1,
                        fontWeight: selected ? FontWeight.w600 : null,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    selected
                        ? Icons.check_circle_rounded
                        : Icons.circle_outlined,
                    size: 22,
                    color: selected ? optionColor : TdTokens.of(context).text3,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class TradeExecutionJournalSummary extends StatelessWidget {
  const TradeExecutionJournalSummary({
    super.key,
    required this.entries,
    this.compact = false,
    this.showHeading = true,
    this.iconSize = 30,
  });

  final List<TradeExecutionJournalEntry> entries;
  final bool compact;
  final bool showHeading;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final selectedOptions = [
      for (final option in _statuses)
        if (entries.contains(TradeExecutionJournalEntry(status: option.status)))
          option,
    ];
    if (selectedOptions.isEmpty) return const SizedBox.shrink();

    if (compact) {
      return Wrap(
        key: key,
        alignment: WrapAlignment.start,
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final option in selectedOptions)
            Tooltip(
              message: tr(context, 'journalStatus_${option.status.name}'),
              child: Semantics(
                label: tr(context, 'journalStatus_${option.status.name}'),
                child: SizedBox(
                  width: iconSize,
                  height: iconSize,
                  child: _TradeJournalEmoji(
                    asset: option.animatedAsset,
                    width: iconSize,
                    height: iconSize,
                  ),
                ),
              ),
            ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showHeading) ...[
          Text(
            tr(context, 'sequence'),
            style: Theme.of(
              context,
            ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 7),
        ],
        for (final option in selectedOptions) ...[
          _SummaryTag(
            label: tr(context, 'journalStatus_${option.status.name}'),
            asset: option.animatedAsset,
            color: _journalStatusColor(tokens, option.status),
            iconSize: 36,
          ),
          if (option != selectedOptions.last) const SizedBox(height: 8),
        ],
      ],
    );
  }
}

class _SummaryTag extends StatelessWidget {
  const _SummaryTag({
    required this.label,
    required this.asset,
    required this.color,
    required this.iconSize,
  });

  final String label;
  final String asset;
  final Color color;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 14, 8),
      decoration: BoxDecoration(
        color: tokens.surface2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.24)),
      ),
      child: Row(
        children: [
          _TradeJournalEmoji(asset: asset, width: iconSize, height: iconSize),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              softWrap: true,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: tokens.text1,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TradeJournalEmoji extends StatelessWidget {
  const _TradeJournalEmoji({
    required this.asset,
    required this.width,
    required this.height,
  });

  final String asset;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: Image.asset(
        asset,
        width: width,
        height: height,
        gaplessPlayback: true,
        filterQuality: FilterQuality.medium,
        excludeFromSemantics: true,
      ),
    );
  }
}
