import 'package:flutter/material.dart';

/// Product-specific semantic accents used by forms, detail panels and
/// execution history. Keeping these roles beside the base theme prevents
/// individual screens from drifting into isolated color systems.
@immutable
class TdSemanticColors {
  const TdSemanticColors({
    required this.result,
    required this.data,
    required this.images,
    required this.behavior,
    required this.decision,
    required this.commitment,
    required this.noEntry,
    required this.entryConditions,
    required this.reverseSignals,
    required this.bounceZone,
    required this.execution,
    required this.notes,
    required this.journalSuccess,
    required this.journalCaution,
    required this.journalNeutral,
    required this.journalInfo,
    required this.journalWarning,
    required this.journalDanger,
    required this.decisionLogoTop,
    required this.decisionLogoBottom,
    required this.decisionMetalLight,
    required this.decisionMetalDeep,
    required this.decisionLogoNode,
    required this.decisionLogoDiamond,
    required this.decisionLogoCheck,
    required this.imageViewerBackground,
    required this.imageViewerForeground,
    required this.onTone,
  });

  final Color result, data, images, behavior;
  final Color decision, commitment, noEntry;
  final Color entryConditions, reverseSignals, bounceZone;
  final Color execution, notes;
  final Color journalSuccess, journalCaution, journalNeutral;
  final Color journalInfo, journalWarning, journalDanger;
  final Color decisionLogoTop, decisionLogoBottom;
  final Color decisionMetalLight, decisionMetalDeep;
  final Color decisionLogoNode, decisionLogoDiamond, decisionLogoCheck;
  final Color imageViewerBackground, imageViewerForeground;
  final Color onTone;
}

@immutable
class TdTokens extends ThemeExtension<TdTokens> {
  const TdTokens({
    required this.bgBase,
    required this.surface1,
    required this.surface2,
    required this.surface3,
    required this.inset,
    required this.lineSubtle,
    required this.lineStrong,
    required this.text1,
    required this.text2,
    required this.text3,
    required this.accent,
    required this.accentBtnTop,
    required this.accentBtnBottom,
    required this.profit,
    required this.profitStrong,
    required this.profitDeep,
    required this.loss,
    required this.lossStrong,
    required this.lossDeep,
    required this.warn,
    required this.warnStrong,
    required this.neutral,
    required this.dangerBtnTop,
    required this.dangerBtnBottom,
    required this.cardTop,
    required this.cardBottom,
    required this.heroStart,
    required this.scrim,
    required this.cardGradient,
    required this.heroGradient,
    required this.primaryGradient,
    required this.dangerGradient,
    required this.cardShadows,
    required this.raisedShadows,
    required this.overlayShadows,
    required this.s1,
    required this.s2,
    required this.s3,
    required this.s4,
    required this.s5,
    required this.s6,
    required this.s7,
    required this.s8,
    required this.fast,
    required this.base,
    required this.slow,
    required this.page,
    required this.count,
    required this.instant,
    required this.chart,
    required this.standard,
    required this.emphasized,
    required this.accel,
    required this.spring,
    required this.linear,
    required this.semantic,
  });

  final Color bgBase, surface1, surface2, surface3, inset;
  final Color lineSubtle, lineStrong, text1, text2, text3;
  final Color accent, accentBtnTop, accentBtnBottom;
  final Color profit, profitStrong, profitDeep;
  final Color loss, lossStrong, lossDeep;
  final Color warn, warnStrong, neutral;
  final Color dangerBtnTop, dangerBtnBottom, cardTop, cardBottom, heroStart;
  final Color scrim;
  final LinearGradient cardGradient,
      heroGradient,
      primaryGradient,
      dangerGradient;
  final List<BoxShadow> cardShadows, raisedShadows, overlayShadows;
  final double s1, s2, s3, s4, s5, s6, s7, s8;
  final Duration instant, fast, base, slow, page, count, chart;
  final Curve standard, emphasized, accel, spring, linear;
  final TdSemanticColors semantic;

  bool get isDark => bgBase.computeLuminance() < 0.08;

  Color tintedSurface(Color tone, {bool nested = false}) => Color.alphaBlend(
    tone.withValues(alpha: isDark ? (nested ? 0.17 : 0.12) : (nested ? 0.055 : 0.045)),
    nested ? surface2 : surface1,
  );

  Color tintedBorder(Color tone) => Color.alphaBlend(
    tone.withValues(alpha: isDark ? 0.34 : 0.25),
    lineSubtle,
  );

  static TdTokens of(BuildContext context) =>
      Theme.of(context).extension<TdTokens>()!;

  factory TdTokens.forBrightness(Brightness brightness) => _tokens(brightness);

  @override
  TdTokens copyWith({
    Color? bgBase,
    Color? surface1,
    Color? surface2,
    Color? surface3,
    Color? inset,
    Color? lineSubtle,
    Color? lineStrong,
    Color? text1,
    Color? text2,
    Color? text3,
    Color? accent,
    Color? accentBtnTop,
    Color? accentBtnBottom,
    Color? profit,
    Color? profitStrong,
    Color? profitDeep,
    Color? loss,
    Color? lossStrong,
    Color? lossDeep,
    Color? warn,
    Color? warnStrong,
    Color? neutral,
    Color? dangerBtnTop,
    Color? dangerBtnBottom,
    Color? cardTop,
    Color? cardBottom,
    Color? heroStart,
    Color? scrim,
    LinearGradient? cardGradient,
    LinearGradient? heroGradient,
    LinearGradient? primaryGradient,
    LinearGradient? dangerGradient,
    List<BoxShadow>? cardShadows,
    List<BoxShadow>? raisedShadows,
    List<BoxShadow>? overlayShadows,
    TdSemanticColors? semantic,
  }) => TdTokens(
    bgBase: bgBase ?? this.bgBase,
    surface1: surface1 ?? this.surface1,
    surface2: surface2 ?? this.surface2,
    surface3: surface3 ?? this.surface3,
    inset: inset ?? this.inset,
    lineSubtle: lineSubtle ?? this.lineSubtle,
    lineStrong: lineStrong ?? this.lineStrong,
    text1: text1 ?? this.text1,
    text2: text2 ?? this.text2,
    text3: text3 ?? this.text3,
    accent: accent ?? this.accent,
    accentBtnTop: accentBtnTop ?? this.accentBtnTop,
    accentBtnBottom: accentBtnBottom ?? this.accentBtnBottom,
    profit: profit ?? this.profit,
    profitStrong: profitStrong ?? this.profitStrong,
    profitDeep: profitDeep ?? this.profitDeep,
    loss: loss ?? this.loss,
    lossStrong: lossStrong ?? this.lossStrong,
    lossDeep: lossDeep ?? this.lossDeep,
    warn: warn ?? this.warn,
    warnStrong: warnStrong ?? this.warnStrong,
    neutral: neutral ?? this.neutral,
    dangerBtnTop: dangerBtnTop ?? this.dangerBtnTop,
    dangerBtnBottom: dangerBtnBottom ?? this.dangerBtnBottom,
    cardTop: cardTop ?? this.cardTop,
    cardBottom: cardBottom ?? this.cardBottom,
    heroStart: heroStart ?? this.heroStart,
    scrim: scrim ?? this.scrim,
    cardGradient: cardGradient ?? this.cardGradient,
    heroGradient: heroGradient ?? this.heroGradient,
    primaryGradient: primaryGradient ?? this.primaryGradient,
    dangerGradient: dangerGradient ?? this.dangerGradient,
    cardShadows: cardShadows ?? this.cardShadows,
    raisedShadows: raisedShadows ?? this.raisedShadows,
    overlayShadows: overlayShadows ?? this.overlayShadows,
    s1: s1,
    s2: s2,
    s3: s3,
    s4: s4,
    s5: s5,
    s6: s6,
    s7: s7,
    s8: s8,
    fast: fast,
    base: base,
    slow: slow,
    page: page,
    count: count,
    instant: instant,
    chart: chart,
    standard: standard,
    emphasized: emphasized,
    accel: accel,
    spring: spring,
    linear: linear,
    semantic: semantic ?? this.semantic,
  );

  @override
  TdTokens lerp(ThemeExtension<TdTokens>? other, double t) => this;
}

TdTokens _tokens(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final bg = dark ? const Color(0xFF0B1017) : const Color(0xFFF3F5F8);
  final surface1 = dark ? const Color(0xFF121923) : const Color(0xFFFFFFFF);
  final surface2 = dark ? const Color(0xFF182230) : const Color(0xFFF8FAFC);
  final surface3 = dark ? const Color(0xFF202C3A) : const Color(0xFFEEF2F6);
  final inset = dark ? const Color(0xFF0E151F) : const Color(0xFFF1F4F7);
  final lineSubtle = dark ? const Color(0xFF293647) : const Color(0xFFDFE5ED);
  final lineStrong = dark ? const Color(0xFF394B61) : const Color(0xFFC8D2DE);
  final text1 = dark ? const Color(0xFFEEF2F7) : const Color(0xFF182230);
  final text2 = dark ? const Color(0xFFABB6C5) : const Color(0xFF536173);
  final text3 = dark ? const Color(0xFF8795A7) : const Color(0xFF626F82);
  final accent = dark ? const Color(0xFF78A6E8) : const Color(0xFF285FAF);
  final profit = dark ? const Color(0xFF45C39A) : const Color(0xFF087A58);
  final profitStrong = dark ? const Color(0xFF45C39A) : const Color(0xFF066B4B);
  final profitDeep = dark ? const Color(0xFF28A87E) : const Color(0xFF138765);
  final loss = dark ? const Color(0xFFF07880) : const Color(0xFFC43E4D);
  final lossStrong = dark ? const Color(0xFFF07880) : const Color(0xFFB52F42);
  final lossDeep = dark ? const Color(0xFFE45E6B) : const Color(0xFFD34D58);
  final warn = dark ? const Color(0xFFE9B85D) : const Color(0xFF94640C);
  final warnStrong = dark ? const Color(0xFFE9B85D) : const Color(0xFF805600);
  final cardTop = dark ? const Color(0xFF151E29) : const Color(0xFFFFFFFF);
  final cardBottom = dark ? const Color(0xFF111923) : const Color(0xFFFAFBFD);
  final accentTop = dark ? const Color(0xFF477CC6) : const Color(0xFF356CBF);
  final accentBottom = dark ? const Color(0xFF3569B2) : const Color(0xFF285BA8);
  final dangerTop = dark ? const Color(0xFFC84C59) : const Color(0xFFBE3E4B);
  final dangerBottom = dark ? const Color(0xFFB83B49) : const Color(0xFFAC3543);
  final semantic = TdSemanticColors(
    result: dark ? const Color(0xFFA3AFBE) : const Color(0xFF607083),
    data: dark ? const Color(0xFF8FB6DF) : const Color(0xFF376A9C),
    images: dark ? const Color(0xFFC1A77B) : const Color(0xFF7A6036),
    behavior: dark ? const Color(0xFFA99BCB) : const Color(0xFF7260A1),
    decision: dark ? const Color(0xFFC7A77D) : const Color(0xFF8A6337),
    commitment: dark ? const Color(0xFF69BDA0) : const Color(0xFF1F7C61),
    noEntry: dark ? const Color(0xFFB5A0D8) : const Color(0xFF75569B),
    entryConditions: dark ? const Color(0xFF82B8C9) : const Color(0xFF35768E),
    reverseSignals: dark ? const Color(0xFFD3979C) : const Color(0xFF9B505B),
    bounceZone: dark ? const Color(0xFF83BDA8) : const Color(0xFF2E705A),
    execution: dark ? const Color(0xFF91A7C2) : const Color(0xFF526987),
    notes: dark ? const Color(0xFF9CA9B8) : const Color(0xFF5B6A7A),
    journalSuccess: profit,
    journalCaution: warn,
    journalNeutral: text3,
    journalInfo: accent,
    journalWarning: warnStrong,
    journalDanger: loss,
    decisionLogoTop: dark ? const Color(0xFF252B38) : const Color(0xFFF3EEE6),
    decisionLogoBottom: dark ? const Color(0xFF171E29) : const Color(0xFFE7E1D7),
    decisionMetalLight: dark ? const Color(0xFFE3CEAA) : const Color(0xFF9A774A),
    decisionMetalDeep: dark ? const Color(0xFFB99566) : const Color(0xFF76552F),
    decisionLogoNode: dark ? const Color(0xFF212A37) : const Color(0xFFF7F2E9),
    decisionLogoDiamond: dark ? const Color(0xFF34313A) : const Color(0xFFE6DCCB),
    decisionLogoCheck: dark ? const Color(0xFFF0E1C7) : const Color(0xFF6D512F),
    imageViewerBackground: const Color(0xFF080B10),
    imageViewerForeground: const Color(0xFFF5F7FA),
    onTone: dark ? bg : const Color(0xFFFFFFFF),
  );
  final shadows = dark
      ? <BoxShadow>[
          const BoxShadow(
            color: Color(0x66000000),
            offset: Offset(0, 8),
            blurRadius: 18,
            spreadRadius: -6,
          ),
          const BoxShadow(
            color: Color(0x40000000),
            offset: Offset(0, 1),
            blurRadius: 3,
          ),
        ]
      : <BoxShadow>[
          const BoxShadow(
            color: Color(0x141B2B4B),
            offset: Offset(0, 8),
            blurRadius: 20,
            spreadRadius: -6,
          ),
          const BoxShadow(
            color: Color(0x0F1B2B4B),
            offset: Offset(0, 1),
            blurRadius: 3,
          ),
        ];
  return TdTokens(
    bgBase: bg,
    surface1: surface1,
    surface2: surface2,
    surface3: surface3,
    inset: inset,
    lineSubtle: lineSubtle,
    lineStrong: lineStrong,
    text1: text1,
    text2: text2,
    text3: text3,
    accent: accent,
    accentBtnTop: accentTop,
    accentBtnBottom: accentBottom,
    profit: profit,
    profitStrong: profitStrong,
    profitDeep: profitDeep,
    loss: loss,
    lossStrong: lossStrong,
    lossDeep: lossDeep,
    warn: warn,
    warnStrong: warnStrong,
    neutral: text2,
    dangerBtnTop: dangerTop,
    dangerBtnBottom: dangerBottom,
    cardTop: cardTop,
    cardBottom: cardBottom,
    heroStart: dark ? const Color(0xFF1A2A40) : const Color(0xFFEAF0F8),
    scrim: dark ? const Color(0x99000000) : const Color(0x730B0F16),
    cardGradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [cardTop, cardBottom],
    ),
    heroGradient: LinearGradient(
      begin: AlignmentDirectional.topStart,
      end: AlignmentDirectional.bottomEnd,
      colors: [
        dark ? const Color(0xFF1A2A40) : const Color(0xFFEAF0F8),
        surface1,
      ],
    ),
    primaryGradient: LinearGradient(colors: [accentTop, accentBottom]),
    dangerGradient: LinearGradient(colors: [dangerTop, dangerBottom]),
    cardShadows: shadows,
    raisedShadows: dark
        ? const [
            BoxShadow(
              color: Color(0x73000000),
              offset: Offset(0, 6),
              blurRadius: 14,
              spreadRadius: -4,
            ),
            BoxShadow(
              color: Color(0x40000000),
              offset: Offset(0, 1),
              blurRadius: 2,
            ),
          ]
        : const [
            BoxShadow(
              color: Color(0x101B2B4B),
              offset: Offset(0, 6),
              blurRadius: 14,
              spreadRadius: -4,
            ),
            BoxShadow(
              color: Color(0x0C1B2B4B),
              offset: Offset(0, 1),
              blurRadius: 2,
            ),
          ],
    overlayShadows: dark
        ? const [
            BoxShadow(
              color: Color(0x99000000),
              offset: Offset(0, 20),
              blurRadius: 40,
              spreadRadius: -10,
            ),
            BoxShadow(
              color: Color(0x55000000),
              offset: Offset(0, 4),
              blurRadius: 10,
            ),
          ]
        : const [
            BoxShadow(
              color: Color(0x301B2B4B),
              offset: Offset(0, 20),
              blurRadius: 40,
              spreadRadius: -10,
            ),
            BoxShadow(
              color: Color(0x201B2B4B),
              offset: Offset(0, 4),
              blurRadius: 10,
            ),
          ],
    s1: 4,
    s2: 8,
    s3: 12,
    s4: 16,
    s5: 20,
    s6: 24,
    s7: 32,
    s8: 40,
    fast: const Duration(milliseconds: 140),
    base: const Duration(milliseconds: 220),
    slow: const Duration(milliseconds: 320),
    page: const Duration(milliseconds: 360),
    count: const Duration(milliseconds: 400),
    instant: const Duration(milliseconds: 90),
    chart: const Duration(milliseconds: 450),
    standard: Curves.easeOutCubic,
    emphasized: const Cubic(0.2, 0, 0, 1),
    accel: const Cubic(0.3, 0, 0.8, 0.15),
    spring: const Cubic(0.34, 1.4, 0.64, 1),
    linear: Curves.linear,
    semantic: semantic,
  );
}

class _TdPageTransitionsBuilder extends PageTransitionsBuilder {
  const _TdPageTransitionsBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    if (route.isFirst) return child;
    final reduce = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    final curve = CurvedAnimation(
      parent: animation,
      curve: Curves.easeOutCubic,
      reverseCurve: Curves.easeInCubic,
    );
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final offset = Offset(rtl ? -0.055 : 0.055, 0);
    return FadeTransition(
      opacity: reduce
          ? Tween<double>(begin: 0.65, end: 1).animate(curve)
          : curve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: reduce ? Offset.zero : offset,
          end: Offset.zero,
        ).animate(curve),
        child: child,
      ),
    );
  }
}

ThemeData buildAppTheme(Brightness brightness) {
  final tokens = _tokens(brightness);
  final dark = brightness == Brightness.dark;
  final scheme =
      ColorScheme.fromSeed(
        seedColor: tokens.accent,
        brightness: brightness,
      ).copyWith(
        primary: tokens.accent,
        onPrimary: Colors.white,
        secondary: tokens.profit,
        error: tokens.loss,
        surface: tokens.surface1,
        onSurface: tokens.text1,
        outlineVariant: tokens.lineSubtle,
        surfaceContainerLow: tokens.surface2,
        surfaceContainerHighest: tokens.surface3,
        onSurfaceVariant: tokens.text2,
      );
  final textTheme =
      const TextTheme(
        displayLarge: TextStyle(
          fontSize: 34,
          height: 1.15,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.6,
          fontFeatures: [FontFeature.tabularFigures()],
        ),
        displayMedium: TextStyle(
          fontSize: 26,
          height: 1.2,
          fontWeight: FontWeight.w700,
          fontFeatures: [FontFeature.tabularFigures()],
        ),
        headlineSmall: TextStyle(
          fontSize: 26,
          height: 1.3,
          fontWeight: FontWeight.w700,
        ),
        titleLarge: TextStyle(
          fontSize: 20,
          height: 1.35,
          fontWeight: FontWeight.w700,
        ),
        titleMedium: TextStyle(
          fontSize: 16,
          height: 1.45,
          fontWeight: FontWeight.w600,
        ),
        titleSmall: TextStyle(
          fontSize: 15,
          height: 1.4,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: TextStyle(
          fontSize: 15,
          height: 1.55,
          fontWeight: FontWeight.w500,
        ),
        bodyMedium: TextStyle(
          fontSize: 14,
          height: 1.55,
          fontWeight: FontWeight.w400,
        ),
        bodySmall: TextStyle(
          fontSize: 12,
          height: 1.45,
          fontWeight: FontWeight.w400,
        ),
        labelLarge: TextStyle(
          fontSize: 14,
          height: 1.4,
          fontWeight: FontWeight.w500,
        ),
        labelMedium: TextStyle(
          fontSize: 13,
          height: 1.3,
          fontWeight: FontWeight.w600,
        ),
        labelSmall: TextStyle(
          fontSize: 11.5,
          height: 1.4,
          fontWeight: FontWeight.w500,
        ),
      ).apply(
        fontFamily: 'IBMPlexSansArabic',
        bodyColor: tokens.text1,
        displayColor: tokens.text1,
      );

  OutlineInputBorder inputBorder(Color color, [double width = 1]) =>
      OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: color, width: width),
      );

  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    fontFamily: 'IBMPlexSansArabic',
    colorScheme: scheme,
    extensions: [tokens],
    textTheme: textTheme,
    scaffoldBackgroundColor: tokens.bgBase,
    canvasColor: tokens.surface2,
    dividerColor: tokens.lineSubtle,
    splashFactory: NoSplash.splashFactory,
    splashColor: Colors.transparent,
    highlightColor: tokens.accent.withValues(alpha: 0.08),
    appBarTheme: AppBarTheme(
      backgroundColor: tokens.bgBase,
      foregroundColor: tokens.text1,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: textTheme.titleLarge,
      iconTheme: IconThemeData(color: tokens.text2, size: 22),
    ),
    cardTheme: CardThemeData(
      color: tokens.surface1,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    listTileTheme: ListTileThemeData(
      contentPadding: const EdgeInsetsDirectional.symmetric(horizontal: 16),
      minVerticalPadding: 12,
      iconColor: tokens.text3,
      titleTextStyle: textTheme.bodyLarge?.copyWith(
        color: tokens.text1,
        fontWeight: FontWeight.w600,
      ),
      subtitleTextStyle: textTheme.labelMedium?.copyWith(color: tokens.text2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: tokens.inset,
      contentPadding: const EdgeInsetsDirectional.fromSTEB(14, 16, 14, 16),
      labelStyle: textTheme.labelLarge?.copyWith(color: tokens.text2),
      hintStyle: textTheme.bodyMedium?.copyWith(color: tokens.text3),
      border: inputBorder(tokens.lineSubtle),
      enabledBorder: inputBorder(tokens.lineSubtle),
      focusedBorder: inputBorder(tokens.accent, 1.5),
      errorBorder: inputBorder(tokens.loss),
      focusedErrorBorder: inputBorder(tokens.loss, 1.5),
      disabledBorder: inputBorder(tokens.lineSubtle.withValues(alpha: 0.6)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: ButtonStyle(
        minimumSize: const WidgetStatePropertyAll(Size(48, 48)),
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        ),
        foregroundColor: WidgetStatePropertyAll(scheme.onPrimary),
        backgroundColor: WidgetStatePropertyAll(tokens.accentBtnBottom),
        textStyle: WidgetStatePropertyAll(
          textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w600),
        ),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
        overlayColor: WidgetStatePropertyAll(
          tokens.accent.withValues(alpha: 0.06),
        ),
        elevation: const WidgetStatePropertyAll(0),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: ButtonStyle(
        minimumSize: const WidgetStatePropertyAll(Size(48, 48)),
        foregroundColor: WidgetStatePropertyAll(tokens.text1),
        side: WidgetStatePropertyAll(BorderSide(color: tokens.lineStrong)),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
        overlayColor: WidgetStatePropertyAll(
          tokens.accent.withValues(alpha: 0.08),
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        minimumSize: const WidgetStatePropertyAll(Size(48, 44)),
        foregroundColor: WidgetStatePropertyAll(tokens.accent),
        overlayColor: WidgetStatePropertyAll(
          tokens.accent.withValues(alpha: 0.08),
        ),
        textStyle: WidgetStatePropertyAll(textTheme.labelLarge),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: ButtonStyle(
        minimumSize: const WidgetStatePropertyAll(Size(48, 48)),
        foregroundColor: WidgetStatePropertyAll(tokens.text2),
        overlayColor: WidgetStatePropertyAll(
          tokens.accent.withValues(alpha: 0.08),
        ),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: tokens.surface2,
      selectedColor: tokens.accent.withValues(alpha: dark ? 0.22 : 0.12),
      disabledColor: tokens.surface2.withValues(alpha: 0.5),
      side: BorderSide(color: tokens.lineStrong),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      labelStyle: textTheme.labelMedium?.copyWith(color: tokens.text2),
      secondaryLabelStyle: textTheme.labelMedium?.copyWith(
        color: tokens.accent,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      showCheckmark: false,
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: tokens.surface2,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28),
        side: BorderSide(color: tokens.lineSubtle),
      ),
      titleTextStyle: textTheme.titleLarge?.copyWith(fontSize: 20),
      contentTextStyle: textTheme.bodyMedium?.copyWith(color: tokens.text2),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: tokens.surface1,
      modalBackgroundColor: tokens.surface1,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      dragHandleColor: tokens.text3.withValues(alpha: 0.5),
      dragHandleSize: const Size(36, 4),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: tokens.surface2,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: tokens.lineSubtle),
      ),
      textStyle: textTheme.bodyMedium?.copyWith(color: tokens.text1),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: tokens.surface3,
      contentTextStyle: textTheme.bodyMedium?.copyWith(color: tokens.text1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: tokens.lineStrong),
      ),
      insetPadding: const EdgeInsets.fromLTRB(16, 0, 16, 78),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? scheme.onPrimary
            : tokens.text3,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? tokens.accentBtnBottom
            : tokens.inset,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? tokens.accent
            : tokens.lineStrong,
      ),
    ),
    dividerTheme: DividerThemeData(
      color: tokens.lineSubtle.withValues(alpha: 0.8),
      thickness: 1,
      space: 1,
    ),
    datePickerTheme: DatePickerThemeData(
      backgroundColor: tokens.surface2,
      surfaceTintColor: Colors.transparent,
      headerBackgroundColor: tokens.surface3,
      headerForegroundColor: tokens.text1,
      todayForegroundColor: WidgetStatePropertyAll(tokens.accent),
      todayBorder: BorderSide(color: tokens.accent),
      dayBackgroundColor: WidgetStateProperty.resolveWith(
        (states) =>
            states.contains(WidgetState.selected) ? tokens.accent : null,
      ),
      dayForegroundColor: WidgetStateProperty.resolveWith(
        (states) =>
            states.contains(WidgetState.selected) ? scheme.onPrimary : tokens.text1,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: tokens.accent,
      linearTrackColor: tokens.inset,
      refreshBackgroundColor: tokens.surface2,
    ),
    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color: tokens.surface3,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: tokens.lineStrong),
      ),
      textStyle: textTheme.labelMedium?.copyWith(color: tokens.text1),
      waitDuration: const Duration(milliseconds: 450),
    ),
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: _TdPageTransitionsBuilder(),
        TargetPlatform.iOS: _TdPageTransitionsBuilder(),
        TargetPlatform.windows: _TdPageTransitionsBuilder(),
        TargetPlatform.macOS: _TdPageTransitionsBuilder(),
        TargetPlatform.linux: _TdPageTransitionsBuilder(),
      },
    ),
  );
}
