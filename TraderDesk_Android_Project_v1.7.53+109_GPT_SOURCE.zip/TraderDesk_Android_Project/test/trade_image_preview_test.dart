import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/trade_image_preview.dart';

void main() {
  late Directory temp;
  late List<File> imageFiles;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_image_view_');
    imageFiles = [];
    for (final name in ['before.png', 'after.png', 'confirmation.png']) {
      final file = File('${temp.path}/$name');
      await file.writeAsBytes(_tinyPng);
      imageFiles.add(file);
    }
  });

  tearDown(() async {
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  Future<void> openViewer(
    WidgetTester tester, {
    required List<TradeImageItem> gallery,
    int initialIndex = 0,
    DateTime? tradedAt,
  }) async {
    final image = gallery[initialIndex];
    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(Brightness.dark),
        locale: const Locale('en'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 250,
              child: TradeImagePreview(
                path: image.path,
                label: image.label,
                fileNamePrefix: image.fileNamePrefix,
                galleryImages: gallery,
                tradedAt: tradedAt,
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(
        ValueKey(
          'trade-image-preview-${image.fileNamePrefix}-${image.path}',
        ),
      ),
    );
    await tester.pumpAndSettle();
  }

  testWidgets('opens a full-screen viewer with time-only translucent header', (
    tester,
  ) async {
    final actualGallery = [
      TradeImageItem(
        path: imageFiles[0].path,
        label: 'Before entry',
        fileNamePrefix: 'before',
      ),
    ];
    await openViewer(
      tester,
      gallery: actualGallery,
      tradedAt: DateTime(2026, 11, 19, 14, 5),
    );

    expect(find.byType(AppBar), findsNothing);
    expect(find.byType(SafeArea), findsNothing);
    expect(find.byKey(const ValueKey('trade-image-gallery')), findsOneWidget);
    expect(tester.widget<AnimatedOpacity>(
      find.byKey(const ValueKey('trade-image-overlay-opacity')),
    ).opacity, 0);
    await tester.tapAt(tester.getCenter(
      find.byKey(const ValueKey('trade-image-viewer-gestures-0')),
    ));
    await tester.pump(const Duration(milliseconds: 220));
    expect(tester.widget<AnimatedOpacity>(
      find.byKey(const ValueKey('trade-image-overlay-opacity')),
    ).opacity, 1);
    expect(find.text('Before entry'), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-image-viewer-trade-time')),
        findsOneWidget);
    expect(find.textContaining('19'), findsNothing);
    expect(find.byTooltip('Save image'), findsOneWidget);

    final imageTransform = tester.widget<Transform>(
      find.byKey(const ValueKey('zoomable-trade-image-0')),
    );
    expect(imageTransform.transform.getMaxScaleOnAxis(), closeTo(1, 0.001));
    final foregroundImage = tester.widget<Image>(
      find.byKey(const ValueKey('trade-image-foreground-0')),
    );
    final backgroundImage = tester.widget<Image>(
      find.byKey(const ValueKey('trade-image-backdrop-0')),
    );
    expect(foregroundImage.fit, BoxFit.contain);
    expect(backgroundImage.fit, BoxFit.cover);
    expect(find.byKey(const ValueKey('trade-image-overlay-opacity')),
        findsOneWidget);
  });

  testWidgets('single-finger movement does not pan the image', (tester) async {
    final actualGallery = [
      TradeImageItem(
        path: imageFiles[0].path,
        label: 'Before entry',
        fileNamePrefix: 'before',
      ),
    ];
    await openViewer(tester, gallery: actualGallery);

    final gesture = find.byKey(
      const ValueKey('trade-image-viewer-gestures-0'),
    );
    await tester.drag(gesture, const Offset(0, 110));
    await tester.pumpAndSettle();

    final transformation = tester.widget<Transform>(
      find.byKey(const ValueKey('zoomable-trade-image-0')),
    ).transform;
    expect(transformation.getMaxScaleOnAxis(), closeTo(1, 0.001));
    expect(transformation.getTranslation().y, closeTo(0, 0.001));

    final focus = tester.getCenter(gesture);
    await tester.doubleTapAt(focus);
    await tester.pumpAndSettle();
    final zoomedBeforeDrag = tester.widget<Transform>(
      find.byKey(const ValueKey('zoomable-trade-image-0')),
    ).transform;
    final translationBeforeDrag = zoomedBeforeDrag.getTranslation();
    await tester.drag(gesture, const Offset(0, 90));
    await tester.pumpAndSettle();
    final zoomedAfterDrag = tester.widget<Transform>(
      find.byKey(const ValueKey('zoomable-trade-image-0')),
    ).transform;
    expect(zoomedAfterDrag.getMaxScaleOnAxis(), closeTo(2.5, 0.001));
    expect(zoomedAfterDrag.getTranslation().x,
        closeTo(translationBeforeDrag.x, 0.001));
    expect(zoomedAfterDrag.getTranslation().y,
        closeTo(translationBeforeDrag.y, 0.001));
  });

  testWidgets('double tap zooms around the selected point and toggles back', (
    tester,
  ) async {
    final actualGallery = [
      TradeImageItem(
        path: imageFiles[0].path,
        label: 'Before entry',
        fileNamePrefix: 'before',
      ),
    ];
    await openViewer(tester, gallery: actualGallery);

    final gesture = find.byKey(
      const ValueKey('trade-image-viewer-gestures-0'),
    );
    final bounds = tester.getRect(gesture);
    final focus = Offset(bounds.left + bounds.width * 0.28,
        bounds.top + bounds.height * 0.36);
    await tester.doubleTapAt(focus);
    await tester.pumpAndSettle();

    final transformation = tester.widget<Transform>(
      find.byKey(const ValueKey('zoomable-trade-image-0')),
    ).transform;
    expect(transformation.getMaxScaleOnAxis(), closeTo(2.5, 0.001));
    expect(transformation.getTranslation().x, isNot(closeTo(0, 0.001)));
    expect(transformation.getTranslation().y, isNot(closeTo(0, 0.001)));

    await tester.doubleTapAt(focus);
    await tester.pumpAndSettle();
    expect(
      tester.widget<Transform>(
        find.byKey(const ValueKey('zoomable-trade-image-0')),
      ).transform.getMaxScaleOnAxis(),
      closeTo(1, 0.001),
    );
  });

  testWidgets('two-finger pinch can zoom and pan the image', (tester) async {
    final actualGallery = [
      for (var i = 0; i < imageFiles.length; i++)
        TradeImageItem(
          path: imageFiles[i].path,
          label: ['Before entry', 'After entry', 'Entry confirmation'][i],
          fileNamePrefix: ['before', 'after', 'confirmation'][i],
        ),
    ];
    await openViewer(tester, gallery: actualGallery);
    await tester.tapAt(tester.getCenter(
      find.byKey(const ValueKey('trade-image-viewer-gestures-0')),
    ));
    await tester.pump(const Duration(milliseconds: 220));

    final imageArea = tester.getRect(
      find.byKey(const ValueKey('trade-image-viewer-gestures-0')),
    );
    final first = await tester.startGesture(
      Offset(imageArea.center.dx - 35, imageArea.center.dy),
      pointer: 11,
    );
    final second = await tester.startGesture(
      Offset(imageArea.center.dx + 35, imageArea.center.dy),
      pointer: 12,
    );
    await first.moveBy(const Offset(-45, -5));
    await second.moveBy(const Offset(35, 5));
    await tester.pump();

    final transform = tester.widget<Transform>(
      find.byKey(const ValueKey('zoomable-trade-image-0')),
    ).transform;
    expect(transform.getMaxScaleOnAxis(), greaterThan(1));
    expect(transform.getTranslation().x, isNot(closeTo(0, 0.001)));
    expect(find.text('Before entry'), findsOneWidget);

    await first.up();
    await second.up();
    await tester.pumpAndSettle();
  });

  testWidgets('one tap shows and hides the transparent image header', (
    tester,
  ) async {
    final actualGallery = [
      TradeImageItem(
        path: imageFiles[0].path,
        label: 'Before entry',
        fileNamePrefix: 'before',
      ),
    ];
    await openViewer(tester, gallery: actualGallery);

    expect(tester.widget<AnimatedOpacity>(
      find.byKey(const ValueKey('trade-image-overlay-opacity')),
    ).opacity, 0);
    await tester.tapAt(tester.getCenter(
      find.byKey(const ValueKey('trade-image-viewer-gestures-0')),
    ));
    await tester.pump(const Duration(milliseconds: 220));
    expect(tester.widget<AnimatedOpacity>(
      find.byKey(const ValueKey('trade-image-overlay-opacity')),
    ).opacity, 1);
    expect(find.text('Before entry'), findsOneWidget);

    await tester.tapAt(tester.getCenter(
      find.byKey(const ValueKey('trade-image-viewer-gestures-0')),
    ));
    await tester.pump(const Duration(milliseconds: 220));
    expect(tester.widget<AnimatedOpacity>(
      find.byKey(const ValueKey('trade-image-overlay-opacity')),
    ).opacity, 0);
  });

  testWidgets('opening any thumbnail retains its position in the gallery', (
    tester,
  ) async {
    final actualGallery = [
      for (var i = 0; i < imageFiles.length; i++)
        TradeImageItem(
          path: imageFiles[i].path,
          label: ['Before entry', 'After entry', 'Entry confirmation'][i],
          fileNamePrefix: ['before', 'after', 'confirmation'][i],
        ),
    ];
    await openViewer(tester, gallery: actualGallery, initialIndex: 1);

    expect(tester.widget<AnimatedOpacity>(
      find.byKey(const ValueKey('trade-image-overlay-opacity')),
    ).opacity, 0);
    await tester.tapAt(tester.getCenter(
      find.byKey(const ValueKey('trade-image-viewer-gestures-1')),
    ));
    await tester.pump(const Duration(milliseconds: 220));
    expect(find.text('After entry'), findsOneWidget);

    await tester.drag(
      find.byKey(const ValueKey('trade-image-gallery')),
      const Offset(-320, 0),
    );
    await tester.pumpAndSettle();
    expect(find.text('Entry confirmation'), findsOneWidget);
  });

  testWidgets('swipes through before, after, then entry-confirmation images', (
    tester,
  ) async {
    final actualGallery = [
      for (var i = 0; i < imageFiles.length; i++)
        TradeImageItem(
          path: imageFiles[i].path,
          label: ['Before entry', 'After entry', 'Entry confirmation'][i],
          fileNamePrefix: ['before', 'after', 'confirmation'][i],
        ),
    ];
    await openViewer(tester, gallery: actualGallery);
    await tester.tapAt(tester.getCenter(
      find.byKey(const ValueKey('trade-image-viewer-gestures-0')),
    ));
    await tester.pump(const Duration(milliseconds: 220));

    expect(find.text('Before entry'), findsOneWidget);
    final page = find.byKey(const ValueKey('trade-image-gallery'));
    await tester.drag(page, const Offset(-320, 0));
    await tester.pumpAndSettle();
    expect(find.text('After entry'), findsOneWidget);

    await tester.drag(page, const Offset(-320, 0));
    await tester.pumpAndSettle();
    expect(find.text('Entry confirmation'), findsOneWidget);
  });
}

const _tinyPng = <int>[
  137,
  80,
  78,
  71,
  13,
  10,
  26,
  10,
  0,
  0,
  0,
  13,
  73,
  72,
  68,
  82,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  1,
  8,
  6,
  0,
  0,
  0,
  31,
  21,
  196,
  137,
  0,
  0,
  0,
  13,
  73,
  68,
  65,
  84,
  8,
  215,
  99,
  248,
  207,
  192,
  240,
  31,
  0,
  5,
  0,
  1,
  255,
  137,
  153,
  61,
  29,
  0,
  0,
  0,
  0,
  73,
  69,
  78,
  68,
  174,
  66,
  96,
  130,
];
