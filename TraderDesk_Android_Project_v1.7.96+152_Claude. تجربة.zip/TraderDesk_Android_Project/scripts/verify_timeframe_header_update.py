#!/usr/bin/env python3
"""Static regression checks for the 1.7.96+152 shared timeframe header."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
MODEL = (ROOT / "lib/models/trade.dart").read_text(encoding="utf-8")
WIDGET_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
RELEASE_NOTES = (ROOT / "RELEASE_NOTES_AR.md").read_text(encoding="utf-8")
BUILD_INFO = (ROOT / "BUILD_INFO_AR.md").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []

def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

# The same title + contextual subtitle is used by every timeframe path.
check(
    "timeframe dialog has one fixed Arabic/English title",
    "title: _copy('اختيار الفريم الزمني', 'Select timeframe')" in FORM,
)
check(
    "timeframe context is rendered as a secondary line",
    "subtitle: contextLabel" in FORM
    and "color: tokens.text2" in FORM
    and "textTheme\n                                    .bodySmall" in FORM,
)
call_count = FORM.count("_showTimeframeSheet(") - 1  # Exclude the method declaration.
context_count = FORM.count("contextLabel:")
check("all timeframe call sites pass contextual labels", call_count == 9 and context_count == 9)
check(
    "old inconsistent timeframe-specific titles are removed from active form code",
    not any(
        text in FORM
        for text in [
            "فريم الارتكاز",
            "فريم Base Buy",
            "فريم Base Sell",
            "فريم ترند لاين",
            "فريم Supply Zone",
            "فريم التأكيد",
            "تعديل الفريم الزمني",
            "تعديل فريم التأكيد",
        ]
    ),
)

# Trade data area: entry reason, confirmation, and anchor (including Base direction).
check(
    "entry reason add/edit contexts identify the chosen reason",
    FORM.count("formatTradeEntryReasonLabel(reason: reason, side: _side)") >= 2,
)
check(
    "confirmation add/edit contexts identify the chosen confirmation",
    FORM.count("_copy('تأكيد الدخول', 'Entry confirmation')} · ${_confirmationLabel(finalType)}") >= 2,
)
check(
    "anchor context is built from the currently displayed anchor label",
    "_copy('الارتكاز', 'Anchor')} · ${_anchorSelectionLabel(anchorKey)}" in FORM,
)
check(
    "Base context uses direction-aware Buy/Sell labels",
    "TradeSide.buy => 'Base Buy'" in CATALOG
    and "TradeSide.sell => 'Base Sell'" in CATALOG,
)

# Entry conditions: opposing signals, bounce-area options, and the two-stage condition.
check(
    "opposing-signal and bounce-area category labels are passed to the shared flow",
    FORM.count("categoryLabel: _copy('إشارات عكسية', 'Opposing signals')") == 2
    and FORM.count("categoryLabel: _copy('منطقة الارتداد', 'Bounce area')") == 2,
)
check(
    "condition context uses the selected option's existing direction-aware label formatter",
    "formatTradeEntryConditionSetupLabel(" in FORM
    and "optionLabel: selectedOptionLabel" in FORM
    and "side: _side" in FORM,
)
check(
    "combined Trendline/Supply Zone opens two individually identified timeframe steps",
    "_copy('ترند لاين', 'Trendline')" in FORM
    and "'$entryConditionsPrefix · Supply Zone'" in FORM,
)

# Existing dialog appearance and selection mechanics remain intact.
check(
    "timeframe choices remain the original eight ordered frames",
    "['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H']" in CATALOG,
)
check(
    "timeframe selection still uses the original centered choice dialog and ListTile rows",
    "_showCenteredTradeChoiceDialog<String>(" in FORM
    and "keyPrefix: 'single-choice'" in FORM
    and "ListTile(" in FORM,
)
check(
    "saved timeframe model and keys remain unchanged",
    "final String timeframe;" in MODEL
    and "'timeframe': timeframe" in MODEL
    and "anchorTimeframes" in MODEL,
)

# Widget regression coverage for each flow and add/edit behavior.
required_widget_labels = [
    "سبب الدخول · RFS",
    "تأكيد الدخول · Bullish Engulfing",
    "الارتكاز · Supply Zone",
    "الارتكاز · Demand Zone",
    "الارتكاز · Base Buy",
    "الارتكاز · Base Sell",
    "ظروف الدخول · إشارات عكسية · Supply Zone",
    "ظروف الدخول · إشارات عكسية · HNS عكسي",
    "ظروف الدخول · منطقة الارتداد · ترند لاين",
    "ظروف الدخول · منطقة الارتداد · Supply Zone",
    "اختيار الفريم الزمني",
]
for label in required_widget_labels:
    check(f"widget test asserts contextual header: {label}", label in WIDGET_TEST)
check(
    "widget tests cover contextual labels on entry-reason and confirmation edit paths",
    "editing an entry reason must use the same contextual heading" in WIDGET_TEST
    and "editing a confirmation must use the same contextual heading" in WIDGET_TEST,
)
check(
    "widget tests verify restrained title/subtitle hierarchy and secondary color",
    "context must remain a quieter secondary line under the common heading" in WIDGET_TEST
    and "timeframeContext.style?.color" in WIDGET_TEST,
)
check(
    "widget tests retain semantic tint assertions for timeframe rows",
    "timeframe rows must use the same purple semantic selection tint" in WIDGET_TEST
    and "Bounce area timeframe list must match the Opposing signals timeframe list" in WIDGET_TEST,
)

# Release metadata and published documentation.
check("pubspec version is 1.7.96+152", "version: 1.7.96+152" in PUBSPEC)
check("workflow display name is 1.7.96+152", "TraderDesk 1.7.96+152" in WORKFLOW)
check(
    "workflow artifact IDs use build 151",
    "traderdesk-1.7.96-build152-arm64-v8a-release" in WORKFLOW
    and "traderdesk-1.7.96-build152-arm64-dart-symbols" in WORKFLOW,
)
check("release notes document all picker areas", "ظروف الدخول" in RELEASE_NOTES and "تأكيد الدخول" in RELEASE_NOTES and "Base Buy" in RELEASE_NOTES)
check("build info identifies source-only delivery", "لا يتضمن هذا التسليم APK" in BUILD_INFO)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
