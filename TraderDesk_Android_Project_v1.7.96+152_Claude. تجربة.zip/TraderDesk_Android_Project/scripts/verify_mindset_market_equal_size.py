#!/usr/bin/env python3
"""Static regression checks for 1.7.96+152: Mindset == Market/Direction rectangle."""
import re, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUB = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
checks = []
def check(name, ok): checks.append((name, bool(ok)))

check("version is 1.7.96+152", "version: 1.7.96+152" in PUB)
check("shared content height constant is 30", "const double _tradeDataControlContentHeight = 30;" in FORM)
check("shared padding constant is 22/24", "fromSTEB(10, 22, 10, 24)" in FORM)
check("padding + content >= control height", 22 + 30 + 24 >= 72)
check("control height still 72", "const double _tradeDataControlHeight = 72;" in FORM)
check("market field uses shared padding", FORM.count("contentPadding:\n                                              _tradeDataControlContentPadding") == 1)
m = re.search(r"label: _copy\('الحالة النفسية', 'Mindset'\),\s*contentPadding: _tradeDataControlContentPadding", FORM)
check("mindset field uses shared padding", m)
check("mindset content row fixed to shared height", "'trade-mood-content-row'" in FORM and "height: _tradeDataControlContentHeight" in FORM)
check("both columns share one width expression", FORM.count("width: marketControlWidth") == 2)
check("mindset popup row height unchanged (42)", "itemHeight: 42" in FORM)
check("selected value size unchanged (14.5)", "const double _tradeDataItemFontSize = 14.5;" in FORM)
check("old 8dp padding removed from both fields", "contentPadding: const EdgeInsetsDirectional.fromSTEB(10, 8, 10, 8)" not in FORM)
check("test asserts equal rectangles", all(x in TEST for x in ["moodFieldRect.top", "moodFieldRect.bottom", "moodFieldRect.width", "trade-mood-content-row"]))
for n in ("moodInput", "moodBorder"):
    check(f"no duplicate declaration of {n} in test", len(re.findall(rf"final {n} =", TEST)) == 1)
check("no duplicate reverseTitleRect", len(re.findall(r"final reverseTitleRect =", TEST)) == 1)
for name, ok in checks: print(("PASS" if ok else "FAIL") + ": " + name)
print(f"{sum(ok for _, ok in checks)}/{len(checks)}")
sys.exit(0 if all(ok for _, ok in checks) else 1)
