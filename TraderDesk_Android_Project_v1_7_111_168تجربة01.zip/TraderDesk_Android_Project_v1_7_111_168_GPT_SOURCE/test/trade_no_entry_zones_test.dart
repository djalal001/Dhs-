import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/trade_no_entry_zones.dart';

const _tone = Color(0xFFB69AF0);

Future<Set<String>> _pump(
  WidgetTester tester, {
  bool enabled = true,
  Set<String>? initial,
  bool arabic = true,
}) async {
  final selected = <String>{...?initial};
  await tester.pumpWidget(
    MaterialApp(
      theme: buildAppTheme(Brightness.dark),
      locale: Locale(arabic ? 'ar' : 'en'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: Scaffold(
        body: StatefulBuilder(
          builder: (context, setState) => SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
            child: TradeNoEntryZones(
              groups: tradeNoEntryGroups,
              selected: selected,
              enabled: enabled,
              arabic: arabic,
              tone: _tone,
              onToggle: (key) => setState(() {
                if (!selected.remove(key)) selected.add(key);
              }),
            ),
          ),
        ),
      ),
    ),
  );
  await tester.pumpAndSettle();
  return selected;
}

Future<void> _openStructural(WidgetTester tester) async {
  await tester.tap(find.byKey(const ValueKey('no-entry-zone-tab-structural')));
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('two sections sit side by side and open on psychological', (tester) async {
    await _pump(tester);
    final psychological = find.byKey(const ValueKey('no-entry-zone-tab-psychological'));
    final structural = find.byKey(const ValueKey('no-entry-zone-tab-structural'));
    expect(find.text('أسباب نفسية'), findsOneWidget);
    expect(find.text('أسباب هيكلية'), findsOneWidget);

    final a = tester.getRect(psychological);
    final b = tester.getRect(structural);
    expect(a.top, closeTo(b.top, .5));
    expect(a.width, closeTo(b.width, .5));
    // Arabic reads right-to-left: psychological is the right-hand rectangle.
    expect(a.left, greaterThan(b.left));

    for (final option in tradeNoEntryPsychologicalOptions) {
      expect(find.byKey(ValueKey('no-entry-${option.key}')), findsOneWidget, reason: option.key);
    }
    expect(find.text('خوف من تكرار الخسارة بعد خسارة سابقة'), findsOneWidget);
    expect(find.text('خوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة'), findsOneWidget);
    for (final option in tradeNoEntryStructuralOptions) {
      expect(find.byKey(ValueKey('no-entry-${option.key}')), findsNothing, reason: option.key);
    }
  });

  testWidgets('the structural section lists its five reasons', (tester) async {
    await _pump(tester);
    await _openStructural(tester);
    expect(find.byType(Dialog), findsNothing);
    for (final option in tradeNoEntryStructuralOptions) {
      expect(find.byKey(ValueKey('no-entry-${option.key}')), findsOneWidget, reason: option.key);
    }
    expect(find.text('كسر وإغلاق إيجابي ضعيف'), findsOneWidget);
    expect(find.text('لا يوجد Trendline يدعم منطقة دخول'), findsOneWidget);
    expect(find.text('وجود منطقة اعتراض قريبة من تأكيد دخول'), findsOneWidget);
    expect(find.text('زخم عالي تجاوز سعر منطقة دخول قليلا وعاد اليها بدون إغلاق'), findsOneWidget);
    expect(find.text('زخم مرتفع على الفريم الاصغر'), findsOneWidget);
    expect(find.text('سيولة عالية تجاوز سعر تأكيد دخول قليلًا وعاد إليها'), findsNothing);
    expect(find.byKey(const ValueKey('no-entry-fearRepeatLossAfterLoss')), findsNothing);
  });

  testWidgets('selecting only shifts the tone: no border, no glow, no checkbox', (tester) async {
    final selected = await _pump(tester);
    Color fill(String key) => (tester
            .widget<AnimatedContainer>(
              find.byKey(ValueKey('trade-behavior-option-surface-$key')),
            )
            .decoration as BoxDecoration)
        .color!;

    final before = fill('fearRepeatLossAfterLoss');
    await tester.tap(find.byKey(const ValueKey('no-entry-fearRepeatLossAfterLoss')));
    await tester.pumpAndSettle();
    expect(selected, {'fearRepeatLossAfterLoss'});
    expect(fill('fearRepeatLossAfterLoss'), isNot(before));
    expect(fill('fearGivingBackProfit'), before);
    final decoration = tester
        .widget<AnimatedContainer>(
          find.byKey(const ValueKey('trade-behavior-option-surface-fearRepeatLossAfterLoss')),
        )
        .decoration as BoxDecoration;
    expect(decoration.border, isNull);
    expect(decoration.boxShadow, isNull);
    expect(find.byType(Checkbox), findsNothing);
    expect(find.byIcon(Icons.check), findsNothing);

    await tester.tap(find.byKey(const ValueKey('no-entry-fearRepeatLossAfterLoss')));
    await tester.pumpAndSettle();
    expect(selected, isEmpty);
  });

  testWidgets('tapping the open section name folds it into the chosen reasons', (tester) async {
    final selected = await _pump(tester);
    final tab = find.byKey(const ValueKey('no-entry-zone-tab-psychological'));

    // Nothing chosen: tapping the name folds nothing.
    await tester.tap(tab);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('no-entry-zone-list-psychological')), findsOneWidget);
    expect(find.byKey(const ValueKey('no-entry-zone-summary-psychological')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('no-entry-hesitationUnclearScenario')));
    await tester.tap(find.byKey(const ValueKey('no-entry-fearLossNoHistory')));
    await tester.pumpAndSettle();
    await tester.tap(tab);
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('no-entry-zone-list-psychological')), findsNothing);
    expect(find.byKey(const ValueKey('no-entry-zone-summary-psychological')), findsOneWidget);
    // Chosen reasons only, in catalog order, one per line.
    final first = tester.getRect(find.text('خوف من الخسارة دون وجود ربح أو خسارة سابقة'));
    final second = tester.getRect(find.text('تردد بسبب عدم وضوح السيناريو'));
    expect(second.top, greaterThanOrEqualTo(first.bottom));
    expect(find.text('خوف من تكرار الخسارة بعد خسارة سابقة'), findsNothing);

    // Tapping the summary unfolds it; the selection survives folding.
    await tester.tap(find.byKey(const ValueKey('no-entry-zone-summary-psychological')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('no-entry-zone-list-psychological')), findsOneWidget);
    expect(selected, {'hesitationUnclearScenario', 'fearLossNoHistory'});
  });

  testWidgets('each section folds on its own', (tester) async {
    await _pump(tester, initial: {'fearLossNoHistory', 'noEntryWeakBreakoutClose'});
    await tester.tap(find.byKey(const ValueKey('no-entry-zone-tab-psychological')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('no-entry-zone-summary-psychological')), findsOneWidget);

    await _openStructural(tester);
    expect(find.byKey(const ValueKey('no-entry-zone-list-structural')), findsOneWidget,
        reason: 'folding psychological does not fold structural');
    await tester.tap(find.byKey(const ValueKey('no-entry-zone-tab-structural')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('no-entry-zone-summary-structural')), findsOneWidget);
    expect(find.text('كسر وإغلاق إيجابي ضعيف'), findsOneWidget);
  });

  testWidgets('badges count the selections of each section', (tester) async {
    await _pump(tester, initial: {
      'fearLossNoHistory',
      'fearGivingBackProfit',
      'noEntryNoTrendlineSupport',
    });
    Finder badge(String id, String text) => find.descendant(
          of: find.byKey(ValueKey('no-entry-zone-tab-$id')),
          matching: find.text(text),
        );
    expect(badge('psychological', '2'), findsOneWidget);
    expect(badge('structural', '1'), findsOneWidget);
  });

  testWidgets('English locale uses English section names and reasons', (tester) async {
    await _pump(tester, arabic: false);
    expect(find.text('Psychological'), findsOneWidget);
    expect(find.text('Structural'), findsOneWidget);
    expect(find.text('Fear of repeating a loss after a previous loss'), findsOneWidget);
  });

  testWidgets('without a trade direction the tiles are locked', (tester) async {
    await _pump(tester, enabled: false);
    final tile = tester.widget<InkWell>(
      find.byKey(const ValueKey('no-entry-fearRepeatLossAfterLoss')),
    );
    expect(tile.onTap, isNull);
  });
}
