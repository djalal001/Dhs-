import 'package:flutter/material.dart';

import '../domain/trade_entry_catalog.dart';
import '../theme/app_theme.dart';

/// The Decisions area of the trade form: three zones (violations · analysis
/// quality · risk management) shown as equal rectangles side by side.
///
/// Choosing a zone moves the content sideways inside the same surface — it is
/// a transition between zones, not a pop-up. The analysis zone is a grid of
/// quiet tonal tiles; once the user has chosen items, tapping the zone's name
/// again folds the grid into a one-line summary of what was selected.
class TradeDecisionZones extends StatefulWidget {
  const TradeDecisionZones({
    super.key,
    required this.groups,
    required this.selected,
    required this.onToggle,
    required this.enabled,
    required this.arabic,
    required this.tone,
    required this.listRowBuilder,
    this.initialZone = 0,
    this.initialAnalysisCollapsed = false,
    this.onZoneChanged,
    this.onAnalysisCollapsedChanged,
  });

  final List<TradeReviewGroup> groups;
  final Set<String> selected;
  final ValueChanged<String> onToggle;
  final bool enabled;
  final bool arabic;
  final Color tone;

  /// Builds a plain selectable row for the list zones (violations / risk).
  final Widget Function(TradeEntryOption option) listRowBuilder;
  final int initialZone;
  final bool initialAnalysisCollapsed;
  final ValueChanged<int>? onZoneChanged;
  final ValueChanged<bool>? onAnalysisCollapsedChanged;

  @override
  State<TradeDecisionZones> createState() => _TradeDecisionZonesState();
}

class _TradeDecisionZonesState extends State<TradeDecisionZones> {
  static const _switchDuration = Duration(milliseconds: 240);
  static const _tileGap = 6.0;

  late int _index = widget.initialZone < 0
      ? 0
      : (widget.initialZone >= widget.groups.length
          ? widget.groups.length - 1
          : widget.initialZone);
  late int _previous = _index;
  late bool _analysisCollapsed = widget.initialAnalysisCollapsed;

  TradeReviewGroup get _active => widget.groups[_index];

  int _countOf(TradeReviewGroup group) =>
      group.options.where((o) => widget.selected.contains(o.key)).length;

  void _onTabTap(int index) {
    final group = widget.groups[index];
    if (index == _index) {
      // Tapping the name of the open analysis zone folds / unfolds it, but
      // only once there is something selected to summarise.
      if (group.id == 'analysis' && _countOf(group) > 0) {
        setState(() => _analysisCollapsed = !_analysisCollapsed);
        widget.onAnalysisCollapsedChanged?.call(_analysisCollapsed);
      }
      return;
    }
    setState(() {
      _previous = _index;
      _index = index;
    });
    widget.onZoneChanged?.call(index);
  }

  void _expandAnalysis() {
    if (!_analysisCollapsed) return;
    setState(() => _analysisCollapsed = false);
    widget.onAnalysisCollapsedChanged?.call(false);
  }

  @override
  Widget build(BuildContext context) {
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final forward = _index >= _previous;
    // Content always enters from the side the chosen tab sits on.
    final direction = (forward ? 1.0 : -1.0) * (rtl ? -1.0 : 1.0);
    final activeKey = ValueKey<String>('decision-zone-panel-${_active.id}');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          key: const ValueKey('decision-zone-tabs'),
          children: [
            for (var i = 0; i < widget.groups.length; i++) ...[
              if (i > 0) const SizedBox(width: 6),
              Expanded(
                child: DecisionZoneTab(
                  key: ValueKey('decision-zone-tab-${widget.groups[i].id}'),
                  title: widget.arabic
                      ? widget.groups[i].titleAr
                      : widget.groups[i].titleEn,
                  count: _countOf(widget.groups[i]),
                  active: i == _index,
                  tone: widget.tone,
                  onTap: () => _onTabTap(i),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        AnimatedSize(
          duration: _switchDuration,
          curve: Curves.easeOutCubic,
          alignment: Alignment.topCenter,
          child: AnimatedSwitcher(
            duration: _switchDuration,
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            // Only the current panel sizes the stack; the leaving one is laid
            // over it so the height never jumps while content slides.
            layoutBuilder: (current, previous) => Stack(
              alignment: Alignment.topCenter,
              children: [
                for (final old in previous)
                  Positioned(top: 0, left: 0, right: 0, child: old),
                if (current != null) current,
              ],
            ),
            transitionBuilder: (child, animation) {
              final incoming = child.key == activeKey;
              final begin = Offset(incoming ? direction * .10 : -direction * .10, 0);
              return FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: Tween<Offset>(begin: begin, end: Offset.zero)
                      .animate(animation),
                  child: child,
                ),
              );
            },
            child: KeyedSubtree(
              key: activeKey,
              child: _buildPanel(context, _active),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPanel(BuildContext context, TradeReviewGroup group) {
    if (group.id == 'analysis') return _buildAnalysis(context, group);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < group.options.length; i++) ...[
          if (i > 0) const SizedBox(height: _tileGap),
          widget.listRowBuilder(group.options[i]),
        ],
      ],
    );
  }

  Widget _buildAnalysis(BuildContext context, TradeReviewGroup group) {
    final selectedOptions = [
      for (final option in group.options)
        if (widget.selected.contains(option.key)) option,
    ];
    final collapsed = _analysisCollapsed && selectedOptions.isNotEmpty;
    final byKey = {for (final o in group.options) o.key: o};

    final grid = Column(
      key: const ValueKey('decision-analysis-grid'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var r = 0; r < tradeAnalysisRowLayout.length; r++) ...[
          if (r > 0) const SizedBox(height: _tileGap),
          Row(
            children: [
              for (var c = 0; c < tradeAnalysisRowLayout[r].length; c++) ...[
                if (c > 0) const SizedBox(width: _tileGap),
                Expanded(
                  child: _AnalysisTile(
                    option: byKey[tradeAnalysisRowLayout[r][c]]!,
                    label: widget.arabic
                        ? byKey[tradeAnalysisRowLayout[r][c]]!.ar
                        : byKey[tradeAnalysisRowLayout[r][c]]!.en,
                    selected: widget.selected
                        .contains(tradeAnalysisRowLayout[r][c]),
                    enabled: widget.enabled,
                    tone: widget.tone,
                    onTap: () => widget.onToggle(tradeAnalysisRowLayout[r][c]),
                  ),
                ),
              ],
            ],
          ),
        ],
      ],
    );

    final summary = DecisionSelectionSummary(
      key: const ValueKey('decision-analysis-summary'),
      sentenceKey: const ValueKey('decision-analysis-summary-sentence'),
      sentence: tradeAnalysisMissedSentence(
        count: selectedOptions.length,
        arabic: widget.arabic,
      ),
      labels: [
        for (final option in selectedOptions)
          widget.arabic ? option.ar : option.en,
      ],
      tone: widget.tone,
      onTap: _expandAnalysis,
    );

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      layoutBuilder: (current, previous) => Stack(
        alignment: Alignment.topCenter,
        children: [
          for (final old in previous)
            Positioned(top: 0, left: 0, right: 0, child: old),
          if (current != null) current,
        ],
      ),
      transitionBuilder: (child, animation) =>
          FadeTransition(opacity: animation, child: child),
      child: collapsed ? summary : grid,
    );
  }
}

/// Tonal rectangle used as the name of one zone. Shared by the Decisions area
/// and the no-entry reasons area so both read as the same component.
class DecisionZoneTab extends StatelessWidget {
  const DecisionZoneTab({
    super.key,
    required this.title,
    required this.count,
    required this.active,
    required this.tone,
    required this.onTap,
  });

  final String title;
  final int count;
  final bool active;
  final Color tone;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fill = active
        ? Color.alphaBlend(
            tone.withValues(alpha: isDark ? .20 : .15),
            tokens.surface3,
          )
        : Color.alphaBlend(
            tone.withValues(alpha: isDark ? .05 : .04),
            tokens.surface3,
          );
    return Semantics(
      button: true,
      selected: active,
      label: title,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: active
                ? tone.withValues(alpha: isDark ? .26 : .22)
                : Colors.transparent,
            width: 0.8,
          ),
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onTap,
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 50),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                child: Center(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                color: active ? tokens.text1 : tokens.text2,
                                fontSize: 14,
                                fontWeight:
                                    active ? FontWeight.w800 : FontWeight.w600,
                                height: 1.2,
                              ),
                        ),
                        if (count > 0) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 1,
                            ),
                            decoration: BoxDecoration(
                              color: tone.withValues(alpha: .20),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              '$count',
                              style: Theme.of(context)
                                  .textTheme
                                  .labelSmall
                                  ?.copyWith(
                                    color: tone,
                                    fontWeight: FontWeight.w800,
                                  ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AnalysisTile extends StatelessWidget {
  const _AnalysisTile({
    required this.option,
    required this.label,
    required this.selected,
    required this.enabled,
    required this.tone,
    required this.onTap,
  });

  final TradeEntryOption option;
  final String label;
  final bool selected;
  final bool enabled;
  final Color tone;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // Tonal difference only: the selected tile sits one step higher in tone.
    // No border, no glow, no check mark.
    final fill = selected
        ? Color.alphaBlend(
            tone.withValues(alpha: isDark ? .20 : .15),
            tokens.surface3,
          )
        : Color.alphaBlend(
            tone.withValues(alpha: isDark ? .05 : .04),
            tokens.surface3,
          );
    return Opacity(
      opacity: enabled ? 1 : .52,
      child: AnimatedContainer(
        key: ValueKey('decision-analysis-surface-${option.key}'),
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(11),
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            key: ValueKey('review-${option.key}'),
            borderRadius: BorderRadius.circular(11),
            onTap: enabled ? onTap : null,
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 46),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 9),
                child: Center(
                  child: Text(
                    label,
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.ltr,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: selected ? tokens.text1 : tokens.text2,
                          fontSize: 13.5,
                          fontWeight:
                              selected ? FontWeight.w700 : FontWeight.w500,
                          height: 1.3,
                        ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Folded form of a zone once the user has chosen items: an optional sentence
/// on its own line and, below it, the chosen items as plain text (no chips).
/// With [stacked] every item takes its own line (long Arabic reasons); without
/// it the items run on one line separated by a wide gap, e.g.
/// `RBS Touch 2    Trend Line Touch 3 Sell Breakout`.
class DecisionSelectionSummary extends StatelessWidget {
  const DecisionSelectionSummary({
    super.key,
    this.sentence,
    this.sentenceKey,
    required this.labels,
    required this.tone,
    required this.onTap,
    this.stacked = false,
    this.latinLabels = true,
  });

  final String? sentence;
  final Key? sentenceKey;
  final List<String> labels;
  final Color tone;
  final VoidCallback onTap;
  final bool stacked;
  final bool latinLabels;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final itemStyle = Theme.of(context).textTheme.bodySmall?.copyWith(
          color: tokens.text1,
          fontSize: 14,
          fontWeight: FontWeight.w700,
          height: 1.35,
        );
    Widget item(String label) => Text(
          label,
          textDirection: latinLabels ? TextDirection.ltr : null,
          style: itemStyle,
        );
    final items = stacked
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (var i = 0; i < labels.length; i++) ...[
                if (i > 0) const SizedBox(height: 8),
                item(labels[i]),
              ],
            ],
          )
        : Wrap(
            spacing: 18,
            runSpacing: 6,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [for (final label in labels) item(label)],
          );
    return Container(
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          tone.withValues(alpha: isDark ? .07 : .05),
          tokens.surface3,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(14, 12, 8, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (sentence != null) ...[
                        Text(
                          sentence!,
                          key: sentenceKey,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: tokens.text2,
                                fontSize: 13.5,
                                fontWeight: FontWeight.w600,
                                height: 1.3,
                              ),
                        ),
                        const SizedBox(height: 8),
                      ],
                      items,
                    ],
                  ),
                ),
                const SizedBox(width: 4),
                Icon(
                  Icons.unfold_more_rounded,
                  size: 18,
                  color: tokens.text3,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Plain tonal tile for one selectable reason (full width, text aligned to the
/// reading start). Same surface language as the analysis tiles: a tonal step
/// instead of a border, glow or check mark.
class DecisionOptionTile extends StatelessWidget {
  const DecisionOptionTile({
    super.key,
    required this.label,
    required this.selected,
    required this.enabled,
    required this.tone,
    required this.onTap,
    this.inkKey,
    this.surfaceKey,
    this.fontSize = 13.5,
    this.leading,
  });

  /// Optional artwork shown before the label (the commitment illustrations).
  final Widget? leading;
  final String label;
  final bool selected;
  final bool enabled;
  final Color tone;
  final VoidCallback onTap;
  final Key? inkKey;
  final Key? surfaceKey;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fill = selected
        ? Color.alphaBlend(
            tone.withValues(alpha: isDark ? .20 : .15),
            tokens.surface3,
          )
        : Color.alphaBlend(
            tone.withValues(alpha: isDark ? .05 : .04),
            tokens.surface3,
          );
    return Opacity(
      opacity: enabled ? 1 : .52,
      child: AnimatedContainer(
        key: surfaceKey,
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(11),
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            key: inkKey,
            borderRadius: BorderRadius.circular(11),
            onTap: enabled ? onTap : null,
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 48),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: [
                    if (leading != null) ...[
                      leading!,
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      child: Text(
                        label,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: selected ? tokens.text1 : tokens.text2,
                              fontSize: fontSize,
                              fontWeight:
                                  selected ? FontWeight.w700 : FontWeight.w500,
                              height: 1.45,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
