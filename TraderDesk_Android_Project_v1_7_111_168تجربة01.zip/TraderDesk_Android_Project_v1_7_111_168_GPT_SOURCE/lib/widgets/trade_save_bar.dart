import 'package:flutter/material.dart';

import '../models/trade.dart';
import '../theme/app_theme.dart';
import '../theme/trade_outcome_palette.dart';

/// The bottom action of the trade form: one capsule that merges the outcome
/// (win / loss / break-even / missed) with the save button.
///
/// The outcome is derived automatically by the form, so the trader normally
/// only presses save. For break-even and missed the outcome pill also carries
/// the sub-choice (break-even type / missed would-have result) and opens the
/// in-place menu through [onOpenMenu].
class TradeSaveBar extends StatelessWidget {
  const TradeSaveBar({
    super.key,
    required this.classification,
    required this.title,
    required this.saveLabel,
    required this.ready,
    required this.busy,
    required this.hasMenu,
    required this.onSave,
    required this.onOpenMenu,
    this.subtitle,
    this.subtitleLtr = false,
  });

  /// `null` while the trader still has to choose between break-even / missed.
  final TradeClassification? classification;
  final String title;
  final String? subtitle;

  /// Amount-like subtitles ("USD 250+") are kept left-to-right.
  final bool subtitleLtr;
  final String saveLabel;

  /// False while a required sub-choice is missing; save then opens the menu.
  final bool ready;
  final bool busy;
  final bool hasMenu;
  final VoidCallback? onSave;
  final VoidCallback? onOpenMenu;

  static const double height = 68;

  static IconData iconFor(TradeClassification? value) => switch (value) {
    TradeClassification.win => Icons.trending_up_rounded,
    TradeClassification.loss => Icons.trending_down_rounded,
    TradeClassification.breakEven => Icons.drag_handle_rounded,
    TradeClassification.missed => Icons.visibility_off_outlined,
    null => Icons.tune_rounded,
  };

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final brightness = Theme.of(context).brightness;
    final isDark = brightness == Brightness.dark;
    final accent = TradeOutcomePalette.of(classification, tokens, brightness);
    final onAccent = ThemeData.estimateBrightnessForColor(accent) ==
            Brightness.dark
        ? Colors.white
        : const Color(0xFF0B0F14);
    final shell = Color.alphaBlend(
      accent.withValues(alpha: isDark ? .05 : .04),
      tokens.surface1,
    );
    final pillFill = Color.alphaBlend(
      accent.withValues(alpha: isDark ? .13 : .10),
      isDark ? tokens.surface2 : tokens.inset,
    );
    final saveFill = ready ? accent : tokens.surface3;
    final saveInk = ready ? onAccent : tokens.text2;
    const duration = Duration(milliseconds: 220);

    final pillBody = Row(
      children: [
        AnimatedContainer(
          duration: duration,
          curve: Curves.easeOutCubic,
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: accent.withValues(alpha: isDark ? .20 : .16),
          ),
          child: Icon(iconFor(classification), size: 22, color: accent),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                key: const ValueKey('trade-outcome-pill-title'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: accent,
                  fontWeight: FontWeight.w800,
                  height: 1.15,
                ),
              ),
              if (subtitle != null && subtitle!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    subtitle!,
                    key: const ValueKey('trade-outcome-pill-subtitle'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textDirection:
                        subtitleLtr ? TextDirection.ltr : null,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: tokens.text2,
                      fontWeight: FontWeight.w600,
                      height: 1.15,
                    ),
                  ),
                ),
            ],
          ),
        ),
        if (hasMenu)
          Icon(Icons.keyboard_arrow_down_rounded, size: 22, color: tokens.text3),
      ],
    );

    final pill = AnimatedContainer(
      key: const ValueKey('trade-outcome-pill'),
      duration: duration,
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: pillFill,
        borderRadius: BorderRadius.circular(21),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: BorderRadius.circular(21),
          onTap: hasMenu && !busy ? onOpenMenu : null,
          child: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(8, 0, 10, 0),
            child: pillBody,
          ),
        ),
      ),
    );

    final save = AnimatedContainer(
      duration: duration,
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: saveFill,
        borderRadius: BorderRadius.circular(21),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          key: const ValueKey('save-trade-button'),
          borderRadius: BorderRadius.circular(21),
          onTap: busy ? null : onSave,
          child: Center(
            child: busy
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.2,
                      color: saveInk,
                    ),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.save_outlined, size: 22, color: saveInk),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          saveLabel,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(
                                color: saveInk,
                                fontWeight: FontWeight.w800,
                              ),
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );

    return Semantics(
      container: true,
      child: AnimatedContainer(
        key: const ValueKey('trade-save-bar'),
        duration: duration,
        curve: Curves.easeOutCubic,
        height: height,
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: shell,
          borderRadius: BorderRadius.circular(27),
          border: Border.all(
            color: accent.withValues(alpha: isDark ? .42 : .38),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Expanded(flex: 9, child: save),
            const SizedBox(width: 6),
            Expanded(flex: 11, child: pill),
          ],
        ),
      ),
    );
  }
}
