#!/usr/bin/env python3
"""Static regression checks for Base and direction-aware Zone S/D anchors."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
MODEL = (ROOT / "lib/models/trade.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
WIDGET_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

anchor_block = CATALOG.split("const tradeAnchorOptions", 1)[1].split("const tradeMoodOptions", 1)[0]
check("anchor catalog contains exactly one Base option", anchor_block.count("TradeEntryOption('base'") == 1)
check("anchor catalog contains one Zone S/D choice", "TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D')" in anchor_block)
check("separate Supply/Demand anchor rows are absent", "TradeEntryOption('supplyZone'" not in anchor_block and "TradeEntryOption('demandZone'" not in anchor_block)
check("single Engulfing anchor replaces separate Bullish/Bearish rows", "TradeEntryOption('engulfing', 'Engulfing', 'Engulfing')" in anchor_block and "TradeEntryOption('bullishEngulfing'" not in anchor_block and "TradeEntryOption('bearishEngulfing'" not in anchor_block)
check("Engulfing anchor resolves by direction", "case 'engulfing':" in CATALOG and "TradeSide.buy => 'Bullish Engulfing'" in CATALOG and "TradeSide.sell => 'Bearish Engulfing'" in CATALOG)
check("legacy and raw-label Engulfing anchors remain readable", all(x in CATALOG for x in ["case 'bullishEngulfing':", "case 'bearishEngulfing':", "case 'Bearish engulfing':", "case 'Bullish engulfing':"]))
check("Zone S/D resolves to Demand Zone for BUY", "if (side == TradeSide.buy) return 'Demand Zone';" in CATALOG)
check("Zone S/D resolves to Supply Zone for SELL", "if (side == TradeSide.sell) return 'Supply Zone';" in CATALOG)
check("legacy supply/demand anchors retain their readable labels", "case 'supplyZone':\n      return 'Supply Zone';" in CATALOG and "case 'demandZone':\n      return 'Demand Zone';" in CATALOG)
check("anchor form uses the shared direction-aware formatter", "String _anchorSelectionLabel(String anchorKey) => formatTradeAnchorLabel(" in FORM)
check("legacy anchor keys are recognized as selected Zone S/D choices", "_selectedAnchorStorageKey(option.key, selected)" in FORM and "selected.contains('demandZone')" in FORM and "selected.contains('supplyZone')" in FORM)
check("new Zone S/D selection removes superseded legacy keys", "_anchors.removeAll({'supplyZone', 'demandZone'})" in FORM)
check("anchor edit and add timeframe dialogs keep contextual headers", FORM.count("_anchorTimeframeContextLabel(option.key)") >= 2 and "contextLabel: _anchorTimeframeContextLabel(anchorKey)" in FORM)
check("saved trade details use direction-aware anchor formatter", "formatTradeAnchorLabel(" in TRADES and "side: trade.side" in TRADES)
check("anchor/timeframe persistence shape remains unchanged", "final Map<String, String> anchorTimeframes" in MODEL and "'anchorTimeframes': anchorTimeframes" in MODEL)
check("widget tests cover Zone S/D BUY/SELL mapping and retained timeframe", all(s in WIDGET_TEST for s in ["trade-anchor-option-zoneSd", "الارتكاز · Demand Zone", "Supply Zone 15MIN", "Demand Zone 15MIN"]))
check("catalog tests cover one Zone S/D anchor and legacy compatibility", all(s in CATALOG_TEST for s in ["Zone S/D", "formatTradeAnchorLabel", "supplyZone", "demandZone"]))
check("timeframe choices remain the original eight frames", "['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H']" in CATALOG)
check("pubspec version is 1.7.92+148", "version: 1.7.92+148" in PUBSPEC)
check("workflow and artifact IDs match build 146", "TraderDesk 1.7.92+148" in WORKFLOW and "traderdesk-1.7.92-build148-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.92-build148-arm64-dart-symbols" in WORKFLOW)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
