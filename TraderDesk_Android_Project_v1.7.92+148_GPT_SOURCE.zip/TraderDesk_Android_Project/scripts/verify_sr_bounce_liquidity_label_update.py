#!/usr/bin/env python3
"""Regression checks for the 1.7.92+148 S/R bounce and liquidity labels."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / 'lib/domain/trade_entry_catalog.dart').read_text(encoding='utf-8')
STRINGS = (ROOT / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8')
CATALOG_TEST = (ROOT / 'test/trade_entry_catalog_test.dart').read_text(encoding='utf-8')
ENTRY_TEST = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
DETAIL_TEST = (ROOT / 'test/trade_detail_layout_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

# Output order and direction terms.
for label in [
    "? 'ارتداد من Support'", ": 'ارتداد من Resistan'",
    "? 'Bounce from Support'", ": 'Bounce from Resistan'",
    "if (setup.touch2) 'Touch 2'", "return '$directionalLabel $suffix';",
]:
    check(f'formatter contains {label}', label in CATALOG)
check('legacy Arabic Support/Resistance chip text is removed from formatter', "'ارتداد من دعم'" not in CATALOG and "'ارتداد من مقاومة'" not in CATALOG)
check('Touch qualifier remains stored using the original touch2 flag', 'setup.touch2' in CATALOG and 'touch2: touch2' in (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8'))

# Liquidity labels and stable keys in both locales.
for expected in [
    "TradeEntryOption('internalLiquiditySweep', 'سحب سيولة داخلي', 'Internal liquidity sweep')",
    "TradeEntryOption('majorStructureLiquiditySweep', 'سحب السيولة خارجي', 'External liquidity sweep')",
]:
    check(f'catalog contains {expected}', expected in CATALOG)
for expected in [
    "'internalLiquiditySweep': 'سحب سيولة داخلي'",
    "'majorStructureLiquiditySweep': 'سحب السيولة خارجي'",
    "'internalLiquiditySweep': 'Internal liquidity sweep'",
    "'majorStructureLiquiditySweep': 'External liquidity sweep'",
]:
    check(f'localized string contains {expected}', expected in STRINGS)
check('old liquidity labels are absent from active catalog and translations', all(old not in CATALOG and old not in STRINGS for old in ['سحب سيولة من منطقة داخلية', 'سحب سيولة من هيكل رئيسي', 'Liquidity sweep from an internal area', 'Liquidity sweep from a major structure']))

# Unit/widget/detail test coverage.
for expected in [
    'ارتداد من Support Touch 2 15MIN',
    'ارتداد من Support 15MIN',
    'ارتداد من Resistan Touch 2 15MIN',
    'ارتداد من Resistan 15MIN',
    'Bounce from Support Touch 2 15MIN',
]:
    check(f'catalog tests assert {expected}', expected in CATALOG_TEST)
check('entry form widget test checks Support/Resistance label order', 'ارتداد من Support Touch 2 15MIN' in ENTRY_TEST and 'ارتداد من Resistan Touch 2 15MIN' in ENTRY_TEST and 'ارتداد من Support 4H' in ENTRY_TEST)
check('saved trade detail tests check Support/Resistance labels', 'ارتداد من Support Touch 2 30MIN' in DETAIL_TEST and 'ارتداد من Resistan Touch 2 15MIN' in DETAIL_TEST)
check('option keys remain unchanged', "TradeEntryOption('internalLiquiditySweep'" in CATALOG and "TradeEntryOption('majorStructureLiquiditySweep'" in CATALOG)
check('version is 1.7.92+148', 'version: 1.7.92+148' in PUBSPEC)
check('workflow release name and artifact IDs match 1.7.92/148', 'TraderDesk 1.7.92+148' in WORKFLOW and 'traderdesk-1.7.92-build148' in WORKFLOW)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
