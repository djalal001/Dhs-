#!/usr/bin/env python3
"""Focused static verification for TraderDesk 1.7.119+175."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE_NOTES = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

check('version is 1.7.119+175', 'version: 1.7.119+175' in PUBSPEC)
check('workflow is versioned 1.7.119+175', 'TraderDesk 1.7.119+175 Android Release APK' in WORKFLOW)
check('workflow release artifacts use build 175', 'traderdesk-1.7.119-build175-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.119-build175-arm64-dart-symbols' in WORKFLOW)
check('build information reports version 1.7.119 and build 175', '1.7.119+175' in BUILD_INFO and 'رقم الإصدار: `1.7.119`' in BUILD_INFO and 'رقم البناء: `175`' in BUILD_INFO)
check('release notes include 1.7.119+175', '1.7.119+175' in RELEASE_NOTES)

# Avoid a duplicate title while the inline choices already say Profit / Loss; restore it after a sign is chosen.
check('result title is suppressed only while inline choices are visible', 'labelText: showTypeChoices\n                ? null\n                : _copy(\'الربح / الخسارة\', \'Profit / loss\')' in FORM)
check('result heading retains floating-label behavior', 'floatingLabelBehavior: FloatingLabelBehavior.auto' in FORM)

# Both keyboard continuation points now execute the state transition from
# onEditingComplete itself, instead of returning early and relying only on a
# secondary submit callback.
result_complete = FORM.split("key: const ValueKey('trade-result-input')", 1)[1].split('keyboardType:', 1)[0]
check('result field wires editing-complete and submitted callbacks', 'onEditingComplete: _handleResultEditingComplete' in result_complete and 'onFieldSubmitted: _handleResultSubmitted' in result_complete)
check('result IME callbacks are both handled by the guided step guard', 'void _handleResultEditingComplete()' in FORM and 'void _handleResultSubmitted(String _)' in FORM)
expected_field = FORM.split("key: const ValueKey('trade-expected-loss-input')", 1)[1].split('onChanged:', 1)[0]
check('expected-loss field wires editing-complete and submitted callbacks', 'onEditingComplete: _handleExpectedLossEditingComplete' in expected_field and 'onSubmitted: _handleExpectedLossSubmitted' in expected_field)
check('expected-loss IME callbacks are both handled by the guided step guard', 'void _handleExpectedLossEditingComplete()' in FORM and 'void _handleExpectedLossSubmitted(String _)' in FORM and '_autoEntryStep != _AutoEntryStep.idle' in FORM)
check('guided IME submit is one-shot across duplicate callbacks', '_resultKeyboardActionHandled' in FORM and '_expectedLossKeyboardActionHandled' in FORM and '_submitGuidedResultOnce()' in FORM and '_submitGuidedExpectedLossOnce()' in FORM)
check('editing a value re-arms its next guided keyboard submission', ' _resultKeyboardActionHandled = false;' in FORM and '_expectedLossKeyboardActionHandled = false;' in FORM and '_expectedLossKeyboardActionHandled = false;\n                              setState(_updateComputedFields);' in FORM)
check('result keyboard still uses Next action', 'textInputAction: TextInputAction.next' in result_complete)

# Preserve the five-stage flow and its edit/manual-entry guard.
check('positive outcome focuses expected-loss field', 'if (_resultSign == 1)' in FORM and '_expectedLossFocusNode.requestFocus();' in FORM)
check('negative outcome skips expected-loss and opens direction', 'if (_resultSign == -1)' in FORM and 'await _openAutoDirectionPopup();' in FORM)
check('expected-loss completion opens direction', 'Future<void> _continueAfterExpectedLoss()' in FORM and 'await _openAutoDirectionPopup();' in FORM)
check('direction selection opens market', '_autoEntryStep = _AutoEntryStep.market;' in FORM and '_openAutoMarketPopup();' in FORM)
check('market selection opens mindset', '_autoEntryStep = _AutoEntryStep.mindset;' in FORM and '_openAutoMindsetDialog();' in FORM)
check('mindset remains multi-select', 'CheckboxListTile(' in FORM and 'trade-mood-option-${item.key}' in FORM)
check('mindset field height remains 72dp', 'const double _tradeDataControlHeight = 72' in FORM and "key: const ValueKey('trade-mood-field')" in FORM)
check('automatic sequence remains restricted to a fresh initial entry', 'widget.trade == null' in FORM and '!_autoEntrySequenceUsed' in FORM)
check('manual direction/market edits do not cascade', 'else if (_autoEntryStep != _AutoEntryStep.idle)' in FORM)

check('positive flow widget test exercises duplicate IME completion callbacks', 'profit advances through expected loss' in TESTS and 'Some keyboards dispatch both callbacks' in TESTS)
check('negative flow widget test exercises keyboard Next', 'loss skips expected loss' in TESTS and 'a negative result skips Expected Loss' in TESTS)
check('tests assert no duplicated result heading before sign selection', TESTS.count('decoration?.labelText, isNull') >= 2)
check('tests assert floating result heading returns after sign selection', TESTS.count("decoration?.labelText,\n        'الربح / الخسارة'") >= 2)
check('profit completion regression checks that Risk % never receives focus', 'read-only Risk % field must never receive focus' in TESTS)
check('manual edit regression remains covered', 'manual edits of an existing direction and market do not auto-advance' in TESTS)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
