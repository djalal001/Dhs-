#!/usr/bin/env python3
"""Retime the bundled emoji animations (GIF + animated WebP) without re-encoding.

Why this exists
---------------
Flutter's `Image.asset` plays animated GIF/WebP files at the frame durations
stored *inside* the file, and offers no playback-speed control. Every emoji
surface (review form, trade details, execution journal) therefore follows the
timing baked into the assets. This tool changes only those duration fields:

* GIF : the 2-byte delay (1/100 s) of every Graphic Control Extension.
* WebP: the 3-byte duration (ms) of every ANMF frame header.

No pixel data, palette, alpha channel, frame count, loop count or file size is
touched, so artwork stays byte-identical and the APK does not grow.

Idempotent by design
--------------------
New timings are always computed from the ORIGINAL timings recorded in
`scripts/emoji_timing_baseline.json`, never from the current files, so running
the tool again with the same --factor changes nothing and a different --factor
replaces (does not compound) the previous one.

Usage
-----
    python3 scripts/retime_emoji_animations.py --factor 1.2          # apply
    python3 scripts/retime_emoji_animations.py --factor 1.2 --dry-run # preview
    python3 scripts/retime_emoji_animations.py --factor 1.0          # restore original speed
    python3 scripts/retime_emoji_animations.py --report              # print current timings

`--factor` is a duration multiplier: 1.2 makes every animation 20 % longer
(playback ~17 % slower); 1.0 is the original speed.

Only needs the Python 3 standard library.
"""

from __future__ import annotations

import argparse
import json
import os
import struct
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
EMOJI_DIR = Path("assets") / "emojis"
DEFAULT_BASELINE = Path(__file__).resolve().parent / "emoji_timing_baseline.json"

GIF_MIN_CS = 2          # many decoders treat shorter GIF delays as ~100 ms
WEBP_MIN_MS = 16
WEBP_MAX_MS = 0xFFFFFF  # 24-bit field


class FormatError(Exception):
    pass


# --------------------------------------------------------------------------- GIF
def _gif_delay_offsets(data: bytes) -> list[int]:
    """Byte offsets of every GCE delay field, in file order."""
    if data[:6] not in (b"GIF87a", b"GIF89a"):
        raise FormatError("not a GIF")
    pos = 13
    flags = data[10]
    if flags & 0x80:
        pos += 3 * (2 ** ((flags & 7) + 1))
    offsets: list[int] = []
    while pos < len(data):
        block = data[pos]
        if block == 0x3B:  # trailer
            break
        if block == 0x21:  # extension
            label = data[pos + 1]
            if label == 0xF9:  # graphic control extension
                if data[pos + 2] != 4:
                    raise FormatError("unexpected GCE size")
                offsets.append(pos + 4)
            pos += 2
            while data[pos] != 0:
                pos += data[pos] + 1
            pos += 1
        elif block == 0x2C:  # image descriptor
            local_flags = data[pos + 9]
            pos += 10
            if local_flags & 0x80:
                pos += 3 * (2 ** ((local_flags & 7) + 1))
            pos += 1  # LZW minimum code size
            while data[pos] != 0:
                pos += data[pos] + 1
            pos += 1
        else:
            raise FormatError(f"unknown GIF block 0x{block:02x}")
    return offsets


def read_gif(data: bytes) -> list[int]:
    return [struct.unpack_from("<H", data, o)[0] for o in _gif_delay_offsets(data)]


def write_gif(data: bytes, delays: list[int]) -> bytes:
    offsets = _gif_delay_offsets(data)
    if len(offsets) != len(delays):
        raise FormatError(f"frame count mismatch: file {len(offsets)} vs {len(delays)}")
    out = bytearray(data)
    for offset, delay in zip(offsets, delays):
        struct.pack_into("<H", out, offset, delay)
    return bytes(out)


# -------------------------------------------------------------------------- WebP
def _webp_duration_offsets(data: bytes) -> list[int]:
    if data[:4] != b"RIFF" or data[8:12] != b"WEBP":
        raise FormatError("not a WebP")
    pos = 12
    offsets: list[int] = []
    while pos + 8 <= len(data):
        tag = data[pos : pos + 4]
        size = struct.unpack_from("<I", data, pos + 4)[0]
        if tag == b"ANMF":
            offsets.append(pos + 8 + 12)  # X, Y, W-1, H-1 (3 bytes each), then duration
        pos += 8 + size + (size & 1)
    return offsets


def read_webp(data: bytes) -> list[int]:
    return [int.from_bytes(data[o : o + 3], "little") for o in _webp_duration_offsets(data)]


def write_webp(data: bytes, durations: list[int]) -> bytes:
    offsets = _webp_duration_offsets(data)
    if len(offsets) != len(durations):
        raise FormatError(f"frame count mismatch: file {len(offsets)} vs {len(durations)}")
    out = bytearray(data)
    for offset, value in zip(offsets, durations):
        out[offset : offset + 3] = value.to_bytes(3, "little")
    return bytes(out)


# ------------------------------------------------------------------------ common
def kind_of(path: Path) -> str | None:
    suffix = path.suffix.lower()
    return {".gif": "gif", ".webp": "webp"}.get(suffix)


def read_timings(path: Path) -> list[int]:
    data = path.read_bytes()
    kind = kind_of(path)
    return read_gif(data) if kind == "gif" else read_webp(data)


def discover(root: Path) -> list[Path]:
    base = root / EMOJI_DIR
    return sorted(p for p in base.rglob("*") if p.is_file() and kind_of(p))


def scaled(value: int, factor: float, kind: str) -> int:
    result = int(value * factor + 0.5)
    if kind == "gif":
        return max(GIF_MIN_CS, min(result, 0xFFFF))
    return max(WEBP_MIN_MS, min(result, WEBP_MAX_MS))


def write_baseline(root: Path, baseline_path: Path) -> None:
    files = {}
    for path in discover(root):
        rel = path.relative_to(root / EMOJI_DIR).as_posix()
        kind = kind_of(path)
        files[rel] = {"kind": kind, "unit": "cs" if kind == "gif" else "ms", "durations": read_timings(path)}
    payload = {
        "about": "Original (pre-retime) frame durations. GIF in 1/100 s, WebP in ms. "
                 "retime_emoji_animations.py scales these by --factor.",
        "files": files,
    }
    baseline_path.write_text(json.dumps(payload, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"baseline written: {len(files)} files -> {baseline_path}")


def total_ms(durations: list[int], kind: str) -> int:
    return sum(durations) * (10 if kind == "gif" else 1)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--factor", type=float, help="duration multiplier relative to the ORIGINAL speed (1.0 = original)")
    parser.add_argument("--dry-run", action="store_true", help="show what would change without writing")
    parser.add_argument("--report", action="store_true", help="print the current timing of every emoji and exit")
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT, help="project root (default: this project)")
    parser.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE, help="baseline JSON path")
    parser.add_argument("--write-baseline", action="store_true",
                        help="record the CURRENT files as the baseline (run on pristine assets only)")
    args = parser.parse_args()

    root = args.root.resolve()
    if args.write_baseline:
        write_baseline(root, args.baseline)
        return 0

    if args.report:
        for path in discover(root):
            kind = kind_of(path)
            durations = read_timings(path)
            rel = path.relative_to(root / EMOJI_DIR).as_posix()
            print(f"{rel:64s} {kind:4s} frames={len(durations):3d} "
                  f"per-frame={min(durations)}..{max(durations)}{'cs' if kind == 'gif' else 'ms'} "
                  f"loop={total_ms(durations, kind) / 1000:.2f}s")
        return 0

    if args.factor is None:
        parser.error("--factor is required (or use --report / --write-baseline)")
    if not 0.5 <= args.factor <= 4.0:
        parser.error("--factor must be between 0.5 and 4.0")

    baseline = json.loads(args.baseline.read_text(encoding="utf-8"))["files"]
    on_disk = {p.relative_to(root / EMOJI_DIR).as_posix(): p for p in discover(root)}
    if set(baseline) != set(on_disk):
        missing = sorted(set(baseline) - set(on_disk))
        extra = sorted(set(on_disk) - set(baseline))
        print(f"asset list differs from baseline. missing={missing} unknown={extra}", file=sys.stderr)
        return 2

    changed = 0
    for rel, entry in sorted(baseline.items()):
        path = on_disk[rel]
        kind = entry["kind"]
        target = [scaled(v, args.factor, kind) for v in entry["durations"]]
        data = path.read_bytes()
        updated = write_gif(data, target) if kind == "gif" else write_webp(data, target)
        if len(updated) != len(data):
            raise FormatError(f"{rel}: size changed")  # cannot happen; defensive
        loop_before = total_ms(entry["durations"], kind) / 1000
        loop_after = total_ms(target, kind) / 1000
        status = "unchanged" if updated == data else "retimed"
        print(f"{status:9s} {rel:64s} loop {loop_before:.2f}s -> {loop_after:.2f}s")
        if updated != data:
            changed += 1
            if not args.dry_run:
                tmp = path.with_suffix(path.suffix + ".tmp")
                tmp.write_bytes(updated)
                os.replace(tmp, path)
    print(f"\n{changed} file(s) {'would change' if args.dry_run else 'changed'}; factor={args.factor}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except FormatError as error:
        print(f"error: {error}", file=sys.stderr)
        sys.exit(1)
