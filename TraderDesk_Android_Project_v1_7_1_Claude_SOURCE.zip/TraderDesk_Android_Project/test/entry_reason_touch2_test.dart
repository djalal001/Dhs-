import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  group('entry reason catalog', () {
    test('offers RFS and SFR right after SBR and RBS', () {
      final keys = tradeEntryReasons.map((option) => option.key).toList();
      expect(keys.take(4), ['SBR', 'RBS', 'RFS', 'SFR']);
      expect(keys.toSet().length, keys.length, reason: 'reason keys must be unique');
      expect(keys, containsAll(['Trend Line SELL', 'Trend Line BREAKOUT SELL', 'Trend Line BUY', 'Trend Line BREAKOUT BUY', 'HNS', 'Supply Zone']));
    });

    test('Touch 2 variants are a separate step, not list entries', () {
      final keys = tradeEntryReasons.map((option) => option.key);
      expect(keys, isNot(contains('SBR Touch 2')));
      expect(keys, isNot(contains('RBS Touch 2')));
    });

    test('only SBR and RBS offer the Touch 2 step', () {
      expect(tradeEntryReasonOffersTouch2('SBR'), isTrue);
      expect(tradeEntryReasonOffersTouch2('RBS'), isTrue);
      for (final other in ['RFS', 'SFR', 'HNS', 'Supply Zone', 'Trend Line BUY', '']) {
        expect(tradeEntryReasonOffersTouch2(other), isFalse, reason: other);
      }
    });

    test('compose keeps the stored format used by earlier versions', () {
      expect(composeTradeEntryReason('SBR', touch2: true), 'SBR Touch 2');
      expect(composeTradeEntryReason('RBS', touch2: true), 'RBS Touch 2');
      expect(composeTradeEntryReason('SBR', touch2: false), 'SBR');
      expect(composeTradeEntryReason('RBS', touch2: false), 'RBS');
      // Reasons without a Touch 2 step never receive the suffix.
      expect(composeTradeEntryReason('RFS', touch2: true), 'RFS');
      expect(composeTradeEntryReason('SFR', touch2: true), 'SFR');
      expect(composeTradeEntryReason('HNS', touch2: true), 'HNS');
    });

    test('stored values from earlier versions are understood', () {
      expect(tradeEntryReasonHasTouch2('SBR Touch 2'), isTrue);
      expect(tradeEntryReasonHasTouch2('RBS Touch 2'), isTrue);
      expect(tradeEntryBaseReason('SBR Touch 2'), 'SBR');
      expect(tradeEntryBaseReason('RBS Touch 2'), 'RBS');
      expect(tradeEntryBaseReason('SBR'), 'SBR');
      // Anything else is left untouched.
      expect(tradeEntryReasonHasTouch2('RFS Touch 2'), isFalse);
      expect(tradeEntryBaseReason('RFS Touch 2'), 'RFS Touch 2');
      expect(tradeEntryBaseReason('Touch 2'), 'Touch 2');
      expect(tradeEntryBaseReason(''), '');
      expect(tradeEntryLabel('SBR Touch 2', arabic: true), 'SBR Touch 2');
      expect(tradeEntryLabel('RFS', arabic: false), 'RFS');
    });

    test('compose and base are inverse operations', () {
      for (final base in ['SBR', 'RBS']) {
        for (final touch2 in [true, false]) {
          final stored = composeTradeEntryReason(base, touch2: touch2);
          expect(tradeEntryBaseReason(stored), base);
          expect(tradeEntryReasonHasTouch2(stored), touch2);
        }
      }
    });

    test('RFS and SFR round-trip through the trade JSON unchanged', () {
      final trade = Trade(
        id: 'json-1',
        accountId: 'a',
        market: 'EURUSD',
        reason: 'RFS',
        result: 10,
        riskPercent: 1,
        side: TradeSide.buy,
        confirmation: '',
        sequence: '',
        mood: 'moodUnknown',
        tradedAt: DateTime(2025, 1, 2),
        entrySetups: const [
          TradeEntrySetup(reason: 'RFS', timeframe: '5MIN'),
          TradeEntrySetup(reason: 'SFR', timeframe: '1H'),
          TradeEntrySetup(reason: 'SBR Touch 2', timeframe: '15MIN'),
        ],
      );
      final decoded = Trade.fromJson(Map<String, dynamic>.from(trade.toJson()));
      expect(decoded.entrySetups, trade.entrySetups);
      expect(decoded.entrySetupSummary, 'RFS · 5MIN، SFR · 1H، SBR Touch 2 · 15MIN');
    });
  });

  group('entry reason flow in the trade form', () {
    late Directory temp;
    late AppController app;

    setUp(() async {
      temp = await Directory.systemTemp.createTemp('trader_desk_touch2_');
      app = await AppController.create(
        store: LocalStore(documentsDirectory: () async => temp),
      );
      app.accounts = [
        TradingAccount(
          id: 'entry-account',
          name: 'Demo',
          type: AccountType.demo,
          startingBalance: 10000,
          currency: 'USD',
          createdAt: DateTime(2025, 1, 1),
        ),
      ];
      app.selectedAccountId = 'entry-account';
    });

    tearDown(() async {
      app.dispose();
      if (await temp.exists()) await temp.delete(recursive: true);
    });

    Future<void> pumpForm(WidgetTester tester, {Trade? trade, Locale locale = const Locale('ar')}) async {
      tester.view.setLogicalSize(const Size(420, 900));
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        AppScope(
          controller: app,
          child: MaterialApp(
            theme: buildAppTheme(Brightness.dark),
            locale: locale,
            supportedLocales: const [Locale('ar'), Locale('en')],
            localizationsDelegates: GlobalMaterialLocalizations.delegates,
            home: TradeFormScreen(trade: trade),
          ),
        ),
      );
      await tester.pumpAndSettle();
    }

    Future<void> openAddEntry(WidgetTester tester) async {
      final addEntry = find.byKey(const ValueKey('add-entry-setup'));
      await tester.ensureVisible(addEntry);
      await tester.tap(addEntry);
      await tester.pumpAndSettle();
    }

    Trade existingTrade(String reason, String timeframe) => Trade(
      id: 'existing-1',
      accountId: 'entry-account',
      market: 'EURUSD',
      reason: reason,
      result: 50,
      riskPercent: 1,
      side: TradeSide.sell,
      confirmation: '',
      sequence: '',
      mood: 'moodCalm',
      tradedAt: DateTime(2025, 1, 2, 10),
      expectedLoss: 100,
      entrySetups: [TradeEntrySetup(reason: reason, timeframe: timeframe)],
      confirmationSetups: const [TradeConfirmationSetup(type: 'confirmHns', timeframe: '5MIN')],
    );

    testWidgets('reason list shows RFS and SFR and no Touch 2 entries', (tester) async {
      await pumpForm(tester);
      await openAddEntry(tester);
      expect(find.text('SBR'), findsOneWidget);
      expect(find.text('RBS'), findsOneWidget);
      expect(find.text('RFS'), findsOneWidget);
      expect(find.text('SFR'), findsOneWidget);
      expect(find.text('SBR Touch 2'), findsNothing);
      expect(find.text('RBS Touch 2'), findsNothing);
    });

    for (final reason in ['RFS', 'SFR']) {
      testWidgets('$reason goes straight to the timeframe list', (tester) async {
        await pumpForm(tester);
        await openAddEntry(tester);
        await tester.tap(find.text(reason).last);
        await tester.pumpAndSettle();
        expect(find.byKey(const ValueKey('touch2-sheet')), findsNothing);
        for (final frame in tradeEntryTimeframes) {
          expect(find.text(frame), findsOneWidget, reason: frame);
        }
        await tester.tap(find.text('5MIN').last);
        await tester.pumpAndSettle();
        expect(find.text('$reason · 5MIN'), findsOneWidget);
      });
    }

    testWidgets('SBR + Touch 2 stores the Touch 2 reason, then asks for the timeframe', (tester) async {
      await pumpForm(tester);
      await openAddEntry(tester);
      await tester.tap(find.text('SBR').last);
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('touch2-sheet')), findsOneWidget);
      expect(find.byKey(const ValueKey('touch2-option')), findsOneWidget);
      expect(find.byKey(const ValueKey('touch2-skip')), findsOneWidget);
      // The timeframe list only appears after the Touch 2 step is resolved.
      expect(find.text('1MIN'), findsNothing);
      await tester.tap(find.byKey(const ValueKey('touch2-option')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('touch2-sheet')), findsNothing);
      await tester.tap(find.text('1MIN').last);
      await tester.pumpAndSettle();
      expect(find.text('SBR Touch 2 · 1MIN'), findsOneWidget);
    });

    testWidgets('RBS can skip Touch 2 and still reaches the timeframe list', (tester) async {
      await pumpForm(tester);
      await openAddEntry(tester);
      await tester.tap(find.text('RBS').last);
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('touch2-sheet')), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('touch2-skip')));
      await tester.pumpAndSettle();
      expect(find.text('4H'), findsOneWidget);
      await tester.tap(find.text('1H').last);
      await tester.pumpAndSettle();
      expect(find.text('RBS · 1H'), findsOneWidget);
      expect(find.text('RBS Touch 2 · 1H'), findsNothing);
    });

    testWidgets('the Touch 2 step is also available in English', (tester) async {
      await pumpForm(tester, locale: const Locale('en'));
      await openAddEntry(tester);
      await tester.tap(find.text('RBS').last);
      await tester.pumpAndSettle();
      expect(find.text('Touch 2 (optional)'), findsOneWidget);
      expect(find.text('Skip'), findsOneWidget);
      await tester.tap(find.text('Skip'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('15MIN').last);
      await tester.pumpAndSettle();
      expect(find.text('RBS · 15MIN'), findsOneWidget);
    });

    testWidgets('dismissing the Touch 2 step cancels the flow without adding anything', (tester) async {
      await pumpForm(tester);
      await openAddEntry(tester);
      await tester.tap(find.text('SBR').last);
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('touch2-sheet')), findsOneWidget);
      // Tap the scrim above the sheet.
      await tester.tapAt(const Offset(10, 10));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('touch2-sheet')), findsNothing);
      expect(find.text('5MIN'), findsNothing);
      expect(find.byType(InputChip), findsNothing);
    });

    testWidgets('editing a stored "RBS Touch 2" pre-selects Touch 2 and can drop it', (tester) async {
      await pumpForm(tester, trade: existingTrade('RBS Touch 2', '5MIN'));
      final chip = find.text('RBS Touch 2 · 5MIN');
      await tester.ensureVisible(chip);
      await tester.tap(chip);
      await tester.pumpAndSettle();

      // The base reason is highlighted in the list; Touch 2 is not a list entry.
      expect(find.text('RBS Touch 2'), findsNothing);
      await tester.tap(find.text('RBS').last);
      await tester.pumpAndSettle();

      expect(tester.widget<ListTile>(find.byKey(const ValueKey('touch2-option'))).selected, isTrue);
      expect(tester.widget<ListTile>(find.byKey(const ValueKey('touch2-skip'))).selected, isFalse);

      await tester.tap(find.byKey(const ValueKey('touch2-skip')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('1H').last);
      await tester.pumpAndSettle();
      expect(find.text('RBS · 1H'), findsOneWidget);
      expect(find.text('RBS Touch 2 · 5MIN'), findsNothing);
    });

    testWidgets('editing a plain "SBR" pre-selects skip and can add Touch 2', (tester) async {
      await pumpForm(tester, trade: existingTrade('SBR', '15MIN'));
      final chip = find.text('SBR · 15MIN');
      await tester.ensureVisible(chip);
      await tester.tap(chip);
      await tester.pumpAndSettle();
      await tester.tap(find.text('SBR').last);
      await tester.pumpAndSettle();

      expect(tester.widget<ListTile>(find.byKey(const ValueKey('touch2-option'))).selected, isFalse);
      expect(tester.widget<ListTile>(find.byKey(const ValueKey('touch2-skip'))).selected, isTrue);

      await tester.tap(find.byKey(const ValueKey('touch2-option')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('15MIN').last);
      await tester.pumpAndSettle();
      expect(find.text('SBR Touch 2 · 15MIN'), findsOneWidget);
      expect(find.text('SBR · 15MIN'), findsNothing);
    });

    testWidgets('editing "SBR Touch 2" into RFS skips the Touch 2 step and drops the suffix', (tester) async {
      await pumpForm(tester, trade: existingTrade('SBR Touch 2', '15MIN'));
      final chip = find.text('SBR Touch 2 · 15MIN');
      await tester.ensureVisible(chip);
      await tester.tap(chip);
      await tester.pumpAndSettle();
      await tester.tap(find.text('RFS').last);
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('touch2-sheet')), findsNothing);
      await tester.tap(find.text('15MIN').last);
      await tester.pumpAndSettle();
      expect(find.text('RFS · 15MIN'), findsOneWidget);
      expect(find.text('SBR Touch 2 · 15MIN'), findsNothing);
    });

    testWidgets('backing out while editing leaves the original setup untouched', (tester) async {
      await pumpForm(tester, trade: existingTrade('SBR Touch 2', '15MIN'));
      final chip = find.text('SBR Touch 2 · 15MIN');
      await tester.ensureVisible(chip);
      await tester.tap(chip);
      await tester.pumpAndSettle();
      await tester.tap(find.text('SBR').last);
      await tester.pumpAndSettle();
      await tester.tapAt(const Offset(10, 10));
      await tester.pumpAndSettle();
      expect(find.text('SBR Touch 2 · 15MIN'), findsOneWidget);
    });
  });
}
