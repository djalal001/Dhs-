import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../models/trade_options.dart';
import '../models/trading_account.dart';
import '../state/app_controller.dart';
import '../state/app_scope.dart';
import '../widgets/common.dart';
import '../widgets/trade_execution_journal.dart';

const _customConfirmation = '__custom_confirmation__';
const _legacyConfirmations = <String>{
  'confirmTechnical',
  'confirmFundamental',
  'confirmPriceAction',
  'confirmIndicator',
  'confirmOther',
};

enum _TradeImageSlot { before, after, confirmation }

class _EntrySetupDraft {
  _EntrySetupDraft({this.reason, this.timeframe});

  String? reason;
  String? timeframe;
}

class _ConfirmationSetupDraft {
  _ConfirmationSetupDraft({
    this.type,
    this.timeframe,
    this.customText = '',
    this.isLegacy = false,
  });

  String? type;
  String? timeframe;
  String customText;
  bool isLegacy;
}

class TradeFormScreen extends StatefulWidget {
  const TradeFormScreen({super.key, this.trade});
  final Trade? trade;
  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _market;
  late final TextEditingController _result;
  late final TextEditingController _expectedLoss;
  late final TextEditingController _risk;
  late final TextEditingController _rewardRisk;
  late final TextEditingController _sequence;
  late final TextEditingController _notes;
  late String _accountId;
  late TradeSide _side;
  late String _mood;
  late final List<_EntrySetupDraft> _entrySetups;
  late final List<_ConfirmationSetupDraft> _confirmationSetups;
  late Set<TradeExecutionJournalEntry> _executionJournal;
  late DateTime _tradedAt;
  String? _beforePath;
  String? _afterPath;
  String? _confirmationImagePath;
  bool _busy = false;
  bool _seededExpectedLoss = false;
  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    final trade = widget.trade;
    _market = TextEditingController(text: trade?.market ?? '');
    _result = TextEditingController(text: trade?.result.toString() ?? '');
    _risk = TextEditingController(text: trade?.riskPercent.toString() ?? '1');
    _expectedLoss = TextEditingController(
      text: trade?.expectedLoss?.toString() ?? '',
    );
    _rewardRisk = TextEditingController();
    _sequence = TextEditingController(text: trade?.sequence ?? '');
    _notes = TextEditingController(text: trade?.notes ?? '');
    _accountId = trade?.accountId ?? '';
    _side = trade?.side ?? TradeSide.buy;
    _mood = trade?.mood.isNotEmpty == true ? trade!.mood : 'moodUnknown';
    final existingSetups = trade?.effectiveEntrySetups ?? const [];
    _entrySetups = existingSetups.isEmpty
        ? [_EntrySetupDraft()]
        : existingSetups
              .map(
                (setup) => _EntrySetupDraft(
                  reason: setup.reason,
                  timeframe: setup.timeframe.isEmpty ? null : setup.timeframe,
                ),
              )
              .toList();
    final existingConfirmationSetups =
        trade?.effectiveConfirmationSetups ?? const [];
    final hasStructuredConfirmations =
        trade?.confirmationSetups.isNotEmpty == true;
    _confirmationSetups = existingConfirmationSetups.isEmpty
        ? [_ConfirmationSetupDraft()]
        : existingConfirmationSetups.map((setup) {
            final isKnownType =
                kTradeConfirmationTypes.contains(setup.type) ||
                _legacyConfirmations.contains(setup.type);
            return _ConfirmationSetupDraft(
              type: isKnownType ? setup.type : _customConfirmation,
              timeframe: setup.timeframe.isEmpty ? null : setup.timeframe,
              customText: isKnownType ? '' : setup.type,
              isLegacy: !hasStructuredConfirmations,
            );
          }).toList();
    _executionJournal = {...?trade?.executionJournal};
    _tradedAt = trade?.tradedAt ?? DateTime.now();
    _beforePath = trade?.beforeImagePath;
    _afterPath = trade?.afterImagePath;
    _confirmationImagePath = trade?.confirmationImagePath;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final app = AppScope.of(context);
    if (_accountId.isEmpty && app.accounts.isNotEmpty) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    if (!_seededExpectedLoss && widget.trade != null) {
      _seededExpectedLoss = true;
      final balance = _accountBalanceBeforeTrade(app);
      final trade = widget.trade!;
      final amount =
          trade.expectedLoss ??
          (balance > 0 ? balance * trade.riskPercent / 100 : 0);
      _expectedLoss.text = amount.toString();
    }
    _updateComputedFields();
  }

  @override
  void dispose() {
    _market.dispose();
    _result.dispose();
    _expectedLoss.dispose();
    _risk.dispose();
    _rewardRisk.dispose();
    _sequence.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickImage(_TradeImageSlot slot) async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery);
      if (picked == null || !mounted) return;
      setState(() => _busy = true);
      final saved = await AppScope.of(context).persistImage(picked.path);
      if (!mounted) return;
      setState(() {
        switch (slot) {
          case _TradeImageSlot.before:
            _beforePath = saved;
          case _TradeImageSlot.after:
            _afterPath = saved;
          case _TradeImageSlot.confirmation:
            _confirmationImagePath = saved;
        }
        _busy = false;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _busy = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  Future<void> _pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _tradedAt,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_tradedAt),
    );
    if (time == null || !mounted) return;
    setState(() {
      _tradedAt = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
      _updateComputedFields();
    });
  }

  double? _parse(TextEditingController controller) =>
      double.tryParse(controller.text.trim().replaceAll(',', '.'));

  double _accountBalanceBeforeTrade(AppController app) {
    TradingAccount? account;
    for (final candidate in app.accounts) {
      if (candidate.id == _accountId) {
        account = candidate;
        break;
      }
    }
    if (account == null) return 0;
    final selectedAccount = account;
    return app.trades
        .where(
          (trade) =>
              trade.accountId == selectedAccount.id &&
              trade.id != widget.trade?.id &&
              trade.tradedAt.isBefore(_tradedAt),
        )
        .fold<double>(selectedAccount.startingBalance, (balance, trade) {
          final next = balance + trade.result;
          return next.isFinite ? next : balance;
        });
  }

  void _updateComputedFields() {
    final app = AppScope.of(context);
    final balance = _accountBalanceBeforeTrade(app);
    final expectedLoss = _parse(_expectedLoss);
    final result = _parse(_result);
    final riskPercent = expectedLoss == null || expectedLoss < 0
        ? null
        : expectedLoss == 0
        ? 0.0
        : balance > 0
        ? expectedLoss / balance * 100
        : null;
    _risk.text = riskPercent != null && riskPercent.isFinite
        ? riskPercent.toStringAsFixed(2)
        : '';
    _rewardRisk.text =
        expectedLoss != null &&
            expectedLoss > 0 &&
            result != null &&
            result.isFinite
        ? ((result / expectedLoss * 100).round() / 100).toStringAsFixed(2)
        : '';
  }

  String? _expectedLossValidator(String? value) {
    final error = _number(value, min: 0);
    if (error != null) return error;
    final expectedLoss = _parse(_expectedLoss) ?? 0;
    final result = _parse(_result) ?? 0;
    if (result != 0 && expectedLoss <= 0) {
      return tr(context, 'expectedLossNeeded');
    }
    return null;
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final app = AppScope.of(context);
    if (app.accounts.isEmpty) return;
    final setups = _entrySetups
        .map(
          (setup) => TradeEntrySetup(
            reason: setup.reason!,
            timeframe: setup.timeframe!,
          ),
        )
        .toList();
    final confirmationSetups = _confirmationSetups
        .map(
          (setup) => TradeConfirmationSetup(
            type: setup.type == _customConfirmation
                ? setup.customText.trim()
                : setup.type!,
            timeframe: setup.timeframe ?? '',
          ),
        )
        .toList();
    final trade = Trade(
      id: widget.trade?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      accountId: _accountId.isEmpty ? app.accounts.first.id : _accountId,
      market: _market.text.trim().toUpperCase(),
      reason: setups.first.reason,
      result: _parse(_result)!,
      riskPercent: _parse(_risk)!,
      expectedLoss: _parse(_expectedLoss)!,
      side: _side,
      confirmation: '',
      confirmationSetups: confirmationSetups,
      executionJournal: _executionJournal.toList(),
      sequence: _sequence.text.trim(),
      mood: _mood,
      tradedAt: _tradedAt,
      entryTimeframe: setups.first.timeframe,
      entrySetups: setups,
      beforeImagePath: _beforePath,
      afterImagePath: _afterPath,
      confirmationImagePath: _confirmationImagePath,
      notes: _notes.text.trim(),
      strategyAdherence: widget.trade?.strategyAdherence,
    );
    Navigator.of(context).pop(trade);
  }

  String? _required(String? value) => value == null || value.trim().isEmpty
      ? tr(context, 'requiredField')
      : null;
  String? _number(String? value, {double? min, double? max}) {
    if (value == null || value.trim().isEmpty)
      return tr(context, 'requiredField');
    final parsed = double.tryParse(value.trim().replaceAll(',', '.'));
    if (parsed == null ||
        !parsed.isFinite ||
        (min != null && parsed < min) ||
        (max != null && parsed > max))
      return tr(context, 'invalidNumber');
    return null;
  }

  List<Widget> _buildEntrySetupFields(
    BuildContext context,
    List<String> choices,
  ) {
    final fields = <Widget>[];
    for (final setup in _entrySetups) {
      fields.add(
        DropdownButtonFormField<String>(
          key: ObjectKey(setup),
          initialValue: setup.reason,
          validator: (value) => value == null || value.isEmpty
              ? tr(context, 'requiredField')
              : null,
          decoration: InputDecoration(
            labelText: tr(context, 'entryReason'),
            prefixIcon: const Icon(Icons.rule_folder_outlined),
            suffixIcon: _entrySetups.length < 2
                ? null
                : IconButton(
                    tooltip: tr(context, 'removeEntrySetup'),
                    onPressed: () => setState(() => _entrySetups.remove(setup)),
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
          ),
          items: [
            for (final value in choices)
              DropdownMenuItem(value: value, child: Text(value)),
          ],
          onChanged: (value) => setState(() {
            if (setup.reason != value) setup.timeframe = null;
            setup.reason = value;
          }),
        ),
      );
      if (setup.reason != null) {
        fields.add(const SizedBox(height: 12));
        fields.add(
          DropdownButtonFormField<String>(
            key: ValueKey('entry-timeframe-${identityHashCode(setup)}'),
            initialValue: setup.timeframe,
            validator: (value) => value == null || value.isEmpty
                ? tr(context, 'requiredField')
                : null,
            decoration: InputDecoration(
              labelText: tr(context, 'entryTimeframe'),
              prefixIcon: const Icon(Icons.schedule_outlined),
            ),
            items: [
              for (final value in kTradeEntryTimeframes)
                DropdownMenuItem(value: value, child: Text(value)),
            ],
            onChanged: (value) => setState(() => setup.timeframe = value),
          ),
        );
      }
      fields.add(const SizedBox(height: 12));
    }
    return fields;
  }

  List<Widget> _buildConfirmationSetupFields(
    BuildContext context,
    List<String> choices,
  ) {
    final fields = <Widget>[];
    for (final setup in _confirmationSetups) {
      fields.add(
        DropdownButtonFormField<String>(
          key: ObjectKey(setup),
          initialValue: setup.type,
          validator: (value) => value == null || value.isEmpty
              ? tr(context, 'requiredField')
              : null,
          decoration: InputDecoration(
            labelText: tr(context, 'confirmation'),
            prefixIcon: const Icon(Icons.verified_outlined),
            suffixIcon: _confirmationSetups.length < 2
                ? null
                : IconButton(
                    tooltip: tr(context, 'removeConfirmationSetup'),
                    onPressed: () =>
                        setState(() => _confirmationSetups.remove(setup)),
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
          ),
          items: [
            for (final value in choices)
              DropdownMenuItem(
                value: value,
                child: Text(
                  value == _customConfirmation
                      ? tr(context, 'customConfirmation')
                      : tr(context, value),
                ),
              ),
          ],
          onChanged: (value) => setState(() {
            if (setup.type != value) {
              setup.timeframe = null;
              setup.customText = '';
              setup.isLegacy = false;
            }
            setup.type = value;
          }),
        ),
      );
      if (setup.type == _customConfirmation) {
        fields.add(const SizedBox(height: 12));
        fields.add(
          TextFormField(
            key: ValueKey(
              'confirmation-custom-input-${identityHashCode(setup)}',
            ),
            initialValue: setup.customText,
            validator: _required,
            textCapitalization: TextCapitalization.sentences,
            decoration: InputDecoration(
              labelText: tr(context, 'enterCustomConfirmation'),
            ),
            onChanged: (value) => setup.customText = value,
          ),
        );
      }
      if (setup.type != null) {
        fields.add(const SizedBox(height: 12));
        fields.add(
          DropdownButtonFormField<String>(
            key: ValueKey('confirmation-timeframe-${identityHashCode(setup)}'),
            initialValue: setup.timeframe,
            validator: (value) =>
                setup.isLegacy || (value != null && value.isNotEmpty)
                ? null
                : tr(context, 'requiredField'),
            decoration: InputDecoration(
              labelText: tr(context, 'confirmationTimeframe'),
              prefixIcon: const Icon(Icons.schedule_outlined),
            ),
            items: [
              for (final value in kTradeConfirmationTimeframes)
                DropdownMenuItem(value: value, child: Text(value)),
            ],
            onChanged: (value) => setState(() {
              setup.timeframe = value;
              setup.isLegacy = false;
            }),
          ),
        );
      }
      fields.add(const SizedBox(height: 12));
    }
    return fields;
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    if (app.accounts.isEmpty)
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: Text(tr(context, 'addFirstAccount'))),
      );
    if (!app.accounts.any((item) => item.id == _accountId))
      _accountId = app.accounts.first.id;
    final currency = app.accounts
        .where((item) => item.id == _accountId)
        .firstOrNull
        ?.currency;
    final confirmationChoices = <String>{
      ...kTradeConfirmationTypes,
      _customConfirmation,
      for (final setup in _confirmationSetups)
        if (setup.type != null &&
            setup.type != _customConfirmation &&
            !kTradeConfirmationTypes.contains(setup.type))
          setup.type!,
    }.toList();
    final entryReasonChoices = <String>{
      ...kTradeEntryReasons,
      for (final setup in _entrySetups)
        if (setup.reason != null && !kTradeEntryReasons.contains(setup.reason))
          setup.reason!,
    }.toList();
    const moods = kTradeMoods;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          tr(context, widget.trade == null ? 'addTrade' : 'editTrade'),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            DropdownButtonFormField<String>(
              initialValue: _accountId,
              decoration: InputDecoration(labelText: tr(context, 'account')),
              items: [
                for (final account in app.accounts)
                  DropdownMenuItem(
                    value: account.id,
                    child: Text(
                      '${account.name} · ${tr(context, account.type == AccountType.demo ? 'demoAccount' : 'realAccount')}',
                    ),
                  ),
              ],
              onChanged: (value) => setState(() {
                _accountId = value ?? _accountId;
                _updateComputedFields();
              }),
            ),
            const SizedBox(height: 12),
            ..._buildEntrySetupFields(context, entryReasonChoices),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: TextButton.icon(
                key: const ValueKey('add-entry-setup'),
                onPressed: () =>
                    setState(() => _entrySetups.add(_EntrySetupDraft())),
                icon: const Icon(Icons.add_circle_outline),
                label: Text(tr(context, 'addEntrySetup')),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              key: const ValueKey('trade-market-input'),
              controller: _market,
              validator: _required,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                labelText: tr(context, 'market'),
                prefixIcon: const Icon(Icons.show_chart),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: TextFormField(
                    key: const ValueKey('trade-result-input'),
                    controller: _result,
                    validator: (value) => _number(value),
                    onChanged: (_) => setState(_updateComputedFields),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                      signed: true,
                    ),
                    decoration: InputDecoration(
                      labelText: tr(context, 'result'),
                      suffixText: currency,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    key: const ValueKey('trade-expected-loss-input'),
                    controller: _expectedLoss,
                    validator: _expectedLossValidator,
                    onChanged: (_) => setState(_updateComputedFields),
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: InputDecoration(
                      labelText: tr(context, 'expectedLoss'),
                      suffixText: currency,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: TextFormField(
                    key: const ValueKey('trade-risk-input'),
                    controller: _risk,
                    readOnly: true,
                    validator: (value) {
                      if (_expectedLoss.text.trim().isEmpty) {
                        return tr(context, 'requiredField');
                      }
                      if (value == null || value.trim().isEmpty) {
                        return tr(context, 'riskBalanceUnavailable');
                      }
                      return _number(value, min: 0);
                    },
                    decoration: InputDecoration(
                      labelText: tr(context, 'riskPercent'),
                      helperText: tr(context, 'riskAutoHint'),
                      suffixText: '%',
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    key: const ValueKey('trade-reward-risk-input'),
                    controller: _rewardRisk,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: tr(context, 'rewardRisk'),
                      helperText: tr(context, 'realizedRiskMultiple'),
                      suffixText: 'R',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<TradeSide>(
              initialValue: _side,
              decoration: InputDecoration(labelText: tr(context, 'direction')),
              items: [
                DropdownMenuItem(
                  value: TradeSide.buy,
                  child: Text(tr(context, 'buy')),
                ),
                DropdownMenuItem(
                  value: TradeSide.sell,
                  child: Text(tr(context, 'sell')),
                ),
              ],
              onChanged: (value) =>
                  setState(() => _side = value ?? TradeSide.buy),
            ),
            const SizedBox(height: 12),
            ..._buildConfirmationSetupFields(context, confirmationChoices),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: TextButton.icon(
                key: const ValueKey('add-confirmation-setup'),
                onPressed: () => setState(
                  () => _confirmationSetups.add(_ConfirmationSetupDraft()),
                ),
                icon: const Icon(Icons.add_circle_outline),
                label: Text(tr(context, 'addConfirmationSetup')),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              tr(context, 'sequence'),
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              tr(context, 'journalSelectionHint'),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 10),
            TradeExecutionJournalSelector(
              selectedEntries: _executionJournal,
              onChanged: (entries) =>
                  setState(() => _executionJournal = entries),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _sequence,
              minLines: 1,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: tr(context, 'journalNote'),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _mood,
              decoration: InputDecoration(labelText: tr(context, 'mood')),
              items: [
                for (final value in moods)
                  DropdownMenuItem(
                    value: value,
                    child: Text(tr(context, value)),
                  ),
              ],
              onChanged: (value) =>
                  setState(() => _mood = value ?? moods.first),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _pickDateTime,
              icon: const Icon(Icons.calendar_month_outlined),
              label: Text(
                '${tr(context, 'dateTime')}: ${shortDate(_tradedAt)} ${TimeOfDay.fromDateTime(_tradedAt).format(context)}',
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ImageAttachmentTile(
                    label: tr(context, 'beforeImage'),
                    path: _beforePath,
                    onTap: () => _pickImage(_TradeImageSlot.before),
                    onRemove: _beforePath == null
                        ? null
                        : () => setState(() => _beforePath = null),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ImageAttachmentTile(
                    label: tr(context, 'afterImage'),
                    path: _afterPath,
                    onTap: () => _pickImage(_TradeImageSlot.after),
                    onRemove: _afterPath == null
                        ? null
                        : () => setState(() => _afterPath = null),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ImageAttachmentTile(
              key: const ValueKey('confirmation-image-attachment'),
              label: tr(context, 'confirmationImage'),
              path: _confirmationImagePath,
              onTap: () => _pickImage(_TradeImageSlot.confirmation),
              onRemove: _confirmationImagePath == null
                  ? null
                  : () => setState(() => _confirmationImagePath = null),
            ),
            const SizedBox(height: 12),
            TextFormField(
              key: const ValueKey('trade-entry-reason-notes-input'),
              controller: _notes,
              minLines: 2,
              maxLines: 4,
              decoration: InputDecoration(
                labelText: tr(context, 'notes'),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: _busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: Text(tr(context, 'save')),
            ),
          ],
        ),
      ),
    );
  }
}
