import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../theme/app_theme.dart';

/// Animated emoji of every journal item. The switch is exhaustive on purpose:
/// adding a status without an asset is a compile error.
String journalAssetOf(TradeExecutionStatus status) => switch (status) {
  TradeExecutionStatus.followedPlan =>
    'assets/emojis/emoji-executed-per-plan.gif',
  TradeExecutionStatus.avoidedEntryBecauseFear =>
    'assets/emojis/emoji-avoided-entry-fear.gif',
  TradeExecutionStatus.enteredEarly => 'assets/emojis/emoji-entered-early.gif',
  TradeExecutionStatus.entryConditionsNotMet =>
    'assets/emojis/emoji-entry-conditions-not-met.gif',
  TradeExecutionStatus.missedHigherTimeframeBounceArea =>
    'assets/emojis/emoji-missed-htf-bounce-zone.gif',
  TradeExecutionStatus.missedLowerTimeframeBounceArea =>
    'assets/emojis/emoji-missed-ltf-bounce-zone.gif',
  TradeExecutionStatus.missedTrendlineFromCandleWicks =>
    'assets/emojis/emoji-missed-wick-trendline.gif',
  TradeExecutionStatus.hesitationPartialSize =>
    'assets/emojis/emoji-hesitation-partial-size.gif',
  TradeExecutionStatus.lateEntry => 'assets/emojis/emoji-late-entry.gif',
  TradeExecutionStatus.stopLossMoved =>
    'assets/emojis/emoji-stop-loss-moved.gif',
  TradeExecutionStatus.noBreakoutPositiveClose =>
    'assets/emojis/emoji-no-breakout-positive-close.gif',
  TradeExecutionStatus.exitedEarlyBecauseFearOfLosingProfit =>
    'assets/emojis/emoji-exited-early-target.gif',
  TradeExecutionStatus.stopLossReducedWithoutReason =>
    'assets/emojis/emoji-stop-loss-reduced-no-reason.webp',
  TradeExecutionStatus.stopLossIncreasedWithoutReason =>
    'assets/emojis/emoji-stop-loss-increased-no-reason.webp',
  TradeExecutionStatus.noTrendlineSupportsEntryZone =>
    'assets/emojis/emoji-no-trendline-supports-zone.webp',
  TradeExecutionStatus.missedHigherTimeframeTrendlineIntegration =>
    'assets/emojis/emoji-missed-htf-trendline-integration.webp',
  TradeExecutionStatus.stopLossIncreasedForLiquiditySafety =>
    'assets/emojis/emoji-stop-loss-increased-liquidity.webp',
  TradeExecutionStatus.stopLossReducedForNegativeClose =>
    'assets/emojis/emoji-stop-loss-reduced-negative-close.webp',
  TradeExecutionStatus.partialSizeAwaitingDeepCorrection =>
    'assets/emojis/emoji-partial-size-deep-correction.webp',
  TradeExecutionStatus.breakevenStopToEntry =>
    'assets/emojis/emoji-breakeven-stop-to-entry.webp',
  TradeExecutionStatus.manualExitNearTarget =>
    'assets/emojis/emoji-manual-exit-near-target.webp',
  TradeExecutionStatus.autoExitAtTarget =>
    'assets/emojis/emoji-auto-exit-at-target.webp',
  TradeExecutionStatus.enteredDespiteFear =>
    'assets/emojis/emoji-entered-despite-fear.webp',
  TradeExecutionStatus.fullPlanCompliance =>
    'assets/emojis/emoji-full-plan-compliance.webp',
  TradeExecutionStatus.fearRepeatLossAfterLoss =>
    'assets/emojis/emoji-fear-repeat-loss-after-loss.webp',
  TradeExecutionStatus.fearGivingBackProfit =>
    'assets/emojis/emoji-fear-giving-back-profit.webp',
  TradeExecutionStatus.fearLossNoHistory =>
    'assets/emojis/emoji-fear-loss-no-history.webp',
  TradeExecutionStatus.hesitationUnclearScenario =>
    'assets/emojis/emoji-hesitation-unclear-scenario.webp',
  TradeExecutionStatus.waitedDeeperRetestDespiteConfirmation =>
    'assets/emojis/emoji-waited-deeper-retest.webp',
};

/// One colour per zone, shared with Trader Labs 4.3.2: walnut for decisions,
/// green for commitment, violet for reasons for not entering. Light mode uses
/// deeper tones so text keeps its contrast.
Color journalZoneColor(JournalZone zone, Brightness brightness) {
  final dark = brightness == Brightness.dark;
  return switch (zone) {
    JournalZone.decisions =>
      dark ? const Color(0xFFB58E72) : const Color(0xFF7A5A43),
    JournalZone.commitment =>
      dark ? const Color(0xFF4FD398) : const Color(0xFF14895C),
    JournalZone.noEntry =>
      dark ? const Color(0xFFC09AF4) : const Color(0xFF7B4FC2),
  };
}

IconData journalZoneIcon(JournalZone zone) => switch (zone) {
  JournalZone.decisions => Icons.fact_check_rounded,
  JournalZone.commitment => Icons.verified_rounded,
  JournalZone.noEntry => Icons.pause_circle_rounded,
};

String _zoneTitle(BuildContext context, JournalZone zone) =>
    tr(context, 'journalZone_${zone.name}');

String _categoryTitle(BuildContext context, JournalCategory category) =>
    tr(context, 'journalCategory_${category.name}');

Duration _motion(BuildContext context, int milliseconds) =>
    MediaQuery.disableAnimationsOf(context)
    ? Duration.zero
    : Duration(milliseconds: milliseconds);

/// Selector for the trade journal: three colour-coded zones (decisions,
/// commitment, reasons for not entering). Tabs stay collapsed to keep the
/// form short; the items that are already chosen stay visible underneath.
class TradeExecutionJournalSelector extends StatefulWidget {
  const TradeExecutionJournalSelector({
    super.key,
    required this.selectedEntries,
    required this.onChanged,
    this.initialZone,
  });

  final Set<TradeExecutionJournalEntry> selectedEntries;
  final ValueChanged<Set<TradeExecutionJournalEntry>> onChanged;

  /// Zone that starts expanded. Null keeps every zone collapsed.
  final JournalZone? initialZone;

  @override
  State<TradeExecutionJournalSelector> createState() =>
      _TradeExecutionJournalSelectorState();
}

class _TradeExecutionJournalSelectorState
    extends State<TradeExecutionJournalSelector> {
  JournalZone? _openZone;

  @override
  void initState() {
    super.initState();
    _openZone = widget.initialZone;
  }

  int _countIn(JournalZone zone) =>
      widget.selectedEntries.where((entry) => entry.status.zone == zone).length;

  void _toggleZone(JournalZone zone) {
    setState(() => _openZone = _openZone == zone ? null : zone);
  }

  void _toggleStatus(TradeExecutionStatus status) {
    final entry = TradeExecutionJournalEntry(status: status);
    final updated = {...widget.selectedEntries};
    if (!updated.remove(entry)) updated.add(entry);
    widget.onChanged(updated);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final open = _openZone;
    // Items of the open zone are already shown as options, so the summary
    // only repeats the zones that are collapsed.
    final collapsedEntries = [
      for (final entry in widget.selectedEntries)
        if (entry.status.zone != open) entry,
    ];

    return DecoratedBox(
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.dividerColor),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(child: _tab(JournalZone.decisions)),
                const SizedBox(width: 8),
                Expanded(child: _tab(JournalZone.commitment)),
              ],
            ),
            const SizedBox(height: 8),
            _tab(JournalZone.noEntry),
            AnimatedSize(
              duration: _motion(context, 220),
              curve: Curves.easeOutCubic,
              alignment: Alignment.topCenter,
              child: open == null
                  ? const SizedBox(width: double.infinity)
                  : _ZonePanel(
                      key: ValueKey('journal-panel-${open.name}'),
                      zone: open,
                      selectedEntries: widget.selectedEntries,
                      onToggle: _toggleStatus,
                    ),
            ),
            if (collapsedEntries.isNotEmpty) ...[
              const SizedBox(height: 12),
              Divider(height: 1, color: theme.dividerColor),
              const SizedBox(height: 12),
              TradeExecutionJournalSummary(
                key: const ValueKey('journal-selection-summary'),
                entries: collapsedEntries,
                showHeading: false,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _tab(JournalZone zone) => _ZoneTab(
    key: ValueKey('journal-zone-${zone.name}'),
    zone: zone,
    count: _countIn(zone),
    open: _openZone == zone,
    onTap: () => _toggleZone(zone),
  );
}

class _ZoneTab extends StatelessWidget {
  const _ZoneTab({
    super.key,
    required this.zone,
    required this.count,
    required this.open,
    required this.onTap,
  });

  final JournalZone zone;
  final int count;
  final bool open;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final theme = Theme.of(context);
    final color = journalZoneColor(zone, theme.brightness);
    final title = _zoneTitle(context, zone);
    return Semantics(
      button: true,
      expanded: open,
      label: title,
      child: AnimatedContainer(
        duration: _motion(context, 160),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: color.withValues(alpha: open ? 0.14 : 0.07),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: open ? 0.55 : 0.2)),
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(10, 10, 8, 10),
              child: Row(
                children: [
                  Icon(journalZoneIcon(zone), size: 20, color: color),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.labelLarge?.copyWith(
                        color: tokens.text1,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  if (count > 0) ...[
                    const SizedBox(width: 6),
                    Container(
                      key: ValueKey('journal-zone-count-${zone.name}'),
                      constraints: const BoxConstraints(minWidth: 22),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Text(
                        '$count',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.labelSmall?.copyWith(
                          color: theme.brightness == Brightness.dark
                              ? const Color(0xFF14110F)
                              : Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                  AnimatedRotation(
                    turns: open ? 0.5 : 0,
                    duration: _motion(context, 180),
                    child: Icon(
                      Icons.expand_more_rounded,
                      size: 22,
                      color: tokens.text3,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ZonePanel extends StatelessWidget {
  const _ZonePanel({
    super.key,
    required this.zone,
    required this.selectedEntries,
    required this.onToggle,
  });

  final JournalZone zone;
  final Set<TradeExecutionJournalEntry> selectedEntries;
  final ValueChanged<TradeExecutionStatus> onToggle;

  bool _isSelected(TradeExecutionStatus status) =>
      selectedEntries.contains(TradeExecutionJournalEntry(status: status));

  @override
  Widget build(BuildContext context) {
    final categories = journalZoneCategories[zone]!;
    final showCategoryTitles = categories.length > 1;
    // Retired items are only listed when the trade already carries them, so
    // they can still be removed but never newly picked.
    final retired = [
      for (final status in journalHistoricalIn(zone))
        if (_isSelected(status)) status,
    ];

    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final category in categories)
            _CategoryBlock(
              zone: zone,
              category: category,
              statuses: journalStatusesOf(category),
              showTitle: showCategoryTitles,
              isSelected: _isSelected,
              onToggle: onToggle,
            ),
          if (retired.isNotEmpty)
            _CategoryBlock(
              zone: zone,
              category: JournalCategory.historical,
              statuses: retired,
              showTitle: true,
              isSelected: _isSelected,
              onToggle: onToggle,
            ),
        ],
      ),
    );
  }
}

class _CategoryBlock extends StatelessWidget {
  const _CategoryBlock({
    required this.zone,
    required this.category,
    required this.statuses,
    required this.showTitle,
    required this.isSelected,
    required this.onToggle,
  });

  final JournalZone zone;
  final JournalCategory category;
  final List<TradeExecutionStatus> statuses;
  final bool showTitle;
  final bool Function(TradeExecutionStatus) isSelected;
  final ValueChanged<TradeExecutionStatus> onToggle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tokens = TdTokens.of(context);
    final color = journalZoneColor(zone, theme.brightness);
    final selectedCount = statuses.where(isSelected).length;
    final note = switch (category) {
      JournalCategory.riskDecisions => 'journalCategoryNote_riskDecisions',
      JournalCategory.historical => 'journalCategoryNote_historical',
      _ => null,
    };

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (showTitle)
            Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(6, 6, 6, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 4,
                        height: 16,
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _categoryTitle(context, category),
                          style: theme.textTheme.labelLarge?.copyWith(
                            color: tokens.text1,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      Text(
                        '$selectedCount/${statuses.length}',
                        style: theme.textTheme.labelSmall?.copyWith(
                          color: selectedCount > 0 ? color : tokens.text3,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  if (note != null) ...[
                    const SizedBox(height: 3),
                    Padding(
                      padding: const EdgeInsetsDirectional.only(start: 12),
                      child: Text(
                        tr(context, note),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: tokens.text3,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          DecoratedBox(
            decoration: BoxDecoration(
              color: theme.colorScheme.surface.withValues(alpha: 0.35),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: theme.dividerColor),
            ),
            child: Column(
              children: [
                for (var index = 0; index < statuses.length; index++) ...[
                  if (index > 0)
                    Divider(
                      height: 1,
                      indent: 12,
                      endIndent: 12,
                      color: theme.dividerColor,
                    ),
                  _JournalOption(
                    status: statuses[index],
                    color: color,
                    selected: isSelected(statuses[index]),
                    onTap: () => onToggle(statuses[index]),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _JournalOption extends StatelessWidget {
  const _JournalOption({
    required this.status,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  final TradeExecutionStatus status;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final label = tr(context, 'journalStatus_${status.name}');
    return Semantics(
      key: ValueKey('journal-option-${status.name}'),
      button: true,
      checked: selected,
      label: label,
      child: AnimatedContainer(
        duration: _motion(context, 140),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: 0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? color.withValues(alpha: 0.32)
                : Colors.transparent,
          ),
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(10, 8, 12, 8),
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: selected ? 0.18 : 0.08),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: color.withValues(alpha: 0.24)),
                    ),
                    alignment: Alignment.center,
                    child: _TradeJournalEmoji(
                      asset: journalAssetOf(status),
                      width: 40,
                      height: 40,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      label,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: tokens.text1,
                        fontWeight: selected ? FontWeight.w600 : null,
                        height: 1.45,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    selected
                        ? Icons.check_circle_rounded
                        : Icons.circle_outlined,
                    size: 22,
                    color: selected ? color : tokens.text3,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Read-only view of the items a trade carries.
///
/// [compact] shows only the animated icons (trade cards). The full form groups
/// the items by zone and sub-group, with the zone colour on every tag.
class TradeExecutionJournalSummary extends StatelessWidget {
  const TradeExecutionJournalSummary({
    super.key,
    required this.entries,
    this.compact = false,
    this.showHeading = true,
    this.iconSize = 30,
  });

  final List<TradeExecutionJournalEntry> entries;
  final bool compact;
  final bool showHeading;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final statuses = <TradeExecutionStatus>{
      for (final entry in entries) entry.status,
    }.toList()..sort((a, b) => journalDisplayIndex(a) - journalDisplayIndex(b));
    if (statuses.isEmpty) return const SizedBox.shrink();

    if (compact) {
      return Wrap(
        key: key,
        alignment: WrapAlignment.start,
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final status in statuses)
            Tooltip(
              message: tr(context, 'journalStatus_${status.name}'),
              child: Semantics(
                label: tr(context, 'journalStatus_${status.name}'),
                child: SizedBox(
                  width: iconSize,
                  height: iconSize,
                  child: _TradeJournalEmoji(
                    asset: journalAssetOf(status),
                    width: iconSize,
                    height: iconSize,
                  ),
                ),
              ),
            ),
        ],
      );
    }

    final theme = Theme.of(context);
    final tokens = TdTokens.of(context);
    final zoneBlocks = <Widget>[];
    for (final zone in JournalZone.values) {
      final inZone = [
        for (final status in statuses)
          if (status.zone == zone) status,
      ];
      if (inZone.isEmpty) continue;
      final color = journalZoneColor(zone, theme.brightness);
      final categories = [
        ...journalZoneCategories[zone]!,
        JournalCategory.historical,
      ];
      final zoneHasSubgroups = journalZoneCategories[zone]!.length > 1;
      zoneBlocks.add(
        Column(
          key: ValueKey('journal-summary-zone-${zone.name}'),
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(journalZoneIcon(zone), size: 18, color: color),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    _zoneTitle(context, zone),
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: color,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Text(
                  '${inZone.length}',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: tokens.text3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            for (final category in categories)
              ..._summaryCategory(
                context,
                category: category,
                color: color,
                statuses: [
                  for (final status in inZone)
                    if (status.category == category) status,
                ],
                showTitle:
                    category == JournalCategory.historical || zoneHasSubgroups,
              ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showHeading) ...[
          Text(
            tr(context, 'sequence'),
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
        ],
        for (var index = 0; index < zoneBlocks.length; index++) ...[
          if (index > 0) const SizedBox(height: 14),
          zoneBlocks[index],
        ],
      ],
    );
  }

  List<Widget> _summaryCategory(
    BuildContext context, {
    required JournalCategory category,
    required Color color,
    required List<TradeExecutionStatus> statuses,
    required bool showTitle,
  }) {
    if (statuses.isEmpty) return const [];
    final tokens = TdTokens.of(context);
    final textTheme = Theme.of(context).textTheme;
    return [
      if (showTitle)
        Padding(
          padding: const EdgeInsetsDirectional.only(
            top: 4,
            bottom: 6,
            start: 2,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _categoryTitle(context, category),
                style: textTheme.labelMedium?.copyWith(
                  color: tokens.text2,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (category == JournalCategory.riskDecisions)
                Text(
                  tr(context, 'journalSummaryNote_riskDecisions'),
                  style: textTheme.bodySmall?.copyWith(
                    color: tokens.text3,
                    height: 1.4,
                  ),
                ),
            ],
          ),
        ),
      for (final status in statuses)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: _SummaryTag(
            key: ValueKey('journal-summary-${status.name}'),
            label: tr(context, 'journalStatus_${status.name}'),
            asset: journalAssetOf(status),
            color: color,
            iconSize: 36,
          ),
        ),
    ];
  }
}

class _SummaryTag extends StatelessWidget {
  const _SummaryTag({
    super.key,
    required this.label,
    required this.asset,
    required this.color,
    required this.iconSize,
  });

  final String label;
  final String asset;
  final Color color;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 14, 8),
      decoration: BoxDecoration(
        color: tokens.surface2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          _TradeJournalEmoji(asset: asset, width: iconSize, height: iconSize),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              softWrap: true,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: tokens.text1,
                fontWeight: FontWeight.w500,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TradeJournalEmoji extends StatelessWidget {
  const _TradeJournalEmoji({
    required this.asset,
    required this.width,
    required this.height,
  });

  final String asset;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      asset,
      width: width,
      height: height,
      gaplessPlayback: true,
      filterQuality: FilterQuality.medium,
      excludeFromSemantics: true,
    );
  }
}
