/// Pick lists of the trade form, mirroring Trader Labs 4.3.2.
///
/// The values are stored on trades as they are written here (reasons and
/// timeframes) or as string keys (confirmation types), so existing values must
/// not be renamed; only append.
library;

/// Entry reasons. `Supply Zone` is new in 4.3.2.
const List<String> kTradeEntryReasons = <String>[
  'SBR',
  'SBR Touch 2',
  'RBS',
  'RBS Touch 2',
  'Trend Line SELL',
  'Trend Line BREAKOUT SELL',
  'Trend Line BUY',
  'Trend Line BREAKOUT BUY',
  'HNS',
  'Supply Zone',
];

/// Entry timeframes. 4.3.2 adds the 1, 2 and 3 minute frames.
const List<String> kTradeEntryTimeframes = <String>[
  '1MIN',
  '2MIN',
  '3MIN',
  '5MIN',
  '15MIN',
  '30MIN',
  '1H',
  '4H',
];

/// Confirmation timeframes (same frames as the entry timeframes).
const List<String> kTradeConfirmationTimeframes = kTradeEntryTimeframes;

/// Confirmation types as string-table keys. `confirmRejectKeyLevel` is new in
/// 4.3.2. The "custom" choice is handled by the form itself.
const List<String> kTradeConfirmationTypes = <String>[
  'confirmBearishEngulfing',
  'confirmBullishEngulfing',
  'confirmHns',
  'confirmBreakoutPullback',
  'confirmEveningStar',
  'confirmRejectKeyLevel',
];

/// Emotional states, as string-table keys.
const List<String> kTradeMoods = <String>[
  'moodUnknown',
  'moodCalm',
  'moodConfident',
  'moodAnxious',
  'moodImpulsive',
  'moodTired',
  'moodUnsureAnalysis',
];
