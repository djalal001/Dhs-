import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_confirmation_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'confirmation-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'confirmation-account';
  });

  tearDown(() async {
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('saves the user-entered custom confirmation text', (
    tester,
  ) async {
    Trade? savedTrade;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(
                        builder: (_) => const TradeFormScreen(),
                      ),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(const ValueKey('trade-market-input')),
      'EURUSD',
    );
    final reasonDropdown = find.byWidgetPredicate(
      (widget) =>
          widget is DropdownButtonFormField<String> &&
          widget.decoration.labelText == 'سبب الدخول',
    );
    await tester.tap(reasonDropdown.first);
    await tester.pumpAndSettle();
    expect(find.text('HNS'), findsOneWidget);
    expect(find.text('Supply Zone'), findsOneWidget);
    await tester.tap(find.text('SBR').last);
    await tester.pumpAndSettle();

    final timeframeDropdown = find.byWidgetPredicate(
      (widget) =>
          widget is DropdownButtonFormField<String> &&
          widget.decoration.labelText == 'الفريم الزمني',
    );
    expect(timeframeDropdown, findsOneWidget);
    await tester.tap(timeframeDropdown.first);
    await tester.pumpAndSettle();
    expect(find.text('1MIN'), findsOneWidget);
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    final addSetupButton = find.byKey(const ValueKey('add-entry-setup'));
    await tester.ensureVisible(addSetupButton);
    await tester.tap(addSetupButton);
    await tester.pumpAndSettle();
    await tester.tap(reasonDropdown.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Trend Line BREAKOUT BUY').last);
    await tester.pumpAndSettle();
    await tester.tap(timeframeDropdown.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();

    await tester.ensureVisible(addSetupButton);
    await tester.tap(addSetupButton);
    await tester.pumpAndSettle();
    await tester.tap(reasonDropdown.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('HNS').last);
    await tester.pumpAndSettle();
    await tester.tap(timeframeDropdown.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();

    final marketField = find.byKey(const ValueKey('trade-market-input'));
    await tester.ensureVisible(marketField);
    await tester.enterText(marketField, 'EURUSD');
    final resultField = find.byKey(const ValueKey('trade-result-input'));
    await tester.ensureVisible(resultField);
    await tester.enterText(resultField, '42.5');
    final riskField = find.byKey(const ValueKey('trade-risk-input'));
    expect(riskField, findsOneWidget);
    await tester.ensureVisible(riskField);
    final expectedLossField = find.byKey(
      const ValueKey('trade-expected-loss-input'),
    );
    await tester.ensureVisible(expectedLossField);
    await tester.enterText(expectedLossField, '100');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(riskField).controller!.text, '1.00');
    final rewardRiskField = find.byKey(
      const ValueKey('trade-reward-risk-input'),
    );
    expect(
      tester.widget<TextFormField>(rewardRiskField).controller!.text,
      '0.43',
    );

    final confirmationDropdown = find.byWidgetPredicate(
      (widget) =>
          widget is DropdownButtonFormField<String> &&
          widget.decoration.labelText == 'نوع التأكيد',
    );
    await tester.ensureVisible(confirmationDropdown.first);
    await tester.tap(confirmationDropdown.first);
    await tester.pumpAndSettle();
    expect(find.text('Bearish engulfing'), findsOneWidget);
    expect(find.text('Bullish Engulfing'), findsOneWidget);
    expect(find.text('HNS'), findsOneWidget);
    expect(find.text('Breakout–Pullback'), findsOneWidget);
    expect(find.text('Evening Star'), findsOneWidget);
    expect(find.text('Reject Key Level'), findsOneWidget);
    await tester.tap(find.text('مخصص — اكتب النوع').last);
    await tester.pumpAndSettle();

    final customInput = find.byWidgetPredicate(
      (widget) =>
          widget is TextFormField &&
          widget.key is ValueKey<String> &&
          (widget.key! as ValueKey<String>).value.startsWith(
            'confirmation-custom-input-',
          ),
    );
    await tester.ensureVisible(customInput);
    await tester.enterText(customInput, 'ارتداد من مستوى يومي');

    final confirmationTimeframe = find.byWidgetPredicate(
      (widget) =>
          widget is DropdownButtonFormField<String> &&
          widget.decoration.labelText == 'فريم التأكيد',
    );
    await tester.ensureVisible(confirmationTimeframe.first);
    await tester.tap(confirmationTimeframe.first);
    await tester.pumpAndSettle();
    expect(find.text('1MIN'), findsOneWidget);
    expect(find.text('2MIN'), findsOneWidget);
    expect(find.text('3MIN'), findsOneWidget);
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();

    final addConfirmationButton = find.byKey(
      const ValueKey('add-confirmation-setup'),
    );
    await tester.ensureVisible(addConfirmationButton);
    await tester.tap(addConfirmationButton);
    await tester.pumpAndSettle();
    await tester.tap(confirmationDropdown.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Bullish Engulfing').last);
    await tester.pumpAndSettle();
    await tester.tap(confirmationTimeframe.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('3MIN').last);
    await tester.pumpAndSettle();

    await tester.ensureVisible(addConfirmationButton);
    await tester.tap(addConfirmationButton);
    await tester.pumpAndSettle();
    await tester.tap(confirmationDropdown.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Evening Star').last);
    await tester.pumpAndSettle();
    await tester.tap(confirmationTimeframe.last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('1MIN').last);
    await tester.pumpAndSettle();

    final moodDropdown = find.byWidgetPredicate(
      (widget) =>
          widget is DropdownButtonFormField<String> &&
          widget.decoration.labelText == 'الحالة النفسية',
    );
    await tester.scrollUntilVisible(
      moodDropdown,
      250,
      scrollable: find.byType(Scrollable).last,
    );
    await tester.ensureVisible(moodDropdown);
    await tester.pumpAndSettle();
    await tester.tap(moodDropdown);
    await tester.pumpAndSettle();
    await tester.tap(find.text('غير واثق من التحليل').last);
    await tester.pumpAndSettle();

    await tester.pump();

    final decisionsTab = find.byKey(const ValueKey('journal-zone-decisions'));
    await tester.scrollUntilVisible(
      decisionsTab,
      -250,
      scrollable: find.byType(Scrollable).last,
    );
    await tester.ensureVisible(decisionsTab);
    await tester.tap(decisionsTab);
    await tester.pumpAndSettle();
    final earlyExitChoice = find.byKey(
      const ValueKey('journal-option-exitedEarlyBecauseFearOfLosingProfit'),
    );
    await tester.ensureVisible(earlyExitChoice);
    await tester.tap(earlyExitChoice);
    await tester.pumpAndSettle();
    expect(
      find.text('لم أحترم الهدف، خرجت مبكرًا بسبب خوف ضياع الأرباح.'),
      findsOneWidget,
    );

    final commitmentTab = find.byKey(const ValueKey('journal-zone-commitment'));
    await tester.ensureVisible(commitmentTab);
    await tester.tap(commitmentTab);
    await tester.pumpAndSettle();
    final commitmentChoice = find.byKey(
      const ValueKey('journal-option-breakevenStopToEntry'),
    );
    await tester.ensureVisible(commitmentChoice);
    await tester.tap(commitmentChoice);
    await tester.pumpAndSettle();

    final noEntryTab = find.byKey(const ValueKey('journal-zone-noEntry'));
    await tester.ensureVisible(noEntryTab);
    await tester.tap(noEntryTab);
    await tester.pumpAndSettle();
    final noEntryChoice = find.byKey(
      const ValueKey('journal-option-fearGivingBackProfit'),
    );
    await tester.ensureVisible(noEntryChoice);
    await tester.tap(noEntryChoice);
    await tester.pumpAndSettle();

    tester.binding.focusManager.primaryFocus?.unfocus();
    await tester.pumpAndSettle();
    await tester.drag(find.byType(ListView).last, const Offset(0, -500));
    await tester.pumpAndSettle();
    final confirmationImage = find.byKey(
      const ValueKey('confirmation-image-attachment'),
    );
    await tester.scrollUntilVisible(
      confirmationImage,
      250,
      scrollable: find.byType(Scrollable).last,
    );
    expect(confirmationImage, findsOneWidget);

    final notesField = find.byKey(
      const ValueKey('trade-entry-reason-notes-input'),
    );
    await tester.scrollUntilVisible(
      notesField,
      250,
      scrollable: find.byType(Scrollable).last,
    );
    await tester.ensureVisible(notesField);
    await tester.enterText(notesField, 'ملاحظة حرة للاختبار');
    expect(
      find.byKey(const ValueKey('entry-reason-note-entryReasonNote1')),
      findsNothing,
    );
    final savedNotes = tester
        .widget<TextFormField>(notesField)
        .controller!
        .text;
    expect(savedNotes, 'ملاحظة حرة للاختبار');

    final saveButton = find.widgetWithText(FilledButton, 'حفظ');
    await tester.ensureVisible(saveButton);
    await tester.pumpAndSettle();
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.entrySetups, [
      const TradeEntrySetup(reason: 'SBR', timeframe: '15MIN'),
      const TradeEntrySetup(
        reason: 'Trend Line BREAKOUT BUY',
        timeframe: '30MIN',
      ),
      const TradeEntrySetup(reason: 'HNS', timeframe: '1H'),
    ]);
    expect(
      savedTrade!.entrySetupSummary,
      'SBR · 15MIN، Trend Line BREAKOUT BUY · 30MIN، HNS · 1H',
    );
    expect(savedTrade!.confirmation, isEmpty);
    expect(savedTrade!.confirmationSetups, const [
      TradeConfirmationSetup(type: 'ارتداد من مستوى يومي', timeframe: '2MIN'),
      TradeConfirmationSetup(
        type: 'confirmBullishEngulfing',
        timeframe: '3MIN',
      ),
      TradeConfirmationSetup(type: 'confirmEveningStar', timeframe: '1MIN'),
    ]);
    expect(savedTrade!.mood, 'moodUnsureAnalysis');
    expect(savedTrade!.expectedLoss, 100);
    expect(savedTrade!.riskPercent, 1);
    expect(savedTrade!.notes, savedNotes);
    expect(savedTrade!.executionJournal.toSet(), {
      TradeExecutionJournalEntry(
        status: TradeExecutionStatus.exitedEarlyBecauseFearOfLosingProfit,
      ),
      TradeExecutionJournalEntry(
        status: TradeExecutionStatus.breakevenStopToEntry,
      ),
      TradeExecutionJournalEntry(
        status: TradeExecutionStatus.fearGivingBackProfit,
      ),
    });
  });
}
