import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/l10n/app_strings.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trade_options.dart';
import 'package:trader_desk/widgets/trade_execution_journal.dart';

void main() {
  group('trade form pick lists (Trader Labs 4.3.2)', () {
    test('entry reasons include Supply Zone', () {
      expect(kTradeEntryReasons, [
        'SBR',
        'SBR Touch 2',
        'RBS',
        'RBS Touch 2',
        'Trend Line SELL',
        'Trend Line BREAKOUT SELL',
        'Trend Line BUY',
        'Trend Line BREAKOUT BUY',
        'HNS',
        'Supply Zone',
      ]);
    });

    test('entry and confirmation timeframes include 1, 2 and 3 minutes', () {
      const frames = [
        '1MIN',
        '2MIN',
        '3MIN',
        '5MIN',
        '15MIN',
        '30MIN',
        '1H',
        '4H',
      ];
      expect(kTradeEntryTimeframes, frames);
      expect(kTradeConfirmationTimeframes, frames);
    });

    test('confirmation types include Reject Key Level', () {
      expect(kTradeConfirmationTypes, [
        'confirmBearishEngulfing',
        'confirmBullishEngulfing',
        'confirmHns',
        'confirmBreakoutPullback',
        'confirmEveningStar',
        'confirmRejectKeyLevel',
      ]);
    });

    test('moods are unchanged', () {
      expect(kTradeMoods, [
        'moodUnknown',
        'moodCalm',
        'moodConfident',
        'moodAnxious',
        'moodImpulsive',
        'moodTired',
        'moodUnsureAnalysis',
      ]);
    });
  });

  group('journal catalog', () {
    test('storage names of the original twelve items never change', () {
      expect(TradeExecutionStatus.values.take(12).map((s) => s.name), [
        'followedPlan',
        'avoidedEntryBecauseFear',
        'enteredEarly',
        'entryConditionsNotMet',
        'missedHigherTimeframeBounceArea',
        'missedLowerTimeframeBounceArea',
        'missedTrendlineFromCandleWicks',
        'hesitationPartialSize',
        'lateEntry',
        'stopLossMoved',
        'noBreakoutPositiveClose',
        'exitedEarlyBecauseFearOfLosingProfit',
      ]);
    });

    test('sub-groups hold the 4.3.2 items in order', () {
      expect(
        journalStatusesOf(
          JournalCategory.executionViolations,
        ).map((s) => s.name),
        [
          'enteredEarly',
          'hesitationPartialSize',
          'lateEntry',
          'stopLossReducedWithoutReason',
          'stopLossIncreasedWithoutReason',
          'exitedEarlyBecauseFearOfLosingProfit',
        ],
      );
      expect(
        journalStatusesOf(JournalCategory.analysisQuality).map((s) => s.name),
        [
          'missedHigherTimeframeBounceArea',
          'missedLowerTimeframeBounceArea',
          'missedTrendlineFromCandleWicks',
          'noBreakoutPositiveClose',
          'noTrendlineSupportsEntryZone',
          'missedHigherTimeframeTrendlineIntegration',
        ],
      );
      expect(
        journalStatusesOf(JournalCategory.riskDecisions).map((s) => s.name),
        [
          'stopLossIncreasedForLiquiditySafety',
          'stopLossReducedForNegativeClose',
          'partialSizeAwaitingDeepCorrection',
        ],
      );
      expect(journalStatusesOf(JournalCategory.commitment).map((s) => s.name), [
        'breakevenStopToEntry',
        'manualExitNearTarget',
        'autoExitAtTarget',
        'enteredDespiteFear',
        'fullPlanCompliance',
      ]);
      expect(journalStatusesOf(JournalCategory.noEntry).map((s) => s.name), [
        'fearRepeatLossAfterLoss',
        'fearGivingBackProfit',
        'fearLossNoHistory',
        'hesitationUnclearScenario',
        'waitedDeeperRetestDespiteConfirmation',
      ]);
      expect(journalStatusesOf(JournalCategory.historical), isEmpty);
    });

    test('each selectable item belongs to exactly one zone list', () {
      final listed = [
        for (final zone in JournalZone.values) ...journalSelectableIn(zone),
      ];
      expect(listed, hasLength(25));
      expect(listed.toSet(), hasLength(25));
      expect(
        listed.toSet(),
        TradeExecutionStatus.values.where((s) => s.isSelectable).toSet(),
      );
      for (final zone in JournalZone.values) {
        for (final status in journalSelectableIn(zone)) {
          expect(status.zone, zone, reason: status.name);
        }
      }
    });

    test('only the four retired items are historical', () {
      expect(
        TradeExecutionStatus.values
            .where((s) => s.category == JournalCategory.historical)
            .map((s) => s.name)
            .toSet(),
        {
          'followedPlan',
          'avoidedEntryBecauseFear',
          'entryConditionsNotMet',
          'stopLossMoved',
        },
      );
      expect(journalHistoricalIn(JournalZone.decisions), [
        TradeExecutionStatus.entryConditionsNotMet,
        TradeExecutionStatus.stopLossMoved,
      ]);
    });

    test('display order follows the selector, retired items last', () {
      final ordered = [...TradeExecutionStatus.values]
        ..sort((a, b) => journalDisplayIndex(a) - journalDisplayIndex(b));
      expect(ordered.first, TradeExecutionStatus.enteredEarly);
      expect(
        ordered.skip(25).toSet(),
        TradeExecutionStatus.values.where((s) => !s.isSelectable).toSet(),
      );
    });

    test('every item survives a JSON round trip', () {
      for (final status in TradeExecutionStatus.values) {
        final entry = TradeExecutionJournalEntry(status: status);
        expect(
          TradeExecutionJournalEntry.tryFromJson(entry.toJson()),
          entry,
          reason: status.name,
        );
      }
    });

    test('old names and unknown names are handled', () {
      expect(
        TradeExecutionJournalEntry.tryFromJson('enteredEarlyOrOutsidePlan'),
        const TradeExecutionJournalEntry(
          status: TradeExecutionStatus.enteredEarly,
        ),
      );
      expect(TradeExecutionJournalEntry.tryFromJson('doesNotExist'), isNull);
    });

    test('behavior flags follow the 4.3.2 meaning of each zone', () {
      expect(
        TradeExecutionStatus.fullPlanCompliance.signalsPlanFollowed,
        isTrue,
      );
      expect(TradeExecutionStatus.followedPlan.signalsPlanFollowed, isTrue);
      expect(TradeExecutionStatus.lateEntry.countsAsDeviation, isTrue);
      expect(
        TradeExecutionStatus
            .stopLossIncreasedForLiquiditySafety
            .countsAsDeviation,
        isFalse,
      );
      expect(
        TradeExecutionStatus.fearGivingBackProfit.describesSkippedEntry,
        isTrue,
      );
      expect(TradeExecutionStatus.lateEntry.describesSkippedEntry, isFalse);
    });
  });

  group('strings and assets', () {
    Future<void> pumpWith(
      WidgetTester tester,
      Locale locale,
      void Function(BuildContext context) check,
    ) async {
      await tester.pumpWidget(
        MaterialApp(
          locale: locale,
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) {
              check(context);
              return const SizedBox();
            },
          ),
        ),
      );
    }

    for (final locale in const [Locale('ar'), Locale('en')]) {
      testWidgets('every journal key has text in ${locale.languageCode}', (
        tester,
      ) async {
        await pumpWith(tester, locale, (context) {
          for (final status in TradeExecutionStatus.values) {
            final label = tr(context, 'journalStatus_${status.name}');
            expect(label, isNot('journalStatus_${status.name}'));
            expect(label.trim(), isNotEmpty);
            if (status.countsAsDeviation) {
              expect(
                tr(context, 'behaviorTip_${status.name}'),
                isNot('behaviorTip_${status.name}'),
                reason: status.name,
              );
            }
          }
          for (final zone in JournalZone.values) {
            expect(
              tr(context, 'journalZone_${zone.name}'),
              isNot(startsWith('journalZone_')),
            );
          }
          for (final category in JournalCategory.values) {
            expect(
              tr(context, 'journalCategory_${category.name}'),
              isNot(startsWith('journalCategory_')),
            );
          }
          for (final key in const [
            'journalCategoryNote_riskDecisions',
            'journalCategoryNote_historical',
            'journalSummaryNote_riskDecisions',
            'confirmRejectKeyLevel',
          ]) {
            expect(tr(context, key), isNot(key));
          }
          // The old pre-written "why I did not enter" notes are gone.
          expect(tr(context, 'entryReasonNote1'), 'entryReasonNote1');
        });
      });
    }

    test('every item has a registered animated asset that exists', () {
      final pubspec = File('pubspec.yaml').readAsStringSync();
      for (final status in TradeExecutionStatus.values) {
        final asset = journalAssetOf(status);
        expect(File(asset).existsSync(), isTrue, reason: asset);
        expect(pubspec, contains('- $asset'), reason: asset);
      }
    });
  });
}
