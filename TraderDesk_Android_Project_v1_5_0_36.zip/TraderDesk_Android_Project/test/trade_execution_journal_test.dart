import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/trade_execution_journal.dart';

TradeExecutionJournalEntry _entry(TradeExecutionStatus status) =>
    TradeExecutionJournalEntry(status: status);

Finder _option(TradeExecutionStatus status) =>
    find.byKey(ValueKey('journal-option-${status.name}'));

Finder _zoneTab(JournalZone zone) =>
    find.byKey(ValueKey('journal-zone-${zone.name}'));

Finder _assetImage(String assetName) => find.byWidgetPredicate(
  (widget) =>
      widget is Image &&
      widget.image is AssetImage &&
      (widget.image as AssetImage).assetName == assetName,
);

Future<void> _pumpApp(
  WidgetTester tester,
  Widget body, {
  Locale locale = const Locale('ar'),
}) => tester.pumpWidget(
  MaterialApp(
    theme: buildAppTheme(Brightness.dark),
    locale: locale,
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: Scaffold(body: SingleChildScrollView(child: body)),
  ),
);

Future<void> _openZone(WidgetTester tester, JournalZone zone) async {
  final tab = _zoneTab(zone);
  await tester.ensureVisible(tab);
  await tester.tap(tab);
  await tester.pumpAndSettle();
}

Future<void> _toggle(WidgetTester tester, TradeExecutionStatus status) async {
  final option = _option(status);
  await tester.ensureVisible(option);
  await tester.tap(option);
  await tester.pumpAndSettle();
}

void main() {
  late Set<TradeExecutionJournalEntry> selected;

  Future<void> pumpSelector(
    WidgetTester tester, {
    Set<TradeExecutionJournalEntry> initial = const {},
    Locale locale = const Locale('ar'),
  }) {
    selected = {...initial};
    return _pumpApp(
      tester,
      StatefulBuilder(
        builder: (context, setState) => TradeExecutionJournalSelector(
          selectedEntries: selected,
          onChanged: (entries) => setState(() => selected = entries),
        ),
      ),
      locale: locale,
    );
  }

  testWidgets('zones start collapsed and open one at a time', (tester) async {
    await pumpSelector(tester);

    for (final zone in JournalZone.values) {
      expect(_zoneTab(zone), findsOneWidget);
    }
    expect(_option(TradeExecutionStatus.enteredEarly), findsNothing);

    await _openZone(tester, JournalZone.decisions);
    expect(_option(TradeExecutionStatus.enteredEarly), findsOneWidget);
    expect(_option(TradeExecutionStatus.fullPlanCompliance), findsNothing);

    await _openZone(tester, JournalZone.commitment);
    expect(_option(TradeExecutionStatus.enteredEarly), findsNothing);
    expect(_option(TradeExecutionStatus.fullPlanCompliance), findsOneWidget);

    await _openZone(tester, JournalZone.commitment);
    expect(_option(TradeExecutionStatus.fullPlanCompliance), findsNothing);
  });

  testWidgets('every selectable item can be chosen from its own zone', (
    tester,
  ) async {
    await pumpSelector(tester);

    for (final zone in JournalZone.values) {
      await _openZone(tester, zone);
      for (final status in journalSelectableIn(zone)) {
        await _toggle(tester, status);
      }
    }

    final expected = {
      for (final zone in JournalZone.values)
        for (final status in journalSelectableIn(zone)) _entry(status),
    };
    expect(selected, hasLength(25));
    expect(selected, expected);
    for (final status in TradeExecutionStatus.values.where(
      (status) => !status.isSelectable,
    )) {
      expect(selected, isNot(contains(_entry(status))));
    }
  });

  testWidgets('tapping a chosen item removes it again', (tester) async {
    await pumpSelector(tester);
    await _openZone(tester, JournalZone.decisions);

    await _toggle(tester, TradeExecutionStatus.enteredEarly);
    expect(selected, {_entry(TradeExecutionStatus.enteredEarly)});
    await _toggle(tester, TradeExecutionStatus.enteredEarly);
    expect(selected, isEmpty);
  });

  testWidgets('zone tabs show how many items are chosen', (tester) async {
    await pumpSelector(
      tester,
      initial: {
        _entry(TradeExecutionStatus.enteredEarly),
        _entry(TradeExecutionStatus.lateEntry),
        _entry(TradeExecutionStatus.fullPlanCompliance),
      },
    );

    expect(
      find.descendant(
        of: find.byKey(const ValueKey('journal-zone-count-decisions')),
        matching: find.text('2'),
      ),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('journal-zone-count-commitment')),
        matching: find.text('1'),
      ),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('journal-zone-count-noEntry')),
      findsNothing,
    );
  });

  testWidgets('chosen items of collapsed zones stay visible underneath', (
    tester,
  ) async {
    await pumpSelector(
      tester,
      initial: {_entry(TradeExecutionStatus.fullPlanCompliance)},
    );
    final summaryTag = find.byKey(
      const ValueKey('journal-summary-fullPlanCompliance'),
    );

    expect(summaryTag, findsOneWidget);
    expect(_option(TradeExecutionStatus.fullPlanCompliance), findsNothing);

    await _openZone(tester, JournalZone.commitment);
    expect(summaryTag, findsNothing);
    expect(_option(TradeExecutionStatus.fullPlanCompliance), findsOneWidget);
  });

  testWidgets('decisions zone shows the 4.3.2 sub-groups and wording', (
    tester,
  ) async {
    await pumpSelector(tester);
    await _openZone(tester, JournalZone.decisions);

    for (final text in const [
      'مخالفات التنفيذ',
      'جودة التحليل والإعداد',
      'قرارات الدخول وإدارة المخاطرة',
      'قرارات تحتاج إلى تقييم بحسب خطة التداول؛ اختيارها لا يعني أنها مخالفة أو خطأ.',
      'دخلت مبكرًا.',
      'دخلت متأخرًا.',
      'الكسر والإغلاق الإيجابي منخفض القوة.',
      'لا يوجد ترند لاين يدعم منطقة الدخول.',
      'لم أفتح الصفقة بالحجم الكامل في انتظار تصحيح عميق لمنطقة الدخول.',
    ]) {
      expect(find.text(text), findsOneWidget, reason: text);
    }
    expect(find.text('عناصر تاريخية'), findsNothing);
  });

  testWidgets('retired items are only listed when already chosen', (
    tester,
  ) async {
    await pumpSelector(tester);
    await _openZone(tester, JournalZone.decisions);
    expect(_option(TradeExecutionStatus.stopLossMoved), findsNothing);
    expect(_option(TradeExecutionStatus.entryConditionsNotMet), findsNothing);
    await _openZone(tester, JournalZone.commitment);
    expect(_option(TradeExecutionStatus.followedPlan), findsNothing);
    await _openZone(tester, JournalZone.noEntry);
    expect(_option(TradeExecutionStatus.avoidedEntryBecauseFear), findsNothing);

    await pumpSelector(
      tester,
      initial: {
        _entry(TradeExecutionStatus.stopLossMoved),
        _entry(TradeExecutionStatus.followedPlan),
      },
    );
    await _openZone(tester, JournalZone.decisions);
    expect(_option(TradeExecutionStatus.stopLossMoved), findsOneWidget);
    expect(find.text('عناصر تاريخية'), findsOneWidget);

    await _toggle(tester, TradeExecutionStatus.stopLossMoved);
    expect(selected, {_entry(TradeExecutionStatus.followedPlan)});

    await _openZone(tester, JournalZone.commitment);
    expect(_option(TradeExecutionStatus.followedPlan), findsOneWidget);
    await _toggle(tester, TradeExecutionStatus.followedPlan);
    expect(selected, isEmpty);
  });

  testWidgets('new items use the animated WebP rendered from the 4.3.2 SVG', (
    tester,
  ) async {
    await pumpSelector(tester);
    await _openZone(tester, JournalZone.commitment);

    expect(
      _assetImage('assets/emojis/emoji-full-plan-compliance.webp'),
      findsOneWidget,
    );
    expect(
      _assetImage('assets/emojis/emoji-breakeven-stop-to-entry.webp'),
      findsOneWidget,
    );
  });

  testWidgets('summary groups the items by zone and sub-group', (tester) async {
    await _pumpApp(
      tester,
      TradeExecutionJournalSummary(
        entries: [
          _entry(TradeExecutionStatus.fullPlanCompliance),
          _entry(TradeExecutionStatus.fearLossNoHistory),
          _entry(TradeExecutionStatus.stopLossReducedForNegativeClose),
          _entry(TradeExecutionStatus.enteredEarly),
          _entry(TradeExecutionStatus.stopLossMoved),
        ],
      ),
    );

    for (final zone in JournalZone.values) {
      expect(
        find.byKey(ValueKey('journal-summary-zone-${zone.name}')),
        findsOneWidget,
      );
    }
    expect(find.text('التصرفات'), findsOneWidget);
    expect(find.text('مخالفات التنفيذ'), findsOneWidget);
    expect(find.text('قرارات الدخول وإدارة المخاطرة'), findsOneWidget);
    expect(
      find.text('للتقييم بحسب الخطة وليست مخالفة تلقائياً.'),
      findsOneWidget,
    );
    expect(find.text('عناصر تاريخية'), findsOneWidget);
    // Commitment and no-entry zones have one sub-group, so no extra title.
    expect(find.text('عناصر الالتزام'), findsNothing);
    expect(find.text('التزمت بالخطة كاملة دون مخالفة.'), findsOneWidget);
    expect(
      find.text('الخوف من الخسارة دون وجود ربح أو خسارة سابقة.'),
      findsOneWidget,
    );
  });

  testWidgets('compact summary shows one animated icon per item in order', (
    tester,
  ) async {
    await _pumpApp(
      tester,
      TradeExecutionJournalSummary(
        compact: true,
        entries: [
          _entry(TradeExecutionStatus.fearGivingBackProfit),
          _entry(TradeExecutionStatus.enteredEarly),
          _entry(TradeExecutionStatus.fullPlanCompliance),
        ],
      ),
    );

    final images = tester
        .widgetList<Image>(find.byType(Image))
        .map((image) => (image.image as AssetImage).assetName)
        .toList();
    expect(images, [
      'assets/emojis/emoji-entered-early.gif',
      'assets/emojis/emoji-full-plan-compliance.webp',
      'assets/emojis/emoji-fear-giving-back-profit.webp',
    ]);
  });

  testWidgets('labels are available in English', (tester) async {
    await pumpSelector(tester, locale: const Locale('en'));

    expect(find.text('Decisions'), findsOneWidget);
    expect(find.text('Commitment'), findsOneWidget);
    await _openZone(tester, JournalZone.noEntry);
    expect(
      find.text('Fear of repeating a loss after a previous loss.'),
      findsOneWidget,
    );
  });
}
