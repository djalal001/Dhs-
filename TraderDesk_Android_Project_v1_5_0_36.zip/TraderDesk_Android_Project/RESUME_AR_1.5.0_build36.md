# متابعة الإصدار 1.5.0+36

مصدر القوائم: الصفحة التفاعلية `TraderLabs_v4_3_2_RejectKeyLevel.html`. إن صدرت نسخة أحدث منها فقارنها بهذه الملفات:

- `lib/models/trade_options.dart`: أسباب الدخول والفريمات وأنواع التأكيد والحالات النفسية. للإضافة فقط، فالقيم تُحفظ كما هي في الصفقات.
- `lib/models/trade.dart`: `TradeExecutionStatus` بكل عناصره، ولكل عنصر منطقة (`JournalZone`) ومجموعة (`JournalCategory`). الأسماء الاثنا عشر الأولى هي مفاتيح التخزين القديمة ولا تُغيَّر. ترتيب العرض داخل كل مجموعة في `_selectableByCategory`.
- `lib/widgets/trade_execution_journal.dart`: واجهة المناطق الثلاث والملخص المجمّع، ودالة `journalAssetOf` الشاملة؛ إضافة عنصر دون رمز تُسبب خطأ ترجمة.
- `lib/l10n/app_strings.dart`: النصوص `journalStatus_*` و`journalZone_*` و`journalCategory_*` و`behaviorTip_*` بالعربية والإنجليزية. النصوص الإنجليزية ترجمة جديدة لأن الصفحة عربية فقط.
- `lib/domain/behavior_lab_report.dart`: يعتمد على أعلام العنصر (`signalsPlanFollowed` و`countsAsDeviation` و`describesSkippedEntry`) لا على أسماء بعينها.

## إضافة عنصر جديد للدفتر

1. أضفه إلى `TradeExecutionStatus` مع منطقته ومجموعته، وإلى `_selectableByCategory`.
2. أضف حالته في `journalAssetOf` وسجّل الملف في `pubspec.yaml`.
3. أضف `journalStatus_<name>` بالعربية والإنجليزية، و`behaviorTip_<name>` إن كان يُحسب انحرافاً.
4. شغّل `flutter test`؛ اختبار `trade_lists_catalog_test.dart` يتحقق من كل ذلك.

## الرموز المتحركة

رموز العناصر الجديدة WebP متحرك (144×144، حلقة 3.6 ثانية) ناتجة عن عرض ملفات SVG المرجعية الموجودة بجانبها في `assets/emojis` إطاراً بإطار بالمتصفح. إن تغيّر رسم في الصفحة فأعد توليد الملف المقابل بالطريقة نفسها.

## نقطتان للانتباه

- نص `Reject Key Level` كُتب عادياً بدل الأحرف المرتفعة الصغيرة المستخدمة في الصفحة (`Reject ᴷᵉʸ ᴸᵉᵛᵉˡ`)، لأن بعض خطوط Android لا تحتوي تلك الأحرف وقد تظهر مربعات. يُغيَّر من `confirmRejectKeyLevel` في ملف النصوص إن رغبت.
- عناصر `entryConditionsNotMet` و`missedHigherTimeframeBounceArea` و`missedLowerTimeframeBounceArea` و`missedTrendlineFromCandleWicks` و`noBreakoutPositiveClose` ما زالت تُعد «دخولاً لم يحدث» في مختبر السلوك، فتُستثنى من نتائج الفوز والخسارة كما في الإصدارات السابقة، حفاظاً على تقارير بياناتك القديمة.
