import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const primary = 'Inter';
  const fallback = ['NotoSansArabicUI', 'NotoSans'];

  test('light and dark application themes use Inter + Noto Arabic UI globally',
      () {
    for (final brightness in [Brightness.light, Brightness.dark]) {
      final theme = buildAppTheme(brightness);
      expect(theme.fontFamily, primary);
      expect(theme.fontFamilyFallback, fallback);

      for (final style in [
        theme.textTheme.displayLarge,
        theme.textTheme.headlineSmall,
        theme.textTheme.titleLarge,
        theme.textTheme.titleMedium,
        theme.textTheme.bodyLarge,
        theme.textTheme.bodyMedium,
        theme.textTheme.bodySmall,
        theme.textTheme.labelLarge,
        theme.textTheme.labelMedium,
        theme.textTheme.labelSmall,
      ]) {
        expect(style?.fontFamily, primary);
        expect(style?.fontFamilyFallback, fallback);
      }
    }
  });

  test('all bundled font files are available locally', () async {
    const minimumBytes = {
      'assets/fonts/Inter-Regular.otf': 50000,
      'assets/fonts/Inter-Medium.otf': 50000,
      'assets/fonts/Inter-SemiBold.otf': 50000,
      'assets/fonts/Inter-Bold.otf': 50000,
      'assets/fonts/NotoSansArabicUI-Regular.ttf': 100000,
      'assets/fonts/NotoSansArabicUI-Bold.ttf': 100000,
      'assets/fonts/NotoSans-Regular.ttf': 100000,
      'assets/fonts/NotoSans-Medium.ttf': 100000,
      'assets/fonts/NotoSans-SemiBold.ttf': 100000,
      'assets/fonts/NotoSans-Bold.ttf': 100000,
    };

    for (final entry in minimumBytes.entries) {
      final data = await rootBundle.load(entry.key);
      expect(data.lengthInBytes, greaterThan(entry.value), reason: entry.key);
    }

    for (final license in [
      'assets/fonts/NOTO_FONTS_OFL_LICENSE.txt',
      'assets/fonts/INTER_OFL_LICENSE.txt',
    ]) {
      final text = await rootBundle.loadString(license);
      expect(text, contains('SIL Open Font License'), reason: license);
    }
  });

  test('letterSpacing is confined to the theme so Arabic letters stay joined',
      () {
    final offenders = <String>[];
    for (final entity in Directory('lib').listSync(recursive: true)) {
      if (entity is! File || !entity.path.endsWith('.dart')) continue;
      final path = entity.path.replaceAll(r'\', '/');
      if (path.endsWith('lib/theme/app_theme.dart')) continue;
      if (entity.readAsStringSync().contains('letterSpacing')) {
        offenders.add(path);
      }
    }
    expect(offenders, isEmpty);
  });
}
