import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/main.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/theme/trade_outcome_palette.dart';
import 'package:trader_desk/theme/trade_detail_palette.dart';
import 'package:trader_desk/widgets/common.dart';

void main() {
  late Directory temp;
  late AppController app;
  late TradingAccount account;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp(
      'trader_desk_trades_filter_',
    );
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    account = TradingAccount(
      id: 'trades-filter-account',
      name: 'Filter account',
      type: AccountType.demo,
      startingBalance: 10000,
      currency: 'USD',
      createdAt: DateTime(2024, 1, 1),
    );
    app.accounts = [account];
    app.selectedAccountId = account.id;
    app.trades = [
      _trade(id: 'winner', result: 25),
      _trade(id: 'loser', result: -12),
      // A missed opportunity with an entirely empty result-and-risk record.
      _trade(
        id: 'missed-empty',
        result: 0,
        classification: TradeClassification.missed,
        riskPercent: 0,
        expectedLoss: 0,
      ),
      // A break-even trade can have risk metadata. The filters must follow
      // the saved classification rather than infer a category from risk fields.
      _trade(
        id: 'neutral-with-risk',
        result: 0,
        classification: TradeClassification.breakEven,
        riskPercent: 0.25,
        expectedLoss: 25,
      ),
      // Empty risk alone is not enough when a profit or loss is recorded.
      _trade(
        id: 'profit-without-risk',
        result: 7,
        riskPercent: 0,
        expectedLoss: null,
      ),
      _trade(
        id: 'loss-without-risk',
        result: -3,
        riskPercent: 0,
        expectedLoss: null,
      ),
      // Review selections do not change a positive-result card's category.
      _trade(
        id: 'executed-with-review-flags',
        result: 9,
        riskPercent: 0.2,
        expectedLoss: 20,
        noEntryReasons: const ['fearLossNoHistory'],
        executionStatuses: const [TradeExecutionStatus.avoidedEntryBecauseFear],
        executionReviewKeys: const ['noBreakoutPositiveClose'],
      ),
    ];
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(390, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }

  Future<void> openTrades(WidgetTester tester) async {
    await tester.pumpWidget(TraderDeskApp(controller: app));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الصفقات').last);
    await tester.pumpAndSettle();
  }

  Future<void> expectFilterOptions(
    WidgetTester tester,
    Map<String, (String, String)> expected, {
    required String selectedKey,
  }) async {
    final menu = find.byKey(const ValueKey('trades-filter-menu'));
    await tester.ensureVisible(menu);
    await tester.tap(menu);
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('trades-filter-menu-title')),
      findsOneWidget,
    );
    expect(find.text('تصنيف الصفقات'), findsOneWidget);
    for (final entry in expected.entries) {
      final option = find.byKey(ValueKey(entry.key));
      expect(option, findsOneWidget);
      expect(
        find.descendant(of: option, matching: find.text(entry.value.$1)),
        findsOneWidget,
      );
      expect(
        find.descendant(of: option, matching: find.text(entry.value.$2)),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: option,
          matching: find.textContaining('('),
        ),
        findsNothing,
      );
    }

    // Tap the currently selected value to close the menu without changing
    // the active filter used by the test.
    await tester.tap(find.byKey(ValueKey(selectedKey)));
    await tester.pumpAndSettle();
  }

  Future<void> selectFilter(WidgetTester tester, String key) async {
    await tester.ensureVisible(
      find.byKey(const ValueKey('trades-filter-menu')),
    );
    await tester.tap(find.byKey(const ValueKey('trades-filter-menu')));
    await tester.pumpAndSettle();
    final tapKey = key == 'trades-filter-missed'
        ? 'trades-filter-missed-select'
        : key;
    await tester.tap(find.byKey(ValueKey(tapKey)));
    await tester.pumpAndSettle();
  }

  testWidgets(
    'one category selector and one period selector stay visible without horizontal scrolling',
    (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await openTrades(tester);

      final controlKeys = [
        'trades-filter-menu',
        'trades-filter-selector',
        'trades-period-menu',
        'trades-period-selector',
      ];
      final row = find.byKey(const ValueKey('trades-filter-row'));
      final rowRect = tester.getRect(row);
      expect(rowRect.left, greaterThanOrEqualTo(0));
      expect(rowRect.right, lessThanOrEqualTo(360));

      for (final key in controlKeys) {
        expect(
          find.descendant(of: row, matching: find.byKey(ValueKey(key))),
          findsOneWidget,
        );
      }
      expect(
        find.descendant(of: row, matching: find.byType(Scrollable)),
        findsNothing,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'category and period popup widths stay within their selector rectangles',
    (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await openTrades(tester);

      final filterSelector = find.byKey(
        const ValueKey('trades-filter-selector'),
      );
      final filterButton = find.byKey(const ValueKey('trades-filter-menu'));
      final filterWidth = tester.getSize(filterSelector).width;
      await tester.tap(filterButton);
      await tester.pumpAndSettle();
      final filterMenuEntry = find.byKey(
        const ValueKey('trades-filter-all'),
      );
      expect(tester.getSize(filterMenuEntry).width, lessThanOrEqualTo(filterWidth + 0.5));
      await tester.tap(filterMenuEntry);
      await tester.pumpAndSettle();

      final periodSelector = find.byKey(
        const ValueKey('trades-period-selector'),
      );
      final periodButton = find.byKey(const ValueKey('trades-period-menu'));
      final periodWidth = tester.getSize(periodSelector).width;
      await tester.tap(periodButton);
      await tester.pumpAndSettle();
      final periodMenuEntry = find.byKey(
        const ValueKey('trades-period-all'),
      );
      expect(tester.getSize(periodMenuEntry).width, lessThanOrEqualTo(periodWidth + 0.5));
      await tester.tap(periodMenuEntry);
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'saved cards preserve classification tint, gradient stripe, and small dot without label text',
    (tester) async {
      usePhoneViewport(tester);
      await openTrades(tester);

      final cases = <(String, TradeClassification, String)>[
        ('winner', TradeClassification.win, 'رابحة'),
        ('loser', TradeClassification.loss, 'خاسرة'),
        ('neutral-with-risk', TradeClassification.breakEven, 'تعادل'),
        ('missed-empty', TradeClassification.missed, 'ضائعة'),
      ];

      for (final (tradeId, classification, classificationLabel) in cases) {
        final cardFinder = find.byKey(ValueKey('trade-summary-$tradeId'));
        await tester.scrollUntilVisible(
          cardFinder,
          260,
          scrollable: find.byKey(const ValueKey('trades-list')),
        );
        await tester.pumpAndSettle();

        final card = tester.widget<AppCard>(cardFinder);
        final cardContext = tester.element(cardFinder);
        final tokens = TdTokens.of(cardContext);
        final expectedColor = switch (classification) {
          TradeClassification.win => tokens.profit,
          TradeClassification.loss => tokens.loss,
          TradeClassification.breakEven =>
            TradeOutcomePalette.breakEven(Theme.of(cardContext).brightness),
          TradeClassification.missed => tokens.neutral,
        };
        expect(card.variant, AppCardVariant.tint);
        expect(card.tintColor, expectedColor);
        expect(card.tintBorderAlpha, 0.12);

        final gradientStripe = find.descendant(
          of: cardFinder,
          matching: find.byWidgetPredicate((widget) {
            if (widget is! DecoratedBox) return false;
            final decoration = widget.decoration;
            return decoration is BoxDecoration &&
                decoration.gradient is LinearGradient;
          }),
        );
        expect(gradientStripe, findsOneWidget);

        final indicator = find.descendant(
          of: cardFinder,
          matching: find.byKey(
            ValueKey('trade-classification-indicator-$tradeId'),
          ),
        );
        expect(indicator, findsOneWidget);
        expect(tester.getSize(indicator), const Size(7, 7));
        expect(
          find.descendant(
            of: cardFinder,
            matching: find.text(classificationLabel),
          ),
          findsNothing,
        );
      }
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('break-even and missed filters separate zero-result records', (
    tester,
  ) async {
    usePhoneViewport(tester);
    await openTrades(tester);

    await expectFilterOptions(
      tester,
      {
        'trades-filter-all': ('الكل', '7'),
        'trades-filter-wins': ('رابحة', '3'),
        'trades-filter-losses': ('خاسرة', '2'),
        'trades-filter-break-even': ('تعادل', '1'),
        'trades-filter-missed': ('ضائعة', '1'),
      },
      selectedKey: 'trades-filter-all',
    );

    await selectFilter(tester, 'trades-filter-missed');
    expect(
      find.byKey(const ValueKey('trade-summary-missed-empty')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-neutral-with-risk')),
      findsNothing,
    );
    for (final excludedId in [
      'winner',
      'loser',
      'profit-without-risk',
      'loss-without-risk',
      'executed-with-review-flags',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$excludedId')), findsNothing);
    }

    await selectFilter(tester, 'trades-filter-break-even');
    expect(
      find.byKey(const ValueKey('trade-summary-neutral-with-risk')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('trade-summary-missed-empty')), findsNothing);

    await selectFilter(tester, 'trades-filter-wins');
    expect(
      find.byKey(const ValueKey('trade-summary-winner')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-empty')),
      findsNothing,
    );

    await selectFilter(tester, 'trades-filter-losses');
    expect(
      find.byKey(const ValueKey('trade-summary-loser')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-empty')),
      findsNothing,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'break-even and missed submenu buttons share one vertical line, size and tone',
    (tester) async {
      usePhoneViewport(tester);
      app.trades = [
        _trade(id: 'be-1', result: 0, classification: TradeClassification.breakEven, breakEvenType: BreakEvenType.balanced),
        _trade(id: 'missed-1', result: 0, classification: TradeClassification.missed),
        for (var i = 0; i < 11; i++) _trade(id: 'win-$i', result: 5),
      ];
      await openTrades(tester);
      await tester.tap(find.byKey(const ValueKey('trades-filter-menu')));
      await tester.pumpAndSettle();

      final breakEven = find.byKey(const ValueKey('trades-filter-break-even-submenu'));
      final missed = find.byKey(const ValueKey('trades-filter-missed-submenu'));
      expect(breakEven, findsOneWidget);
      expect(missed, findsOneWidget);

      final breakEvenRect = tester.getRect(breakEven);
      final missedRect = tester.getRect(missed);
      expect(breakEvenRect.size, missedRect.size);
      expect(
        breakEvenRect.left,
        closeTo(missedRect.left, .1),
        reason: 'both sub-filter buttons must sit on the same vertical line',
      );

      // The count column reserves the same width in every row.
      final countWidths = [
        for (final name in ['all', 'wins', 'losses', 'breakEven', 'missed'])
          tester.getSize(find.byKey(ValueKey('trades-filter-count-$name'))).width,
      ];
      for (final width in countWidths) {
        expect(width, closeTo(countWidths.first, .1));
      }

      // Same effective glyph colour, independent of the host row being enabled.
      Color glyphColor(Finder button) {
        final icon = tester.widget<Icon>(
          find.descendant(of: button, matching: find.byIcon(Icons.tune_rounded)),
        );
        return icon.color!;
      }

      expect(glyphColor(breakEven), glyphColor(missed));
      final iconTheme = IconTheme.of(
        tester.element(
          find.descendant(of: breakEven, matching: find.byIcon(Icons.tune_rounded)),
        ),
      );
      expect(iconTheme.opacity, 1);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('break-even submenu filters balanced and entry-area exits', (tester) async {
    usePhoneViewport(tester);
    app.trades = [
      _trade(id: 'be-balanced', result: 0, classification: TradeClassification.breakEven, breakEvenType: BreakEvenType.balanced),
      _trade(id: 'be-at-entry', result: 0, classification: TradeClassification.breakEven, breakEvenType: BreakEvenType.atEntry),
      _trade(id: 'be-legacy', result: 0, classification: TradeClassification.breakEven),
      _trade(id: 'ordinary-win', result: 5),
    ];
    await openTrades(tester);
    final mainMenu = find.byKey(const ValueKey('trades-filter-menu'));
    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    final submenu = find.byKey(const ValueKey('trades-filter-break-even-submenu'));
    expect(submenu, findsOneWidget);
    await tester.tap(submenu);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trades-break-even-subfilter-all')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-break-even-subfilter-balanced')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-break-even-subfilter-atEntry')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trades-break-even-subfilter-balanced')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-be-balanced')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-be-at-entry')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-be-legacy')), findsNothing);
    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-filter-break-even-submenu')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-break-even-subfilter-atEntry')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-be-at-entry')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-be-balanced')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'missed filter submenu separates missed winners and losers while All includes unknown',
    (tester) async {
    usePhoneViewport(tester);
    app.trades = [
      _trade(
        id: 'missed-unknown',
        result: 0,
        classification: TradeClassification.missed,
      ),
      _trade(
        id: 'missed-potential-win',
        result: 0,
        classification: TradeClassification.missed,
        missedOutcome: MissedTradeOutcome.win,
      ),
      _trade(
        id: 'missed-potential-loss',
        result: 0,
        classification: TradeClassification.missed,
        missedOutcome: MissedTradeOutcome.loss,
      ),
      _trade(id: 'executed-win', result: 20),
    ];
    await openTrades(tester);

    final mainMenu = find.byKey(const ValueKey('trades-filter-menu'));
    await tester.ensureVisible(mainMenu);
    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    final missedSubmenu = find.byKey(
      const ValueKey('trades-filter-missed-submenu'),
    );
    expect(missedSubmenu, findsOneWidget);
    // Tapping the category label itself selects all missed opportunities;
    // only the small adjacent control opens the three-way sub-filter.
    await tester.tap(find.byKey(const ValueKey('trades-filter-missed-select')));
    await tester.pumpAndSettle();
    for (final id in [
      'missed-potential-win',
      'missed-potential-loss',
      'missed-unknown',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$id')), findsOneWidget);
    }

    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-filter-missed-submenu')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('trades-missed-subfilter-all')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-missed-subfilter-wins')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-missed-subfilter-losses')), findsOneWidget);
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trades-missed-subfilter-all')),
        matching: find.text('الكل'),
      ),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trades-missed-subfilter-wins')),
        matching: find.text('رابحة'),
      ),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trades-missed-subfilter-losses')),
        matching: find.text('خاسرة'),
      ),
      findsOneWidget,
    );
    final allLabel = find.descendant(
      of: find.byKey(const ValueKey('trades-missed-subfilter-all')),
      matching: find.text('الكل'),
    );
    final winsLabel = find.descendant(
      of: find.byKey(const ValueKey('trades-missed-subfilter-wins')),
      matching: find.text('رابحة'),
    );
    final lossesLabel = find.descendant(
      of: find.byKey(const ValueKey('trades-missed-subfilter-losses')),
      matching: find.text('خاسرة'),
    );
    expect(
      tester.widget<Text>(allLabel).style?.color,
      TdTokens.of(tester.element(allLabel)).text3,
      reason: 'All is neutral gray',
    );
    expect(
      tester.widget<Text>(winsLabel).style?.color,
      TdTokens.of(tester.element(winsLabel)).profit,
      reason: 'Wins is green',
    );
    expect(
      tester.widget<Text>(lossesLabel).style?.color,
      TdTokens.of(tester.element(lossesLabel)).loss,
      reason: 'Losses is red',
    );

    await tester.tap(find.byKey(const ValueKey('trades-missed-subfilter-wins')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-missed-potential-win')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed-potential-loss')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-missed-unknown')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-executed-win')), findsNothing);

    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-filter-missed-submenu')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-missed-subfilter-losses')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-missed-potential-loss')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed-potential-win')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-missed-unknown')), findsNothing);

    // Selecting the Missed category label itself returns to All; the small
    // adjacent control is the only place that narrows it to Wins or Losses.
    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-filter-missed-select')));
    await tester.pumpAndSettle();
    for (final id in [
      'missed-potential-win',
      'missed-potential-loss',
      'missed-unknown',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$id')), findsOneWidget);
    }

    await tester.tap(mainMenu);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-filter-missed-submenu')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trades-missed-subfilter-all')));
    await tester.pumpAndSettle();
    for (final id in [
      'missed-potential-win',
      'missed-potential-loss',
      'missed-unknown',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$id')), findsOneWidget);
    }
    expect(tester.takeException(), isNull);
  });

  testWidgets('19 missed zero-result records are counted consistently', (
    tester,
  ) async {
    usePhoneViewport(tester);
    app.trades = List.generate(
      19,
      (index) => _trade(
        id: 'missed-record-${index.toString().padLeft(2, "0")}',
        result: 0,
        classification: TradeClassification.missed,
        riskPercent: index < 11 ? 0 : 0.25,
        expectedLoss: index < 11 ? 0 : 25,
      ),
    );
    await openTrades(tester);
    await expectFilterOptions(
      tester,
      {
        'trades-filter-all': ('الكل', '19'),
        'trades-filter-wins': ('رابحة', '0'),
        'trades-filter-losses': ('خاسرة', '0'),
        'trades-filter-break-even': ('تعادل', '0'),
        'trades-filter-missed': ('ضائعة', '19'),
      },
      selectedKey: 'trades-filter-all',
    );

    await selectFilter(tester, 'trades-filter-missed');
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trades-filter-selector')),
        matching: find.text('ضائعة'),
      ),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('trades-filter-missed')), findsNothing);
    await tester.drag(
      find.byKey(const ValueKey('trades-list')),
      const Offset(0, -6000),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-summary-missed-record-00')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'one selected period filters All, Wins, Losses, Break-even and Missed together',
    (tester) async {
      usePhoneViewport(tester);
      final today = DateTime.now();
      app.trades = [
        _trade(id: 'recent-win', result: 12, tradedAt: today),
        _trade(
          id: 'old-win',
          result: 18,
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(
          id: 'recent-loss',
          result: -8,
          tradedAt: today.subtract(const Duration(days: 1)),
        ),
        _trade(
          id: 'old-loss',
          result: -5,
          tradedAt: DateTime(2020, 1, 4),
        ),
        _trade(
          id: 'recent-missed',
          result: 0,
          classification: TradeClassification.missed,
          riskPercent: 0,
          expectedLoss: null,
          noEntryReasons: const ['fearLossNoHistory'],
          tradedAt: today.subtract(const Duration(days: 2)),
        ),
        _trade(
          id: 'old-missed-journal',
          result: 0,
          classification: TradeClassification.missed,
          riskPercent: 0,
          expectedLoss: null,
          executionStatuses: const [
            TradeExecutionStatus.missedHigherTimeframeBounceArea,
          ],
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(
          id: 'mid-month-win-missed-key',
          result: 5,
          executionReviewKeys: const ['noTrendlineSupportsEntryZone'],
          tradedAt: today.subtract(const Duration(days: 15)),
        ),
        _trade(
          id: 'exactly-seven-days-old-loss',
          result: -4,
          tradedAt: today.subtract(const Duration(days: 7)),
        ),
      ];
      await openTrades(tester);

      final periodMenu = find.byKey(const ValueKey('trades-period-menu'));
      await tester.ensureVisible(periodMenu);
      await tester.tap(periodMenu);
      await tester.pumpAndSettle();
      for (final period in ['all', 'week', 'month', 'year', 'custom']) {
        expect(find.byKey(ValueKey('trades-period-$period')), findsOneWidget);
      }

      // Choosing a date range does not force a category; it is shared by
      // whichever category the trader selects next.
      await tester.tap(find.byKey(const ValueKey('trades-period-week')));
      await tester.pumpAndSettle();
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-period-selector')),
          matching: find.text('أسبوع'),
        ),
        findsOneWidget,
      );
      // Every menu count and visible card uses the same seven-day snapshot.
      await expectFilterOptions(
        tester,
        {
          'trades-filter-all': ('الكل', '3'),
          'trades-filter-wins': ('رابحة', '1'),
          'trades-filter-losses': ('خاسرة', '1'),
          'trades-filter-break-even': ('تعادل', '0'),
          'trades-filter-missed': ('ضائعة', '1'),
        },
        selectedKey: 'trades-filter-all',
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-net-profit-metric')),
          matching: find.text('USD 4.00'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-win-rate-metric')),
          matching: find.text('50.0%'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-filter-selector')),
          matching: find.text('الكل'),
        ),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-win')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-win')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-loss')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-loss')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-missed-journal')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-exactly-seven-days-old-loss')),
        findsNothing,
      );

      // Changing the shared period updates the currently visible category too.
      await tester.tap(find.byKey(const ValueKey('trades-period-menu')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('trades-period-month')));
      await tester.pumpAndSettle();
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-period-selector')),
          matching: find.text('شهر'),
        ),
        findsOneWidget,
      );
      await expectFilterOptions(
        tester,
        {
          'trades-filter-all': ('الكل', '5'),
          'trades-filter-wins': ('رابحة', '2'),
          'trades-filter-losses': ('خاسرة', '2'),
          'trades-filter-break-even': ('تعادل', '0'),
          'trades-filter-missed': ('ضائعة', '1'),
        },
        selectedKey: 'trades-filter-all',
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-net-profit-metric')),
          matching: find.text('USD 5.00'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-win-rate-metric')),
          matching: find.text('50.0%'),
        ),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-exactly-seven-days-old-loss')),
        findsOneWidget,
      );

      await selectFilter(tester, 'trades-filter-wins');
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('trades-period-selector')),
          matching: find.text('شهر'),
        ),
        findsOneWidget,
      );
      expect(find.byKey(const ValueKey('trade-summary-recent-win')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-win')), findsNothing);
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsOneWidget,
      );

      await selectFilter(tester, 'trades-filter-losses');
      expect(
        find.byKey(const ValueKey('trade-summary-recent-loss')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-loss')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-exactly-seven-days-old-loss')),
        findsOneWidget,
      );

      await selectFilter(tester, 'trades-filter-missed');
      expect(
        find.byKey(const ValueKey('trade-summary-recent-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-missed-journal')),
        findsNothing,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'saved trade summary stays clean and linked purple entry conditions open with details',
    (tester) async {
      usePhoneViewport(tester);
      const signal = TradeEntryConditionSetup(
        optionKey: 'strongRejectionWickAgainstDirection',
        timeframe: '15MIN',
      );
      app.trades = [
        _trade(
          id: 'practical-entry-card',
          result: 0,
          riskPercent: 0,
          expectedLoss: 0,
          reverseSignalSetups: const [signal],
          practicalNoEntryReverseSignalSetups: const [signal],
        ),
      ];

      await openTrades(tester);
      final savedCard = find.byKey(
        const ValueKey('trade-summary-practical-entry-card'),
      );
      expect(savedCard, findsOneWidget);

      // The compact saved card must not gain an unsolicited BUY/SELL badge,
      // purple condition box, or untranslated entryConditions key.
      expect(
        find.descendant(of: savedCard, matching: find.text('BUY')),
        findsNothing,
      );
      expect(
        find.descendant(of: savedCard, matching: find.text('SELL')),
        findsNothing,
      );
      expect(
        find.descendant(of: savedCard, matching: find.byIcon(Icons.north_east_rounded)),
        findsNothing,
      );
      expect(
        find.descendant(of: savedCard, matching: find.byIcon(Icons.south_east_rounded)),
        findsNothing,
      );
      expect(
        find.byKey(
          const ValueKey('trade-summary-linked-entry-conditions-practical-entry-card'),
        ),
        findsNothing,
      );
      expect(find.text('entryConditions'), findsNothing);

      // Opening the saved trade reveals the purple panel expanded by default.
      await tester.tap(savedCard);
      await tester.pumpAndSettle();
      final detailsSurface = find.byKey(
        const ValueKey('trade-detail-entry-conditions-panel-surface'),
      );
      expect(detailsSurface, findsOneWidget);
      final detailPanel = tester.widget<Container>(detailsSurface);
      expect(
        (detailPanel.decoration as BoxDecoration).color,
        TradeDetailPalette.reviewNoEntryDark,
      );
      expect(find.text('إشارات عكسية'), findsOneWidget);
      expect(find.text('15MIN'), findsOneWidget);
      final savedReverseField = find.byKey(
        const ValueKey('trade-detail-reverse-signals'),
      );
      final savedReverseSurface = tester.widget<Container>(
        find.descendant(
          of: savedReverseField,
          matching: find.byWidgetPredicate(
            (widget) => widget is Container &&
                widget.decoration is BoxDecoration &&
                (widget.decoration as BoxDecoration).color ==
                    TradeDetailPalette.linkedEntryConditionsFieldDark,
          ),
        ).first,
      );
      expect(
        (savedReverseSurface.decoration as BoxDecoration).color,
        TradeDetailPalette.linkedEntryConditionsFieldDark,
        reason: 'a practical opposing-signal marker keeps the same muted purple inner field after saving',
      );
      expect(find.text('entryConditions'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'floating add button fades while scrolling and becomes clear at rest',
    (tester) async {
      usePhoneViewport(tester);
      app.trades = List.generate(
        24,
        (index) => _trade(
          id: 'scroll-$index',
          result: index.isEven ? 10 : -5,
        ),
      );
      await openTrades(tester);

      final button = find.byKey(const ValueKey('trades-add-floating'));
      final opacity = find.byKey(
        const ValueKey('trades-add-floating-opacity'),
      );
      expect(button, findsOneWidget);
      expect(find.byKey(const ValueKey('trades-list')), findsOneWidget);
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);

      await tester.drag(
        find.byKey(const ValueKey('trades-list')),
        const Offset(0, -380),
      );
      await tester.pump();
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.30);

      await tester.pump(const Duration(milliseconds: 800));
      await tester.pump(const Duration(milliseconds: 200));
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);
      final listRect = tester.getRect(
        find.byKey(const ValueKey('trades-list')),
      );
      final navRect = tester.getRect(
        find.byKey(const ValueKey('td-bottom-navigation')),
      );
      final fabRect = tester.getRect(button);
      expect(listRect.bottom, closeTo(navRect.top, 1));
      expect(fabRect.left, lessThan(listRect.left + 60));
      expect(fabRect.bottom, lessThanOrEqualTo(listRect.bottom));
      expect(tester.takeException(), isNull);
    },
  );
}

Trade _trade({
  required String id,
  required double result,
  List<String> noEntryReasons = const [],
  List<TradeExecutionStatus> executionStatuses = const [],
  List<String> executionReviewKeys = const [],
  List<TradeEntryConditionSetup> reverseSignalSetups = const [],
  List<TradeEntryConditionSetup> practicalNoEntryReverseSignalSetups = const [],
  TradeClassification? classification,
  MissedTradeOutcome? missedOutcome,
  BreakEvenType? breakEvenType,
  double riskPercent = 0.25,
  double? expectedLoss = 25,
  DateTime? tradedAt,
}) => Trade(
  id: id,
  accountId: 'trades-filter-account',
  market: 'EURUSD',
  reason: 'Breakout',
  result: result,
  riskPercent: riskPercent,
  expectedLoss: expectedLoss,
  side: TradeSide.buy,
  confirmation: 'confirmTechnical',
  sequence: '',
  mood: 'moodCalm',
  tradedAt: tradedAt ?? DateTime(2024, 1, 1),
  noEntryReasons: noEntryReasons,
  reverseSignalSetups: reverseSignalSetups,
  practicalNoEntryReverseSignalSetups: practicalNoEntryReverseSignalSetups,
  executionReviewKeys: executionReviewKeys,
  classification: classification,
  missedOutcome: missedOutcome,
  breakEvenType: breakEvenType,
  executionJournal: executionStatuses
      .map((status) => TradeExecutionJournalEntry(status: status))
      .toList(growable: false),
);
