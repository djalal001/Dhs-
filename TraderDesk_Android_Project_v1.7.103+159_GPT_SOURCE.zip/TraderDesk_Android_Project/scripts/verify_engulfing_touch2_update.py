#!/usr/bin/env python3
"""Static regression checks for direction-aware Engulfing and BREAKOUT Touch 2."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
BREAKOUT_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
checks = []
def check(label, condition): checks.append((label, bool(condition)))

check("S/R bounce saved label includes Touch 2", "if (setup.touch2) 'Touch 2'" in CATALOG)
check("BREAKOUT optional Touch 2 persists as a direction-neutral semantic value", "directionalBreakout Touch 2" in CATALOG and "return touch2 ? 'directionalBreakout Touch 2' : 'directionalBreakout';" in CATALOG)
check("BREAKOUT Touch 2 label resolves to RBS for BUY", "final breakoutLabel = side == TradeSide.buy" in CATALOG and "return '$breakoutLabel Touch 2';" in CATALOG)
check("BREAKOUT Touch 2 label resolves to SBR for SELL", "side == TradeSide.sell" in CATALOG and "'SBR'" in CATALOG)
check("editing a legacy SBR/RBS Touch 2 record opens the shared chooser", "tradeEntryReasonSelectionKey(currentReason) == 'directionalBreakout'" in FORM and "tradeEntryUsesTouch2(currentReason)" in FORM)
check("BREAKOUT uses the same centered Touch 2 sheet", "baseReason == 'directionalBreakout'" in FORM and "_showTouch2Sheet(" in FORM)
check("Bounce S/R chip tests assert Touch 2 in Arabic and English", "ارتداد من Support Touch 2 15MIN" in CATALOG_TEST and "Bounce from Support Touch 2 15MIN" in CATALOG_TEST)
check("BREAKOUT widget test covers both Touch 2 and Continue", "find.text('Touch 2')" in BREAKOUT_TEST and "find.text('متابعة')" in BREAKOUT_TEST and "RBS Touch 2 15MIN" in BREAKOUT_TEST)
check("legacy RBS Touch 2 edit restores the same dialog and selected choice", "editing a legacy RBS Touch 2 setup restores the shared BREAKOUT detail dialog" in BREAKOUT_TEST and "touch2-choice-directionalBreakout" in BREAKOUT_TEST and "the legacy Touch 2 choice must be restored when editing" in BREAKOUT_TEST)

check("confirmation catalog has one Engulfing option", "TradeEntryOption('confirmEngulfing', 'Engulfing', 'Engulfing')" in CATALOG and "TradeEntryOption('confirmBullishEngulfing'" not in CATALOG and "TradeEntryOption('confirmBearishEngulfing'" not in CATALOG)
check("legacy confirmation keys map to the single Engulfing picker row", "tradeConfirmationSelectionKey(String type)" in CATALOG and "type == 'confirmBullishEngulfing'" in CATALOG and "type == 'confirmBearishEngulfing'" in CATALOG)
check("new confirmation resolves by BUY/SELL", "tradeConfirmationDisplayKey" in CATALOG and "return 'confirmBullishEngulfing';" in CATALOG and "return 'confirmBearishEngulfing';" in CATALOG)
check("confirmation editing selects the semantic Engulfing option", "tradeConfirmationSelectionKey(current.type)" in FORM)
check("confirmation duplicate detection uses semantic selection key", FORM.count("tradeConfirmationSelectionKey(item.type)") == 1 and "tradeConfirmationSelectionKey(entry.value.type)" in FORM)
check("saved trade summary resolves new Engulfing by direction", TRADES.count("tradeConfirmationDisplayKey(") >= 2)
check("confirmation widget test expects BUY-side Bullish Engulfing", "تأكيد الدخول · Bullish Engulfing" in ENTRY_TEST and "Bullish Engulfing 5MIN" in ENTRY_TEST)

check("anchor catalog has one Engulfing option", "TradeEntryOption('engulfing', 'Engulfing', 'Engulfing')" in CATALOG and "TradeEntryOption('bullishEngulfing'" not in CATALOG and "TradeEntryOption('bearishEngulfing'" not in CATALOG)
check("anchor formatter resolves Engulfing by direction", "case 'engulfing':" in CATALOG and "TradeSide.buy => 'Bullish Engulfing'" in CATALOG and "TradeSide.sell => 'Bearish Engulfing'" in CATALOG)
check("legacy concrete anchor values remain displayable", "case 'bullishEngulfing':" in CATALOG and "case 'bearishEngulfing':" in CATALOG)
check("legacy anchors map to the single Engulfing picker row", "if (optionKey == 'engulfing')" in FORM and "selected.contains('bullishEngulfing')" in FORM and "selected.contains('bearishEngulfing')" in FORM)
check("selecting semantic Engulfing removes superseded concrete keys", "_anchors.removeAll({'bullishEngulfing', 'bearishEngulfing'})" in FORM)
check("anchor widget test covers BUY and SELL labels", "الارتكاز · Bullish Engulfing" in ENTRY_TEST and "Bearish Engulfing 5MIN" in ENTRY_TEST)

for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
failed = [label for label, ok in checks if not ok]
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
