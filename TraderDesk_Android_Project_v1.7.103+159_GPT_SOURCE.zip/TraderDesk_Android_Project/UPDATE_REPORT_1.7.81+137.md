# تقرير التحديث والتحقق — TraderDesk 1.7.81+137

## مصدر المشروع

- المصدر المستخدم مباشرةً: `TraderDesk_Android_Project_v1.7.80+136_GPT_SOURCE.zip` الذي حدده المستخدم.
- لم تُستخدم ملفات أو تغييرات من الإصدارات التي أُنشئت بعد `1.7.80+136`.
- الإصدار الجديد: `1.7.81`، رقم البناء `137`.

## التعديلات المنفذة في أسباب الدخول

### 1. تحديث أسماء Trend Line

تُعرض العناصر القديمة الآن بالأسماء المطلوبة:

| المفتاح المحفوظ القديم | الاسم المعروض الجديد |
|---|---|
| `Trend Line SELL` | `Trendline Sell 3 Touch` |
| `Trend Line BUY` | `Trendline Buy 3 Touch` |
| `Trend Line BREAKOUT SELL` | `Trend Line Touch 3 Sell Breakout` |
| `Trend Line BREAKOUT BUY` | `Trend Line Touch 3 Buy Breakout` |

أُبقيت مفاتيح التخزين الأربعة القديمة كما هي؛ التغيير في العرض فقط، ولذلك تظل الصفقات التي سُجلت سابقاً بهذه القيم قابلة للقراءة، وتظهر بالأسماء الجديدة في قائمة الاختيار، والحقل المختار، وبطاقات الصفقات، والتفاصيل، وملخص اليوم.

### 2. استبدال Supply Zone بخيار Zone S/D

- أزيل خيار `Supply Zone` من قائمة **أسباب الدخول** المباشرة، وأضيف بدلاً منه خيار واحد باسم `Zone S/D`.
- عند اختيار `Zone S/D` في صفقة BUY، يظهر في العناصر المختارة: `Demand Zone`.
- عند اختياره في صفقة SELL، يظهر: `Supply Zone`.
- يُخزّن الاختيار الجديد بمفتاح دلالي ثابت هو `zoneSd`؛ ويُحلّ الاسم المعروض اعتماداً على اتجاه الصفقة في نموذج الإضافة/التعديل، وسياق اختيار الفريم، وبطاقات الصفقات، والتفاصيل، وملخص اليوم.
- الصفقات القديمة التي خزّنت حرفياً `Supply Zone` تبقى قابلة للعرض وتحافظ على اسمها التاريخي حتى يحرر المستخدم ذلك الاختيار؛ عند فتحه للتحرير يُربط بصف `Zone S/D` الجديد، وعند حفظه بعد التحرير يصبح اتجاهياً.

## التوافق مع البيانات

- لم تتغير بنية `TradeEntrySetup` أو شكل JSON أو ترتيب الحقول.
- لم تتغير مفاتيح Trend Line القديمة.
- لم تتغير مفاتيح أسباب الدخول الأخرى أو الفريمات أو آلية إضافة/تعديل/حذف الأسباب.
- اختيار `Zone S/D` الجديد يستخدم قيمة `reason: zoneSd` ضمن البنية الحالية نفسها.
- لم تُغيّر خيارات Supply Zone في الارتكاز أو ظروف الدخول أو الإشارات العكسية؛ نطاق الاستبدال هو قائمة أسباب الدخول فقط.

## الملفات التي عُدّلت أو أُضيفت

- `lib/domain/trade_entry_catalog.dart`
- `lib/screens/trade_form_screen.dart`
- `lib/widgets/trade_entry_setup_chips.dart`
- `lib/screens/trades_screen.dart`
- `lib/screens/days_screen.dart`
- `test/trade_entry_catalog_test.dart`
- `test/custom_confirmation_test.dart`
- `test/trading_app_test.dart`
- `scripts/verify_entry_reason_names_update.py` (جديد)
- سكربتات التحقق القائمة التي تم تحديث مرجع إصدارها إلى `1.7.81+137`.
- `pubspec.yaml` و`.github/workflows/android-build.yml` و`README.md` و`RELEASE_NOTES_AR.md` و`BUILD_INFO_AR.md`.

## نتائج التحقق الفعلية

- نجحت سكربتات التحقق الثابتة التسعة بإجمالي **268/268** تحققاً.
- سكربت تغطية الخطوط اجتاز عينتي محارف عربية ولاتينية/أرقام.
- نجح `python3 -m compileall -q scripts`.
- نجح فحص صياغة Bash باستخدام `bash -n` للملفات `android/gradlew` و`build_release_apk.sh` و`verify_arm64_apk.sh`.
- نجح تحليل YAML لملفي `pubspec.yaml` و`.github/workflows/android-build.yml`.
- نجح تحليل ملفات Android XML الثمانية.

## ما لم يُنفذ

- لم تكن Flutter SDK أو Dart SDK متوفرتين في بيئة التنفيذ.
- لذلك لم يتم تشغيل `flutter analyze` أو `flutter test`، ولم يتم تشغيل تنسيق Dart أو بناء APK.
- أُضيفت/حُدّثت اختبارات Flutter لتغطية أسماء Trend Line وسلوك Zone S/D عند التبديل بين BUY وSELL، لكنها لم تُنفذ فعلياً هنا.
- التسليم هو المشروع المصدري الكامل بصيغة ZIP، وليس APK.
