#!/usr/bin/env python3
"""Static regression checks for TraderDesk 1.7.113+169 release and retained form section tabs."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
REPORT = ROOT / "UPDATE_REPORT_1.7.113+169.md"

checks = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


check("package version is 1.7.113+169", "version: 1.7.113+169" in PUBSPEC)
check("workflow names release 1.7.113+169", "TraderDesk 1.7.113+169 Android Release APK" in WORKFLOW)
check("workflow artifact names use build 169", "traderdesk-1.7.113-build169-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.113-build169-arm64-dart-symbols" in WORKFLOW)
check("new release report exists", REPORT.is_file())

check("section navigation is one horizontal Row", "Widget _buildFormSectionNavigation(BuildContext context)" in FORM and "return Row(" in FORM[FORM.index("Widget _buildFormSectionNavigation(BuildContext context)"):FORM.index("Widget _buildFormSectionTab(")])
check("all three tabs have separate stable keys", all(f"key: '{key}'" in FORM for key in ("details", "conditions", "behavior")) and "trade-form-section-tab-$keyName" in FORM)
check("full Arabic titles are defined", all(title in FORM for title in ("بيانات الصفقة", "ظروف الدخول", "سلوك التداول")))
check("short Arabic labels are defined", all(title in FORM for title in ("shortAr: 'بيانات'", "shortAr: 'ظروف'", "shortAr: 'سلوك'")))
check("selected label uses full title and idle label uses short title", "selected ? fullTitle : shortTitle" in FORM)
check("original icons are used", all(icon in FORM for icon in ("Icons.receipt_long_outlined", "Icons.radar_rounded", "Icons.fact_check_outlined")))
check("original section tone constants are used", all(token in FORM for token in ("tone: _dataTone", "tone: conditionsTone", "tone: _behaviorTone")))
check("tab highlight uses low-intensity tint and thin edge", "isDark ? .13 : .085" in FORM and "isDark ? .045 : .028" in FORM and "selected ? .17 : .075" in FORM and "width: .8" in FORM)
check("tab children expand equally", "Expanded(\n            child: _buildFormSectionTab(" in FORM)
check("form side padding is 6dp", "padding: const EdgeInsets.fromLTRB(6, 10, 6, 34)" in FORM)
check("all panels keep their state while hidden", FORM.count("maintainState: true") >= 3 and FORM.count("maintainAnimation: true") >= 3)
check("each separate panel reuses the same existing card and hides duplicate header", all(f"showHeader: false" in FORM[FORM.index(marker):FORM.index(end, FORM.index(marker))] for marker, end in (("Widget _buildTradeDetailsSection", "String _confirmationLabel"), ("Widget _buildEntryConditionsSection", "Widget _buildBehaviorCard"), ("Widget _buildBehaviorCard", "/// Keeps the commitment"))))
check("conditions retain practical-link state and field controls", "_hasPracticalNoEntryReason" in FORM and "_togglePracticalNoEntryReverseSignal" in FORM and "practical-no-entry-link-${setups[index].optionKey}" in FORM)
check("behavior headings remain in requested order", FORM.index("title: _copy('القرارات'", FORM.index("Widget _buildBehaviorCard")) < FORM.index("title: _copy('الالتزام'", FORM.index("Widget _buildBehaviorCard")) < FORM.index("title: _copy('أسباب عدم الدخول'", FORM.index("Widget _buildBehaviorCard")))
check("save bar remains after images", FORM.index("_sectionCard(\n                    context,\n                    title: _copy('صور الصفقة'") < FORM.index("_buildSaveBar(account.currency)"))
check("obsolete cross-card rail painter is removed from the separated layout", "_LinkedSectionConnectorPainter" not in FORM and "_linkedSectionsRailKey" not in FORM)
check("widget test covers layout, names, icons, navigation and state retention", all(part in TESTS for part in ("trade form sections use full-width horizontal tabs", "detailsRect.width", "find.text('بيانات الصفقة')", "find.text('ظروف الدخول')", "find.text('سلوك التداول')", "trade-decision-zones")))

failed = [name for name, passed in checks if not passed]
for name, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
