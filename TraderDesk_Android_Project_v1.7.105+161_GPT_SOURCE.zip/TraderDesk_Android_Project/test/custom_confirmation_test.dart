import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';
import 'package:trader_desk/widgets/decision_section_logo.dart';

Future<void> _enterSignedResult(
  WidgetTester tester,
  String amount, {
  required bool negative,
}) async {
  final input = find.byKey(const ValueKey('trade-result-input'));
  final signOption = find.byKey(ValueKey(
    negative ? 'trade-result-sign-negative' : 'trade-result-sign-positive',
  ));
  if (signOption.evaluate().isEmpty) {
    final resultField = tester.widget<TextFormField>(input);
    final existingText = resultField.controller?.text ?? '';
    final wasSigned = RegExp(r'^[+\-−]').hasMatch(existingText);
    if (wasSigned && !resultField.readOnly) {
      // Removing the leading symbol is the supported way to reopen sign choice.
      await tester.enterText(input, existingText.replaceFirst(RegExp(r'^[+\-−]'), ''));
    } else {
      await tester.tap(input);
    }
    await tester.pumpAndSettle();
  }
  expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsOneWidget,
      reason: 'the editable amount exposes + and − choices whenever its sign is absent');
  expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsOneWidget);
  await tester.tap(signOption);
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsNothing);
  expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsNothing);
  await tester.enterText(input, '${negative ? '−' : '+'}$amount');
  await tester.pumpAndSettle();
  expect(
    tester.widget<TextFormField>(input).controller!.text,
    '${negative ? '−' : '+'}$amount',
    reason: 'the selected sign is stored as an editable leading character in the amount',
  );
}

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_entry_v151_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'entry-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'entry-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('adds Windows entry reason, custom confirmation and review selections', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketSelector = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    await tester.tap(marketSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-market-option-NQ')));
    await tester.pumpAndSettle();
    await _enterSignedResult(tester, '42.5', negative: false);
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(find.byKey(const ValueKey('trade-risk-input'))).controller!.text, '1.00');
    expect(tester.widget<TextFormField>(find.byKey(const ValueKey('trade-reward-risk-input'))).controller!.text, '0.43');

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Zone S/D'), findsOneWidget);
    expect(find.text('SFR / RFS'), findsOneWidget);
    expect(find.text('Trendline Touch 3'), findsOneWidget);
    expect(find.text('Trend Line Touch 3 Breakout'), findsOneWidget);
    expect(find.text('Trendline Sell 3 Touch'), findsNothing);
    expect(find.text('Trendline Buy 3 Touch'), findsNothing);
    expect(find.text('Trend Line Touch 3 Sell Breakout'), findsNothing);
    expect(find.text('Trend Line Touch 3 Buy Breakout'), findsNothing);
    expect(find.text('Supply Zone'), findsNothing,
        reason: 'Supply Zone is no longer a direct Entry Reason choice');
    await tester.tap(find.text('Zone S/D').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D resolves to Demand Zone for BUY');

    // The same saved semantic Zone S/D key follows direction changes.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Supply Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D resolves to Supply Zone for SELL');
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget);

    // A single BREAKOUT choice resolves to the correct scenario from direction.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('BREAKOUT'), findsOneWidget);
    expect(find.text('SBR'), findsNothing);
    expect(find.text('RBS'), findsNothing);
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();
    final breakoutTouchDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(breakoutTouchDialog, findsOneWidget,
        reason: 'BREAKOUT opens the same centered optional Touch 2 chooser');
    expect(find.text('RBS Touch — اختياري'), findsOneWidget,
        reason: 'BUY-side BREAKOUT detail identifies the resulting RBS scenario');
    expect(find.text('Touch 2'), findsOneWidget);
    expect(find.text('متابعة'), findsOneWidget);
    expect(tester.widget<ListTile>(find.byKey(
      const ValueKey('touch2-choice-directionalBreakout'),
    )).selected, isFalse);
    expect(tester.widget<ListTile>(find.byKey(
      const ValueKey('skip-touch2-directionalBreakout'),
    )).selected, isFalse,
        reason: 'Continue is not preselected when no Touch 2 qualifier exists');
    expect(tester.getRect(breakoutTouchDialog).width, lessThan(340));
    await tester.tap(find.text('Touch 2').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('سبب الدخول · RBS Touch 2'), findsOneWidget,
        reason: 'BUY resolves BREAKOUT Touch 2 to RBS');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS Touch 2 15MIN'), findsOneWidget);

    // The same semantic Breakout resolves to SBR after changing to SELL.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SBR Touch 2 15MIN'), findsOneWidget);
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · SBR'), findsOneWidget);
    expect(find.text('SBR Touch — اختياري'), findsOneWidget,
        reason: 'SELL-side BREAKOUT detail identifies the resulting SBR scenario');
    await tester.tap(find.text('متابعة').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('SBR 30MIN'), findsOneWidget);

    // Return to BUY for the remaining reason, confirmation and review checks.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    // SFR / RFS share one row. BUY displays RFS; SELL displays SFR.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('SFR / RFS'), findsOneWidget);
    await tester.tap(find.text('SFR / RFS').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · RFS'), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 5MIN'), findsOneWidget);

    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SFR 5MIN'), findsOneWidget,
        reason: 'the unified SFR/RFS setup follows the selected SELL direction');

    // Trendline Touch 3 is one generic row and resolves to the chosen side.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3'), findsOneWidget);
    await tester.tap(find.text('Trendline Touch 3').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · Trendline Touch 3 Sell'), findsOneWidget);
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3 Sell 30MIN'), findsOneWidget);

    // Changing back to BUY updates the concrete Trendline label.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3 Buy 30MIN'), findsOneWidget);

    // The new Trendline breakout row uses the inverse side in its final label.
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Trend Line Touch 3 Breakout'), findsOneWidget);
    await tester.tap(find.text('Trend Line Touch 3 Breakout').last);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · Trend Line Touch 3 Sell Breakout'), findsOneWidget);
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('Trend Line Touch 3 Sell Breakout 4H'), findsOneWidget);

    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Trend Line Touch 3 Buy Breakout 4H'), findsOneWidget,
        reason: 'BUY maps to Sell Breakout and SELL maps to Buy Breakout');

    // Return to BUY before continuing with the existing Breakout edit assertion.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    // Editing the semantic Breakout choice keeps BREAKOUT selected in its picker.
    final savedBreakout = find.text('RBS 15MIN');
    await tester.ensureVisible(savedBreakout);
    await tester.tap(savedBreakout);
    await tester.pumpAndSettle();
    expect(find.text('BREAKOUT'), findsOneWidget);
    final breakoutOption = find.text('BREAKOUT').last;
    await tester.tap(breakoutOption);
    await tester.pumpAndSettle();
    expect(find.text('سبب الدخول · RBS'), findsOneWidget);
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS 2MIN'), findsOneWidget);

    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    await tester.ensureVisible(addConfirmation);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    expect(find.text('Reject ᴷᵉʸ ᴸᵉᵛᵉˡ'), findsOneWidget);
    await tester.tap(find.text('مخصص').last);
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField).last, 'ارتداد من مستوى يومي');
    await tester.tap(find.text('تأكيد').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('2MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من مستوى يومي 2MIN'), findsOneWidget);

    await tester.ensureVisible(find.text('القرارات'));
    await tester.tap(find.text('القرارات'));
    await tester.pumpAndSettle();
    final decisionOption = find.byKey(const ValueKey('review-enteredEarly'));
    final decisionOptionText = find.descendant(
      of: decisionOption,
      matching: find.byType(Text),
    );
    expect(
      tester.widget<Text>(decisionOptionText).style?.fontSize,
      14.5,
      reason: 'trading behavior option text should be comfortably readable',
    );
    expect(
      find.byType(DecisionSectionLogo),
      findsNothing,
      reason: 'the decisions mark is reserved for the saved trade details',
    );
    await tester.tap(find.byKey(const ValueKey('review-enteredEarly')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-enteredEarly')), findsNothing);
    final selectedDecisionSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-enteredEarly')),
    );
    expect(
      (selectedDecisionSurface.decoration as BoxDecoration).color,
      const Color(0xFFC6A071).withValues(alpha: .14),
      reason: 'selected decisions use a subtle category-tinted row rather than a checkbox square',
    );
    expect(
      find.descendant(of: decisionOption, matching: find.byType(Checkbox)),
      findsNothing,
    );
    expect(
      find.descendant(of: decisionOption, matching: find.byIcon(Icons.check)),
      findsNothing,
    );

    await tester.ensureVisible(find.text('الالتزام'));
    await tester.tap(find.text('الالتزام'));
    await tester.pumpAndSettle();
    final commitmentOption = find.byKey(
      const ValueKey('review-fullPlanCompliance'),
    );
    expect(
      tester.widget<Text>(find.descendant(
        of: commitmentOption,
        matching: find.byType(Text),
      )).style?.fontSize,
      14.5,
    );
    await tester.tap(commitmentOption);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-fullPlanCompliance')), findsOneWidget);
    final selectedCommitmentSurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-fullPlanCompliance')),
    );
    expect(
      (selectedCommitmentSurface.decoration as BoxDecoration).color,
      const Color(0xFF55C99A).withValues(alpha: .14),
      reason: 'commitment selections share the clean selected-row treatment without checkbox squares',
    );
    expect(
      find.descendant(of: commitmentOption, matching: find.byType(Checkbox)),
      findsNothing,
    );
    expect(find.byType(TradeReviewOptionEmoji), findsNWidgets(5));

    await tester.ensureVisible(find.text('أسباب عدم الدخول'));
    await tester.tap(find.text('أسباب عدم الدخول'));
    await tester.pumpAndSettle();
    final noEntryOption = find.byKey(
      const ValueKey('no-entry-fearRepeatLossAfterLoss'),
    );
    expect(
      tester.widget<Text>(find.descendant(
        of: noEntryOption,
        matching: find.byType(Text),
      )).style?.fontSize,
      14.5,
    );
    await tester.tap(noEntryOption);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('review-art-fearRepeatLossAfterLoss')), findsOneWidget);
    final selectedNoEntrySurface = tester.widget<AnimatedContainer>(
      find.byKey(const ValueKey('trade-behavior-option-surface-fearRepeatLossAfterLoss')),
    );
    expect(
      (selectedNoEntrySurface.decoration as BoxDecoration).color,
      const Color(0xFFB69AF0).withValues(alpha: .14),
      reason: 'selected no-entry reasons use a subtle purple row tint without a checkbox square',
    );
    expect(
      find.descendant(of: noEntryOption, matching: find.byType(Checkbox)),
      findsNothing,
    );
    expect(
      find.descendant(of: noEntryOption, matching: find.byIcon(Icons.check)),
      findsNothing,
    );
    expect(find.byType(TradeReviewOptionEmoji), findsNWidgets(10));
    expect(tester.widget<TextFormField>(find.byKey(
      const ValueKey('trade-result-input'),
    )).controller!.text, isEmpty,
        reason: 'a no-entry reason clears the realized P/L and changes the record to a missed setup');
    expect(find.byKey(const ValueKey('trade-result-sign-indicator')), findsNothing,
        reason: 'no-entry evidence removes the previously selected positive sign');
    expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsNothing);
    expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsNothing);

    final classify = find.byKey(
      const ValueKey('choose-trade-classification-button'),
    );
    await tester.ensureVisible(classify);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-classification-option-win')), findsNothing);
    expect(find.byKey(const ValueKey('trade-classification-option-loss')), findsNothing);
    expect(find.byKey(const ValueKey('trade-classification-option-breakEven')), findsNothing);
    expect(
      find.byKey(const ValueKey('trade-classification-option-missed')),
      findsOneWidget,
    );
    await tester.tap(find.byKey(const ValueKey('trade-classification-option-missed')));
    await tester.pumpAndSettle();
    expect(classify, findsNothing);

    final missedChip = find.byKey(const ValueKey('trade-missed-outcome-chip'));
    final missedChipLabel = find.byKey(
      const ValueKey('trade-missed-outcome-chip-label'),
    );
    expect(missedChip, findsOneWidget,
        reason: 'Missed has a compact outlined label that cycles its hypothetical outcome');
    final formTokens = TdTokens.of(tester.element(missedChip));
    BoxDecoration missedDecoration() =>
        tester.widget<AnimatedContainer>(missedChip).decoration as BoxDecoration;
    Color? missedFill() => missedDecoration().color;
    Color missedBorderColor() => (missedDecoration().border as Border).top.color;
    expect(missedFill(), Colors.transparent,
        reason: 'the initial missed outcome remains a neutral grey outline');
    expect(
      missedBorderColor(),
      formTokens.text3.withValues(alpha: .68),
    );
    expect(tester.widget<Text>(missedChipLabel).style!.color, formTokens.text2);

    await tester.tap(find.byKey(const ValueKey('trade-missed-outcome-chip-tap')));
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(missedChipLabel).style!.color, formTokens.loss,
        reason: 'first tap marks the missed opportunity as a losing one');
    expect(missedFill(), formTokens.loss.withValues(alpha: .10));
    expect(
      missedBorderColor(),
      formTokens.loss.withValues(alpha: .88),
    );

    await tester.tap(find.byKey(const ValueKey('trade-missed-outcome-chip-tap')));
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(missedChipLabel).style!.color, formTokens.profit,
        reason: 'second tap marks the missed opportunity as a winning one');
    expect(missedFill(), formTokens.profit.withValues(alpha: .10));
    expect(
      missedBorderColor(),
      formTokens.profit.withValues(alpha: .88),
    );

    await tester.tap(find.byKey(const ValueKey('trade-missed-outcome-chip-tap')));
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(missedChipLabel).style!.color, formTokens.text2,
        reason: 'third tap returns the missed outcome to its neutral state');
    expect(missedFill(), Colors.transparent);

    // A missed opportunity must be explicitly labelled as a hypothetical win
    // or loss. Neutral grey is an unresolved state and cannot be saved.
    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();
    expect(savedTrade, isNull,
        reason: 'a missed opportunity without a win/loss choice must not be saved');
    expect(
      find.text('حدد ما إذا كانت الفرصة الضائعة رابحة أم خاسرة قبل حفظ الصفقة.'),
      findsOneWidget,
      reason: 'the form explains the required missed-outcome choice',
    );

    // Cycle once more to green so the saved record proves the choice persists.
    await tester.tap(find.byKey(const ValueKey('trade-missed-outcome-chip-tap')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-missed-outcome-chip-tap')));
    await tester.pumpAndSettle();

    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.missed);
    expect(savedTrade!.effectiveClassification, TradeClassification.missed);
    expect(savedTrade!.missedOutcome, MissedTradeOutcome.win,
        reason: 'the missed setup hypothetical outcome survives save independently of result=0');
    expect(savedTrade!.market, 'NQ');
    expect(savedTrade!.entrySetups, const [
      TradeEntrySetup(reason: 'zoneSd', timeframe: '15MIN'),
      TradeEntrySetup(reason: 'directionalBreakout Touch 2', timeframe: '15MIN'),
      TradeEntrySetup(reason: 'directionalBreakout', timeframe: '2MIN'),
      TradeEntrySetup(reason: 'directionalBreakout', timeframe: '30MIN'),
      TradeEntrySetup(reason: 'directionalSfrRfs', timeframe: '5MIN'),
      TradeEntrySetup(reason: 'directionalTrendlineTouch3', timeframe: '30MIN'),
      TradeEntrySetup(reason: 'directionalTrendlineTouch3Breakout', timeframe: '4H'),
    ]);
    expect(savedTrade!.confirmationSetups, const [TradeConfirmationSetup(type: 'ارتداد من مستوى يومي', timeframe: '2MIN')]);
    expect(savedTrade!.executionReviewKeys, containsAll(['enteredEarly', 'fullPlanCompliance']));
    expect(savedTrade!.noEntryReasons, ['fearRepeatLossAfterLoss']);
    expect(savedTrade!.expectedLoss, 100);
    expect(savedTrade!.riskPercent, 1);
    expect(savedTrade!.result, 0,
        reason: 'a record containing a no-entry reason must save with zero realized P/L');
  });

  testWidgets('break-even subtype choices gate the save button', (tester) async {
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
    final classify = find.byKey(const ValueKey('choose-trade-classification-button'));
    await tester.ensureVisible(classify);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-classification-option-breakEven')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('break-even-type-balanced')), findsOneWidget);
    expect(find.byKey(const ValueKey('break-even-type-atEntry')), findsOneWidget);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing,
        reason: 'the save action stays absent until a break-even subtype is chosen');
    await tester.tap(find.byKey(const ValueKey('break-even-type-atEntry')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('save-trade-button')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('break-even subtypes pop up in place of the save button', (tester) async {
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
    final classify = find.byKey(const ValueKey('choose-trade-classification-button'));
    await tester.ensureVisible(classify);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-classification-option-breakEven')));
    await tester.pumpAndSettle();

    // The popup opens by itself, with both choices visible at once.
    final popup = find.byKey(const ValueKey('break-even-type-popup'));
    expect(popup, findsOneWidget);
    final balanced = find.byKey(const ValueKey('break-even-type-balanced'));
    final atEntry = find.byKey(const ValueKey('break-even-type-atEntry'));
    expect(balanced, findsOneWidget);
    expect(atEntry, findsOneWidget);
    const viewport = Rect.fromLTWH(0, 0, 420, 900);
    final popupRect = tester.getRect(popup);
    expect(viewport.contains(popupRect.topLeft), isTrue);
    expect(viewport.contains(popupRect.bottomRight), isTrue);
    for (final option in [balanced, atEntry]) {
      final rect = tester.getRect(option);
      expect(rect.height, greaterThanOrEqualTo(48),
          reason: 'each option is a full-size, finger-friendly target');
      expect(popupRect.contains(rect.topLeft), isTrue);
      expect(popupRect.contains(rect.bottomRight), isTrue);
    }

    // The popup grows from the bottom edge of the save slot.
    final slotRect = tester.getRect(find.byWidgetPredicate(
      (widget) => widget is SizedBox && widget.key is GlobalKey &&
          (widget.key as GlobalKey).toString().contains('trade-save-slot'),
    ));
    expect((popupRect.bottom - slotRect.bottom).abs(), lessThan(14),
        reason: 'the popup is anchored over the save button position');
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);

    // Dismissing without a choice keeps the save button hidden but leaves a
    // prompt in the same slot that reopens the popup.
    await tester.tapAt(const Offset(10, 10));
    await tester.pumpAndSettle();
    expect(popup, findsNothing);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    final prompt = find.byKey(const ValueKey('choose-break-even-type-button'));
    expect(prompt, findsOneWidget);
    await tester.tap(prompt);
    await tester.pumpAndSettle();
    expect(popup, findsOneWidget);

    // One tap selects, closes the popup and brings the save button back in the
    // same slot, with the chosen subtype shown beside the classification.
    await tester.tap(balanced);
    await tester.pumpAndSettle();
    expect(popup, findsNothing);
    expect(prompt, findsNothing);
    final save = find.byKey(const ValueKey('save-trade-button'));
    expect(save, findsOneWidget);
    expect(tester.getRect(save).bottom, closeTo(slotRect.bottom, 80));
    final chipLabel = tester.widget<Text>(
      find.byKey(const ValueKey('trade-break-even-type-chip-label')),
    );
    expect(chipLabel.data, 'متساوي');

    // The subtype can still be changed through the chip.
    await tester.tap(find.byKey(const ValueKey('trade-break-even-type-chip')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('break-even-type-atEntry')));
    await tester.pumpAndSettle();
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('trade-break-even-type-chip-label')),
      ).data,
      'عند منطقة الدخول',
    );
    expect(find.byKey(const ValueKey('save-trade-button')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('editing a legacy RBS Touch 2 setup restores the shared BREAKOUT detail dialog', (tester) async {
    tester.view.setLogicalSize(const Size(420, 900));
    tester.view.devicePixelRatio = 1;
    final legacyTrade = Trade(
      id: 'legacy-rbs-touch2-edit',
      accountId: 'entry-account',
      market: 'NQ',
      reason: 'RBS Touch 2',
      result: 0,
      riskPercent: 1,
      side: TradeSide.buy,
      confirmation: '',
      sequence: '',
      mood: 'moodCalm',
      tradedAt: DateTime(2026, 1, 1),
      entrySetups: const [
        TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '15MIN'),
      ],
    );

    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: TradeFormScreen(trade: legacyTrade),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final legacyChip = find.text('RBS Touch 2 15MIN');
    expect(legacyChip, findsOneWidget);
    await tester.ensureVisible(legacyChip);
    await tester.tap(find.byKey(const ValueKey('trade-setup-edit-entry-reason-0')));
    await tester.pumpAndSettle();

    expect(find.text('BREAKOUT'), findsOneWidget);
    await tester.tap(find.text('BREAKOUT').last);
    await tester.pumpAndSettle();

    final touchDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(touchDialog, findsOneWidget);
    expect(find.text('RBS Touch — اختياري'), findsOneWidget);
    expect(find.text('Touch 2'), findsOneWidget);
    expect(find.text('متابعة'), findsOneWidget);
    final selectedContinue = find.byKey(
      const ValueKey('skip-touch2-directionalBreakout'),
    );
    expect(tester.widget<ListTile>(selectedContinue).selected, isFalse);
    final selectedTouch2 = find.byKey(
      const ValueKey('touch2-choice-directionalBreakout'),
    );
    expect(selectedTouch2, findsOneWidget);
    expect(tester.widget<ListTile>(selectedTouch2).selected, isTrue,
        reason: 'the legacy Touch 2 choice must be restored when editing');

    await tester.tap(find.text('Touch 2').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('15MIN'), findsOneWidget);
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RBS Touch 2 15MIN'), findsOneWidget);

    final directionSelector = find.byKey(
      const ValueKey('trade-direction-selector'),
    );
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('SBR Touch 2 15MIN'), findsOneWidget,
        reason: 'the semantic Touch 2 breakout follows direction after editing');
  });

}
