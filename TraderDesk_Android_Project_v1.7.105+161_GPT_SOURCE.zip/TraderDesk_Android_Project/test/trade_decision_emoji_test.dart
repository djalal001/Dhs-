import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';

void main() {
  test('current Decisions options contain no emoji artwork', () {
    final decisionKeys = tradeReviewGroups
        .expand((group) => group.options)
        .map((option) => option.key)
        .toSet();

    expect(decisionKeys, hasLength(21));
    expect(decisionKeys.intersection(tradeReviewOptionEmojiAssets.keys.toSet()),
        isEmpty);
  });

  test('commitment and no-entry options retain their separate artwork', () {
    final commitmentKeys = tradeCommitmentOptions
        .map((option) => option.key)
        .toSet();
    final noEntryKeys = tradeNoEntryOptions.map((option) => option.key).toSet();
    final expectedKeys = {...commitmentKeys, ...noEntryKeys};

    expect(expectedKeys, hasLength(10));
    expect(tradeReviewOptionEmojiAssets.keys.toSet(), expectedKeys);
    for (final asset in tradeReviewOptionEmojiAssets.values) {
      expect(File(asset).existsSync(), isTrue, reason: asset);
    }
  });

  test('remaining animated WebP artwork has alpha and valid animation frames', () {
    expect(tradeReviewOptionEmojiAssets, isNotEmpty);
    for (final entry in tradeReviewOptionEmojiAssets.entries) {
      final asset = entry.value;
      expect(asset, endsWith('.webp'), reason: entry.key);
      final bytes = File(asset).readAsBytesSync();
      expect(String.fromCharCodes(bytes.sublist(0, 4)), 'RIFF', reason: entry.key);
      expect(String.fromCharCodes(bytes.sublist(8, 12)), 'WEBP', reason: entry.key);
      var frameCount = 0;
      for (var i = 12; i + 3 < bytes.length; i++) {
        if (bytes[i] == 0x41 &&
            bytes[i + 1] == 0x4E &&
            bytes[i + 2] == 0x4D &&
            bytes[i + 3] == 0x46) {
          frameCount++;
        }
      }
      expect(frameCount, greaterThanOrEqualTo(10), reason: entry.key);
      final extendedHeader = <int>[
        for (var i = 12; i + 8 < bytes.length; i++)
          if (bytes[i] == 0x56 &&
              bytes[i + 1] == 0x50 &&
              bytes[i + 2] == 0x38 &&
              bytes[i + 3] == 0x58)
            bytes[i + 8],
      ];
      expect(extendedHeader, isNotEmpty, reason: entry.key);
      expect(extendedHeader.first & 0x10, isNot(0), reason: entry.key);
    }
  });
}
