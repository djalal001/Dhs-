import 'package:flutter/material.dart';

/// Only the non-decision review areas retain artwork. The current Decisions
/// catalog is deliberately typography-and-surface only, with no emoji art.
const tradeReviewOptionEmojiAssets = <String, String>{
  'breakevenStopToEntry':
      'assets/emojis/commitment/breakevenStopToEntry.webp',
  'manualExitNearTarget':
      'assets/emojis/commitment/manualExitNearTarget.webp',
  'autoExitAtTarget': 'assets/emojis/commitment/autoExitAtTarget.webp',
  'enteredDespiteFear': 'assets/emojis/commitment/enteredDespiteFear.webp',
  'fullPlanCompliance': 'assets/emojis/commitment/fullPlanCompliance.webp',
  'fearRepeatLossAfterLoss':
      'assets/emojis/no_entry/fearRepeatLossAfterLoss.webp',
  'fearGivingBackProfit':
      'assets/emojis/no_entry/fearGivingBackProfit.webp',
  'fearLossNoHistory': 'assets/emojis/no_entry/fearLossNoHistory.webp',
  'hesitationUnclearScenario':
      'assets/emojis/no_entry/hesitationUnclearScenario.webp',
  'waitedDeeperRetestDespiteConfirmation':
      'assets/emojis/no_entry/waitedDeeperRetestDespiteConfirmation.webp',
};

/// Compact artwork used only for commitment and no-entry review tiles.
class TradeReviewOptionEmoji extends StatelessWidget {
  const TradeReviewOptionEmoji({
    super.key,
    required this.optionKey,
    this.size = 26,
  });

  final String optionKey;
  final double size;

  @override
  Widget build(BuildContext context) {
    final asset = tradeReviewOptionEmojiAssets[optionKey];
    if (asset == null) return const SizedBox.shrink();

    return RepaintBoundary(
      child: ExcludeSemantics(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(7),
          child: Image.asset(
            asset,
            width: size,
            height: size,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.medium,
            gaplessPlayback: true,
          ),
        ),
      ),
    );
  }
}
