import '../models/trade.dart';

class TradeEntryOption {
  const TradeEntryOption(this.key, this.ar, this.en);
  final String key;
  final String ar;
  final String en;
}

class TradeReviewGroup {
  const TradeReviewGroup({required this.id, required this.titleAr, required this.titleEn, required this.options, this.noteAr, this.noteEn});
  final String id;
  final String titleAr;
  final String titleEn;
  final String? noteAr;
  final String? noteEn;
  final List<TradeEntryOption> options;
}

const tradeEntryTimeframes = <String>['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H'];

/// Formats the selected/saved Entry Conditions label. Direction-aware
/// reverse-signal labels are resolved from the trade side in one shared place.
/// Keep timeframes adjacent to their descriptions, without decorative dots.
String formatTradeEntryConditionSetupLabel({
  required TradeEntryConditionSetup setup,
  required String optionLabel,
  required bool arabic,
  TradeSide? side,
}) {
  const reverseSignalKeys = {
    'reverseSr',
    'reverseSdZone',
    'reverseHns',
    'reverseLongCandleWick',
    'negativeCloseAgainstDirection',
    'strongRejectionWickAgainstDirection',
  };
  if (reverseSignalKeys.contains(setup.optionKey)) {
    final label = tradeReverseSignalDisplayLabel(
      optionKey: setup.optionKey,
      arabic: arabic,
      side: side,
    );
    return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';
  }

  // Legacy combined Trendline + Supply Zone records (no longer offered by the
  // Bounce area picker) keep their original two-timeframe presentation.
  if (setup.optionKey == 'bounceFromTrendlineAndSupplyZone') {
    final prefix = arabic ? 'ارتداد من' : 'Bounce from';
    return '$prefix Trend Line ${setup.timeframe} - Supply Zone ${setup.secondaryTimeframe ?? '—'}';
  }

  // Bounce area · Zone S/D resolves to the concrete zone from the trade
  // direction at display time: BUY shows Supply Zone and SELL shows Demand
  // Zone, followed directly by the selected timeframe.
  if (setup.optionKey == 'bounceFromZoneSd') {
    final prefix = arabic ? 'ارتداد من' : 'Bounce from';
    final zone = switch (side) {
      TradeSide.buy => 'Supply Zone',
      TradeSide.sell => 'Demand Zone',
      null => 'Zone S/D',
    };
    final label = '$prefix $zone';
    return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';
  }

  // S/R bounce chips use the selected trade direction as an English market
  // term inside the Arabic label. The optional 2 Touch choice remains stored
  // as a boolean for compatibility, while its chip caption is "Touch 2".
  // Keep the order stable: direction, Touch 2 (when selected), timeframe.
  if (setup.optionKey == 'bounceFromSrZone') {
    final directionalLabel = side == null
        ? optionLabel
        : arabic
            ? (side == TradeSide.buy
                ? 'ارتداد من Support'
                : 'ارتداد من Resistan')
            : (side == TradeSide.buy
                ? 'Bounce from Support'
                : 'Bounce from Resistan');
    final suffix = [
      if (setup.touch2) 'Touch 2',
      if (setup.timeframe.isNotEmpty) setup.timeframe,
    ].join(' ');
    if (suffix.isEmpty) return directionalLabel;
    return '$directionalLabel $suffix';
  }

  return setup.timeframe.isEmpty ? optionLabel : '$optionLabel ${setup.timeframe}';
}

const tradeEntryReasons = <TradeEntryOption>[
  // One direction-aware Breakout choice replaces the separate SBR/RBS rows.
  TradeEntryOption('directionalBreakout', 'BREAKOUT', 'BREAKOUT'),
  // SFR/RFS share one row; BUY resolves to RFS and SELL resolves to SFR.
  TradeEntryOption('directionalSfrRfs', 'SFR / RFS', 'SFR / RFS'),
  // Direction selects the concrete Trendline Touch 3 scenario after choice.
  TradeEntryOption(
    'directionalTrendlineTouch3',
    'Trendline Touch 3',
    'Trendline Touch 3',
  ),
  // Breakout uses the opposite-side Trendline scenario by specification.
  TradeEntryOption(
    'directionalTrendlineTouch3Breakout',
    'Trend Line Touch 3 Breakout',
    'Trend Line Touch 3 Breakout',
  ),
  TradeEntryOption('HNS', 'HNS', 'HNS'),
  TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D'),
];

/// Returns the selected key for the entry-reason picker. Legacy SBR/RBS,
/// SFR/RFS and separate Trendline options migrate to their direction-aware
/// semantic row when edited. Their historical stored values remain readable.
String tradeEntryReasonSelectionKey(String reason) {
  final base = tradeEntryBaseReason(reason);
  if (base == 'SBR' ||
      base == 'RBS' ||
      base == 'BREAKOUT' ||
      base == 'directionalBreakout') {
    return 'directionalBreakout';
  }
  if (base == 'SFR' ||
      base == 'RFS' ||
      base == 'SFR / RFS' ||
      base == 'directionalSfrRfs') {
    return 'directionalSfrRfs';
  }
  if ({
    'Trend Line SELL',
    'Trend Line BUY',
    'Trendline Sell 3 Touch',
    'Trendline Buy 3 Touch',
    'Trendline Touch 3 Sell',
    'Trendline Touch 3 Buy',
    'Trendline Touch 3',
    'directionalTrendlineTouch3',
  }.contains(base)) {
    return 'directionalTrendlineTouch3';
  }
  if ({
    'Trend Line BREAKOUT SELL',
    'Trend Line BREAKOUT BUY',
    'Trend Line Touch 3 Sell Breakout',
    'Trend Line Touch 3 Buy Breakout',
    'Trend Line Touch 3 Breakout',
    'directionalTrendlineTouch3Breakout',
  }.contains(base)) {
    return 'directionalTrendlineTouch3Breakout';
  }
  if (base == 'Supply Zone' || base == 'Zone S/D' || base == 'zoneSd') {
    return 'zoneSd';
  }
  return base;
}

/// Formats entry reasons for every user-facing surface. New semantic choices
/// resolve from the saved trade side. Legacy concrete keys remain readable so
/// historical trades are not silently reinterpreted until they are edited.
String formatTradeEntryReasonLabel({
  required String reason,
  TradeSide? side,
}) {
  switch (reason) {
    case 'directionalBreakout':
    case 'BREAKOUT':
      if (side == TradeSide.buy) return 'RBS';
      if (side == TradeSide.sell) return 'SBR';
      return 'BREAKOUT';
    case 'directionalBreakout Touch 2':
      final breakoutLabel = side == TradeSide.buy
          ? 'RBS'
          : side == TradeSide.sell
              ? 'SBR'
              : 'BREAKOUT';
      return '$breakoutLabel Touch 2';
    case 'directionalSfrRfs':
      if (side == TradeSide.buy) return 'RFS';
      if (side == TradeSide.sell) return 'SFR';
      return 'SFR / RFS';
    case 'directionalTrendlineTouch3':
      if (side == TradeSide.buy) return 'Trendline Touch 3 Buy';
      if (side == TradeSide.sell) return 'Trendline Touch 3 Sell';
      return 'Trendline Touch 3';
    case 'directionalTrendlineTouch3Breakout':
      if (side == TradeSide.buy) return 'Trend Line Touch 3 Sell Breakout';
      if (side == TradeSide.sell) return 'Trend Line Touch 3 Buy Breakout';
      return 'Trend Line Touch 3 Breakout';
    case 'Trend Line SELL':
    case 'Trendline Sell 3 Touch':
      return 'Trendline Touch 3 Sell';
    case 'Trend Line BUY':
    case 'Trendline Buy 3 Touch':
      return 'Trendline Touch 3 Buy';
    case 'Trendline Touch 3 Sell':
      return 'Trendline Touch 3 Sell';
    case 'Trendline Touch 3 Buy':
      return 'Trendline Touch 3 Buy';
    case 'Trend Line BREAKOUT SELL':
    case 'Trend Line Touch 3 Sell Breakout':
      return 'Trend Line Touch 3 Sell Breakout';
    case 'Trend Line BREAKOUT BUY':
    case 'Trend Line Touch 3 Buy Breakout':
      return 'Trend Line Touch 3 Buy Breakout';
    case 'SFR':
      return 'SFR';
    case 'RFS':
      return 'RFS';
    case 'zoneSd':
    case 'Zone S/D':
      if (side == TradeSide.buy) return 'Demand Zone';
      if (side == TradeSide.sell) return 'Supply Zone';
      return 'Zone S/D';
    default:
      // Old saved `Supply Zone` values remain historical fixed-zone records.
      return reason;
  }
}

/// Legacy Touch 2 records for SBR/RBS remain readable and editable. The
/// single BREAKOUT picker now exposes the same optional Touch 2 detail, stored
/// under a direction-neutral semantic reason so its label follows BUY/SELL.
/// S/R bounce Touch 2 remains stored separately on TradeEntryConditionSetup.touch2.
const tradeEntryTouch2EligibleReasons = <String>{'SBR', 'RBS'};

String tradeEntryBaseReason(String reason) {
  if (reason == 'directionalBreakout Touch 2') return 'directionalBreakout';
  for (final base in tradeEntryTouch2EligibleReasons) {
    if (reason == '$base Touch 2') return base;
  }
  return reason;
}

bool tradeEntryUsesTouch2(String reason) =>
    reason == 'directionalBreakout Touch 2' ||
    tradeEntryTouch2EligibleReasons.any((base) => reason == '$base Touch 2');

String tradeEntryReasonWithTouch2(String baseReason, bool touch2) {
  if (baseReason == 'directionalBreakout') {
    return touch2 ? 'directionalBreakout Touch 2' : 'directionalBreakout';
  }
  return touch2 && tradeEntryTouch2EligibleReasons.contains(baseReason)
      ? '$baseReason Touch 2'
      : baseReason;
}

const tradeConfirmationOptions = <TradeEntryOption>[
  TradeEntryOption('confirmEngulfing', 'Engulfing', 'Engulfing'),
  TradeEntryOption('confirmHns', 'HNS', 'HNS'),
  TradeEntryOption('confirmBreakoutPullback', 'Breakout–Pullback', 'Breakout–Pullback'),
  TradeEntryOption('confirmEveningStar', 'Evening Star', 'Evening Star'),
  TradeEntryOption('confirmRejectKeyLevel', 'Reject ᴷᵉʸ ᴸᵉᵛᵉˡ', 'Reject Key Level'),
  TradeEntryOption('__custom__', 'مخصص', 'Custom'),
];

/// Legacy Bullish/Bearish confirmation records map to the new single picker
/// row when edited. Their saved values remain unchanged until the user edits.
String tradeConfirmationSelectionKey(String type) {
  if (type == 'confirmBullishEngulfing' ||
      type == 'confirmBearishEngulfing' ||
      type == 'Bullish Engulfing' ||
      type == 'Bullish engulfing' ||
      type == 'bullish engulfing' ||
      type == 'Bearish engulfing' ||
      type == 'bearish engulfing' ||
      type == 'Bearish Engulfing' ||
      type == 'Engulfing') {
    return 'confirmEngulfing';
  }
  return type;
}

/// Converts the semantic Engulfing choice to the concrete candle pattern
/// using the current trade direction. Historical concrete labels are
/// canonicalized for display without changing their stored meaning.
String tradeConfirmationDisplayKey({
  required String type,
  required TradeSide? side,
}) {
  if (type == 'confirmBullishEngulfing' ||
      type == 'Bullish Engulfing' ||
      type == 'Bullish engulfing' ||
      type == 'bullish engulfing') {
    return 'confirmBullishEngulfing';
  }
  if (type == 'confirmBearishEngulfing' ||
      type == 'Bearish engulfing' ||
      type == 'bearish engulfing' ||
      type == 'Bearish Engulfing') {
    return 'confirmBearishEngulfing';
  }
  if (type == 'confirmEngulfing' || type == 'Engulfing') {
    if (side == TradeSide.buy) return 'confirmBullishEngulfing';
    if (side == TradeSide.sell) return 'confirmBearishEngulfing';
    return 'confirmEngulfing';
  }
  return type;
}

/// The four choices shown when the user opens the Opposing Signals selector.
/// S/R and S-D are semantic groups: their saved category is interpreted using
/// the selected trade side, so changing Buy/Sell updates the displayed
/// opposing reference without rewriting the stored setup.
const tradeReverseSignalOptions = <TradeEntryOption>[
  TradeEntryOption('reverseSr', 'S/R عكسي', 'Reverse S/R'),
  TradeEntryOption('reverseSdZone', 'S - D Zone عكسي', 'Reverse S - D Zone'),
  TradeEntryOption('reverseHns', 'HNS عكسي', 'Reverse HNS'),
  TradeEntryOption(
    'reverseLongCandleWick',
    'ذيل شمعة طويل عكسي',
    'Opposing long candle wick',
  ),
];

/// Resolves the concrete reversed S/R or S-D reference from its semantic
/// category and trade direction. For S/R role reversal, a former resistance
/// that flips polarity is displayed as Support for Buy, while a former
/// support that flips polarity is displayed as Resistance for Sell. The
/// S-D Zone mapping follows the separately specified application convention.
/// Legacy keys remain readable for old saved trades.
String tradeReverseSignalDisplayLabel({
  required String optionKey,
  required bool arabic,
  TradeSide? side,
}) {
  switch (optionKey) {
    case 'reverseSr':
      if (side == TradeSide.buy) {
        return arabic ? 'Support عكسي' : 'Reverse Support';
      }
      if (side == TradeSide.sell) {
        return arabic ? 'Resistan عكسي' : 'Reverse Resistan';
      }
      return arabic ? 'S/R عكسي' : 'Reverse S/R';
    case 'reverseSdZone':
      if (side == TradeSide.buy) return 'Supply Zone';
      if (side == TradeSide.sell) return 'Demand Zone';
      return arabic ? 'S - D Zone عكسي' : 'Reverse S - D Zone';
    case 'reverseHns':
      return arabic ? 'HNS عكسي' : 'Reverse HNS';
    case 'reverseLongCandleWick':
      return arabic ? 'ذيل شمعة طويل عكسي' : 'Opposing long candle wick';
    // Preserve the meaning of records saved before this catalog revision.
    case 'negativeCloseAgainstDirection':
      return arabic
          ? 'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول'
          : 'Negative close before the bounce did not support the trade direction';
    case 'strongRejectionWickAgainstDirection':
      return arabic
          ? 'نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة'
          : 'Strong rejection pattern with a long wick against the trade direction';
    default:
      return optionKey;
  }
}

/// Top-level choices of the Bounce area picker. «سحب سيولة» and
/// «إرتداد من Trendline» are menu rows only: each opens a small popup with its
/// concrete choices (see [tradeBounceZoneSubOptions]) before the timeframe
/// picker, and the menu keys themselves are never stored on a trade.
const tradeBounceZoneOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromSrZone', 'ارتداد من منطقة S/R', 'Bounce from an S/R zone'),
  TradeEntryOption(tradeLiquiditySweepMenuKey, 'سحب سيولة', 'Liquidity sweep'),
  TradeEntryOption(tradeTrendlineBounceMenuKey, 'إرتداد من Trendline', 'Bounce from a Trendline'),
  TradeEntryOption('bounceFromZoneSd', 'ارتداد من Zone S/D', 'Bounce from Zone S/D'),
];

const tradeLiquiditySweepMenuKey = 'liquiditySweepMenu';
const tradeTrendlineBounceMenuKey = 'trendlineBounceMenu';

/// Popup choices behind the «سحب سيولة» row. The stored keys are the original
/// liquidity-sweep keys, so previously saved trades keep their meaning.
const tradeLiquiditySweepOptions = <TradeEntryOption>[
  TradeEntryOption('internalLiquiditySweep', 'سيولة داخلية', 'Internal liquidity'),
  TradeEntryOption('majorStructureLiquiditySweep', 'سيولة خارجية', 'External liquidity'),
];

/// Popup choices behind the «إرتداد من Trendline» row.
const tradeTrendlineBounceOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromTrendlineTouch34', 'Trendline Touch 3-4', 'Trendline Touch 3-4'),
  TradeEntryOption('bounceFromTrendlineTouch34Breakout', 'Trend Line Touch 3-4 Breakout', 'Trend Line Touch 3-4 Breakout'),
];

/// Every key a saved Bounce area setup can carry, with the label shown on the
/// field chip and in saved-trade details. Includes legacy keys so older
/// records stay readable after the picker was reorganised.
const tradeBounceZoneLabelOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromSrZone', 'ارتداد من منطقة S/R', 'Bounce from an S/R zone'),
  TradeEntryOption('internalLiquiditySweep', 'سحب سيولة داخلية', 'Internal liquidity sweep'),
  TradeEntryOption('majorStructureLiquiditySweep', 'سحب سيولة خارجية', 'External liquidity sweep'),
  TradeEntryOption('bounceFromTrendlineTouch34', 'إرتداد من Trendline Touch 3-4', 'Bounce from Trendline Touch 3-4'),
  TradeEntryOption('bounceFromTrendlineTouch34Breakout', 'إرتداد من Trend Line Touch 3-4 Breakout', 'Bounce from Trend Line Touch 3-4 Breakout'),
  TradeEntryOption('bounceFromZoneSd', 'ارتداد من Zone S/D', 'Bounce from Zone S/D'),
  // Legacy records.
  TradeEntryOption('bounceFromTrendline', 'إرتداد من Trendline', 'Bounce from a Trendline'),
  TradeEntryOption('bounceFromTrendlineAndSupplyZone', 'ارتداد من ترند لاين و Supply Zone', 'Bounce from a trendline and Supply Zone'),
];

/// The concrete choices behind a Bounce area menu row, or null when the row
/// continues straight to the timeframe picker.
List<TradeEntryOption>? tradeBounceZoneSubOptions(String menuKey) {
  if (menuKey == tradeLiquiditySweepMenuKey) return tradeLiquiditySweepOptions;
  if (menuKey == tradeTrendlineBounceMenuKey) {
    return tradeTrendlineBounceOptions;
  }
  return null;
}

/// Maps a stored setup key to the picker row that should appear selected when
/// the setup is edited. Keys that are not part of a grouped menu map to
/// themselves, so Opposing signals and the S/R bounce are unaffected.
String tradeBounceZoneMenuKey(String optionKey) {
  switch (optionKey) {
    case 'internalLiquiditySweep':
    case 'majorStructureLiquiditySweep':
      return tradeLiquiditySweepMenuKey;
    case 'bounceFromTrendline':
    case 'bounceFromTrendlineTouch34':
    case 'bounceFromTrendlineTouch34Breakout':
      return tradeTrendlineBounceMenuKey;
    default:
      return optionKey;
  }
}

/// Formats an anchor label consistently in forms and saved-trade details.
/// The new Zone S/D option resolves to the concrete zone from trade direction;
/// legacy `supplyZone`/`demandZone` records retain their historical labels.
String formatTradeAnchorLabel({
  required String anchorKey,
  required bool arabic,
  TradeSide? side,
}) {
  switch (anchorKey) {
    case 'zoneSd':
    case 'Zone S/D':
      if (side == TradeSide.buy) return 'Demand Zone';
      if (side == TradeSide.sell) return 'Supply Zone';
      return 'Zone S/D';
    case 'base':
      return switch (side) {
        TradeSide.buy => 'Base Buy',
        TradeSide.sell => 'Base Sell',
        null => 'Base',
      };
    case 'engulfing':
    case 'Engulfing':
      return switch (side) {
        TradeSide.buy => 'Bullish Engulfing',
        TradeSide.sell => 'Bearish Engulfing',
        null => 'Engulfing',
      };
    case 'bullishEngulfing':
    case 'Bullish engulfing':
    case 'bullish engulfing':
    case 'Bullish Engulfing':
      return 'Bullish Engulfing';
    case 'bearishEngulfing':
    case 'Bearish engulfing':
    case 'bearish engulfing':
    case 'Bearish Engulfing':
      return 'Bearish Engulfing';
    case 'supplyZone':
      return 'Supply Zone';
    case 'demandZone':
      return 'Demand Zone';
    default:
      final option = tradeAnchorOptions
          .where((item) => item.key == anchorKey)
          .firstOrNull;
      return option == null ? anchorKey : (arabic ? option.ar : option.en);
  }
}

/// Optional price reference selected for a trade's entry context.
/// Values are stored by key so their presentation can evolve independently.
const tradeAnchorOptions = <TradeEntryOption>[
  TradeEntryOption('keyLevel', 'Key Level', 'Key Level'),
  TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D'),
  TradeEntryOption('engulfing', 'Engulfing', 'Engulfing'),
  TradeEntryOption('base', 'Base', 'Base'),
];

const tradeMoodOptions = <TradeEntryOption>[
  TradeEntryOption('moodUnknown', 'غير مسجلة', 'Not recorded'),
  TradeEntryOption('moodCalm', 'هادئ', 'Calm'),
  TradeEntryOption('moodConfident', 'واثق', 'Confident'),
  TradeEntryOption('moodAnxious', 'قلق', 'Anxious'),
  TradeEntryOption('moodImpulsive', 'مندفع', 'Impulsive'),
  TradeEntryOption('moodTired', 'متعب', 'Tired'),
  TradeEntryOption('moodUnsureAnalysis', 'غير واثق من التحليل', 'Unsure about the analysis'),
];

const tradeReviewViolationsOptions = <TradeEntryOption>[
  TradeEntryOption('enteredEarly', 'دخول مبكر', 'Early entry'),
  TradeEntryOption('lateEntry', 'دخول متأخر', 'Late entry'),
  TradeEntryOption(
    'hesitationPartialSize',
    'لم أفتح الحجم الكامل بسبب التردد',
    'Did not open the full size because of hesitation',
  ),
  TradeEntryOption(
    'stopLossReducedWithoutReason',
    'تغيير وقف الخسارة لتقليل المخاطرة بلا سبب',
    'Changed the stop loss to reduce risk without a reason',
  ),
  TradeEntryOption(
    'stopLossIncreasedWithoutReason',
    'تغيير وقف الخسارة لزيادة المخاطرة بلا سبب',
    'Changed the stop loss to increase risk without a reason',
  ),
  TradeEntryOption(
    'exitedEarlyBecauseFearOfLosingProfit',
    'خروج مبكر خوفاً من ضياع الأرباح',
    'Exited early out of fear of giving back profits',
  ),
];

const tradeReviewQualityOptions = <TradeEntryOption>[
  TradeEntryOption('qualityRbs', 'RBS', 'RBS'),
  TradeEntryOption('qualityRbsTouch2', 'RBS Touch 2', 'RBS Touch 2'),
  TradeEntryOption('qualityRfs', 'RFS', 'RFS'),
  TradeEntryOption('qualitySbr', 'SBR', 'SBR'),
  TradeEntryOption('qualitySbrTouch2', 'SBR Touch 2', 'SBR Touch 2'),
  TradeEntryOption('qualitySfr', 'SFR', 'SFR'),
  TradeEntryOption('qualityZoneSupply', 'Zone Supply', 'Zone Supply'),
  TradeEntryOption('qualityZoneDemand', 'Zone Demand', 'Zone Demand'),
  TradeEntryOption(
    'qualityTrendlineTouch3Sell',
    'Trendline Touch 3 Sell',
    'Trendline Touch 3 Sell',
  ),
  TradeEntryOption(
    'qualityTrendlineTouch3Buy',
    'Trendline Touch 3 Buy',
    'Trendline Touch 3 Buy',
  ),
  TradeEntryOption(
    'qualityTrendLineTouch3SellBreakout',
    'Trend Line Touch 3 Sell Breakout',
    'Trend Line Touch 3 Sell Breakout',
  ),
  TradeEntryOption(
    'qualityTrendLineTouch3BuyBreakout',
    'Trend Line Touch 3 Buy Breakout',
    'Trend Line Touch 3 Buy Breakout',
  ),
];

const tradeReviewRiskOptions = <TradeEntryOption>[
  TradeEntryOption(
    'stopLossIncreasedForLiquiditySafety',
    'زيادة المخاطرة لسبب منطقي: سيولة عالية مع وجود منطقة أمان أبعد قليلا',
    'Increase risk for a logical reason: high liquidity with a slightly farther safety area',
  ),
  TradeEntryOption(
    'stopLossReducedForNegativeClose',
    'تقليل المخاطرة لسبب منطقي: إغلاق سلبي لا يدعم اتجاه الصفقة',
    'Reduce risk for a logical reason: a negative close does not support the trade direction',
  ),
  TradeEntryOption(
    'partialSizeAwaitingDeepCorrection',
    'لم أفتح الحجم الكامل انتظارًا لتصحيح أعمق لمنطقة الدخول',
    'Did not open the full size while waiting for a deeper correction into the entry area',
  ),
];

/// Only these three groups are offered in the current Decisions selector.
/// Previously saved analysis keys remain readable through the legacy catalog
/// below, but are deliberately not presented as selectable options.
const tradeReviewGroups = <TradeReviewGroup>[
  TradeReviewGroup(
    id: 'violations',
    titleAr: 'مخالفات',
    titleEn: 'Violations',
    options: tradeReviewViolationsOptions,
  ),
  TradeReviewGroup(
    id: 'analysisQuality',
    titleAr: 'جودة تحليل',
    titleEn: 'Analysis quality',
    options: tradeReviewQualityOptions,
  ),
  TradeReviewGroup(
    id: 'riskManagement',
    titleAr: 'إدارة المخاطرة',
    titleEn: 'Risk management',
    options: tradeReviewRiskOptions,
  ),
];

/// Historical labels used only when showing records saved before the new
/// Decisions catalog. These options are not shown in the current editor.
const tradeLegacyAnalysisReviewOptions = <TradeEntryOption>[
  TradeEntryOption(
    'missedHigherTimeframeBounceArea',
    'لم أنتبه لمنطقة ارتداد في الفريم الأكبر',
    'Missed a higher-timeframe bounce area',
  ),
  TradeEntryOption(
    'missedLowerTimeframeBounceArea',
    'لم أنتبه لمنطقة ارتداد في الفريم الأصغر',
    'Missed a lower-timeframe bounce area',
  ),
  TradeEntryOption(
    'missedTrendlineFromCandleWicks',
    'لم أنتبه لاحتمالية رسم الترند لاين من ذيول الشموع',
    'Missed the possibility of drawing the trendline from candle wicks',
  ),
  TradeEntryOption(
    'noBreakoutPositiveClose',
    'الكسر والإغلاق الإيجابي ضعيفان',
    'Breakout and positive close lacked strength',
  ),
  TradeEntryOption(
    'noTrendlineSupportsEntryZone',
    'لا يوجد ترند لاين يدعم منطقة الدخول',
    'No trendline supported the entry zone',
  ),
  TradeEntryOption(
    'missedHigherTimeframeTrendlineIntegration',
    'لم أدمج ترند 1h–4h في تحليلي',
    'Did not include the 1h–4h trend in the analysis',
  ),
];

/// Builds the exact review sentence requested for the collapsed quality list.
/// Selection order follows the catalog, so the result stays stable even when
/// the user taps the rectangles in a different order.
String tradeReviewQualityScenarioSummary(
  Iterable<String> selectedKeys, {
  required bool arabic,
}) {
  final selected = selectedKeys.toSet();
  final labels = tradeReviewQualityOptions
      .where((option) => selected.contains(option.key))
      .map((option) => arabic ? option.ar : option.en)
      .toList(growable: false);
  if (labels.isEmpty) return '';
  if (arabic) {
    return labels.length == 1
        ? 'لم أنتبه لوجود ${labels.single}'
        : 'لم انتبه لوجود سيناريو: ${labels.join('، ')}';
  }
  return labels.length == 1
      ? 'I did not notice ${labels.single}'
      : 'I did not notice this scenario: ${labels.join(', ')}';
}

const tradeCommitmentOptions = <TradeEntryOption>[
  TradeEntryOption('breakevenStopToEntry', 'التزمت بخطة نقل وقف الخسارة إلى نقطة الدخول وخرجت بتعادل', 'Moved the stop to entry as planned and exited breakeven'),
  TradeEntryOption('manualExitNearTarget', 'خرجت يدويًا وفق الخطة عند اقتراب السعر من الهدف', 'Exited manually as planned when price approached the target'),
  TradeEntryOption('autoExitAtTarget', 'خرجت تلقائيًا وفق الخطة عند بلوغ الهدف', 'Exited automatically as planned at the defined target'),
  TradeEntryOption('enteredDespiteFear', 'التزمت بشروط الدخول رغم الخوف من الخسارة', 'Followed the entry conditions despite feeling fear of loss'),
  TradeEntryOption('fullPlanCompliance', 'التزمت بالخطة كاملة', 'Followed the complete plan without deviation'),
];

const tradeNoEntryOptions = <TradeEntryOption>[
  TradeEntryOption('fearRepeatLossAfterLoss', 'الخوف من تكرار الخسارة بعد خسارة سابقة', 'Fear of repeating a loss after a previous loss'),
  TradeEntryOption('fearGivingBackProfit', 'الخوف من خسارة الأرباح بعد صفقة رابحة.', 'Fear of giving back profit after a winning trade.'),
  TradeEntryOption('fearLossNoHistory', 'الخوف من الخسارة دون وجود ربح أو خسارة سابقة.', 'Fear of loss without a prior win or loss.'),
  TradeEntryOption('hesitationUnclearScenario', 'التردد بسبب عدم وضوح السيناريو.', 'Hesitation because the scenario was unclear.'),
  TradeEntryOption(
    'waitedDeeperRetestDespiteConfirmation',
    'الخوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة.',
    'Fear of a deep correction because the entry confirmation was far from the zone.',
  ),
];

String tradeEntryLabel(String key, {required bool arabic}) {
  for (final option in [...tradeEntryReasons, ...tradeConfirmationOptions, ...tradeMoodOptions, ...tradeCommitmentOptions, ...tradeNoEntryOptions, ...tradeReviewGroups.expand((group) => group.options), ...tradeLegacyAnalysisReviewOptions]) {
    if (option.key == key) return arabic ? option.ar : option.en;
  }
  return key;
}
