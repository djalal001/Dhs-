#!/usr/bin/env python3
"""Focused static regressions for the 1.7.105+161 visual corrections."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
DETAIL_TESTS = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
checks = {
    "Mindset restores the reference PopupMenuButton -> 72dp SizedBox -> InputDecorator hierarchy": "return PopupMenuButton<String>(" in FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")] and FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")].index("return PopupMenuButton<String>(") < FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")].index("child: SizedBox(") < FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")].index("child: InputDecorator(") and "key: const ValueKey('trade-mood-field')" in FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")] and "height: _tradeDataControlHeight" in FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")],
    "Mindset actual InputDecorator is compared edge-to-edge with Market/Direction": "moodSurfaceRect.top" in TESTS and "moodSurfaceRect.bottom" in TESTS and "closeTo(marketDirectionRect.top, .1)" in TESTS and "closeTo(marketDirectionRect.bottom, .1)" in TESTS,
    "generic no-entry causes do not activate purple section or side connector": "final hasPracticalReverseSignalLink = _hasPracticalNoEntryReason" in FORM and "final hasNoEntryLink = _hasEntryConditionsNoEntryLink" not in FORM,
    "missed-classification semantics still include generic no-entry reasons": "bool get _hasEntryConditionsNoEntryLink =>" in FORM and "_noEntryReasons.isNotEmpty || _hasPracticalNoEntryReason" in FORM,
    "release is 1.7.105+161": "version: 1.7.105+161" in PUBSPEC,
    "workflow release uses build 156": "TraderDesk 1.7.105+161" in WORKFLOW and "traderdesk-1.7.105-build161-arm64-v8a-release" in WORKFLOW,
    "no nested selected-value pill helper remains": "_selectedTradeDataValueDecoration" not in FORM,
    "selected market/direction value renders as plain text": "key: selectedValueKey == null ? null : ValueKey(selectedValueKey)" in FORM and "child: displayedValue" in FORM,
    "selected Mindset value renders as plain text": "trade-mood-selected-value" in FORM and "_selectedTradeDataValueDecoration" not in FORM,
    "selected popup row uses a subtle accent-family tint": "TdTokens.of(context).accent.withValues(alpha: .11)" in FORM,
    "popup options have no checkmark": "Icons.check_rounded" not in FORM[FORM.index("Future<void> _showCompactPopupChoice"):FORM.index("Widget _compactPopupChoice")],
    "all market options remain in the popup source": "values: const ['NQ', 'ES', 'GC']" in FORM,
    "original direction toggle behavior is preserved while popup highlighting is added": "_side == value ? null : value" in FORM and "clearing BUY must re-lock the market selector" in TESTS,
    "Mindset field uses the exact shared 72dp geometry": "height: _tradeDataControlHeight" in FORM and "const double _tradeDataControlHeight = 72;" in FORM and "_mindsetControlHeight" not in FORM,
    "Mindset popup restores original 42dp row height": "PopupMenuItem<String>" in FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")] and "height: 42" in FORM[FORM.index("Widget _buildMindsetSelector"):FORM.index("Widget _setupSelectionField")],
    "test protects equal 72dp Mindset and Market/Direction field heights": "Mindset control bounds must match the Market / Direction rectangle exactly" in TESTS and "moodSurfaceRect.top" in TESTS and "moodSurfaceRect.bottom" in TESTS and "closeTo(marketDirectionRect.top, .1)" in TESTS and "closeTo(marketDirectionRect.bottom, .1)" in TESTS and "Market / Direction is the 72dp reference field" in TESTS,
    "unrecorded Mindset uses muted placeholder styling": "_mood == 'moodUnknown'" in FORM and "TdTokens.of(context).text2" in FORM,
    "decisions and no-entry selections have no checkbox square": "AnimatedContainer(" in FORM and "trade-behavior-option-surface-${option.key}" in FORM and "Icons.check, size: 15" not in FORM[FORM.index("Widget _selectionRow"):FORM.index("Widget _buildBehaviorCard")],
    "selected behavior row uses a quiet section accent tint": "accent.withValues(alpha: isDark ? .14 : .09)" in FORM,
    "tests cover checkbox-free decision and no-entry selections": "selected decisions use a subtle category-tinted row" in (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8") and "selected no-entry reasons use a subtle purple row tint" in (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8"),
    "test protects original compact Mindset menu row height": "Mindset popup row height retains its original compact 42dp geometry" in TESTS,
    "only explicit practical opposing-signal link colors its field violet": "final reverseSignalTone = hasPracticalReverseSignalLink" in FORM and "tone: reverseSignalTone" in FORM,
    "Bounce area field keeps its normal blue tone": "tone: _entryConditionsTone" in FORM and "Bounce area keeps its original blue field palette" in FORM,
    "long-press purple fill applies only to the linked opposing-signal field": "practicalNoEntrySetups.isNotEmpty" in FORM and "fillColorOverride: entryConditionFieldFill" in FORM,
    "saved detail purple state is tied only to an explicit practical marker": "final reverseSignalsLinkedToNoEntry = trade.hasPracticalNoEntryReason;" in TRADES,
    "saved detail Bounce area stays in blue palette": "fill: TradeDetailPalette.entryConditionsFieldDark" in TRADES and "optionFill: TradeDetailPalette.entryConditionsChipDark" in TRADES,
    "saved detail tests distinguish purple opposing signal from blue Bounce area": "Bounce area chips keep their original blue surface" in DETAIL_TESTS and "Bounce area heading stays in its established blue-grey palette" in DETAIL_TESTS,
    "form tests verify Bounce area does not inherit violet after long-press": "linking an opposing signal must not recolor the Bounce area inner field" in TESTS,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{sum(checks.values())}/{len(checks)} checks passed")
if not all(checks.values()):
    raise SystemExit(1)
