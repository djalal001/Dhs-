#!/usr/bin/env python3
"""Regression checks for the 1.7.105+161 mindset reference layout and missed-trade save gate."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
SAVE_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
BUILD_INFO = (ROOT / "BUILD_INFO_AR.md").read_text(encoding="utf-8")

checks = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

start = FORM.index("Widget _buildMindsetSelector")
end = FORM.index("Widget _setupSelectionField", start)
mood = FORM[start:end]
row_start = FORM.index("key: const ValueKey('trade-entry-identifiers-row')")
row_end = FORM.index("key: const ValueKey('trade-anchor-selector')", row_start)
identifiers_row = FORM[row_start:row_end]

check("package version is 1.7.105+161", "version: 1.7.105+161" in PUBSPEC)
check("workflow version and artifact identity use build 156", "TraderDesk 1.7.105+161" in WORKFLOW and "traderdesk-1.7.105-build161-arm64-v8a-release" in WORKFLOW)
check("mindset selector restores the exact 1.7.92+148 wrapper order", "return PopupMenuButton<String>(" in mood and mood.index("return PopupMenuButton<String>(") < mood.index("child: SizedBox(") < mood.index("child: InputDecorator(") and "key: const ValueKey('trade-mood-field')" in mood and "height: _tradeDataControlHeight" in mood)
check("mindset visible border remains the fixed-height InputDecorator inside the reference child", "key: const ValueKey('trade-mood-field-surface')" in mood and mood.index("child: SizedBox(") < mood.index("child: InputDecorator(") and "height: _tradeDataControlHeight" in mood)
check("mindset width remains constrained only by the same parent half-column", "width: marketControlWidth" not in mood and "width: constraints.maxWidth" not in mood and "SizedBox.expand" not in mood and "trade-mood-control-bounds" not in mood)
check("mindset popup preserves 42dp rows and the subtle selected row", "height: 42" in mood and "accent.withValues(alpha: .11)" in mood)
check("mindset and market/direction remain equal half-width columns", identifiers_row.count("width: marketControlWidth") >= 2 and "(constraints.maxWidth - identifierGap) / 2" in FORM and "width: marketControlWidth" in identifiers_row)
check("layout test measures the actual InputDecorator surface", "find.byKey(const ValueKey('trade-mood-field-surface'))" in ENTRY_TEST)
check("layout test compares actual surface top and bottom edges against Market / Direction", all(token in ENTRY_TEST for token in ["moodRect.width", "moodRect.height", "moodSurfaceRect.top", "moodSurfaceRect.bottom", "closeTo(marketDirectionRect.top, .1)", "closeTo(marketDirectionRect.bottom, .1)", "marketDirectionRect.width", "marketDirectionRect.height", "closeTo(8, .1)"]))
check("save rejects an unresolved missed outcome before creating Trade", "selectedClassification == TradeClassification.missed" in FORM and "_missedOutcome == null" in FORM and FORM.index("_missedOutcome == null") < FORM.index("final trade = Trade("))
check("save validation explains required win/loss choice in Arabic and English", "حدد ما إذا كانت الفرصة الضائعة رابحة أم خاسرة قبل حفظ الصفقة." in FORM and "Choose whether the missed opportunity was a win or loss before saving." in FORM)
check("widget test proves grey missed state cannot save", "Neutral grey is an unresolved state and cannot be saved." in SAVE_TEST and "savedTrade, isNull" in SAVE_TEST)
check("widget test proves the same missed trade can save after explicit outcome", "savedTrade!.missedOutcome, MissedTradeOutcome.win" in SAVE_TEST)
check("build metadata names exact 1.7.98+154 parent source", "TraderDesk_Android_Project_v1.7.99+155_GPT_SOURCE.zip" in BUILD_INFO)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + ": " + name)
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
