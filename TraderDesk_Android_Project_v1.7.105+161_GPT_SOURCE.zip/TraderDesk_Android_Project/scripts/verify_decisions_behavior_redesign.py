#!/usr/bin/env python3
"""Static verification for TraderDesk 1.7.105+161 Decisions redesign."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
DETAIL = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
EMOJI = (ROOT / "lib/widgets/decision_option_emoji.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
FORM_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
DETAIL_TEST = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


def section(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[1].split(end, 1)[0]


violations = section(CATALOG, "const tradeReviewViolationsOptions", "const tradeReviewQualityOptions")
quality = section(CATALOG, "const tradeReviewQualityOptions", "const tradeReviewRiskOptions")
risk = section(CATALOG, "const tradeReviewRiskOptions", "/// Only these three groups")

check("release version is 1.7.105+161", "version: 1.7.105+161" in PUBSPEC)
check("workflow identity is 1.7.105+161", "TraderDesk 1.7.105+161" in WORKFLOW)
check("workflow release artifact uses build161", "traderdesk-1.7.105-build161-arm64-v8a-release" in WORKFLOW)
check("version code is incremented once", "version: 1.7.105+161" in PUBSPEC and "1.7.104+160" not in PUBSPEC)

check("violations contains exactly the six requested items", len(re.findall(r"TradeEntryOption\(", violations)) == 6)
for label in [
    "دخول مبكر",
    "دخول متأخر",
    "لم أفتح الحجم الكامل بسبب التردد",
    "تغيير وقف الخسارة لتقليل المخاطرة بلا سبب",
    "تغيير وقف الخسارة لزيادة المخاطرة بلا سبب",
    "خروج مبكر خوفاً من ضياع الأرباح",
]:
    check(f"violations label present: {label}", label in violations)

check("quality has exactly twelve options", len(re.findall(r"TradeEntryOption\(", quality)) == 12)
for label in [
    "RBS", "RBS Touch 2", "RFS", "SBR", "SBR Touch 2", "SFR",
    "Zone Supply", "Zone Demand", "Trendline Touch 3 Sell",
    "Trendline Touch 3 Buy", "Trend Line Touch 3 Sell Breakout",
    "Trend Line Touch 3 Buy Breakout",
]:
    check(f"quality location present: {label}", label in quality)

check("risk has exactly the three requested items", len(re.findall(r"TradeEntryOption\(", risk)) == 3)
for label in [
    "زيادة المخاطرة لسبب منطقي: سيولة عالية مع وجود منطقة أمان أبعد قليلا",
    "تقليل المخاطرة لسبب منطقي: إغلاق سلبي لا يدعم اتجاه الصفقة",
    "لم أفتح الحجم الكامل انتظارًا لتصحيح أعمق لمنطقة الدخول",
]:
    check(f"risk label present: {label}", label in risk)

check("current editor groups are exactly three", len(re.findall(r"TradeReviewGroup\(", section(CATALOG, "const tradeReviewGroups", "/// Historical labels"))) == 3)
check("current group captions match the request", all(s in CATALOG for s in ["titleAr: 'مخالفات'", "titleAr: 'جودة تحليل'", "titleAr: 'إدارة المخاطرة'"]))
check("old analysis items are in the legacy read-only list", "const tradeLegacyAnalysisReviewOptions" in CATALOG and "tradeLegacyAnalysisReviewOptions" in DETAIL)
check("old analysis items are not offered in current groups", "missedHigherTimeframeBounceArea" not in section(CATALOG, "const tradeReviewGroups", "/// Historical labels"))

check("category selector is a horizontal row", "Widget _buildDecisionCategorySelector()" in FORM and "return Row(" in section(FORM, "Widget _buildDecisionCategorySelector()", "Widget _buildDecisionCategoryButton"))
check("category switching uses a short animated transition", "AnimatedSwitcher(" in section(FORM, "Widget _buildBehaviorCard", "Widget _buildDecisionCategorySelector") and "Duration(milliseconds: 190)" in FORM)
check("category content is switched inline rather than in a popup", "_buildDecisionCategoryContent(" in FORM and "showDialog" not in section(FORM, "Widget _buildDecisionCategorySelector()", "Widget _behaviorExpansion"))
check("behavior card horizontal insets are reduced", "contentPadding: const EdgeInsetsDirectional.fromSTEB(7, 14, 7, 14)" in FORM)

quality_ui = section(FORM, "Widget _buildQualityPlacesSelector()", "Widget _buildQualityPlaceTile")
quality_tile = section(FORM, "Widget _buildQualityPlaceTile", "Widget _buildSelectedQualityPlaces")
quality_preview = section(FORM, "Widget _buildSelectedQualityPlaces", "Widget _behaviorExpansion")
check("quality list is headed by a clickable Places title", "trade-quality-places-toggle" in quality_ui and "_copy('أماكن', 'Locations')" in quality_ui)
check("quality items use a two-column rectangle grid", "crossAxisCount: 2" in quality_ui and "mainAxisExtent: 54" in quality_ui)
check("quality selection changes fill only without outlines", "selected ?" in quality_tile and "border:" not in quality_tile and "boxShadow" not in quality_tile)
check("quality selection has no icon or checkbox", "Icon(" not in quality_tile and "Checkbox" not in quality_tile and "Emoji" not in quality_tile)
check("quality list collapses with animated size", "AnimatedSize(" in quality_ui and "_qualityPlacesExpanded" in quality_ui)
check("one selection uses the exact single-item phrase", "لم أنتبه لوجود" in quality_preview)
check("multiple selections use the scenario phrase", "لم انتبه لوجود سيناريو" in quality_preview)
check("collapsed preview lists the user's selected locations", "trade-quality-selected-${option.key}" in quality_preview)
check("selection persists through executionReviewKeys", "executionReviewKeys: _executionReviewKeys.toList(growable: false)" in FORM)
check("saved details reuse the singular/plural quality summary", "tradeReviewQualityScenarioSummary(keys, arabic: arabic)" in DETAIL)

check("decision illustration widget has no decision assets", "assets/emojis/decisions/" not in EMOJI and "decisionOptionEmojiAssets" not in EMOJI)
check("decision illustration assets are removed from the project", not (ROOT / "assets/emojis/decisions").exists())
check("decision illustration assets are not bundled", "assets/emojis/decisions/" not in PUBSPEC)
check("commitment and no-entry illustrations remain separate", "assets/emojis/commitment/" in EMOJI and "assets/emojis/no_entry/" in EMOJI)
check("saved decision tiles suppress artwork", "!isDecisionOption &&" in DETAIL and "tradeLegacyAnalysisReviewOptions.any" in DETAIL)

check("catalog test covers new counts and quality strings", "hasLength(12)" in CATALOG_TEST and "hasLength(6)" in CATALOG_TEST and "hasLength(3)" in CATALOG_TEST)
check("form test covers category switching and collapsed selected list", "trade-decision-category-analysisQuality" in FORM_TEST and "trade-quality-places-toggle" in FORM_TEST and "لم أنتبه لوجود" in FORM_TEST)
check("detail test checks legacy labels and no decision emoji", "جودة التحليل والإعداد · سجل سابق" in DETAIL_TEST and "findsNWidgets(2)" in DETAIL_TEST)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
