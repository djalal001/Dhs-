# Mandatory build rules for TraderDesk

Before changing build configuration or generating an Android package, read this file and `BUILD_INSTRUCTIONS_AR.md`.

## Android architecture policy — do not change without an explicit user request

- The only supported and distributable Android ABI is `arm64-v8a`.
- Produce exactly one APK: `build/app/outputs/flutter-apk/app-release.apk`.
- Build with: `flutter build apk --release --target-platform android-arm64`.
- Never pass `--split-per-abi` or `--splits-per-abi`.
- Never build or publish `armeabi-v7a`, `x86`, or `x86_64` APKs.
- Do not create a universal/multi-ABI APK or Android App Bundle as a substitute for the one requested APK.
- Keep `android/app/build.gradle.kts` `defaultConfig.ndk.abiFilters` restricted to `arm64-v8a`. Do not remove the filter or re-add other ABIs.
- Keep the JNI packaging exclusions for non-ARM64 libraries.
- Before publishing, run `bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk`. The build must fail if there is more than one APK or if any ABI other than `arm64-v8a` is present.
- Upload/publish only the verified `app-release.apk`; do not upload debug APKs or intermediate build outputs. The GitHub Release workflow publishes this one APK when a `v*` version tag is pushed.

If a requested tool or CI template defaults to three ABI outputs, override that default instead of accepting its outputs. Do not treat three architecture APKs as harmless alternatives: this project's release policy is one ARM64 APK only.
