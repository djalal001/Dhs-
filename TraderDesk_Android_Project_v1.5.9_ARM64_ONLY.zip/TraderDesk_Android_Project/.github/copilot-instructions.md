# TraderDesk repository instructions

Follow the mandatory Android architecture policy in the root `AGENTS.md` and `BUILD_INSTRUCTIONS_AR.md` for every build or release task.

The only allowed Android output is one release APK for `arm64-v8a`:

```bash
flutter build apk --release --target-platform android-arm64
bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk
```

Never use `--split-per-abi` / `--splits-per-abi`; never generate, attach, or publish `armeabi-v7a`, `x86`, or `x86_64` packages. Preserve `android/app/build.gradle.kts`'s explicit ARM64-only `defaultConfig.ndk.abiFilters` and the non-ARM64 JNI exclusions. The verification script is mandatory before publishing. Version tags matching `v*` publish this one verified APK to GitHub Releases; do not attach other APKs.
