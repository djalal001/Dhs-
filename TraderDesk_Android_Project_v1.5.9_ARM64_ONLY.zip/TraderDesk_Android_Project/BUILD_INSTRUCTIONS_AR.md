# تعليمات البناء الإلزامية — معمارية واحدة فقط

## سياسة المشروع

الناتج المسموح به هو **APK Release واحدة فقط** لمعمارية `arm64-v8a`، المناسبة للهواتف الحديثة ذات معالجات ARM 64-bit. لا تُنشئ نسخاً لـ`armeabi-v7a` أو `x86` أو `x86_64`، ولا APK شاملة تجمع المعماريات.

## أمر البناء الوحيد المعتمد

```bash
flutter clean
flutter pub get
flutter build apk --release --target-platform android-arm64
bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk
```

الناتج الوحيد المطلوب:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## أوامر ممنوعة

- `flutter build apk --split-per-abi`
- `flutter build apk --splits-per-abi`
- `flutter build apk --release` دون `--target-platform android-arm64`
- أي بناء أو نشر لملفات Debug أو لملفات `armeabi-v7a` أو `x86` أو `x86_64`.

خيار تقسيم APK حسب ABI ينتج APK منفصلة للمعماريات المستهدفة، وقد ينتج ثلاثة ملفات كما حدث في التسليم السابق. لا تستخدمه حتى لو اقترحته أداة أو قالب CI تلقائياً.

## قيد Android Gradle

داخل `android/app/build.gradle.kts` يجب الحفاظ على هذا القيد ضمن `defaultConfig`:

```kotlin
ndk {
    abiFilters.clear()
    abiFilters.addAll(listOf("arm64-v8a"))
}
```

يُبقي المشروع أيضاً استبعادات JNI للمعماريات الأخرى كطبقة حماية إضافية. لا تحذف هذه الإعدادات ولا تضف معماريات جديدة دون طلب صريح من المستخدم.

## التحقق قبل الرفع أو النشر

```bash
bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk
```

يتحقق السكربت من أن مجلد المخرجات يحتوي APK واحدة بالضبط، وأنها تتضمن مكتبات `arm64-v8a` فقط بما فيها `libapp.so` و`libflutter.so`. أي نتيجة مخالفة توقف عملية النشر. سير عمل GitHub Actions يشغّل الفحص نفسه ويرفع ملف `app-release.apk` وحده كـArtifact، وينشر الملف نفسه وحده في GitHub Release عند دفع وسم إصدار يبدأ بـ`v`. أرشيفا Source code ZIP/TAR اللذان يضيفهما GitHub تلقائياً هما أرشيفا مصدر، وليسا APK إضافيين.

يجب قراءة `AGENTS.md` و`.github/copilot-instructions.md` قبل أي تعديل آلي على البناء؛ هذه السياسة ليست اقتراحاً اختيارياً.
