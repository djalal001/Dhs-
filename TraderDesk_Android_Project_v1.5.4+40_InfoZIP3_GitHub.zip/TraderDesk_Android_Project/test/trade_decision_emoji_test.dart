import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';

void main() {
  test('all 15 Windows decision options have a matching emoji asset', () {
    final decisionKeys = tradeReviewGroups
        .expand((group) => group.options)
        .map((option) => option.key)
        .toSet();

    expect(decisionKeys, hasLength(15));
    expect(decisionOptionEmojiAssets.keys.toSet(), decisionKeys);
  });

  test('every decision emoji asset is bundled in the project', () {
    for (final asset in decisionOptionEmojiAssets.values) {
      expect(File(asset).existsSync(), isTrue, reason: asset);
    }
  });
  test('all 25 saved review options have a matching Windows illustration', () {
    final decisionKeys = tradeReviewGroups
        .expand((group) => group.options)
        .map((option) => option.key)
        .toSet();
    final commitmentKeys = tradeCommitmentOptions.map((option) => option.key).toSet();
    final noEntryKeys = tradeNoEntryOptions.map((option) => option.key).toSet();
    final expectedKeys = {...decisionKeys, ...commitmentKeys, ...noEntryKeys};

    expect(expectedKeys, hasLength(25));
    expect(tradeReviewOptionEmojiAssets.keys.toSet(), expectedKeys);
  });

  test('every commitment and no-entry illustration is bundled', () {
    for (final entry in tradeReviewOptionEmojiAssets.entries) {
      expect(File(entry.value).existsSync(), isTrue, reason: '${entry.key}: ${entry.value}');
    }
  });

}
