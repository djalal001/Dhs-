from pathlib import Path

root = Path(__file__).resolve().parents[1]

def edit(rel, fn):
    p = root / rel
    s = p.read_text(encoding='utf-8')
    out = fn(s)
    if out == s:
        raise SystemExit(f'No change made to {rel}')
    p.write_text(out, encoding='utf-8')

# Model: persisted break-even subtype, backward-compatible with old records.
def model(s):
    s = s.replace(
"enum TradeClassification {\n  win,\n  loss,\n  breakEven,\n  missed;",
"enum TradeClassification {\n  win,\n  loss,\n  breakEven,\n  missed;"
)
    marker = "enum MissedTradeOutcome {"
    addition = """enum BreakEvenType {\n  equal,\n  entryZone;\n  static BreakEvenType? tryParse(Object? source) {\n    for (final value in BreakEvenType.values) {\n      if (value.name == source) return value;\n    }\n    return null;\n  }\n}\n"""
    s = s.replace(marker, addition + marker, 1)
    s = s.replace("    this.classification,\n    this.missedOutcome,", "    this.classification,\n    this.breakEvenType,\n    this.missedOutcome,", 1)
    s = s.replace("  final TradeClassification? classification;\n  /// Optional hypothetical", "  final TradeClassification? classification;\n  /// The selected reason for a break-even result. Null is retained for legacy records.\n  final BreakEvenType? breakEvenType;\n  /// Optional hypothetical", 1)
    s = s.replace("    classification: classification,\n    missedOutcome: missedOutcome,", "    classification: classification,\n    breakEvenType: breakEvenType,\n    missedOutcome: missedOutcome,", 1)
    s = s.replace("    'classification': classification?.name,\n    'missedOutcome': missedOutcome?.name,", "    'classification': classification?.name,\n    'breakEvenType': breakEvenType?.name,\n    'missedOutcome': missedOutcome?.name,", 1)
    s = s.replace("    classification: TradeClassification.tryParse(json['classification']),\n    missedOutcome:", "    classification: TradeClassification.tryParse(json['classification']),\n    breakEvenType: BreakEvenType.tryParse(json['breakEvenType']),\n    missedOutcome:", 1)
    return s
edit('lib/models/trade.dart', model)

# Backup reconstruction must preserve the field.
def store(s):
    old = "        classification: trade.classification,\n        missedOutcome: trade.missedOutcome,"
    new = "        classification: trade.classification,\n        breakEvenType: trade.breakEvenType,\n        missedOutcome: trade.missedOutcome,"
    return s.replace(old, new, 1)
edit('lib/data/local_store.dart', store)

# Form state, initialization, validation, selection UI and persistence.
def form(s):
    s = s.replace("  TradeClassification? _classification;\n  MissedTradeOutcome? _missedOutcome;", "  TradeClassification? _classification;\n  BreakEvenType? _breakEvenType;\n  MissedTradeOutcome? _missedOutcome;")
    s = s.replace("    _classification = trade?.effectiveClassification;\n    _missedOutcome = trade?.missedOutcome;", "    _classification = trade?.effectiveClassification;\n    _breakEvenType = trade?.breakEvenType;\n    _missedOutcome = trade?.missedOutcome;")
    s = s.replace("        _classification = null;\n        _missedOutcome = null;\n      }\n    } else if (_classification != null", "        _classification = null;\n        _breakEvenType = null;\n        _missedOutcome = null;\n      }\n    } else if (_classification != null", 1)
    s = s.replace("      _classification = null;\n      _missedOutcome = null;\n    } else if (_classification != TradeClassification.missed)", "      _classification = null;\n      _breakEvenType = null;\n      _missedOutcome = null;\n    } else if (_classification != TradeClassification.missed)", 1)
    # result-sign change/reset path
    s = s.replace("        _classification = null;\n        _missedOutcome = null;\n      }\n      _updateComputedFields();", "        _classification = null;\n        _breakEvenType = null;\n        _missedOutcome = null;\n      }\n      _updateComputedFields();", 1)
    # choose classification result
    s = s.replace("        if (selected != TradeClassification.missed) _missedOutcome = null;", "        if (selected != TradeClassification.missed) _missedOutcome = null;\n        if (selected != TradeClassification.breakEven) _breakEvenType = null;")
    # Add helper widget before missed widget.
    needle = "  Widget _buildMissedOutcomeChip(TdTokens tokens) {"
    helper = r'''  String _breakEvenTypeLabel(BreakEvenType value) => switch (value) {
    BreakEvenType.equal => _copy('متساوي', 'Equal'),
    BreakEvenType.entryZone => _copy('عند منطقة دخول', 'At entry zone'),
  };
  Widget _buildBreakEvenTypeSelector(TdTokens tokens) {
    final tone = TradeOutcomePalette.breakEven(Theme.of(context).brightness);
    return Column(
      key: const ValueKey('break-even-type-selector'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final value in BreakEvenType.values) ...[
          if (value != BreakEvenType.equal) const SizedBox(height: 7),
          OutlinedButton(
            key: ValueKey('break-even-type-${value.name}'),
            onPressed: _busy ? null : () => setState(() => _breakEvenType = value),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(44),
              backgroundColor: _breakEvenType == value
                  ? tone.withValues(alpha: .10)
                  : tokens.surface2,
              foregroundColor: _breakEvenType == value ? tone : tokens.text1,
              side: BorderSide(
                color: _breakEvenType == value
                    ? tone.withValues(alpha: .88)
                    : tokens.lineStrong.withValues(alpha: .66),
                width: _breakEvenType == value ? 1.1 : .8,
              ),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
            ),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                _breakEvenTypeLabel(value),
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ],
    );
  }
'''
    s = s.replace(needle, helper + needle, 1)
    # save gate after null classification
    old = """    if (selectedClassification == null) {
      _showValidationMessage(tr(context, 'tradeClassificationRequired'));
      return;
    }
    if (selectedClassification == TradeClassification.missed &&"""
    new = """    if (selectedClassification == null) {
      _showValidationMessage(tr(context, 'tradeClassificationRequired'));
      return;
    }
    if (selectedClassification == TradeClassification.breakEven &&
        _breakEvenType == null) {
      _showValidationMessage(tr(context, 'breakEvenTypeRequired'));
      return;
    }
    if (selectedClassification == TradeClassification.missed &&"""
    s = s.replace(old, new, 1)
    s = s.replace("      classification: selectedClassification,\n      missedOutcome:", "      classification: selectedClassification,\n      breakEvenType: selectedClassification == TradeClassification.breakEven\n          ? _breakEvenType\n          : null,\n      missedOutcome:", 1)
    # Insert two stacked options between classification row and save button.
    old = """                    const SizedBox(height: 7),
                    FilledButton.icon(
                      key: const ValueKey('save-trade-button'),"""
    new = """                    if (_classification == TradeClassification.breakEven) ...[
                      const SizedBox(height: 8),
                      _buildBreakEvenTypeSelector(tokens),
                    ],
                    const SizedBox(height: 7),
                    FilledButton.icon(
                      key: const ValueKey('save-trade-button'),"""
    s = s.replace(old, new, 1)
    return s
edit('lib/screens/trade_form_screen.dart', form)

# Trades screen: subtype filter and nested selector alongside Missed.
def trades(s):
    s = s.replace("enum _MissedTradeFilter { all, wins, losses }", "enum _MissedTradeFilter { all, wins, losses }\nenum _BreakEvenFilter { all, equal, entryZone }")
    s = s.replace("  _MissedTradeFilter _missedTradeFilter = _MissedTradeFilter.all;", "  _MissedTradeFilter _missedTradeFilter = _MissedTradeFilter.all;\n  _BreakEvenFilter _breakEvenFilter = _BreakEvenFilter.all;")
    # Insert helpers after missed filter color method.
    needle = "  DateTimeRange? _selectedPeriodBounds() {"
    helper = r'''  String _breakEvenFilterLabel(BuildContext context, _BreakEvenFilter filter) => switch (filter) {
    _BreakEvenFilter.all => tr(context, 'all'),
    _BreakEvenFilter.equal => tr(context, 'breakEvenEqual'),
    _BreakEvenFilter.entryZone => tr(context, 'breakEvenEntryZone'),
  };
  Color _breakEvenFilterColor(BuildContext context, _BreakEvenFilter filter) =>
      TradeOutcomePalette.breakEven(Theme.of(context).brightness);
'''
    s = s.replace(needle, helper + needle, 1)
    s = s.replace("      case _TradeFilter.breakEven:\n        return _outcomeOf(trade) == TradeClassification.breakEven;", """      case _TradeFilter.breakEven:
        if (_outcomeOf(trade) != TradeClassification.breakEven) return false;
        return switch (_breakEvenFilter) {
          _BreakEvenFilter.all => true,
          _BreakEvenFilter.equal => trade.breakEvenType == BreakEvenType.equal,
          _BreakEvenFilter.entryZone => trade.breakEvenType == BreakEvenType.entryZone,
        };""")
    # Replace the menu's missed-only special blocks with both subtype menus.
    s = s.replace("enabled: filter != _TradeFilter.missed,", "enabled: filter != _TradeFilter.missed && filter != _TradeFilter.breakEven,")
    s = s.replace("""                                        child: filter == _TradeFilter.missed
                                            ? InkWell(""", """                                        child: filter == _TradeFilter.missed || filter == _TradeFilter.breakEven
                                            ? InkWell(""")
    # Direct row selection must set appropriate subfilter.
    s = s.replace("""                                                    _filter = _TradeFilter.missed;
                                                    _missedTradeFilter = _MissedTradeFilter.all;""", """                                                    _filter = filter;
                                                    if (filter == _TradeFilter.missed) {
                                                      _missedTradeFilter = _MissedTradeFilter.all;
                                                    } else {
                                                      _breakEvenFilter = _BreakEvenFilter.all;
                                                    }""")
    # Make submenu condition include break-even and choose a typed PopupMenu.
    s = s.replace("if (filter == _TradeFilter.missed) ...[", "if (filter == _TradeFilter.missed || filter == _TradeFilter.breakEven) ...[")
    s = s.replace("""                                          key: const ValueKey('trades-filter-missed-submenu'),""", """                                          key: ValueKey(filter == _TradeFilter.missed
                                              ? 'trades-filter-missed-submenu'
                                              : 'trades-filter-break-even-submenu'),""")
    s = s.replace("""                                          child: SizedBox(
                                            width: 28,""", """                                          child: SizedBox(
                                            width: 28,""", 1)
    # Replace PopupMenuButton generic block type and callbacks/item builder carefully.
    s = s.replace("PopupMenuButton<_MissedTradeFilter>(", "PopupMenuButton<dynamic>(", 1)
    s = s.replace("""                                              _filter = _TradeFilter.missed;
                                              _missedTradeFilter = selection;""", """                                              if (filter == _TradeFilter.missed) {
                                                _filter = _TradeFilter.missed;
                                                _missedTradeFilter = selection as _MissedTradeFilter;
                                              } else {
                                                _filter = _TradeFilter.breakEven;
                                                _breakEvenFilter = selection as _BreakEvenFilter;
                                              }""", 1)
    old = """                                          itemBuilder: (submenuContext) => [
                                            for (final selection in _MissedTradeFilter.values)
                                              PopupMenuItem<_MissedTradeFilter>(
                                                key: ValueKey(
                                                  'trades-missed-subfilter-${selection.name}',
                                                ),
                                                value: selection,
                                                height: 42,
                                                child: Text(
                                                  _missedFilterLabel(submenuContext, selection),
                                                  style: Theme.of(submenuContext)
                                                      .textTheme
                                                      .bodyMedium
                                                      ?.copyWith(
                                                        color: _missedFilterColor(
                                                          submenuContext,
                                                          selection,
                                                        ),
                                                        fontWeight: FontWeight.w700,
                                                      ),
                                                ),
                                              ),
                                          ],"""
    new = """                                          itemBuilder: (submenuContext) => [
                                            for (final selection in filter == _TradeFilter.missed
                                                ? _MissedTradeFilter.values
                                                : _BreakEvenFilter.values)
                                              PopupMenuItem<dynamic>(
                                                key: ValueKey(
                                                  'trades-${filter == _TradeFilter.missed ? 'missed' : 'break-even'}-subfilter-${selection.name}',
                                                ),
                                                value: selection,
                                                height: 42,
                                                child: Text(
                                                  filter == _TradeFilter.missed
                                                      ? _missedFilterLabel(submenuContext, selection as _MissedTradeFilter)
                                                      : _breakEvenFilterLabel(submenuContext, selection as _BreakEvenFilter),
                                                  style: Theme.of(submenuContext)
                                                      .textTheme
                                                      .bodyMedium
                                                      ?.copyWith(
                                                        color: filter == _TradeFilter.missed
                                                            ? _missedFilterColor(submenuContext, selection as _MissedTradeFilter)
                                                            : _breakEvenFilterColor(submenuContext, selection as _BreakEvenFilter),
                                                        fontWeight: FontWeight.w700,
                                                      ),
                                                ),
                                              ),
                                          ],"""
    if old not in s: raise SystemExit('submenu block not found')
    s = s.replace(old, new, 1)
    return s
edit('lib/screens/trades_screen.dart', trades)

# Strings.
def strings(s):
    s = s.replace("    'classificationBreakEven': 'تعادل',\n", "    'classificationBreakEven': 'تعادل',\n    'breakEvenTypeRequired': 'اختر نوع التعادل قبل حفظ الصفقة.',\n    'breakEvenEqual': 'متساوي',\n    'breakEvenEntryZone': 'عند منطقة دخول',\n", 1)
    s = s.replace("    'classificationBreakEven': 'Break-even',\n", "    'classificationBreakEven': 'Break-even',\n    'breakEvenTypeRequired': 'Choose the break-even type before saving.',\n    'breakEvenEqual': 'Equal',\n    'breakEvenEntryZone': 'At entry zone',\n", 1)
    return s
edit('lib/l10n/app_strings.dart', strings)

# Release metadata.
for rel in ['pubspec.yaml', '.github/workflows/android-build.yml']:
    p = root / rel
    s = p.read_text(encoding='utf-8').replace('1.7.99+155', '1.7.100+156').replace('build155', 'build156')
    p.write_text(s, encoding='utf-8')

(root / 'BUILD_INFO_AR.md').write_text('''# معلومات البناء والتسليم — TraderDesk 1.7.100+156\n\n- رقم الإصدار: `1.7.100`؛ رقم البناء: `156`.\n- مصدر التحديث: `TraderDesk_Android_Project_v1.7.99+155_GPT_SOURCE.zip`.\n- يتضمن هذا التسليم مشروع المصدر الكامل بصيغة ZIP.\n- التعديل الرئيسي: اختيار نوع التعادل (متساوي / عند منطقة دخول) عند إدخال الصفقة، مع حفظه وفلترته.\n''', encoding='utf-8')
(root / 'UPDATE_REPORT_1.7.100+156.md').write_text('''# تقرير تحديث TraderDesk 1.7.100+156\n\n## التغييرات\n- إضافة `BreakEvenType` محفوظ مع الصفقة ومتوافق مع JSON والنسخ الاحتياطي.\n- لا يظهر زر حفظ الصفقة قبل اختيار أحد نوعي التعادل.\n- إضافة فلتر فرعي للتعادل بجانب التصنيف داخل قائمة الصفقات.\n- الحفاظ على السجلات القديمة: تعادلها يظهر ضمن «الكل» إذا لم يكن لها نوع محفوظ.\n\n## التحقق\n- تم تشغيل `dart format` على الملفات المعدلة.\n- تم تشغيل `flutter analyze` و`flutter test` إن توفرت أداة Flutter في بيئة التنفيذ؛ النتائج موضحة في ملف التسليم النهائي.\n''', encoding='utf-8')
