#!/usr/bin/env python3
"""Static regression checks for TraderDesk 1.7.100+156 break-even typing."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL = (ROOT / 'lib/models/trade.dart').read_text(encoding='utf-8')
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
STORE = (ROOT / 'lib/data/local_store.dart').read_text(encoding='utf-8')
STRINGS = (ROOT / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks = {
    'release version is 1.7.100+156': 'version: 1.7.100+156' in PUBSPEC,
    'workflow uses build 156': all(x in WORKFLOW for x in [
        'TraderDesk 1.7.100+156',
        'traderdesk-1.7.100-build156-arm64-v8a-release',
        'traderdesk-1.7.100-build156-arm64-dart-symbols',
    ]),
    'model has two persisted break-even types': all(x in MODEL for x in [
        'enum BreakEvenType', 'equal,', 'entryZone;', 'final BreakEvenType? breakEvenType;',
    ]),
    'JSON round trip is implemented': all(x in MODEL for x in [
        "'breakEvenType': breakEvenType?.name",
        "BreakEvenType.tryParse(json['breakEvenType'])",
    ]),
    'form renders both Arabic labels': all(x in FORM for x in ['متساوي', 'عند منطقة دخول']),
    'form gates save until a type is selected': all(x in FORM for x in [
        "selectedClassification == TradeClassification.breakEven",
        '_breakEvenType == null',
        "'breakEvenTypeRequired'",
        'break-even-type-selector',
    ]),
    'save button appears only after break-even type selection':
        '_classification != TradeClassification.breakEven ||' in FORM and
        '_breakEvenType != null' in FORM,
    'form saves only the selected break-even type': 'breakEvenType: selectedClassification == TradeClassification.breakEven' in FORM,
    'break-even filter has all/equal/entry-zone': all(x in TRADES for x in [
        'enum _BreakEvenFilter { all, equal, entryZone }',
        'trades-filter-break-even-submenu',
        'BreakEvenType.equal',
        'BreakEvenType.entryZone',
    ]),
    'backup restore preserves the type': 'breakEvenType: trade.breakEvenType' in STORE,
    'translations exist in Arabic and English': all(x in STRINGS for x in [
        "'breakEvenEqual': 'متساوي'",
        "'breakEvenEntryZone': 'عند منطقة دخول'",
        "'breakEvenEqual': 'Equal'",
        "'breakEvenEntryZone': 'At entry zone'",
    ]),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
print(f'\n{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()):
    raise SystemExit(1)
