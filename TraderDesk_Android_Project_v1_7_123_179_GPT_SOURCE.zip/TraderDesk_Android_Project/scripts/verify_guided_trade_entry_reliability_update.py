#!/usr/bin/env python3
"""Static regression checks for persistent guided trade-entry completion."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/release-arm64.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE_NOTES = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []


def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))


def method_body(signature: str, next_signature: str) -> str:
    if signature not in FORM or next_signature not in FORM:
        return ''
    return FORM.split(signature, 1)[1].split(next_signature, 1)[0]


check('version is 1.7.123+179', 'version: 1.7.123+179' in PUBSPEC)
check('ARM64 APK artifact uses build 179', 'traderdesk-1.7.123-build179-arm64-v8a-release' in WORKFLOW)
check('Dart symbols artifact uses build 179', 'traderdesk-1.7.123-build179-arm64-dart-symbols' in WORKFLOW)
check('build information identifies 1.7.123+179', '1.7.123+179' in BUILD_INFO and 'رقم البناء: `179`' in BUILD_INFO)
check('release notes identify 1.7.123+179', '1.7.123+179' in RELEASE_NOTES)

# A guided session is available only to new, non-missed trades. It no longer
# requires all the later fields to be empty; the first missing item is derived.
check('guided session is explicitly tracked', 'bool _guidedEntryActive = false;' in FORM)
check('manual opt-out persists after deliberately editing a completed step', 'bool _guidedEntryOptedOut = false;' in FORM)
check('only a new trade without a manual opt-out can start guidance', 'widget.trade == null &&' in FORM and '!_guidedEntryOptedOut' in FORM and '!_hasEntryConditionsNoEntryLink' in FORM)
check('next step is derived from live form values', ' _AutoEntryStep get _nextIncompleteGuidedStep' in FORM)
check('positive result requires Expected Loss only when it is missing', '_resultSign == 1 && !_hasValidGuidedExpectedLoss' in FORM)
check('Direction is skipped when already selected', 'if (_side == null) return _AutoEntryStep.direction;' in FORM)
check('Market is skipped when already selected', "if (_symbol == null || _symbol!.trim().isEmpty)" in FORM)
check('Mindset is skipped when a real selection exists', 'if (!_hasRecordedMindset) return _AutoEntryStep.mindset;' in FORM)
check('all automatic advancement passes through one next-missing resolver', 'Future<void> _advanceGuidedEntry()' in FORM and 'final next = _nextIncompleteGuidedStep;' in FORM)

# Closing overlays must leave the current step pending. Verify the awaited
# popup/dialog methods do not reset the active step on dismissal.
direction_popup = method_body('Future<void> _openAutoDirectionPopup()', 'void _handleDirectionSelected')
market_popup = method_body('Future<void> _openAutoMarketPopup()', 'void _handleMarketSelected')
mindset_dialog = method_body('Future<void> _openAutoMindsetDialog()', 'List<String> get _orderedMoodKeys')
check('dismissing Direction popup keeps the step pending', 'await _showCompactPopupChoice<TradeSide>' in direction_popup and '_autoEntryStep = _AutoEntryStep.idle' not in direction_popup)
check('dismissing Market popup keeps the step pending', 'await _showCompactPopupChoice<String>' in market_popup and '_autoEntryStep = _AutoEntryStep.idle' not in market_popup)
check('dismissing Mindset dialog keeps the step pending', 'await _showMindsetMultiSelect()' in mindset_dialog and '_autoEntryStep = _AutoEntryStep.idle' not in mindset_dialog)
check('Direction selection resumes only when Direction is the first missing item', '_nextIncompleteGuidedStep == _AutoEntryStep.direction' in FORM)
check('Market selection resumes only when Market is the first missing item', '_nextIncompleteGuidedStep == _AutoEntryStep.market' in FORM)
check('manual editing of earlier fields cancels guided cascade', 'Selecting a previously completed field is a deliberate manual edit' in FORM and 'if (_guidedEntryActive) {' in FORM)
check('manual Mindset opening during another pending step cancels cascade', 'if (_guidedEntryActive && !isPendingGuidedMindset)' in FORM)
check('Mindset completion ends guided session only after explicit Done', 'if (isPendingGuidedMindset)' in FORM and '_guidedEntryActive = false;' in FORM)
check('Mindset dialog remains multi-select', 'CheckboxListTile(' in FORM and "_selectedMoods = selected.isEmpty" in FORM)
check('unconfirmed Mindset choices persist across dismiss and reopen', 'Set<String>? _guidedMindsetDraft;' in FORM and '_guidedMindsetDraft = {...draft};' in FORM)

# Result and Expected Loss IME paths retain their explicit Done handling.
check('result Done invokes guided completion', 'onEditingComplete: _handleResultEditingComplete' in FORM and 'onFieldSubmitted: _handleResultSubmitted' in FORM)
check('Expected Loss Done invokes guided completion', 'onEditingComplete: _handleExpectedLossEditingComplete' in FORM and 'onSubmitted: _handleExpectedLossSubmitted' in FORM)
check('read-only computed values are removed from focus traversal', 'canRequestFocus: false' in FORM and 'skipTraversal: true' in FORM and 'descendantsAreFocusable: false' in FORM)

# Widget tests must cover dismiss/reopen, resume at the first missing item,
# and manual edits which must not cascade.
check('widget test closes and reopens Direction, Market, and Mindset', "guided flow resumes after Direction, Market, and Mindset overlays are dismissed" in TESTS)
check('resume test dismisses overlays with Navigator.pop', 'navigator.pop();' in TESTS)
check('resume test verifies pending Mindset selections survive dialog dismissal', 'unconfirmed Mindset selections survive dismissing and reopening the dialog' in TESTS)
check('widget test skips already completed Direction and Market', 'guided flow skips Direction and Market when they are already complete' in TESTS)
check('widget test verifies manual edits cancel remaining cascade', 'manually changing a completed guided field cancels the remaining cascade' in TESTS)
check('widget test verifies manual opt-out does not restart after changing result sign', 'manual opt-out prevents a later result correction from restarting guidance' in TESTS)
check('existing-trade manual edit coverage remains', 'manual edits of an existing direction and market do not auto-advance' in TESTS)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
