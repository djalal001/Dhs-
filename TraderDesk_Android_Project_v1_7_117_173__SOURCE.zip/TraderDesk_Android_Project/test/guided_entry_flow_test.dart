import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

/// The guided flow waits for the keyboard to close and for each menu to
/// finish closing, using real timers, so tests must advance the clock.
Future<void> _advance(WidgetTester tester) async {
  await tester.pump(const Duration(milliseconds: 400));
  await tester.pumpAndSettle();
}

bool _hasFocus(WidgetTester tester, Finder field) => tester
    .widget<EditableText>(
      find.descendant(of: field, matching: find.byType(EditableText)),
    )
    .focusNode
    .hasFocus;

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_flow_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'flow-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'flow-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  Future<void> openForm(WidgetTester tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () => Navigator.of(context).push<Trade>(
                    MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                  ),
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();
  }

  final resultInput = find.byKey(const ValueKey('trade-result-input'));
  final expectedLossInput =
      find.byKey(const ValueKey('trade-expected-loss-input'));
  final positiveWord = find.byKey(const ValueKey('trade-result-sign-positive'));
  final negativeWord = find.byKey(const ValueKey('trade-result-sign-negative'));
  final buy = find.byKey(const ValueKey('trade-direction-option-buy'));
  final sell = find.byKey(const ValueKey('trade-direction-option-sell'));
  final marketNq = find.byKey(const ValueKey('trade-market-option-NQ'));
  final moodCalm = find.byKey(const ValueKey('trade-mood-option-moodCalm'));
  final moodTired = find.byKey(const ValueKey('trade-mood-option-moodTired'));
  final moodUnknown =
      find.byKey(const ValueKey('trade-mood-option-moodUnknown'));
  final moodDone = find.byKey(const ValueKey('trade-mood-done'));

  testWidgets('Profit and Loss words are centred in the empty result field', (
    tester,
  ) async {
    await openForm(tester);
    expect(find.descendant(of: positiveWord, matching: find.text('ربح')),
        findsOneWidget);
    expect(find.descendant(of: negativeWord, matching: find.text('خسارة')),
        findsOneWidget);
    final words = find.byKey(const ValueKey('trade-result-sign-words'));
    expect(words, findsOneWidget);
    final fieldRect = tester.getRect(resultInput);
    final wordsRect = tester.getRect(words);
    expect(wordsRect.center.dx, closeTo(fieldRect.center.dx, .5));
    expect(wordsRect.center.dy, closeTo(fieldRect.center.dy, .5));
    final profitRect = tester.getRect(positiveWord);
    final lossRect = tester.getRect(negativeWord);
    expect(profitRect.width, closeTo(lossRect.width, .5),
        reason: 'the two words share the rectangle in equal halves');
    expect(
      (profitRect.center.dx + lossRect.center.dx) / 2,
      closeTo(fieldRect.center.dx, .5),
    );
  });

  testWidgets('Profit inserts + and Loss inserts − with the keyboard', (
    tester,
  ) async {
    await openForm(tester);
    await tester.tap(positiveWord);
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(resultInput).controller!.text, '+');
    expect(tester.testTextInput.isVisible, isTrue);
    expect(find.byKey(const ValueKey('trade-result-sign-words')), findsNothing);

    // Deleting the sign brings the words back so it can be chosen again.
    await tester.enterText(resultInput, '');
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-result-sign-words')),
        findsOneWidget);
    await tester.tap(negativeWord);
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(resultInput).controller!.text, '−');
  });

  testWidgets('winning trade: Continue moves into the expected loss field', (
    tester,
  ) async {
    await openForm(tester);
    await tester.tap(positiveWord);
    await tester.pumpAndSettle();
    await tester.enterText(resultInput, '+500');
    await tester.pumpAndSettle();
    await tester.testTextInput.receiveAction(TextInputAction.next);
    await tester.pumpAndSettle();
    expect(_hasFocus(tester, expectedLossInput), isTrue,
        reason: 'the cursor must already be inside the expected loss field');
    expect(buy, findsNothing, reason: 'direction waits for the next Continue');

    await tester.enterText(expectedLossInput, '100');
    await tester.pumpAndSettle();
    await tester.testTextInput.receiveAction(TextInputAction.next);
    await _advance(tester);
    expect(buy, findsOneWidget);
    expect(sell, findsOneWidget);
  });

  testWidgets(
      'losing trade: Continue opens direction, then market, then mindset', (
    tester,
  ) async {
    await openForm(tester);
    await tester.tap(negativeWord);
    await tester.pumpAndSettle();
    await tester.enterText(resultInput, '−250');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(expectedLossInput).readOnly, isTrue,
        reason: 'a losing trade has no expected loss entry');
    await tester.testTextInput.receiveAction(TextInputAction.next);
    await _advance(tester);
    expect(buy, findsOneWidget, reason: 'the direction menu opens by itself');

    await tester.tap(sell);
    await _advance(tester);
    expect(marketNq, findsOneWidget,
        reason: 'choosing a direction opens the market menu');

    await tester.tap(marketNq);
    await _advance(tester);
    expect(moodCalm, findsOneWidget,
        reason: 'choosing a market opens the mindset menu');

    // Mindset accepts several choices and stays open between them.
    await tester.tap(moodCalm);
    await tester.pumpAndSettle();
    await tester.tap(moodTired);
    await tester.pumpAndSettle();
    expect(moodDone, findsOneWidget);
    await tester.tap(moodDone);
    await tester.pumpAndSettle();
    expect(moodDone, findsNothing);
    expect(find.byKey(const ValueKey('trade-direction-option-sell-selected-value')),
        findsOneWidget);
    expect(find.byKey(const ValueKey('trade-market-option-NQ-selected-value')),
        findsOneWidget);
    expect(
      tester
          .widget<Text>(find.byKey(const ValueKey('trade-mood-selected-value')))
          .data,
      contains('+1'),
      reason: 'two mindset states are summarised as first + count',
    );
  });

  testWidgets('"Not recorded" is exclusive in the mindset menu', (tester) async {
    await openForm(tester);
    await tester.tap(negativeWord);
    await tester.pumpAndSettle();
    await tester.enterText(resultInput, '−10');
    await tester.pumpAndSettle();
    await tester.testTextInput.receiveAction(TextInputAction.next);
    await _advance(tester);
    await tester.tap(buy);
    await _advance(tester);
    await tester.tap(marketNq);
    await _advance(tester);
    await tester.tap(moodCalm);
    await tester.pumpAndSettle();
    await tester.tap(moodTired);
    await tester.pumpAndSettle();
    await tester.tap(moodUnknown);
    await tester.pumpAndSettle();
    await tester.tap(moodDone);
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<Text>(find.byKey(const ValueKey('trade-mood-selected-value')))
          .data,
      'غير مسجلة',
    );
  });

  testWidgets('dismissing a menu ends the guided chain', (tester) async {
    await openForm(tester);
    await tester.tap(negativeWord);
    await tester.pumpAndSettle();
    await tester.enterText(resultInput, '−80');
    await tester.pumpAndSettle();
    await tester.testTextInput.receiveAction(TextInputAction.next);
    await _advance(tester);
    expect(buy, findsOneWidget);
    await tester.tapAt(const Offset(4, 4));
    await _advance(tester);
    expect(buy, findsNothing);
    expect(marketNq, findsNothing);
    expect(moodCalm, findsNothing);
  });

  testWidgets('changing one item by hand never starts the chain', (
    tester,
  ) async {
    await openForm(tester);
    await tester.tap(find.byKey(const ValueKey('trade-direction-selector')));
    await tester.pumpAndSettle();
    await tester.tap(buy);
    await _advance(tester);
    expect(marketNq, findsNothing,
        reason: 'a manual direction choice must not open the market menu');

    await tester.tap(find.byKey(const ValueKey('trade-market-input')));
    await tester.pumpAndSettle();
    await tester.tap(marketNq);
    await _advance(tester);
    expect(moodCalm, findsNothing,
        reason: 'a manual market choice must not open the mindset menu');
  });

  test('mindset keys are stored compatibly in the single mood string', () {
    expect(parseTradeMoodKeys(''), isEmpty);
    expect(parseTradeMoodKeys(null), isEmpty);
    expect(parseTradeMoodKeys('moodCalm'), ['moodCalm']);
    expect(parseTradeMoodKeys('moodTired,moodCalm'),
        ['moodCalm', 'moodTired'],
        reason: 'keys come back in catalogue order');
    expect(parseTradeMoodKeys('moodUnknown,moodCalm'), ['moodCalm']);
    expect(parseTradeMoodKeys('legacyUnknownKey'), isEmpty);
    expect(joinTradeMoodKeys(['moodCalm', 'moodTired']), 'moodCalm,moodTired');
    expect(tradeMoodIsUnrecorded(''), isTrue);
    expect(tradeMoodIsUnrecorded('moodUnknown'), isTrue);
    expect(tradeMoodIsUnrecorded('moodCalm,moodTired'), isFalse);
  });
}
