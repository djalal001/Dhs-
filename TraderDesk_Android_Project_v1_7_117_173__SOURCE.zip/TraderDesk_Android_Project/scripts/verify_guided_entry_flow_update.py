#!/usr/bin/env python3
"""Static regression checks for the 1.7.117+173 guided entry flow update.

Source-level checks only: Flutter/Dart are not run by this script.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
read = lambda rel: (ROOT / rel).read_text(encoding="utf-8")
FORM = read("lib/screens/trade_form_screen.dart")
CATALOG = read("lib/domain/trade_entry_catalog.dart")
TRADES = read("lib/screens/trades_screen.dart")
PUBSPEC = read("pubspec.yaml")
WORKFLOW = read(".github/workflows/android-build.yml")
FLOW_TEST = read("test/guided_entry_flow_test.dart")
ENTRY_TEST = read("test/entry_conditions_test.dart")
checks: list[tuple[str, bool]] = []


def check(name: str, result: bool) -> None:
    checks.append((name, bool(result)))


def section(text: str, start: str, end: str) -> str:
    a = text.index(start)
    return text[a:text.index(end, a)]


check("project version is 1.7.117+173", "version: 1.7.117+173" in PUBSPEC)
check("workflow names 1.7.117+173 and build 173 artifacts",
      "TraderDesk 1.7.117+173" in WORKFLOW
      and "traderdesk-1.7.117-build173-arm64-v8a-release" in WORKFLOW
      and "traderdesk-1.7.117-build173-arm64-dart-symbols" in WORKFLOW)
check("update report exists", (ROOT / "UPDATE_REPORT_1.7.117+173.md").is_file())

# 1. Profit / Loss words centred inside the result rectangle.
field = section(FORM, "Widget _resultAmountField", "Widget _numericField")
words = section(FORM, "Widget _resultSignWord(int sign)", "Widget _resultAmountField")
check("Arabic words ربح and خسارة are rendered", "'ربح'" in words and "'خسارة'" in words)
check("English words Profit and Loss are rendered", "'Profit'" in words and "'Loss'" in words)
check("each word takes an equal Expanded half, hairline between them, so the pair is centred",
      words.count("Expanded(") == 1 and "_resultSignWord(1)," in words and "_resultSignWord(-1)," in words and "width: 1," in words)
check("words overlay fills the whole field and each word is centred",
      "Positioned.fill(child: _resultSignWords())" in field and "child: Center(" in words)
check("label floats on the border while the words are shown",
      "showWords ? FloatingLabelBehavior.always : null" in field)
check("words only while no sign is chosen and entry is not a missed link",
      "_resultSign == null && !_hasEntryConditionsNoEntryLink" in field)
check("field stays the first Stack child so focus and text survive",
      re.search(r"Stack\(\s*children: \[\s*field,", field) is not None)
check("Profit writes + and Loss writes − through the existing handler",
      "onTap: () => _selectResultSign(sign)" in words
      and "final signCharacter = sign > 0 ? '+' : '−';" in FORM)
check("choosing a word raises the keyboard",
      "_resultFocusNode.requestFocus()" in section(FORM, "void _selectResultSign", "void _handleResultChanged"))
check("deleting the sign still brings the words back",
      "_resultSign = nextSign;" in section(FORM, "void _handleResultChanged", "String? _resultValidator"))
check("old small +/− buttons and sign prefix removed",
      "_resultSignChoiceButton" not in FORM and "_resultSignPrefix" not in FORM and "_showResultSignChoices" not in FORM)
check("test keys for the sign choices are unchanged",
      "'trade-result-sign-positive'" in words and "'trade-result-sign-negative'" in words)

# 2 + 3. Continue key.
check("result keyboard action is Continue", "textInputAction: TextInputAction.next," in field and "onEditingComplete: _handleResultContinue" in field)
cont = section(FORM, "void _handleResultContinue()", "void _handleExpectedLossContinue()")
check("profit moves straight into the expected-loss field",
      "if (sign > 0) {" in cont and "_expectedLossFocusNode.requestFocus();" in cont)
check("loss goes to the direction menu through the guided flow",
      "unawaited(_runEntryFlow());" in cont and "_resultFocusNode.unfocus();" in cont)
check("incomplete amount does not advance", "_parseResult() == null" in cont)
check("expected loss field has its own focus node and Continue key",
      "focusNode: _expectedLossFocusNode" in FORM and "onEditingComplete: _handleExpectedLossContinue" in FORM and "textInputAction: TextInputAction.next" in FORM)
check("expected loss Continue chains only when reached from the result field",
      "final inFlow = _flowPendingExpectedLoss;" in section(FORM, "void _handleExpectedLossContinue()", "Future<void> _runEntryFlow()"))
check("expected loss stays read-only for losses (unchanged)", "readOnly: (_parseResult() ?? 0) < 0" in FORM)

# 4 + 5. Direction -> market -> mindset.
flow = section(FORM, "Future<void> _runEntryFlow()", "void _toggleMood(String key)")
check("flow opens direction first", flow.index("'trade-direction-option'") < flow.index("'trade-market-option'") < flow.index("showButtonMenu()"))
check("choosing direction opens market, choosing market opens mindset",
      "if (side == null || !mounted) return;" in flow and "if (market == null || !mounted) return;" in flow)
check("dismissing any menu ends the chain", flow.count("== null") >= 2)
check("flow selects the direction directly (never toggles it off)", "onSelected: (value) => setState(() => _side = value)," in flow)
check("flow returns to the data tab first", "_activeFormSectionIndex = 0" in flow)
check("flow waits for keyboard and scrolls the anchor into view", "Duration(milliseconds: 300)" in flow and "Scrollable.ensureVisible" in flow)
check("flow skips forms whose direction is already set (editing)", "_side != null) return;" in flow)
check("chain is reachable only from the two Continue handlers",
      FORM.count("_runEntryFlow()") == 3)  # definition + two unawaited calls
check("manual direction choice keeps the original toggle and no chain",
      "() => _side = _side == value ? null : value" in FORM)
check("manual market choice has no chain", "onSelected: _selectMarket," in FORM and "void _selectMarket(String value) => setState(() => _symbol = value);" in FORM)
check("menu helper reports the selection", "Future<T?> _showCompactPopupChoice<T>" in FORM and "return selected;" in FORM)
check("mindset menu is opened through its own PopupMenuButton state", "findAncestorStateOfType<PopupMenuButtonState<String>>()" in flow and "_moodPopupAnchorKey" in FORM)

# Mindset: multi-select, layout untouched.
mood = section(FORM, "Widget _buildMindsetSelector", "Widget _collapsibleSelectionFieldLabel")
check("mindset keeps the PopupMenuButton > SizedBox > InputDecorator hierarchy",
      mood.index("return PopupMenuButton<String>(") < mood.index("child: SizedBox(") < mood.index("child: InputDecorator("))
check("mindset field keys, 72dp height and 30dp content are unchanged",
      "ValueKey('trade-mood-dropdown')" in mood and "ValueKey('trade-mood-field')" in mood
      and "ValueKey('trade-mood-field-surface')" in mood and "height: _tradeDataControlHeight" in mood
      and "height: _tradeDataContentHeight" in mood and "_blueSelectorDecoration(" in mood)
check("mindset rows keep keys, 42dp height and tint-only selection",
      "ValueKey('trade-mood-option-${item.key}')" in mood and "rowHeight: 42" in mood
      and "accent.withValues(alpha: .11)" in mood and "Icons.check" not in mood)
check("mindset rows toggle without closing; Done closes",
      "onTap: () => _toggleMood(item.key)" in mood and "Navigator.of(rowContext).pop<String>('done')" in mood)
toggle = section(FORM, "void _toggleMood(String key)", "String _moodFieldText()")
check("'Not recorded' is exclusive and empty selection falls back to it",
      "key == tradeMoodUnknownKey" in toggle and "next.remove(tradeMoodUnknownKey);" in toggle and "if (next.isEmpty) next.add(tradeMoodUnknownKey);" in toggle)
check("selection persists in the existing mood string (backward compatible)",
      "String get _mood => joinTradeMoodKeys(_moodKeys);" in FORM and "mood: _mood," in FORM
      and "parseTradeMoodKeys(trade?.mood)" in FORM and "final String mood;" in read("lib/models/trade.dart"))
check("catalog helpers parse, join and detect unrecorded", all(x in CATALOG for x in ["List<String> parseTradeMoodKeys", "String joinTradeMoodKeys", "bool tradeMoodIsUnrecorded"]))
check("saved views list every chosen mindset", TRADES.count("_moodSummary(context, trade.mood)") == 2 and "tradeMoodIsUnrecorded(trade.mood)" in TRADES)

# Tests ship with the update.
check("flow widget tests cover centring, signs, both outcomes, dismissal and manual edits",
      all(x in FLOW_TEST for x in ["centred in the empty result field", "Profit inserts + and Loss inserts", "winning trade: Continue moves", "losing trade: Continue opens direction", "dismissing a menu ends the guided chain", "changing one item by hand never starts the chain", "exclusive"]))
check("legacy mindset test updated for the multi-select menu", "trade-mood-done" in ENTRY_TEST)

passed = sum(1 for _, ok in checks if ok)
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + ": " + name)
print(f"\n{passed}/{len(checks)} checks passed")
raise SystemExit(0 if passed == len(checks) else 1)
