#!/usr/bin/env python3
"""Static regression checks for popup, field geometry and selected text."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))
check('release metadata is 1.7.110+166', 'version: 1.7.110+166' in PUBSPEC and 'TraderDesk 1.7.110+166' in WORKFLOW)
check('workflow artifacts use build156', 'traderdesk-1.7.110-build166-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.110-build166-arm64-dart-symbols' in WORKFLOW)
check('shared selected-item font token remains 14.5dp', 'const double _tradeDataItemFontSize = 14.5;' in FORM)
check('selected trade-data values retain the common font token', FORM.count('fontSize: _tradeDataItemFontSize') >= 7)
check('market/direction and mindset fields render plain selected text', '_selectedTradeDataValueDecoration' not in FORM and 'trade-mood-selected-value' in FORM and 'child: displayedValue' in FORM)
check('popup menu items retain all option labels', 'for (final value in values)' in FORM and 'labelFor(value)' in FORM)
check('selected popup row gets a slight accent tint without checkmark', 'accent.withValues(alpha: .11)' in FORM and 'Icons.check_rounded' not in FORM[FORM.index('Future<T?> _showCompactPopupChoice'):FORM.index('Widget _compactPopupChoice')])
check('mindset menu follows the original 1.7.92 width constraints', 'final popupWidth = constraints.maxWidth < 180' in FORM and 'constraints: BoxConstraints.tightFor(width: popupWidth)' in FORM)
check('mindset preserves original 42dp popup row height', '_MoodMenuRow(' in FORM[FORM.index('Widget _buildMindsetSelector'):FORM.index('Widget _setupSelectionField')] and 'rowHeight: 42' in FORM[FORM.index('Widget _buildMindsetSelector'):FORM.index('Widget _setupSelectionField')])
check('market-direction and mindset share exactly the same 72dp height', 'const double _tradeDataControlHeight = 72;' in FORM and 'height: _tradeDataControlHeight' in FORM and '_mindsetControlHeight' not in FORM and 'Mindset control bounds must match the Market / Direction rectangle exactly' in TESTS and 'moodSurfaceRect.top' in TESTS and 'moodSurfaceRect.bottom' in TESTS and 'closeTo(marketDirectionRect.top, .1)' in TESTS and 'closeTo(marketDirectionRect.bottom, .1)' in TESTS)
check('unrecorded mindset uses the muted placeholder tone', 'moodUnrecorded' in FORM and 'TdTokens.of(context).text2' in FORM)
check('all ordinary popups keep the shared trade-data surface', 'color: tdPopupMenuColor(Theme.of(context).brightness)' in FORM and 'shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness)' in FORM)
check('semantic dialogs retain contextual surfaces', 'tone.withValues(alpha: brightness == Brightness.dark ? .14 : .08)' in FORM and '_entryConditionsSurface(' in FORM[FORM.index('Future<T?> _showCenteredTradeChoiceDialog'):FORM.index('Future<String?> _showTimeframeSheet')] and 'dialogBorderColor.withValues(alpha: .56)' in FORM)
check('entry reason and condition labels use common font size', FORM.count('fontSize: _tradeDataItemFontSize') >= 7)
check('result sign is part of editable amount text', "RegExp(r'^[+\\-−]?[0-9]*[.,]?[0-9]*$')" in FORM and 'onChanged: _handleResultChanged' in FORM)
check('test covers delete-and-reselect result sign flow', 'the result sign can be deleted from the amount and chosen again' in TESTS)
failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
