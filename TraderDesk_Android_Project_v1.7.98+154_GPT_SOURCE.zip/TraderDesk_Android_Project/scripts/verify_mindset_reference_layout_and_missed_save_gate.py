#!/usr/bin/env python3
"""Regression checks for the 1.7.98+154 mindset reference layout and missed-trade save gate."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
SAVE_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
BUILD_INFO = (ROOT / "BUILD_INFO_AR.md").read_text(encoding="utf-8")

checks = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

start = FORM.index("Widget _buildMindsetSelector")
end = FORM.index("Widget _setupSelectionField", start)
mood = FORM[start:end]
row_start = FORM.index("key: const ValueKey('trade-entry-identifiers-row')")
row_end = FORM.index("key: const ValueKey('trade-anchor-selector')", row_start)
identifiers_row = FORM[row_start:row_end]

check("package version is 1.7.98+154", "version: 1.7.98+154" in PUBSPEC)
check("workflow version and artifact identity use build 154", "TraderDesk 1.7.98+154" in WORKFLOW and "traderdesk-1.7.98-build154-arm64-v8a-release" in WORKFLOW)
check("mindset selector uses the 1.7.92 PopupMenuButton wrapper", "return PopupMenuButton<String>(" in mood and "enabled: enabled" in mood)
check("mindset control uses the original direct SizedBox/InputDecorator structure", "key: const ValueKey('trade-mood-field')" in mood and "child: SizedBox(" in mood and "height: _tradeDataControlHeight" in mood and "child: InputDecorator(" in mood)
check("mindset has no extra KeyedSubtree or width wrapper", "KeyedSubtree" not in mood and "width: constraints.maxWidth" not in mood)
check("mindset popup preserves 42dp rows and the subtle selected row", "height: 42" in mood and "accent.withValues(alpha: .11)" in mood)
check("mindset and market/direction remain equal half-width columns", identifiers_row.count("width: marketControlWidth") >= 2 and "(constraints.maxWidth - identifierGap) / 2" in FORM)
check("layout test measures the actual mindset field surface", "find.byKey(const ValueKey('trade-mood-field'))" in ENTRY_TEST)
check("layout test compares width, height, and vertical position", all(token in ENTRY_TEST for token in ["moodRect.width", "moodRect.height", "moodRect.center.dy", "marketDirectionRect.width", "marketDirectionRect.height", "closeTo(8, .1)"]))
check("save rejects an unresolved missed outcome before creating Trade", "selectedClassification == TradeClassification.missed" in FORM and "_missedOutcome == null" in FORM and FORM.index("_missedOutcome == null") < FORM.index("final trade = Trade("))
check("save validation explains required win/loss choice in Arabic and English", "حدد ما إذا كانت الفرصة الضائعة رابحة أم خاسرة قبل حفظ الصفقة." in FORM and "Choose whether the missed opportunity was a win or loss before saving." in FORM)
check("widget test proves grey missed state cannot save", "Neutral grey is an unresolved state and cannot be saved." in SAVE_TEST and "savedTrade, isNull" in SAVE_TEST)
check("widget test proves the same missed trade can save after explicit outcome", "savedTrade!.missedOutcome, MissedTradeOutcome.win" in SAVE_TEST)
check("build metadata names exact 1.7.97+153 parent source", "TraderDesk_Android_Project_v1.7.97+153_GPT_SOURCE.zip" in BUILD_INFO)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + ": " + name)
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
