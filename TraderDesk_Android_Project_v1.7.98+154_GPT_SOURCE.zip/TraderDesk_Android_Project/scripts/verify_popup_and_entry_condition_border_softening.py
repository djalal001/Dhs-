#!/usr/bin/env python3
"""Regression checks for muted popup and saved Entry Conditions borders in 1.7.98+154."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP_THEME = (ROOT / 'lib/theme/app_theme.dart').read_text(encoding='utf-8')
DETAIL_PALETTE = (ROOT / 'lib/theme/trade_detail_palette.dart').read_text(encoding='utf-8')
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
PALETTE_TEST = (ROOT / 'test/trade_detail_palette_test.dart').read_text(encoding='utf-8')
DETAIL_TEST = (ROOT / 'test/trade_detail_layout_test.dart').read_text(encoding='utf-8')
ENTRY_TEST = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []
def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))

check('release version is 1.7.98+154', 'version: 1.7.98+154' in PUBSPEC)
check('workflow identifies 1.7.98+154/build154', 'TraderDesk 1.7.98+154' in WORKFLOW and 'traderdesk-1.7.98-build154-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.98-build154-arm64-dart-symbols' in WORKFLOW)
check('global popup border remains unchanged outside Trade Data', 'const Color(0xFF315C8C)' in APP_THEME and 'const Color(0xFFB9CDEA)' in APP_THEME)
check('Trade Data dark popup border uses approved muted blue-grey', 'const Color(0xFF294055)' in APP_THEME)
check('Trade Data light popup border uses muted neutral blue-grey', 'const Color(0xFFC7D1DC)' in APP_THEME)
check('Trade Data popup border width is reduced to .8', 'tdTradeDataPopupMenuBorderColor(brightness)' in APP_THEME and 'width: .8' in APP_THEME)
check('centered choice dialogs keep the softened common border for neutral selectors and contextual border for semantic selectors', 'shape: accentTone == null' in FORM and 'tdTradeDataPopupMenuShape(brightness)' in FORM and 'BorderSide(color: dialogBorderColor, width: .8)' in FORM)
check('neutral popup divider opacity is softened and semantic divider keeps its original contextual alpha', 'tdTradeDataPopupMenuBorderColor(brightness)\n                                .withValues(alpha: .48)' in FORM and 'dialogBorderColor.withValues(alpha: .56)' in FORM)
check('anchor dialog divider opacity is softened', 'tdTradeDataPopupMenuBorderColor(brightness)\n                          .withValues(alpha: .48)' in FORM)
check('normal saved entry-condition edge is muted', 'entryConditionsFieldEdge = Color(0xFF344653)' in DETAIL_PALETTE)
check('linked saved entry-condition edge is muted', 'linkedEntryConditionsFieldEdge = Color(0xFF453B56)' in DETAIL_PALETTE)
check('linked outer detail border is muted', 'linkedEntryConditionsPanelBorderDark = Color(0xFF4B425B)' in DETAIL_PALETTE)
check('linked divider is muted', 'linkedEntryConditionsPanelDividerDark = Color(0xFF41384F)' in DETAIL_PALETTE)
check('reverse-signal chips use the same fill and edge color in normal and linked states', 'entryConditionsChipDark' in TRADES and 'entryConditionsChipEdgeDark' in TRADES and 'linkedEntryConditionsChipDark' in TRADES and 'linkedEntryConditionsChipEdgeDark' in TRADES)
bounce_detail = TRADES.split("label: arabic ? 'منطقة الارتداد'", 1)[1].split('if (trade.executionJournal', 1)[0] if "label: arabic ? 'منطقة الارتداد'" in TRADES else ''
check('Bounce area saved chips keep the original blue fill and edge even when Opposing signals is linked', 'fill: TradeDetailPalette.entryConditionsFieldDark' in bounce_detail and 'optionFill: TradeDetailPalette.entryConditionsChipDark' in bounce_detail and 'optionEdge: TradeDetailPalette.entryConditionsChipEdgeDark' in bounce_detail and 'linkedEntryConditions' not in bounce_detail)
check('palette chip edges exactly match chip fills', 'entryConditionsChipEdgeDark = Color(0xFF1E3041)' in DETAIL_PALETTE and 'linkedEntryConditionsChipEdgeDark = Color(0xFF3B334B)' in DETAIL_PALETTE)
check('palette widget tests assert Trade Data popup border color and width', 'trade-data popup border uses the approved muted outline' in PALETTE_TEST and 'const Color(0xFF294055)' in PALETTE_TEST and 'shape.side.width, .8' in PALETTE_TEST)
check('saved detail UI test asserts muted purple panel border', 'linkedEntryConditionsPanelBorderDark' in DETAIL_TEST and 'linked Entry Conditions panel outline remains muted' in DETAIL_TEST)
check('saved detail UI test asserts violet opposing-signal field and blue Bounce area', 'a practically linked opposing signal uses the saved violet surface' in DETAIL_TEST and 'saved opposing-signal field outline remains muted' in DETAIL_TEST and 'Bounce area chips keep their original blue surface' in DETAIL_TEST)
check('normal Entry Conditions chips are tested against their own surface edge', 'should not have a bright contrasting outline' in DETAIL_TEST and 'trade-detail-entry-condition-value-HNS عكسي' in DETAIL_TEST)
check('Trade Data form theme uses the softened popup shape', 'popupMenuTheme: baseTheme.popupMenuTheme.copyWith(' in FORM and 'shape: tdTradeDataPopupMenuShape(baseTheme.brightness)' in FORM)
check('popup widget tests assert the approved border color', ENTRY_TEST.count('const Color(0xFF294055)') >= 3)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
