#!/usr/bin/env python3
"""Regression checks for Touch 2 dialog defaults/context and final labels in 1.7.96+152."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
STRINGS = (ROOT / "lib/l10n/app_strings.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
BREAKOUT_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
checks = []
def check(label, condition): checks.append((label, bool(condition)))

check("new or non-Touch2 S/R bounce does not preselect Continue", "current?.touch2 == true" in FORM and "? true\n            : null" in FORM)
check("non-Touch2 BREAKOUT does not preselect Continue", "isEditingSameBreakout && tradeEntryUsesTouch2(currentReason)\n          ? true\n          : null" in FORM)
check("saved Touch 2 is restored when editing", "selectedTouch2" in FORM and "tradeEntryUsesTouch2(currentReason)" in FORM)
check("BUY BREAKOUT title is RBS Touch — optional", "TradeSide.buy => 'RBS'" in FORM and "'$scenario Touch — اختياري'" in FORM)
check("SELL BREAKOUT title is SBR Touch — optional", "TradeSide.sell => 'SBR'" in FORM)
check("S/R Touch2 title shows Support/Resistan context", "TradeSide.buy => 'Support'" in FORM and "TradeSide.sell => 'Resistan'" in FORM)
check("both Touch2 call sites supply current direction", FORM.count("side: _side,") >= 2)
check("Bearish confirmation localization is title-cased in both locales", STRINGS.count("'confirmBearishEngulfing': 'Bearish Engulfing'") == 2)
check("form confirmation formatter uses Bearish Engulfing", "return 'Bearish Engulfing';" in FORM)
check("legacy lowercase and new title-case keys remain readable", "type == 'Bearish engulfing'" in CATALOG and "type == 'Bearish Engulfing'" in CATALOG)
check("S/R display uses Resistan rather than Resistance", "'ارتداد من Resistan'" in CATALOG and "'Bounce from Resistan'" in CATALOG)
check("reverse S/R display uses Resistan rather than Resistance", "'Resistan عكسي'" in CATALOG and "'Reverse Resistan'" in CATALOG)
check("S/R widget tests assert neutral Continue and contextual BUY/SELL titles", "ارتداد من Support Touch — اختياري" in ENTRY_TEST and "ارتداد من Resistan Touch — اختياري" in ENTRY_TEST and "the user chooses it" in ENTRY_TEST)
check("BREAKOUT widget tests assert neutral Continue and direction-aware headings", "RBS Touch — اختياري" in BREAKOUT_TEST and "SBR Touch — اختياري" in BREAKOUT_TEST and "skip-touch2-directionalBreakout" in BREAKOUT_TEST)
check("catalog tests cover Resistan and both Bearish Engulfing legacy casings", "ارتداد من Resistan Touch 2 15MIN" in CATALOG_TEST and "Reverse Resistan" in CATALOG_TEST and "Bearish Engulfing" in CATALOG_TEST)
check("release version is 1.7.96+152", "version: 1.7.96+152" in PUBSPEC)

for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
failed = [label for label, ok in checks if not ok]
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
