from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
test = (root / "test/entry_conditions_test.dart").read_text(encoding="utf-8")

checks = {
    "Mindset InputDecorator has a stable test key": "trade-mood-input-decorator" in source,
    "Mindset decoration fixes its own painted container to the shared height": (
        "constraints: const BoxConstraints.tightFor(" in source
        and "height: _tradeDataControlHeight" in source
    ),
    "Market/direction remains on its existing shared 72dp control": (
        "height: _tradeDataControlHeight" in source
        and "trade-market-direction-field" in source
    ),
    "Regression test measures the Mindset InputDecorator, not just the tap target": (
        "find.byKey(\n      const ValueKey('trade-mood-input-decorator')" in test
    ),
    "Regression test compares actual rectangle height and painted bounds": (
        "moodInputRect.height" in test
        and "marketDirectionRect.height" in test
        and "moodInputRenderBox.paintBounds.height" in test
        and "marketInputRenderBox.paintBounds.height" in test
    ),
    "Regression test also verifies same width and top alignment": (
        "moodInputRect.width" in test and "moodInputRect.top" in test
    ),
}

for label, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {label}")

if not all(checks.values()):
    raise SystemExit(1)
print(f"\n{sum(checks.values())}/{len(checks)} checks passed")
