import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/main.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/state/app_controller.dart';

void main() {
  late Directory temp;
  late AppController app;
  late TradingAccount account;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp(
      'trader_desk_trades_filter_',
    );
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    account = TradingAccount(
      id: 'trades-filter-account',
      name: 'Filter account',
      type: AccountType.demo,
      startingBalance: 10000,
      currency: 'USD',
      createdAt: DateTime(2024, 1, 1),
    );
    app.accounts = [account];
    app.selectedAccountId = account.id;
    app.trades = [
      _trade(id: 'winner', result: 25),
      _trade(id: 'loser', result: -12),
      // A saved setup with a no-entry reason belongs to the missed filter,
      // irrespective of any legacy result amount on the record.
      _trade(
        id: 'missed-by-reason',
        result: 7,
        noEntryReasons: const ['fearLossNoHistory'],
      ),
      _trade(
        id: 'missed-by-fear-journal',
        result: -3,
        executionStatuses: const [TradeExecutionStatus.avoidedEntryBecauseFear],
      ),
      _trade(
        id: 'missed-by-conditions-journal',
        result: 0,
        executionStatuses: const [TradeExecutionStatus.entryConditionsNotMet],
      ),
      _trade(
        id: 'missed-by-area-journal',
        result: 9,
        executionStatuses: const [
          TradeExecutionStatus.missedHigherTimeframeBounceArea,
          TradeExecutionStatus.missedLowerTimeframeBounceArea,
          TradeExecutionStatus.missedTrendlineFromCandleWicks,
        ],
      ),
      _trade(
        id: 'missed-by-review-keys',
        result: 6,
        executionReviewKeys: const ['noBreakoutPositiveClose'],
      ),
    ];
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(390, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }

  Future<void> openTrades(WidgetTester tester) async {
    await tester.pumpWidget(TraderDeskApp(controller: app));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الصفقات').last);
    await tester.pumpAndSettle();
  }

  testWidgets('missed filter includes no-entry reasons and missed journal statuses', (
    tester,
  ) async {
    usePhoneViewport(tester);
    await openTrades(tester);

    expect(find.byKey(const ValueKey('trades-filter-all')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-wins')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-losses')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-missed')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-summary-missed-by-reason')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-by-fear-journal')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-by-conditions-journal')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-by-area-journal')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-summary-missed-by-review-keys')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('trade-summary-winner')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-loser')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('trades-filter-wins')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-winner')), findsOneWidget);
    for (final missedId in [
      'missed-by-reason',
      'missed-by-fear-journal',
      'missed-by-conditions-journal',
      'missed-by-area-journal',
      'missed-by-review-keys',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$missedId')), findsNothing);
    }

    await tester.tap(find.byKey(const ValueKey('trades-filter-losses')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-loser')), findsOneWidget);
    for (final missedId in [
      'missed-by-reason',
      'missed-by-fear-journal',
      'missed-by-conditions-journal',
      'missed-by-area-journal',
      'missed-by-review-keys',
    ]) {
      expect(find.byKey(ValueKey('trade-summary-$missedId')), findsNothing);
    }
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'one selected period filters All, Wins, Losses and Missed together',
    (tester) async {
      usePhoneViewport(tester);
      final today = DateTime.now();
      app.trades = [
        _trade(id: 'recent-win', result: 12, tradedAt: today),
        _trade(
          id: 'old-win',
          result: 18,
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(
          id: 'recent-loss',
          result: -8,
          tradedAt: today.subtract(const Duration(days: 1)),
        ),
        _trade(
          id: 'old-loss',
          result: -5,
          tradedAt: DateTime(2020, 1, 4),
        ),
        _trade(
          id: 'recent-missed',
          result: 4,
          noEntryReasons: const ['fearLossNoHistory'],
          tradedAt: today.subtract(const Duration(days: 2)),
        ),
        _trade(
          id: 'old-missed-journal',
          result: -2,
          executionStatuses: const [
            TradeExecutionStatus.missedHigherTimeframeBounceArea,
          ],
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(
          id: 'mid-month-win-missed-key',
          result: 5,
          executionReviewKeys: const ['noTrendlineSupportsEntryZone'],
          tradedAt: today.subtract(const Duration(days: 15)),
        ),
      ];
      await openTrades(tester);

      final periodMenu = find.byKey(const ValueKey('trades-period-menu'));
      await tester.ensureVisible(periodMenu);
      await tester.tap(periodMenu);
      await tester.pumpAndSettle();
      for (final period in ['all', 'week', 'month', 'year', 'custom']) {
        expect(find.byKey(ValueKey('trades-period-$period')), findsOneWidget);
      }

      // Choosing a date range does not force a category; it is shared by
      // whichever category the trader selects next.
      await tester.tap(find.byKey(const ValueKey('trades-period-week')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('trades-filter-all')),
        findsOneWidget,
      );
      expect(find.byKey(const ValueKey('trade-summary-recent-win')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-win')), findsNothing);
      expect(find.byKey(const ValueKey('trade-summary-recent-loss')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-loss')), findsNothing);
      expect(find.byKey(const ValueKey('trade-summary-recent-missed')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-missed-journal')), findsNothing);
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsNothing,
      );

      // Changing the shared period updates the currently visible category too.
      await tester.tap(find.byKey(const ValueKey('trades-period-menu')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('trades-period-month')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsOneWidget,
      );

      await tester.tap(find.byKey(const ValueKey('trades-filter-wins')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('trade-summary-recent-win')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-win')), findsNothing);
      expect(
        find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')),
        findsNothing,
      );

      await tester.tap(find.byKey(const ValueKey('trades-filter-losses')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('trade-summary-recent-loss')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-loss')), findsNothing);

      await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('trade-summary-recent-missed')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-mid-month-win-missed-key')), findsOneWidget);
      expect(find.byKey(const ValueKey('trade-summary-old-missed-journal')), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'floating add button fades while scrolling and becomes clear at rest',
    (tester) async {
      usePhoneViewport(tester);
      app.trades = List.generate(
        24,
        (index) => _trade(
          id: 'scroll-$index',
          result: index.isEven ? 10 : -5,
        ),
      );
      await openTrades(tester);

      final button = find.byKey(const ValueKey('trades-add-floating'));
      final opacity = find.byKey(
        const ValueKey('trades-add-floating-opacity'),
      );
      expect(button, findsOneWidget);
      expect(find.byKey(const ValueKey('trades-list')), findsOneWidget);
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);

      await tester.drag(
        find.byKey(const ValueKey('trades-list')),
        const Offset(0, -380),
      );
      await tester.pump();
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.30);

      await tester.pump(const Duration(milliseconds: 800));
      await tester.pump(const Duration(milliseconds: 200));
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);
      final listRect = tester.getRect(
        find.byKey(const ValueKey('trades-list')),
      );
      final navRect = tester.getRect(
        find.byKey(const ValueKey('td-bottom-navigation')),
      );
      final fabRect = tester.getRect(button);
      expect(listRect.bottom, closeTo(navRect.top, 1));
      expect(fabRect.left, lessThan(listRect.left + 60));
      expect(fabRect.bottom, lessThanOrEqualTo(listRect.bottom));
      expect(tester.takeException(), isNull);
    },
  );
}

Trade _trade({
  required String id,
  required double result,
  List<String> noEntryReasons = const [],
  List<TradeExecutionStatus> executionStatuses = const [],
  List<String> executionReviewKeys = const [],
  DateTime? tradedAt,
}) => Trade(
  id: id,
  accountId: 'trades-filter-account',
  market: 'EURUSD',
  reason: 'Breakout',
  result: result,
  riskPercent: 0.25,
  side: TradeSide.buy,
  confirmation: 'confirmTechnical',
  sequence: '',
  mood: 'moodCalm',
  tradedAt: tradedAt ?? DateTime(2024, 1, 1),
  noEntryReasons: noEntryReasons,
  executionReviewKeys: executionReviewKeys,
  executionJournal: executionStatuses
      .map((status) => TradeExecutionJournalEntry(status: status))
      .toList(growable: false),
);
