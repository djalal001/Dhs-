#!/usr/bin/env python3
"""Static regression checks for the 1.7.107+163 update:
1) analysis-quality summary = sentence line + chosen items as plain text below it
   (form and saved trade); 2) «أسباب عدم الدخول» redesigned as two side-by-side
   sections (psychological / structural).

Static only: it reads the source files. It does not run Flutter."""
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
rd = lambda p: (ROOT / p).read_text(encoding="utf-8")
CATALOG = rd("lib/domain/trade_entry_catalog.dart")
ZONES = rd("lib/widgets/trade_decision_zones.dart")
NOENTRY = rd("lib/widgets/trade_no_entry_zones.dart")
FORM = rd("lib/screens/trade_form_screen.dart")
TRADES = rd("lib/screens/trades_screen.dart")
PUBSPEC = rd("pubspec.yaml")
WORKFLOW = rd(".github/workflows/android-build.yml")
T_ZONES = rd("test/trade_no_entry_zones_test.dart")
T_DEC = rd("test/trade_decision_zones_test.dart")
T_SUM = rd("test/trade_behavior_summary_test.dart")
T_CAT = rd("test/trade_entry_catalog_test.dart")

checks: list[tuple[str, bool]] = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

def block(src: str, start: str, end: str) -> str:
    return src.split(start, 1)[1].split(end, 1)[0]

# --- release metadata
check("pubspec version is 1.7.107+163", "version: 1.7.107+163" in PUBSPEC)
check("workflow identity updated", "TraderDesk 1.7.107+163" in WORKFLOW and "traderdesk-1.7.107-build163-arm64-v8a-release" in WORKFLOW)
check("update report exists", (ROOT / "UPDATE_REPORT_1.7.107+163.md").exists())

# --- 1) analysis summary
summary = block(ZONES, "class DecisionSelectionSummary", "class DecisionOptionTile")
check("summary: sentence is its own widget above the items (Column, then items)", "if (sentence != null) ...[" in summary and "const SizedBox(height: 8)" in summary and "items," in summary)
check("summary: items are plain Text in a Wrap with a wide gap (no chip box)", "Wrap(" in summary and "spacing: 18" in summary and "BorderRadius.circular(9)" not in summary)
check("form analysis summary uses the shared summary with the sentence", "DecisionSelectionSummary(" in ZONES and "tradeAnalysisMissedSentence(" in ZONES and "_AnalysisSummary" not in ZONES)
check("saved trade: analysis items are rendered inline", "_SavedInlineSelection(" in TRADES and "inline: category.id == 'analysis'" in TRADES and "trade-review-analysis-inline" in TRADES)
check("saved trade: sentence still comes from the shared function", "tradeAnalysisMissedSentence(count: keys.length" in TRADES)

# --- 2) no-entry catalog
psy = block(CATALOG, "const tradeNoEntryPsychologicalOptions", "];")
stru = block(CATALOG, "const tradeNoEntryStructuralOptions", "];")
psy_texts = [
    "خوف من تكرار الخسارة بعد خسارة سابقة",
    "خوف من خسارة الأرباح بعد صفقة رابحة",
    "خوف من الخسارة دون وجود ربح أو خسارة سابقة",
    "تردد بسبب عدم وضوح السيناريو",
    "خوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة",
]
stru_texts = [
    "كسر وإغلاق إيجابي ضعيف",
    "لا يوجد Trendline يدعم منطقة دخول",
    "وجود منطقة اعتراض قريبة من تأكيد دخول",
    "سيولة عالية تجاوز سعر تأكيد دخول قليلًا وعاد إليها",
]
for t in psy_texts: check(f"psychological text present: {t}", f"'{t}'" in psy)
for t in stru_texts: check(f"structural text present: {t}", f"'{t}'" in stru)
check("psychological order is the requested one", [psy.index(t) for t in psy_texts] == sorted(psy.index(t) for t in psy_texts))
check("structural order is the requested one", [stru.index(t) for t in stru_texts] == sorted(stru.index(t) for t in stru_texts))
keys_old = ["fearRepeatLossAfterLoss", "fearGivingBackProfit", "fearLossNoHistory", "hesitationUnclearScenario", "waitedDeeperRetestDespiteConfirmation"]
check("the five original storage keys are unchanged", all(f"'{k}'" in psy for k in keys_old))
new_keys = re.findall(r"TradeEntryOption\('(noEntry\w+)'", stru)
check("four new structural keys, prefixed noEntry", len(new_keys) == 4 and len(set(new_keys)) == 4)
legacy = block(CATALOG, "const tradeLegacyReviewOptions", "];")
check("new keys do not collide with legacy analysis keys", not any(f"'{k}'" in legacy for k in new_keys))
check("two groups with the requested titles", "titleAr: 'أسباب نفسية'" in CATALOG and "titleAr: 'أسباب هيكلية'" in CATALOG and "const tradeNoEntryGroups" in CATALOG)
check("flat tradeNoEntryOptions still exists (9 = 5 + 4)", "const tradeNoEntryOptions = <TradeEntryOption>[\n  ...tradeNoEntryPsychologicalOptions,\n  ...tradeNoEntryStructuralOptions,\n];" in CATALOG)

# --- 2) no-entry widget + form
check("two tabs share the Decisions tab component", "DecisionZoneTab(" in NOENTRY and "no-entry-zone-tab-" in NOENTRY)
check("tiles share the Decisions tile component and keep the old keys", "DecisionOptionTile(" in NOENTRY and "ValueKey('no-entry-${group.options[i].key}')" in NOENTRY and "trade-behavior-option-surface-${group.options[i].key}" in NOENTRY)
check("tile text keeps the 14.5 size of the other behavior rows", "_labelFontSize = 14.5" in NOENTRY)
check("folding summary lists the chosen reasons one per line", "stacked: true" in NOENTRY and "DecisionSelectionSummary(" in NOENTRY)
check("fold only when something is selected", "selectedOptions.isNotEmpty" in NOENTRY)
check("slide switch without dialog", "SlideTransition" in NOENTRY and "showDialog" not in NOENTRY and "showModalBottomSheet" not in NOENTRY)
beh = block(FORM, "Widget _buildBehaviorCard", "Widget _insetBehaviorSection")
noentry_section = beh.split("أسباب عدم الدخول", 1)[1]
check("form renders TradeNoEntryZones inside the same expansion", "TradeNoEntryZones(" in noentry_section and "headerKey: _noEntryConnectorAnchorKey" in beh)
check("form no longer renders the flat no-entry list", "for (final option in tradeNoEntryOptions)" not in beh)
check("selection still goes through _toggleSet(_noEntryReasons …)", "_toggleSet(\n              _noEntryReasons," in beh)
check("section state survives the expansion tile closing", "_noEntryZoneIndex" in FORM and "_noEntryCollapsedZones" in FORM)
check("commitment section is still the previous row design", "_selectionRow(" in beh and "tradeCommitmentOptions" in beh)
check("decisions area untouched (TradeDecisionZones still wired)", "TradeDecisionZones(" in beh)

# --- saved trade
check("saved trade groups no-entry by section + legacy bucket", "for (final group in tradeNoEntryGroups)" in TRADES and "'legacy'" in TRADES)
check("saved no-entry tiles carry no artwork", "showArtwork: false" in TRADES)

# --- tests were written
check("widget test file for the new section exists with 8 tests", T_ZONES.count("testWidgets(") == 8)
check("decision zones test covers sentence-above-items layout", "sentence first and the items below it" in T_DEC)
check("summary test covers saved inline layout and groups", "trade-review-analysis-inline" in T_SUM and "أسباب هيكلية" in T_SUM)
check("catalog test covers the two sections", "psychological and structural" in T_CAT)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(("PASS" if ok else "FAIL") + ": " + label)
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed))
    sys.exit(1)
