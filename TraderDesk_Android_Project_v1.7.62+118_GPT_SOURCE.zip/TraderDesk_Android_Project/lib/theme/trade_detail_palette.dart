import 'package:flutter/material.dart';

/// Deliberately preserved colors from TraderDesk 1.7.17+73.
/// These saved-trade panels keep their established dark surfaces and accents.
abstract final class TradeDetailPalette {
  static const dataTone = Color(0xFF8AB4D9);

  /// Slightly stronger than the data-panel accent for small field headings.
  static Color dataLabelTone(Brightness brightness) =>
      brightness == Brightness.dark
          ? const Color(0xFF94BDE2)
          : const Color(0xFF355F86);

  static const dataSurfaceDark = Color(0xFF2B3B4C);
  static const dataFieldDark = Color(0xFF243140);
  static const dataFieldEdge = Color(0xFF425569);

  /// Shared accent of the saved Entry Conditions panel and its two headings.
  static const entryConditionsTone = Color(0xFF78AFC3);

  static Color entryConditionsLabelTone(Brightness brightness) =>
      brightness == Brightness.dark
          ? entryConditionsTone
          : const Color(0xFF356B7F);

  static const reviewTone = Color(0xFFB7A6F2);
  static const decisionTone = Color(0xFFC6A071);
  static const commitmentTone = Color(0xFF55C99A);
  static const noEntryTone = Color(0xFFB69AF0);
  static const reviewOuterDark = Color(0xFF292B36);
  static const reviewDecisionDark = Color(0xFF242526);
  static const reviewCommitmentDark = Color(0xFF172F2F);
  static const reviewNoEntryDark = Color(0xFF2A2635);
  static const reviewDecisionOptionDark = Color(0xFF383638);
  static const reviewCommitmentOptionDark = Color(0xFF203B39);
  static const reviewNoEntryOptionDark = Color(0xFF373047);
}
