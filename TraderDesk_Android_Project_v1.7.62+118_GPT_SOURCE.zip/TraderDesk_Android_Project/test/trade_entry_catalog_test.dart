import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';

void main() {
  test('opposing-signal selector exposes the four requested categories', () {
    expect(
      tradeReverseSignalOptions.map((option) => option.key).toList(),
      ['reverseSr', 'reverseSdZone', 'reverseHns', 'reverseLongCandleWick'],
    );
    expect(
      tradeReverseSignalOptions.map((option) => option.ar).toList(),
      ['S/R عكسي', 'S - D Zone عكسي', 'HNS عكسي', 'ذيل شمعة طويل عكسي'],
    );
  });

  test(
    'reverse S/R role reversal and S-D categories resolve from trade direction',
    () {
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.buy,
        ),
        'Support عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Resistance عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSdZone',
          arabic: true,
          side: TradeSide.buy,
        ),
        'Supply Zone',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSdZone',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Demand Zone',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.buy,
        ),
        'Reverse Support',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.sell,
        ),
        'Reverse Resistance',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseHns',
          arabic: true,
          side: TradeSide.buy,
        ),
        'HNS عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseLongCandleWick',
          arabic: true,
          side: TradeSide.sell,
        ),
        'ذيل شمعة طويل عكسي',
      );
    },
  );

  test('legacy opposing-signal records remain readable', () {
    expect(
      tradeReverseSignalDisplayLabel(
        optionKey: 'negativeCloseAgainstDirection', arabic: true,
      ),
      'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول',
    );
    expect(
      tradeReverseSignalDisplayLabel(
        optionKey: 'strongRejectionWickAgainstDirection', arabic: true,
      ),
      'نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة',
    );
  });

  test('updates the no-entry reason text without changing its saved key', () {
    final option = tradeNoEntryOptions.singleWhere(
      (item) => item.key == 'waitedDeeperRetestDespiteConfirmation',
    );
    expect(
      option.ar,
      'الخوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة.',
    );
    expect(
      option.en,
      'Fear of a deep correction because the entry confirmation was far from the zone.',
    );
  });

  test('includes RFS and SFR as direct timeframe-based entry reasons', () {
    final keys = tradeEntryReasons.map((option) => option.key).toSet();

    expect(keys, containsAll(['SBR', 'RBS', 'RFS', 'SFR']));
    expect(keys, isNot(contains('SBR Touch 2')));
    expect(keys, isNot(contains('RBS Touch 2')));
  });

  test('defines the reverse-signal and bounce-area option lists independently', () {
    expect(tradeReverseSignalOptions.map((item) => item.key), [
      'reverseSr',
      'reverseSdZone',
      'reverseHns',
      'reverseLongCandleWick',
    ]);
    expect(tradeBounceZoneOptions.map((item) => item.key), [
      'bounceFromSrZone',
      'internalLiquiditySweep',
      'majorStructureLiquiditySweep',
      'bounceFromTrendline',
      'bounceFromTrendlineAndSupplyZone',
    ]);
  });

  test('defines the five single-choice Anchor references', () {
    expect(
      tradeAnchorOptions.map((item) => item.en).toList(),
      [
        'Key Level',
        'Supply Zone',
        'Demand Zone',
        'Bullish Engulfing',
        'Bearish engulfing',
      ],
    );
    expect(tradeAnchorOptions.map((item) => item.key).toSet().length, 5);
  });


  test('new opposing signal categories use the existing setup JSON shape', () {
    for (final key in [
      'reverseSr',
      'reverseSdZone',
      'reverseHns',
      'reverseLongCandleWick',
    ]) {
      final selected = TradeEntryConditionSetup(
        optionKey: key,
        timeframe: '15MIN',
      );
      expect(TradeEntryConditionSetup.fromJson(selected.toJson()), selected);
      expect(selected.toJson().keys, containsAll(['optionKey', 'timeframe']));
    }
  });

  test('reverse labels in saved setup follow the selected direction', () {
    const srSetup = TradeEntryConditionSetup(
      optionKey: 'reverseSr',
      timeframe: '15MIN',
    );
    const sdSetup = TradeEntryConditionSetup(
      optionKey: 'reverseSdZone',
      timeframe: '30MIN',
    );

    expect(
      formatTradeEntryConditionSetupLabel(
        setup: srSetup, optionLabel: 'S/R عكسي', arabic: true, side: TradeSide.buy,
      ),
      'Support عكسي 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: srSetup, optionLabel: 'S/R عكسي', arabic: true, side: TradeSide.sell,
      ),
      'Resistance عكسي 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: sdSetup, optionLabel: 'S - D Zone عكسي', arabic: true, side: TradeSide.buy,
      ),
      'Supply Zone 30MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: sdSetup, optionLabel: 'S - D Zone عكسي', arabic: true, side: TradeSide.sell,
      ),
      'Demand Zone 30MIN',
    );
  });

  test('formats entry-condition labels without separator dots or duplicated names', () {
    const combined = TradeEntryConditionSetup(
      optionKey: 'bounceFromTrendlineAndSupplyZone',
      timeframe: '30MIN',
      secondaryTimeframe: '5MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: combined,
        optionLabel: 'ارتداد من ترند لاين و Supply Zone',
        arabic: true,
      ),
      'ارتداد من Trend Line 30MIN - Supply Zone 5MIN',
    );
    const regular = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regular,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
      ),
      'ارتداد من منطقة S/R 15MIN',
    );
  });

  test('S/R bounce label follows direction only after a side is selected', () {
    const setup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );

    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
      ),
      'ارتداد من منطقة S/R 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من دعم 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من مقاومة 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'Bounce from an S/R zone',
        arabic: false,
        side: TradeSide.buy,
      ),
      'Bounce from support 15MIN',
    );
  });

  test('S/R bounce Touch 2 is shown as an optional saved qualifier', () {
    const setup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
      touch2: true,
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من مقاومة - لمسة 2 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'Bounce from an S/R zone',
        arabic: false,
        side: TradeSide.buy,
      ),
      'Bounce from support - Touch 2 15MIN',
    );
  });

  test('S/R Touch 2 survives model JSON and older records default to false', () {
    const selected = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '30MIN',
      touch2: true,
    );
    expect(TradeEntryConditionSetup.fromJson(selected.toJson()), selected);
    expect(
      TradeEntryConditionSetup.fromJson({
        'optionKey': 'bounceFromSrZone',
        'timeframe': '30MIN',
      }).touch2,
      isFalse,
    );
  });

  test(
    'entry reason and confirmation labels place timeframe with a plain space',
    () {
      expect(
        const TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '5MIN').label,
        'RBS Touch 2 5MIN',
      );
      expect(
        const TradeConfirmationSetup(
          type: 'Breakout–Pullback',
          timeframe: '15MIN',
        ).label,
        'Breakout–Pullback 15MIN',
      );
    },
  );

  test('Touch 2 qualifier is supported only for SBR and RBS', () {
    expect(tradeEntryTouch2EligibleReasons, {'SBR', 'RBS'});
    expect(tradeEntryBaseReason('SBR Touch 2'), 'SBR');
    expect(tradeEntryBaseReason('RBS Touch 2'), 'RBS');
    expect(tradeEntryUsesTouch2('SBR Touch 2'), isTrue);
    expect(tradeEntryUsesTouch2('RBS'), isFalse);
    expect(tradeEntryReasonWithTouch2('SBR', true), 'SBR Touch 2');
    expect(tradeEntryReasonWithTouch2('RBS', false), 'RBS');
    expect(tradeEntryReasonWithTouch2('RFS', true), 'RFS');
    expect(tradeEntryReasonWithTouch2('SFR', true), 'SFR');
  });
}
