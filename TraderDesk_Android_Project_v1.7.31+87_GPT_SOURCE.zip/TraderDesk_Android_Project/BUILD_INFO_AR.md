# معلومات البناء والتسليم — TraderDesk 1.7.31+87

- رقم الإصدار: `1.7.31`؛ رقم البناء: `87`.
- اسم الحزمة: `com.traderdesk.trader_desk`.
- نوع التسليم: مشروع Flutter كامل بصيغة ZIP، وليس APK.
- نقطة البداية: المشروع المصدر للإصدار `1.7.30+86`.
- لم تتوفر أدوات Flutter أو Dart SDK في بيئة التحرير؛ لذلك لم تُشغّل أوامر `flutter pub get` أو `flutter analyze` أو `flutter test` أو `flutter build apk --release`.
- لا يتضمن هذا التسليم APK، ولا ندّعي نجاح بناء أو تشغيل التطبيق على جهاز.
