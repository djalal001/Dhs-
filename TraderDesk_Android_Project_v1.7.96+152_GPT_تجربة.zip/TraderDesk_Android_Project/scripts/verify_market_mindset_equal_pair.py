#!/usr/bin/env python3
"""Static regression checks for equal market/direction and mindset fields."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
REPORT = (ROOT / "UPDATE_REPORT_1.7.96+152.md").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))

start = FORM.index("key: const ValueKey('trade-entry-identifiers-available')")
end = FORM.index("const SizedBox(height: 12)", start)
pair = FORM[start:end]

check("the two top fields share one explicit parent row", "trade-entry-identifiers-row" in pair and "child: Row(" in pair)
check("manual width calculation is removed", "marketControlWidth" not in FORM)
check("market/direction occupies an Expanded equal-width column", "Expanded(\n                                    child: SizedBox(\n                                      height: _tradeDataControlHeight,\n                                      child: InputDecorator(\n                                        key: const ValueKey('trade-market-direction-field')" in pair)
check("mindset occupies an Expanded equal-width column", "Expanded(\n                                    child: SizedBox(\n                                      height: _tradeDataControlHeight,\n                                      child: _buildMindsetSelector(" in pair)
check("both fields share the same 72dp parent-level height", pair.count("height: _tradeDataControlHeight") == 2 and "const double _tradeDataControlHeight = 72;" in FORM)
check("the gap between the fields is fixed at 8dp", "const identifierGap = 8.0;" in FORM and "SizedBox(width: identifierGap)" in pair)
check("market and mindset retain their stable widget keys", "trade-market-direction-field" in pair and "trade-mood-field" in FORM)
check("widget test verifies equal field widths", "closeTo(marketDirectionRect.width, 1)" in TEST)
check("widget test verifies equal field heights", "marketDirectionHeight, closeTo(moodHeight, .1)" in TEST)
check("widget test verifies precise 8dp gutter", "closeTo(8, .1)" in TEST and "professional gutter" in TEST)
check("widget test verifies opposite outer-edge alignment", "mindset selector must align to the opposite edge" in TEST)
check("application version is 1.7.96+152", "version: 1.7.96+152" in PUBSPEC)
check("Android workflow uses build 152 identifiers", "TraderDesk 1.7.96+152" in WORKFLOW and "traderdesk-1.7.96-build152-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.96-build152-arm64-dart-symbols" in WORKFLOW)
check("update report records the requested adjustment", "مستطيل **السوق / الاتجاه**" in REPORT and "مستطيل **الحالة النفسية**" in REPORT and "8dp" in REPORT)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
