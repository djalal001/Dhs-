#!/usr/bin/env python3
"""Static regression checks for TraderDesk 1.7.96+152 bounce UI and direction gate."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
DETAIL_TEST = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
RELEASE = (ROOT / "RELEASE_NOTES_AR.md").read_text(encoding="utf-8")
BUILD_INFO = (ROOT / "BUILD_INFO_AR.md").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))

def section(text: str, start: str, end: str) -> str:
    if start not in text or end not in text:
        return ""
    return text.split(start, 1)[1].split(end, 1)[0]

# Release metadata.
check("pubspec version is 1.7.96+152", "version: 1.7.96+152" in PUBSPEC)
check("workflow identifies release 1.7.96+152", "TraderDesk 1.7.96+152" in WORKFLOW)
check("workflow release APK artifact uses version/build 1.7.96/152", "traderdesk-1.7.96-build152-arm64-v8a-release" in WORKFLOW)
check("workflow Dart symbols artifact uses version/build 1.7.96/152", "traderdesk-1.7.96-build152-arm64-dart-symbols" in WORKFLOW)

# Bounce picker inherits one semantic tone through choice -> detail -> timeframe.
condition_setup = section(FORM, "Future<TradeEntryConditionSetup?> _showEntryConditionSetup", "Future<bool?> _showTouch2Sheet")
touch_sheet = section(FORM, "Future<bool?> _showTouch2Sheet", "Future<String?> _showEntryReasonSheet")
bounce_add = section(FORM, "Future<void> _addBounceZoneSetup()", "void _removeReverseSignalSetup")
check("bounce option picker forwards the section's semantic accent", "accentTone: choiceTone" in condition_setup)
check("S/R Touch 2 dialog accepts the semantic accent", "Color? accentTone" in touch_sheet and "accentTone: accentTone" in touch_sheet)
check("S/R Touch 2 dialog inherits the same choiceTone", "accentTone: choiceTone" in condition_setup)
check("bounce add/edit paths use the same shared accent getter", FORM.count("choiceTone: _currentReverseSignalTone") >= 4)
check("Bounce area timeframe picker receives the same accent", "accentTone: choiceTone" in condition_setup)
check("S/R dialog and timeframe picker share accent plumbing", "semanticAccent = accentTone ?? tokens.accent" in FORM and "selectedTileColor" in FORM)
check("widget test verifies S/R detail picker surface color", "srTouch2Background" in ENTRY_TEST and "same color" in ENTRY_TEST)
check("widget test verifies S/R detail picker border color", "srTouch2Shape.side.color" in ENTRY_TEST)
check("widget test verifies S/R detail row accent tint", "srTouch2Option.selectedTileColor" in ENTRY_TEST)

# Required copy is exact for the Bounce S/R branch; generic RBS remains unchanged.
check("Bounce S/R qualifier is exactly 2 Touch", "? '2 Touch'" in touch_sheet)
check("Bounce S/R continuation text is exactly متابعة in Arabic", "_copy('متابعة', 'Continue')" in touch_sheet)
check("legacy long continuation sentence is absent from active Bounce S/R code", "تجاوزها والمتابعة إلى الفريم الزمني" not in touch_sheet)
check("Bounce S/R widget test asserts 2 Touch", "find.text('2 Touch'), findsOneWidget" in ENTRY_TEST)
check("Bounce S/R widget test asserts متابعة", "find.text('متابعة'), findsOneWidget" in ENTRY_TEST)
check("Bounce S/R widget test rejects لمسة 2", "find.text('لمسة 2'), findsNothing" in ENTRY_TEST)
check("saved label formatter displays compact Touch before timeframe", "if (setup.touch2) 'Touch 2'" in CATALOG and "return '$directionalLabel $suffix';" in CATALOG)
check("catalog test validates directional S/R Touch labels", "ارتداد من Resistan Touch 2 15MIN" in CATALOG_TEST and "Bounce from Support Touch 2 15MIN" in CATALOG_TEST)
check("saved trade-detail test expects compact Support/Resistance Touch labels", "ارتداد من Support Touch 2 30MIN" in DETAIL_TEST and "ارتداد من Resistan Touch 2 15MIN" in DETAIL_TEST)

# Direction gate covers all editable/selectable items in Trade Details, Entry Conditions,
# and Trading Behavior while leaving the Direction selector and Result/Risk available.
check("shared direction-state helper exists", "bool get _hasTradeDirection => _side != null;" in FORM)
check("market selector is locked without direction", "enabled: _hasTradeDirection" in section(FORM, "child: _compactPopupChoice<String>", "child: _compactPopupChoice<TradeSide>"))
check("direction selector remains enabled", "enabled: true" in FORM.split("trade-direction-selector", 1)[1].split("selectedValue: _side", 1)[0])
check("mindset popup follows direction state", "onTap: enabled" in section(FORM, "Widget _buildMindsetSelector", "Widget _setupSelectionField") and "onSelected: (value) => setState(() => _mood = value)" in FORM)
check("entry reason and confirmation controls share the gate", FORM.count("enabled: _hasTradeDirection") >= 7)
check("date/time input is disabled without direction", "onPressed: _hasTradeDirection ? _pickDateTime : null" in FORM)
check("anchor picker and its edit/delete controls are gated", "onTap: _hasTradeDirection ? _pickAnchors : null" in FORM and "if (!_hasTradeDirection) return;" in section(FORM, "Future<void> _pickAnchors()", "Widget _anchorMultiSelector"))
check("bounce and opposing-signal fields share the gate", "enabled: _hasTradeDirection" in section(FORM, "Widget _buildLinkedEntryBehaviorSections", "Widget _buildBehaviorCard"))
check("all three trading-behavior groups gate option rows", section(FORM, "Widget _buildBehaviorCard", "Widget _behaviorExpansion").count("enabled: _hasTradeDirection") == 3)
check("behavior option tap is null while disabled", "onTap: enabled\n            ? () => _toggleSet" in section(FORM, "Widget _selectionRow", "\n}\n"))
check("mutation callbacks guard adds/edits/removals", all(x in FORM for x in ["Future<void> _addEntrySetup() async {\n    if (!_hasTradeDirection) return;", "Future<void> _addConfirmationSetup() async {\n    if (!_hasTradeDirection) return;", "void _removeEntrySetup(TradeEntrySetup setup) {\n    if (!_hasTradeDirection) return;"]))
check("Result & Risk remains an unguarded editable section", "_resultAmountField(suffix: account.currency)" in FORM and "_numericField(controller: _expectedLoss" in FORM)
check("widget tests cover locked fields and unlocked fields after BUY", "Selecting a side unlocks" in ENTRY_TEST and "tester.widget<InkWell>(marketSelector).onTap, isNull" in ENTRY_TEST and "tester.widget<InkWell>(marketSelector).onTap, isNotNull" in ENTRY_TEST)
check("widget test covers Result & Risk before selecting direction", "result requires choosing a sign before entering its magnitude" in ENTRY_TEST and "await _enterSignedResult(tester, '42.5', negative: false);" in ENTRY_TEST and "controller!.text, '+42.5'" in ENTRY_TEST)
check("widget test covers behavior options before and after direction", "tester.widget<InkWell>(reviewRow).onTap, isNull" in ENTRY_TEST and "tester.widget<InkWell>(reviewRow).onTap, isNotNull" in ENTRY_TEST)
check("widget test covers direction cleared and form re-locked", "clearing BUY must re-lock the market selector" in ENTRY_TEST)

check("release notes document all four requested refinements", all(x in RELEASE for x in ["2 Touch", "«متابعة»", "BUY أو SELL", "النتيجة والمخاطرة"]))
check("build info identifies release 1.7.96+152 and exact source ZIP", "1.7.96`؛ رقم البناء: `152" in BUILD_INFO and "TraderDesk_Android_Project_v1.7.95+151_GPT_SOURCE.zip" in BUILD_INFO)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
