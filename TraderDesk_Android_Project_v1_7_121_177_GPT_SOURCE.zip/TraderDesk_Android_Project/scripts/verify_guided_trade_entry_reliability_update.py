#!/usr/bin/env python3
"""Focused regression checks for the guided profit/loss -> direction flow."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/release-arm64.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE_NOTES = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks = []
def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))

check('version is 1.7.121+177', 'version: 1.7.121+177' in PUBSPEC)
check('ARM64 APK artifact uses build 177', 'traderdesk-1.7.121-build177-arm64-v8a-release' in WORKFLOW)
check('Dart symbols artifact uses build 177', 'traderdesk-1.7.121-build177-arm64-dart-symbols' in WORKFLOW)
check('build information identifies 1.7.121+177', '1.7.121+177' in BUILD_INFO and 'رقم البناء: `177`' in BUILD_INFO)
check('release notes identify 1.7.121+177', '1.7.121+177' in RELEASE_NOTES)

# Guided progression is derived from live fresh-trade state, not stale focus flags.
check('fresh-flow predicate excludes editing existing trades', 'widget.trade == null' in FORM and 'bool get _isFreshGuidedEntry' in FORM)
check('fresh-flow predicate waits for direction and market to be unset', '_side == null' in FORM and '_symbol == null' in FORM)
check('fresh-flow predicate requires default unknown mood', "_selectedMoods.contains('moodUnknown')" in FORM)
check('result sign selection starts the guided step only for a fresh trade', 'final startAutomaticSequence = _isFreshGuidedEntry;' in FORM)
check('profit result advances to Expected Loss', 'if (_resultSign == 1)' in FORM and '_expectedLossFocusNode.requestFocus();' in FORM)
check('loss result skips Expected Loss and opens Direction', 'if (_resultSign == -1)' in FORM and 'await _openAutoDirectionPopup();' in FORM)
check('Expected Loss completion opens Direction', 'Future<void> _continueAfterExpectedLoss()' in FORM and 'await _openAutoDirectionPopup();' in FORM)
check('result input uses Done and guided callbacks', 'textInputAction: TextInputAction.done' in FORM and 'onEditingComplete: _handleResultEditingComplete' in FORM and 'onFieldSubmitted: _handleResultSubmitted' in FORM)
expected_field = FORM.split("key: const ValueKey('trade-expected-loss-input')", 1)[1].split('onChanged:', 1)[0]
check('Expected Loss input uses Done and both guided callbacks', 'textInputAction: TextInputAction.done' in expected_field and 'onEditingComplete: _handleExpectedLossEditingComplete' in expected_field and 'onSubmitted: _handleExpectedLossSubmitted' in expected_field)
check('result handler does not use default next-focus traversal', '_handleResultEditingComplete()' in FORM and '_resultFocusNode.unfocus();' in FORM)
check('Expected Loss handler does not use default next-focus traversal', '_handleExpectedLossEditingComplete()' in FORM and '_expectedLossFocusNode.unfocus();' in FORM)
check('read-only calculated fields cannot request focus', 'canRequestFocus: false' in FORM and 'skipTraversal: true' in FORM and 'descendantsAreFocusable: false' in FORM)
check('risk and reward/risk remain read-only outputs', "key: const ValueKey('trade-risk-input')" in FORM and "key: const ValueKey('trade-reward-risk-input')" in FORM)
check('direction selection continues to market', '_autoEntryStep = _AutoEntryStep.market;' in FORM and '_openAutoMarketPopup();' in FORM)
check('market selection continues to mindset', '_autoEntryStep = _AutoEntryStep.mindset;' in FORM and '_openAutoMindsetDialog();' in FORM)
check('manual changes on an existing trade do not cascade', 'manual edits of an existing direction and market do not auto-advance' in TESTS)

# Widget tests use actual IME actions (not only manual callback invocation).
profit_test = TESTS.split("testWidgets('profit advances through expected loss", 1)[1].split("testWidgets('loss skips expected loss", 1)[0]
loss_test = TESTS.split("testWidgets('loss skips expected loss", 1)[1].split("testWidgets('manual edits", 1)[0]
check('profit test sends real Done after result amount', 'receiveAction(TextInputAction.done)' in profit_test)
check('profit test sends real Done after Expected Loss amount', profit_test.count('receiveAction(TextInputAction.done)') >= 2)
check('profit test asserts Direction popup appears after Expected Loss Done', "trade-direction-option-buy" in profit_test and 'submitting expected loss opens the direction choices' in profit_test)
check('loss test sends real Done after loss amount', 'receiveAction(TextInputAction.done)' in loss_test)
check('loss test asserts Direction opens directly', "trade-direction-option-buy" in loss_test and 'skips Expected Loss and opens Direction' in loss_test)
check('profit test asserts Risk % does not receive focus', 'read-only Risk % field must never receive focus' in profit_test)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
