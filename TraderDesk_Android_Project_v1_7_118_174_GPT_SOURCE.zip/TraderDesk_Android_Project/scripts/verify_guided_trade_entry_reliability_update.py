#!/usr/bin/env python3
"""Focused static verification for TraderDesk 1.7.118+174."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE_NOTES = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

check('version is 1.7.118+174', 'version: 1.7.118+174' in PUBSPEC)
check('workflow is versioned 1.7.118+174', 'TraderDesk 1.7.118+174 Android Release APK' in WORKFLOW)
check('workflow release artifacts use build 174', 'traderdesk-1.7.118-build174-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.118-build174-arm64-dart-symbols' in WORKFLOW)
check('build information reports 1.7.118+174', '1.7.118+174' in BUILD_INFO and '174' in BUILD_INFO)
check('release notes include 1.7.118+174', '1.7.118+174' in RELEASE_NOTES)

# The result heading must be present irrespective of the linked-no-entry state.
check('result field always has its original heading', "labelText: _copy('الربح / الخسارة', 'Profit / loss')" in FORM)
check('result heading retains floating-label behavior', 'floatingLabelBehavior: FloatingLabelBehavior.auto' in FORM)

# Both keyboard continuation points now execute the state transition from
# onEditingComplete itself, instead of returning early and relying only on a
# secondary submit callback.
result_complete = FORM.split("key: const ValueKey('trade-result-input')", 1)[1].split('keyboardType:', 1)[0]
check('result keyboard completion directly calls continuation', 'onEditingComplete: () {' in result_complete and '_continueAfterResult();' in result_complete)
expected_field = FORM.split("key: const ValueKey('trade-expected-loss-input')", 1)[1].split('onChanged:', 1)[0]
check('expected-loss keyboard completion directly calls continuation', 'onEditingComplete: () {' in expected_field and '_continueAfterExpectedLoss();' in expected_field)
check('result keyboard still uses Next action', 'textInputAction: TextInputAction.next' in result_complete)

# Preserve the five-stage flow and its edit/manual-entry guard.
check('positive outcome focuses expected-loss field', 'if (_resultSign == 1)' in FORM and '_expectedLossFocusNode.requestFocus();' in FORM)
check('negative outcome skips expected-loss and opens direction', 'if (_resultSign == -1)' in FORM and 'await _openAutoDirectionPopup();' in FORM)
check('expected-loss completion opens direction', 'Future<void> _continueAfterExpectedLoss()' in FORM and 'await _openAutoDirectionPopup();' in FORM)
check('direction selection opens market', '_autoEntryStep = _AutoEntryStep.market;' in FORM and '_openAutoMarketPopup();' in FORM)
check('market selection opens mindset', '_autoEntryStep = _AutoEntryStep.mindset;' in FORM and '_openAutoMindsetDialog();' in FORM)
check('mindset remains multi-select', 'CheckboxListTile(' in FORM and 'trade-mood-option-${item.key}' in FORM)
check('mindset field height remains 72dp', 'const double _tradeDataControlHeight = 72' in FORM and "key: const ValueKey('trade-mood-field')" in FORM)
check('automatic sequence remains restricted to a fresh initial entry', 'widget.trade == null' in FORM and '!_autoEntrySequenceUsed' in FORM)
check('manual direction/market edits do not cascade', 'else if (_autoEntryStep != _AutoEntryStep.idle)' in FORM)

check('positive flow widget test exercises keyboard Next', 'profit advances through expected loss' in TESTS and 'receiveAction(TextInputAction.next)' in TESTS)
check('negative flow widget test exercises keyboard Next', 'loss skips expected loss' in TESTS and 'a negative result skips Expected Loss' in TESTS)
check('tests assert the result floating heading exists in win and loss flows', TESTS.count("decoration?.labelText,\n        'الربح / الخسارة'") >= 1 and "decoration?.labelText, 'الربح / الخسارة'" in TESTS)
check('manual edit regression remains covered', 'manual edits of an existing direction and market do not auto-advance' in TESTS)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
