import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../domain/trade_entry_catalog.dart';
import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../models/trading_account.dart';
import '../state/app_controller.dart';
import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../theme/trade_outcome_palette.dart';
import '../widgets/common.dart';
import '../widgets/decision_option_emoji.dart';

enum _TradeImageSlot { before, after, confirmation }

// Muted, product-grade tones inspired by the Windows trade-entry panels.
const _resultTone = Color(0xFF9BA9B9);
const _dataTone = Color(0xFF76AEE8);
const _imagesTone = Color(0xFF9AA3AD);
const _behaviorTone = Color(0xFFB7A2EC);
const _decisionTone = Color(0xFFC6A071);
const _commitmentTone = Color(0xFF55C99A);
const _noEntryTone = Color(0xFFB69AF0);
const _entryConditionsTone = Color(0xFF78AFC3);
const _reverseSignalsTone = Color(0xFF6E9FB6);
const _bounceZoneTone = Color(0xFF83B7C9);

class TradeFormScreen extends StatefulWidget {
  const TradeFormScreen({super.key, this.trade});
  final Trade? trade;

  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _anchorMenuAnchorKey = GlobalKey();
  final _marketPopupAnchorKey = GlobalKey();
  final _directionPopupAnchorKey = GlobalKey();
  final _behaviorLinkStackKey = GlobalKey(debugLabel: 'behavior-link-stack');
  final _reverseSignalsHeaderKey = GlobalKey(
    debugLabel: 'reverse-signals-link-header',
  );
  final _noEntryHeaderKey = GlobalKey(debugLabel: 'no-entry-link-header');
  late final TextEditingController _result;
  late final TextEditingController _expectedLoss;
  late final TextEditingController _risk;
  late final TextEditingController _rewardRisk;
  late String _accountId;
  String? _symbol;
  TradeSide? _side;
  late Set<String> _anchors;
  late Map<String, String> _anchorTimeframes;
  late String _mood;
  late DateTime _tradedAt;
  late List<TradeEntrySetup> _entrySetups;
  late List<TradeConfirmationSetup> _confirmationSetups;
  late List<TradeEntryConditionSetup> _reverseSignalSetups;
  late List<TradeEntryConditionSetup> _bounceZoneSetups;
  late Set<String> _executionReviewKeys;
  late Set<String> _noEntryReasons;
  TradeClassification? _classification;
  String? _beforePath;
  String? _afterPath;
  String? _confirmationImagePath;
  bool _busy = false;
  bool _seededExpectedLoss = false;
  final _picker = ImagePicker();

  bool get _ar => AppStrings.isArabic(context);
  String _copy(String ar, String en) => _ar ? ar : en;

  @override
  void initState() {
    super.initState();
    final trade = widget.trade;
    _symbol = trade?.market.isNotEmpty == true ? trade!.market : null;
    _result = TextEditingController(text: trade?.result.toString() ?? '');
    _expectedLoss = TextEditingController(
      text: trade?.expectedLoss?.toString() ?? '',
    );
    _risk = TextEditingController(
      text: trade?.riskPercent.toStringAsFixed(2) ?? '',
    );
    _rewardRisk = TextEditingController();
    _accountId = trade?.accountId ?? '';
    _side = trade?.side;
    _anchors = {...?trade?.effectiveAnchors};
    _anchorTimeframes = {...?trade?.anchorTimeframes};
    _mood = trade?.mood.isNotEmpty == true ? trade!.mood : 'moodUnknown';
    _tradedAt = trade?.tradedAt ?? DateTime.now();
    _entrySetups = [...?trade?.effectiveEntrySetups];
    _confirmationSetups = [...?trade?.effectiveConfirmationSetups];
    _reverseSignalSetups = [...?trade?.reverseSignalSetups];
    _bounceZoneSetups = [...?trade?.bounceZoneSetups];
    _executionReviewKeys = {...?trade?.executionReviewKeys};
    _noEntryReasons = {...?trade?.noEntryReasons};
    _classification = trade?.effectiveClassification;
    _beforePath = trade?.beforeImagePath;
    _afterPath = trade?.afterImagePath;
    _confirmationImagePath = trade?.confirmationImagePath;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final app = AppScope.of(context);
    if (_accountId.isEmpty && app.accounts.isNotEmpty) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    if (!_seededExpectedLoss && widget.trade != null) {
      _seededExpectedLoss = true;
      final balance = _accountBalanceBeforeTrade(app);
      final trade = widget.trade!;
      final amount =
          trade.expectedLoss ??
          (trade.result >= 0 && balance > 0
              ? balance * trade.riskPercent / 100
              : 0);
      _expectedLoss.text = trade.expectedLoss != null || amount > 0
          ? amount.toString()
          : '';
    }
    _updateComputedFields();
  }

  @override
  void dispose() {
    _result.dispose();
    _expectedLoss.dispose();
    _risk.dispose();
    _rewardRisk.dispose();
    super.dispose();
  }

  double? _parse(TextEditingController controller) =>
      double.tryParse(controller.text.trim().replaceAll(',', '.'));

  TradingAccount? get _account {
    final app = AppScope.of(context);
    for (final item in app.accounts) {
      if (item.id == _accountId) return item;
    }
    return app.accounts.firstOrNull;
  }

  double _accountBalanceBeforeTrade(AppController app) {
    TradingAccount? account;
    for (final candidate in app.accounts) {
      if (candidate.id == _accountId) {
        account = candidate;
        break;
      }
    }
    if (account == null) return 0;
    final selectedAccount = account;
    return app.trades
        .where(
          (trade) =>
              trade.accountId == selectedAccount.id &&
              trade.id != widget.trade?.id &&
              trade.isExecuted &&
              trade.tradedAt.isBefore(_tradedAt),
        )
        .fold<double>(selectedAccount.startingBalance, (balance, trade) {
          final next = balance + trade.result;
          return next.isFinite ? next : balance;
        });
  }

  void _updateComputedFields() {
    final app = AppScope.of(context);
    final balance = _accountBalanceBeforeTrade(app);
    var parsedLoss = _parse(_expectedLoss);
    final result = _parse(_result);
    final isLosingResult = result != null && result < 0;
    if (isLosingResult &&
        _expectedLoss.text.trim().isNotEmpty &&
        (widget.trade == null ||
            parsedLoss == null ||
            !parsedLoss.isFinite ||
            parsedLoss < 0)) {
      _expectedLoss.clear();
      parsedLoss = null;
    }
    final recordedLoss =
        parsedLoss != null && parsedLoss.isFinite && parsedLoss >= 0
        ? parsedLoss
        : null;
    // For a losing trade with no previously recorded planned risk, use the
    // realized loss as the risk amount for derived percentages and R-multiple.
    // It is not added to the trade result or stored as a second cash loss.
    final loss = isLosingResult && (recordedLoss == null || recordedLoss == 0)
        ? result.abs()
        : recordedLoss;
    final risk = loss == null || loss < 0
        ? null
        : loss == 0
        ? 0.0
        : balance > 0
        ? loss / balance * 100
        : null;
    _risk.text = risk != null && risk.isFinite ? risk.toStringAsFixed(2) : '';
    _rewardRisk.text =
        loss != null && loss > 0 && result != null && result.isFinite
        ? (result / loss).toStringAsFixed(2)
        : '';
  }

  Future<void> _pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _tradedAt,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_tradedAt),
    );
    if (time == null || !mounted) return;
    setState(() {
      _tradedAt = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
      _updateComputedFields();
    });
  }

  Future<void> _pickImage(_TradeImageSlot slot) async {
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 92,
      );
      if (picked == null || !mounted) return;
      setState(() => _busy = true);
      final saved = await AppScope.of(context).persistImage(picked.path);
      if (!mounted) return;
      setState(() {
        switch (slot) {
          case _TradeImageSlot.before:
            _beforePath = saved;
          case _TradeImageSlot.after:
            _afterPath = saved;
          case _TradeImageSlot.confirmation:
            _confirmationImagePath = saved;
        }
        _busy = false;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _busy = false);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  /// Shows the main entry/confirmation choices in the same restrained blue
  /// surface used by the anchored market/side/anchor menus. Long catalogs scroll
  /// inside the centered dialog without stretching it across the screen.
  Future<T?> _showCenteredTradeChoiceDialog<T>({
    required String title,
    required List<({String label, T value})> options,
    required String keyPrefix,
    T? selectedValue,
    List<Key?>? optionKeys,
  }) => showDialog<T>(
    context: context,
    barrierDismissible: true,
    builder: (dialogContext) {
      final brightness = Theme.of(dialogContext).brightness;
      final tokens = TdTokens.of(dialogContext);
      final screen = MediaQuery.sizeOf(dialogContext);
      final dialogWidth = (screen.width - 56).clamp(240.0, 360.0).toDouble();
      final dialogMaxHeight = (screen.height * .68)
          .clamp(160.0, 560.0)
          .toDouble();

      return Dialog(
        key: ValueKey('trade-centered-choice-$keyPrefix'),
        backgroundColor: tdPopupMenuColor(brightness),
        surfaceTintColor: Colors.transparent,
        elevation: 9,
        shape: tdPopupMenuShape(brightness),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: SizedBox(
          width: dialogWidth,
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: dialogMaxHeight),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 13, 12, 12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(5, 0, 5, 10),
                    child: Text(
                      title,
                      textAlign: TextAlign.start,
                      style: Theme.of(dialogContext).textTheme.titleMedium
                          ?.copyWith(
                            color: tokens.text1,
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: tdPopupMenuBorderColor(brightness)
                        .withValues(alpha: .65),
                  ),
                  const SizedBox(height: 5),
                  Flexible(
                    child: ListView.separated(
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      itemCount: options.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 2),
                      itemBuilder: (itemContext, index) {
                        final option = options[index];
                        final isSelected = option.value == selectedValue;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 1),
                          child: ListTile(
                            key: optionKeys != null && index < optionKeys.length
                                ? optionKeys[index]
                                : ValueKey('$keyPrefix-option-$index'),
                            minTileHeight: 48,
                            minVerticalPadding: 8,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 11,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(9),
                            ),
                            selected: isSelected,
                            selectedTileColor: tokens.accent.withValues(
                              alpha: .09,
                            ),
                            title: Text(
                              option.label,
                              softWrap: true,
                              style: Theme.of(itemContext).textTheme.bodySmall
                                  ?.copyWith(
                                    color: tokens.text1,
                                    fontSize: 14.5,
                                    fontWeight: isSelected
                                        ? FontWeight.w700
                                        : FontWeight.w500,
                                  ),
                            ),
                            trailing: Icon(
                              isSelected
                                  ? Icons.check_circle_rounded
                                  : Icons.chevron_left_rounded,
                              size: 18,
                              color: isSelected ? tokens.accent : tokens.text3,
                            ),
                            onTap: () =>
                                Navigator.pop(dialogContext, option.value),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );

  Future<String?> _showChoiceSheet({
    required String title,
    required List<TradeEntryOption> options,
    String? selectedKey,
    bool centered = false,
  }) {
    if (centered) {
      return _showCenteredTradeChoiceDialog<String>(
        title: title,
        keyPrefix: 'single-choice',
        selectedValue: selectedKey,
        options: [
          for (final option in options)
            (label: _ar ? option.ar : option.en, value: option.key),
        ],
      );
    }

    final tokens = TdTokens.of(context);
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: tokens.surface1,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(sheetContext).height * .72,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                child: Text(
                  title,
                  style: Theme.of(sheetContext).textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(4, 0, 4, 16),
                  itemCount: options.length,
                  separatorBuilder: (_, _) =>
                      Divider(height: 1, color: tokens.lineSubtle),
                  itemBuilder: (itemContext, index) {
                    final option = options[index];
                    final isSelected = option.key == selectedKey;
                    return ListTile(
                      dense: false,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                      selected: isSelected,
                      selectedTileColor: tokens.accent.withValues(alpha: .08),
                      title: Text(
                        _ar ? option.ar : option.en,
                        style: Theme.of(itemContext).textTheme.bodyMedium
                            ?.copyWith(
                              fontWeight: isSelected
                                  ? FontWeight.w800
                                  : FontWeight.w500,
                            ),
                      ),
                      trailing: Icon(
                        isSelected ? Icons.check_circle : Icons.chevron_left,
                        size: 19,
                        color: isSelected ? tokens.accent : tokens.text3,
                      ),
                      onTap: () => Navigator.pop(sheetContext, option.key),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<String?> _showTimeframeSheet({
    required String title,
    String? selectedFrame,
    bool centered = false,
  }) => _showChoiceSheet(
    title: title,
    selectedKey: selectedFrame,
    centered: centered,
    options: [
      for (final frame in tradeEntryTimeframes)
        TradeEntryOption(frame, frame, frame),
    ],
  );

  Future<TradeEntryConditionSetup?> _showEntryConditionSetup({
    required String title,
    required List<TradeEntryOption> options,
    TradeEntryConditionSetup? current,
  }) async {
    final optionKey = await _showChoiceSheet(
      title: title,
      options: options,
      selectedKey: current?.optionKey,
      centered: true,
    );
    if (optionKey == null || !mounted) return null;

    final isTrendlineAndSupplyZone =
        optionKey == 'bounceFromTrendlineAndSupplyZone';
    var touch2 = false;
    if (optionKey == 'bounceFromSrZone') {
      final selectedTouch2 = await _showTouch2Sheet(
        baseReason: 'bounceFromSrZone',
        selected:
            current?.optionKey == 'bounceFromSrZone' &&
            (current?.touch2 ?? false),
      );
      if (selectedTouch2 == null || !mounted) return null;
      touch2 = selectedTouch2;
    }
    final primaryTimeframe = await _showTimeframeSheet(
      title: isTrendlineAndSupplyZone
          ? _copy('فريم ترند لاين', 'Trendline timeframe')
          : _copy('الفريم الزمني', 'Timeframe'),
      selectedFrame: current?.timeframe,
      centered: true,
    );
    if (primaryTimeframe == null || !mounted) return null;

    String? supplyZoneTimeframe;
    if (isTrendlineAndSupplyZone) {
      // The combined condition intentionally opens a second timeframe sheet
      // immediately after the Trendline timeframe has been selected.
      supplyZoneTimeframe = await _showTimeframeSheet(
        title: _copy('فريم Supply Zone', 'Supply Zone timeframe'),
        selectedFrame: current?.secondaryTimeframe,
        centered: true,
      );
      if (supplyZoneTimeframe == null || !mounted) return null;
    }

    return TradeEntryConditionSetup(
      optionKey: optionKey,
      timeframe: primaryTimeframe,
      secondaryTimeframe: supplyZoneTimeframe,
      touch2: touch2,
    );
  }

  Future<bool?> _showTouch2Sheet({
    required String baseReason,
    bool selected = false,
  }) {
    return _showCenteredTradeChoiceDialog<bool>(
      title: baseReason == 'bounceFromSrZone'
          ? _copy('تفصيل ارتداد S/R — اختياري', 'S/R bounce detail — optional')
          : _copy(
              'تفصيل $baseReason — اختياري',
              '$baseReason detail — optional',
            ),
      keyPrefix: 'touch2-$baseReason',
      selectedValue: selected ? true : null,
      optionKeys: [
        ValueKey('touch2-choice-$baseReason'),
        ValueKey('skip-touch2-$baseReason'),
      ],
      options: [
        (label: _copy('لمسة 2', 'Touch 2'), value: true),
        (
          label: _copy(
            'تجاوزها والمتابعة إلى الفريم الزمني',
            'Skip and choose timeframe',
          ),
          value: false,
        ),
      ],
    );
  }

  Future<String?> _showEntryReasonSheet({
    String? currentReason,
    bool editing = false,
  }) async {
    final currentBase = currentReason == null
        ? null
        : tradeEntryBaseReason(currentReason);
    final baseReason = await _showChoiceSheet(
      title: editing
          ? _copy('تعديل سبب الدخول', 'Edit entry reason')
          : _copy('سبب الدخول', 'Entry reason'),
      options: tradeEntryReasons,
      selectedKey: currentBase,
      centered: true,
    );
    if (baseReason == null || !mounted) return null;
    if (!tradeEntryTouch2EligibleReasons.contains(baseReason))
      return baseReason;

    final touch2 = await _showTouch2Sheet(
      baseReason: baseReason,
      selected:
          currentReason != null &&
          currentBase == baseReason &&
          tradeEntryUsesTouch2(currentReason),
    );
    if (touch2 == null || !mounted) return null;
    return tradeEntryReasonWithTouch2(baseReason, touch2);
  }

  Future<String?> _showCustomConfirmationDialog({
    String initialValue = '',
  }) async {
    final controller = TextEditingController(text: initialValue);
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_copy('تأكيد مخصص', 'Custom confirmation')),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 80,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            labelText: _copy('اكتب نوع التأكيد', 'Enter confirmation type'),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(tr(context, 'cancel')),
          ),
          FilledButton(
            onPressed: () {
              final text = controller.text.trim();
              if (text.isNotEmpty) Navigator.pop(dialogContext, text);
            },
            child: Text(tr(context, 'confirm')),
          ),
        ],
      ),
    );
    controller.dispose();
    return value;
  }

  Future<void> _addEntrySetup() async {
    final reason = await _showEntryReasonSheet();
    if (reason == null || !mounted) return;
    final timeframe = await _showTimeframeSheet(
      title: _copy('الفريم الزمني', 'Timeframe'),
      centered: true,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      if (!_entrySetups.any(
        (item) => item.reason == reason && item.timeframe == timeframe,
      )) {
        _entrySetups.add(TradeEntrySetup(reason: reason, timeframe: timeframe));
      }
    });
  }

  Future<void> _addConfirmationSetup() async {
    final type = await _showChoiceSheet(
      title: _copy('تأكيد الدخول', 'Entry confirmation'),
      options: tradeConfirmationOptions,
      centered: true,
    );
    if (type == null || !mounted) return;
    String finalType = type;
    if (type == '__custom__') {
      final custom = await _showCustomConfirmationDialog();
      if (custom == null || !mounted) return;
      finalType = custom;
    }
    final timeframe = await _showTimeframeSheet(
      title: _copy('فريم التأكيد', 'Confirmation timeframe'),
      centered: true,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      if (!_confirmationSetups.any(
        (item) => item.type == finalType && item.timeframe == timeframe,
      )) {
        _confirmationSetups.add(
          TradeConfirmationSetup(type: finalType, timeframe: timeframe),
        );
      }
    });
  }

  Future<void> _editEntrySetup(TradeEntrySetup current) async {
    final reason = await _showEntryReasonSheet(
      currentReason: current.reason,
      editing: true,
    );
    if (reason == null || !mounted) return;
    final timeframe = await _showTimeframeSheet(
      title: _copy('تعديل الفريم الزمني', 'Edit timeframe'),
      selectedFrame: current.timeframe,
      centered: true,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _entrySetups.indexOf(current);
      if (index < 0) return;
      final replacement = TradeEntrySetup(reason: reason, timeframe: timeframe);
      if (_entrySetups.asMap().entries.any(
        (entry) => entry.key != index && entry.value == replacement,
      )) {
        _entrySetups.removeAt(index);
      } else {
        _entrySetups[index] = replacement;
      }
    });
  }

  Future<void> _editConfirmationSetup(TradeConfirmationSetup current) async {
    final type = await _showChoiceSheet(
      title: _copy('تعديل تأكيد الدخول', 'Edit entry confirmation'),
      options: tradeConfirmationOptions,
      selectedKey:
          tradeConfirmationOptions.any((item) => item.key == current.type)
          ? current.type
          : '__custom__',
      centered: true,
    );
    if (type == null || !mounted) return;
    String finalType = type;
    if (type == '__custom__') {
      final custom = await _showCustomConfirmationDialog(
        initialValue: current.type == '__custom__' ? '' : current.type,
      );
      if (custom == null || !mounted) return;
      finalType = custom;
    }
    final timeframe = await _showTimeframeSheet(
      title: _copy('تعديل فريم التأكيد', 'Edit confirmation timeframe'),
      selectedFrame: current.timeframe,
      centered: true,
    );
    if (timeframe == null || !mounted) return;
    setState(() {
      final index = _confirmationSetups.indexOf(current);
      if (index < 0) return;
      final replacement = TradeConfirmationSetup(
        type: finalType,
        timeframe: timeframe,
      );
      if (_confirmationSetups.asMap().entries.any(
        (entry) => entry.key != index && entry.value == replacement,
      )) {
        _confirmationSetups.removeAt(index);
      } else {
        _confirmationSetups[index] = replacement;
      }
    });
  }

  Future<void> _addReverseSignalSetup() async {
    final setup = await _showEntryConditionSetup(
      title: _copy('إشارات عكسية', 'Opposing signals'),
      options: tradeReverseSignalOptions,
    );
    if (setup == null || !mounted) return;
    setState(() {
      if (!_reverseSignalSetups.contains(setup))
        _reverseSignalSetups.add(setup);
    });
  }

  Future<void> _editReverseSignalSetup(TradeEntryConditionSetup current) async {
    final setup = await _showEntryConditionSetup(
      title: _copy('تعديل الإشارة العكسية', 'Edit opposing signal'),
      options: tradeReverseSignalOptions,
      current: current,
    );
    if (setup == null || !mounted) return;
    setState(() {
      final index = _reverseSignalSetups.indexOf(current);
      if (index < 0) return;
      if (_reverseSignalSetups.asMap().entries.any(
        (entry) => entry.key != index && entry.value == setup,
      )) {
        _reverseSignalSetups.removeAt(index);
      } else {
        _reverseSignalSetups[index] = setup;
      }
    });
  }

  Future<void> _addBounceZoneSetup() async {
    final setup = await _showEntryConditionSetup(
      title: _copy('منطقة الارتداد', 'Bounce area'),
      options: tradeBounceZoneOptions,
    );
    if (setup == null || !mounted) return;
    setState(() {
      if (!_bounceZoneSetups.contains(setup)) _bounceZoneSetups.add(setup);
    });
  }

  Future<void> _editBounceZoneSetup(TradeEntryConditionSetup current) async {
    final setup = await _showEntryConditionSetup(
      title: _copy('تعديل منطقة الارتداد', 'Edit bounce area'),
      options: tradeBounceZoneOptions,
      current: current,
    );
    if (setup == null || !mounted) return;
    setState(() {
      final index = _bounceZoneSetups.indexOf(current);
      if (index < 0) return;
      if (_bounceZoneSetups.asMap().entries.any(
        (entry) => entry.key != index && entry.value == setup,
      )) {
        _bounceZoneSetups.removeAt(index);
      } else {
        _bounceZoneSetups[index] = setup;
      }
    });
  }

  void _removeReverseSignalSetup(TradeEntryConditionSetup setup) =>
      setState(() => _reverseSignalSetups.remove(setup));

  void _removeBounceZoneSetup(TradeEntryConditionSetup setup) =>
      setState(() => _bounceZoneSetups.remove(setup));

  void _removeEntrySetup(TradeEntrySetup setup) =>
      setState(() => _entrySetups.remove(setup));
  void _removeConfirmationSetup(TradeConfirmationSetup setup) =>
      setState(() => _confirmationSetups.remove(setup));

  void _toggleSet(Set<String> values, String key, bool selected) {
    setState(() {
      if (selected) {
        values.add(key);
      } else {
        values.remove(key);
      }
    });
  }

  String? _number(String? value, {double? min}) {
    if (value == null || value.trim().isEmpty)
      return tr(context, 'requiredField');
    final parsed = double.tryParse(value.trim().replaceAll(',', '.'));
    if (parsed == null || !parsed.isFinite || (min != null && parsed < min))
      return tr(context, 'invalidNumber');
    return null;
  }

  String? _expectedLossValidator(String? value) {
    // The result itself supplies the realized loss when it is negative, so
    // this separate planned-loss field is intentionally not required then.
    final result = _parse(_result);
    if (result != null && result < 0) return null;
    if ((value == null || value.trim().isEmpty) &&
        (_classification == TradeClassification.breakEven ||
            _classification == TradeClassification.missed)) {
      return null;
    }
    final invalid = _number(value, min: 0);
    if (invalid != null) return invalid;
    final loss = _parse(_expectedLoss) ?? 0;
    if (result != 0 && loss <= 0) return tr(context, 'expectedLossNeeded');
    return null;
  }

  Future<void> _chooseClassification() async {
    final selected = await showModalBottomSheet<TradeClassification>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      backgroundColor: TdTokens.of(context).surface1,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        final tokens = TdTokens.of(sheetContext);
        Color colorFor(TradeClassification value) => switch (value) {
          TradeClassification.win => tokens.profit,
          TradeClassification.loss => tokens.loss,
          TradeClassification.breakEven => TradeOutcomePalette.breakEven(
            Theme.of(sheetContext).brightness,
          ),
          TradeClassification.missed => tokens.neutral,
        };
        String labelFor(TradeClassification value) => switch (value) {
          TradeClassification.win => tr(sheetContext, 'classificationWin'),
          TradeClassification.loss => tr(sheetContext, 'classificationLoss'),
          TradeClassification.breakEven => tr(
            sheetContext,
            'classificationBreakEven',
          ),
          TradeClassification.missed => tr(
            sheetContext,
            'classificationMissed',
          ),
        };
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                tr(sheetContext, 'chooseTradeClassification'),
                style: Theme.of(sheetContext).textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              for (final value in TradeClassification.values)
                Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: Material(
                    color: tokens.surface2,
                    borderRadius: BorderRadius.circular(13),
                    child: InkWell(
                      key: ValueKey(
                        'trade-classification-option-${value.name}',
                      ),
                      borderRadius: BorderRadius.circular(13),
                      onTap: () => Navigator.of(sheetContext).pop(value),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 13,
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 9,
                              height: 9,
                              decoration: BoxDecoration(
                                color: colorFor(value),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Text(
                                labelFor(value),
                                style: Theme.of(sheetContext)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w700),
                              ),
                            ),
                            Icon(
                              Icons.chevron_left_rounded,
                              size: 19,
                              color: tokens.text3,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
    if (selected != null && mounted) {
      setState(() => _classification = selected);
    }
  }

  String _classificationLabel(TradeClassification value) => switch (value) {
    TradeClassification.win => tr(context, 'classificationWin'),
    TradeClassification.loss => tr(context, 'classificationLoss'),
    TradeClassification.breakEven => tr(context, 'classificationBreakEven'),
    TradeClassification.missed => tr(context, 'classificationMissed'),
  };

  bool _classificationMatchesResult(TradeClassification value, double result) =>
      switch (value) {
        TradeClassification.win => result > 0,
        TradeClassification.loss => result < 0,
        TradeClassification.breakEven ||
        TradeClassification.missed => result == 0,
      };

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final selectedClassification = _classification;
    if (selectedClassification == null) {
      _showValidationMessage(tr(context, 'tradeClassificationRequired'));
      return;
    }
    final enteredResult = _parse(_result);
    if (enteredResult == null ||
        !_classificationMatchesResult(selectedClassification, enteredResult)) {
      _showValidationMessage(tr(context, 'tradeClassificationResultMismatch'));
      return;
    }
    if (_symbol == null || _symbol!.trim().isEmpty) {
      _showValidationMessage(
        _copy('اختر الرمز: NQ أو ES أو GC.', 'Choose a symbol: NQ, ES, or GC.'),
      );
      return;
    }
    if (_side == null) {
      _showValidationMessage(
        _copy(
          'حدد اتجاه الصفقة: شراء أو بيع.',
          'Choose the trade direction: buy or sell.',
        ),
      );
      return;
    }
    if (_entrySetups.isEmpty) {
      _showValidationMessage(
        _copy(
          'أضف سبب دخول واحدًا على الأقل مع الفريم الزمني.',
          'Add at least one entry reason with its timeframe.',
        ),
      );
      return;
    }
    if (_confirmationSetups.isEmpty) {
      _showValidationMessage(
        _copy(
          'أضف تأكيد دخول واحدًا على الأقل مع فريمه الزمني.',
          'Add at least one entry confirmation with its timeframe.',
        ),
      );
      return;
    }
    final app = AppScope.of(context);
    if (app.accounts.isEmpty) return;
    final balance = _accountBalanceBeforeTrade(app);
    final result = _parse(_result)!;
    final parsedLoss = _parse(_expectedLoss);
    final recordedLoss =
        parsedLoss != null && parsedLoss.isFinite && parsedLoss >= 0
        ? parsedLoss
        : null;
    final loss = result < 0 && (recordedLoss == null || recordedLoss == 0)
        ? result.abs()
        : recordedLoss ?? 0.0;
    final risk = loss == 0 ? 0.0 : (balance > 0 ? loss / balance * 100 : null);
    if (risk == null || !risk.isFinite) {
      _showValidationMessage(tr(context, 'riskBalanceUnavailable'));
      return;
    }
    final setups = [..._entrySetups];
    final confirmations = [..._confirmationSetups];
    final trade = Trade(
      id: widget.trade?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      accountId: app.accounts.any((item) => item.id == _accountId)
          ? _accountId
          : (app.selectedAccountId ?? app.accounts.first.id),
      market: _symbol!.trim().toUpperCase(),
      reason: setups.first.reason,
      result: result,
      riskPercent: risk,
      // Keep this optional when the loss amount was derived solely from the
      // realized result. Existing or explicitly entered planned risk is kept.
      expectedLoss: recordedLoss ?? (result < 0 ? null : loss),
      side: _side!,
      confirmation: '',
      confirmationSetups: confirmations,
      reverseSignalSetups: [..._reverseSignalSetups],
      bounceZoneSetups: [..._bounceZoneSetups],
      executionJournal: widget.trade?.executionJournal ?? const [],
      executionReviewKeys: _executionReviewKeys.toList(growable: false),
      noEntryReasons: _noEntryReasons.toList(growable: false),
      sequence: widget.trade?.sequence ?? '',
      mood: _mood,
      tradedAt: _tradedAt,
      entryTimeframe: setups.first.timeframe,
      entrySetups: setups,
      beforeImagePath: _beforePath,
      afterImagePath: _afterPath,
      confirmationImagePath: _confirmationImagePath,
      notes: widget.trade?.notes ?? '',
      strategyAdherence: widget.trade?.strategyAdherence,
      classification: selectedClassification,
      anchor: _orderedAnchorKeys.firstOrNull,
      anchors: _orderedAnchorKeys,
      anchorTimeframes: {
        for (final key in _orderedAnchorKeys)
          if (_anchorTimeframes[key] != null) key: _anchorTimeframes[key]!,
      },
    );
    Navigator.of(context).pop(trade);
  }

  void _showValidationMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  InputDecoration _blueSelectorDecoration({
    required String label,
    IconData? icon,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fieldFill = isDark
        ? const Color(0xFF071834)
        : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);
    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(
        color: isDark
            ? const Color(0xFF21405B).withValues(alpha: .52)
            : tokens.lineSubtle.withValues(alpha: .68),
        width: .78,
      ),
    );
    return InputDecoration(
      labelText: label,
      prefixIcon: icon == null
          ? null
          : Icon(icon, size: 17, color: tokens.text2),
      prefixIconConstraints: icon == null
          ? null
          : const BoxConstraints(minWidth: 36, minHeight: 48),
      filled: true,
      fillColor: fieldFill,
      border: fieldBorder,
      enabledBorder: fieldBorder,
      focusedBorder: fieldBorder.copyWith(
        borderSide: BorderSide(
          color: _dataTone.withValues(alpha: .78),
          width: 1.05,
        ),
      ),
      contentPadding: const EdgeInsetsDirectional.fromSTEB(10, 13, 10, 13),
      floatingLabelBehavior: FloatingLabelBehavior.auto,
    );
  }

  Future<void> _showCompactPopupChoice<T>({
    required GlobalKey anchorKey,
    required List<T> values,
    required String itemKeyPrefix,
    required T? selectedValue,
    required String Function(T value) labelFor,
    required ValueChanged<T> onSelected,
    required double minMenuWidth,
  }) async {
    final anchorContext = anchorKey.currentContext;
    final anchorRenderObject = anchorContext?.findRenderObject();
    final overlay = Overlay.of(context);
    final overlayRenderObject = overlay.context.findRenderObject();
    if (anchorRenderObject is! RenderBox ||
        overlayRenderObject is! RenderBox ||
        !anchorRenderObject.hasSize ||
        !overlayRenderObject.hasSize) {
      return;
    }

    final anchorTopLeft = anchorRenderObject.localToGlobal(
      Offset.zero,
      ancestor: overlayRenderObject,
    );
    final anchorRect = anchorTopLeft & anchorRenderObject.size;
    final overlayRect = Offset.zero & overlayRenderObject.size;
    final screenWidthLimit = overlayRenderObject.size.width - 24;
    final requestedWidth = anchorRenderObject.size.width < minMenuWidth
        ? minMenuWidth
        : anchorRenderObject.size.width;
    final menuWidth = requestedWidth > screenWidthLimit
        ? screenWidthLimit
        : requestedWidth;

    final selected = await showMenu<T>(
      context: context,
      position: RelativeRect.fromRect(
        anchorRect.shift(const Offset(0, 7)),
        overlayRect,
      ),
      color: tdPopupMenuColor(Theme.of(context).brightness),
      surfaceTintColor: Colors.transparent,
      elevation: 9,
      shape: tdPopupMenuShape(Theme.of(context).brightness),
      menuPadding: const EdgeInsets.symmetric(vertical: 5),
      constraints: BoxConstraints.tightFor(width: menuWidth),
      popUpAnimationStyle: tdPopupMenuAnimationStyle,
      items: [
        for (final value in values)
          PopupMenuItem<T>(
            key: ValueKey(
              '$itemKeyPrefix-${value is Enum ? value.name : value.toString()}',
            ),
            value: value,
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    labelFor(value),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: TdTokens.of(context).text1,
                      fontSize: 14.5,
                      fontWeight: value == selectedValue
                          ? FontWeight.w700
                          : FontWeight.w500,
                    ),
                  ),
                ),
                if (value == selectedValue) ...[
                  const SizedBox(width: 5),
                  Icon(
                    Icons.check_rounded,
                    size: 16,
                    color: TdTokens.of(context).accent,
                  ),
                ],
              ],
            ),
          ),
      ],
    );

    if (selected != null && mounted) onSelected(selected);
  }

  Widget _compactPopupChoice<T>({
    required Key key,
    required GlobalKey popupAnchorKey,
    required String itemKeyPrefix,
    required String caption,
    TextDirection valueDirection = TextDirection.ltr,
    double minMenuWidth = 176,
    required T? selectedValue,
    required List<T> values,
    required String Function(T value) labelFor,
    required ValueChanged<T> onSelected,
  }) {
    final tokens = TdTokens.of(context);
    return InkWell(
      key: key,
      borderRadius: BorderRadius.circular(12),
      onTap: () => _showCompactPopupChoice<T>(
        anchorKey: popupAnchorKey,
        values: values,
        itemKeyPrefix: itemKeyPrefix,
        selectedValue: selectedValue,
        labelFor: labelFor,
        onSelected: onSelected,
        minMenuWidth: minMenuWidth,
      ),
      child: SizedBox(
        key: popupAnchorKey,
        height: 38,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    selectedValue == null ? caption : labelFor(selectedValue),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textDirection: selectedValue == null
                        ? (_ar ? TextDirection.rtl : TextDirection.ltr)
                        : valueDirection,
                    style:
                        (selectedValue == null
                                ? Theme.of(context).textTheme.labelSmall
                                : Theme.of(context).textTheme.labelMedium)
                            ?.copyWith(
                              color: selectedValue == null
                                  ? tokens.text2
                                  : tokens.text1,
                              fontSize: selectedValue == null ? 10.5 : 12.5,
                              fontWeight: selectedValue == null
                                  ? FontWeight.w600
                                  : FontWeight.w700,
                            ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final tokens = TdTokens.of(context);
    final softenedTokens = tokens.copyWith(
      lineSubtle: tokens.lineSubtle.withValues(alpha: .68),
      lineStrong: tokens.lineStrong.withValues(alpha: .54),
    );
    final baseTheme = Theme.of(context);
    final defaultFieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: softenedTokens.lineSubtle, width: 0.78),
    );
    final focusedFieldBorder = defaultFieldBorder.copyWith(
      borderSide: BorderSide(
        color: tokens.accent.withValues(alpha: .78),
        width: 1.05,
      ),
    );
    if (app.accounts.isEmpty) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: Text(tr(context, 'addFirstAccount'))),
      );
    }
    if (!app.accounts.any((item) => item.id == _accountId)) {
      _accountId = app.selectedAccountId ?? app.accounts.first.id;
    }
    final account = _account ?? app.accounts.first;
    return Theme(
      data: baseTheme.copyWith(
        dividerColor: softenedTokens.lineSubtle,
        inputDecorationTheme: baseTheme.inputDecorationTheme.copyWith(
          border: defaultFieldBorder,
          enabledBorder: defaultFieldBorder,
          focusedBorder: focusedFieldBorder,
          disabledBorder: defaultFieldBorder,
        ),
        chipTheme: baseTheme.chipTheme.copyWith(
          side: BorderSide(color: softenedTokens.lineStrong, width: 0.8),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: baseTheme.outlinedButtonTheme.style?.copyWith(
            side: WidgetStatePropertyAll(
              BorderSide(color: softenedTokens.lineStrong, width: 0.8),
            ),
          ),
        ),
        extensions: [softenedTokens],
      ),
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            tr(context, widget.trade == null ? 'addTrade' : 'editTrade'),
          ),
          actions: [
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 14),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: tokens.surface2,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: softenedTokens.lineSubtle,
                      width: 0.8,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.account_balance_wallet_outlined,
                        size: 15,
                        color: tokens.text2,
                      ),
                      const SizedBox(width: 6),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 120),
                        child: Text(
                          account.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.labelMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: Stack(
            children: [
              ListView(
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 34),
                children: [
                  _sectionCard(
                    context,
                    title: _copy('النتيجة والمخاطرة', 'Result & risk'),
                    icon: Icons.query_stats_outlined,
                    tone: _resultTone,
                    gradientColors: const [
                      Color(0xFF343D4A),
                      Color(0xFF29323E),
                      Color(0xFF222B36),
                      Color(0xFF181F29),
                    ],
                    borderTone: const Color(0xFF5B6471),
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _numericField(
                              controller: _result,
                              key: const ValueKey('trade-result-input'),
                              label: _copy('الربح / الخسارة', 'Profit / loss'),
                              suffix: account.currency,
                              validator: _number,
                              signed: true,
                              onChanged: (_) => setState(_updateComputedFields),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _numericField(
                              controller: _expectedLoss,
                              key: const ValueKey('trade-expected-loss-input'),
                              label: _copy('الخسارة المتوقعة', 'Expected loss'),
                              suffix: account.currency,
                              validator: _expectedLossValidator,
                              readOnly: (_parse(_result) ?? 0) < 0,
                              onChanged: (_) => setState(_updateComputedFields),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _readoutField(
                              controller: _risk,
                              key: const ValueKey('trade-risk-input'),
                              label: _copy('نسبة المخاطرة', 'Risk %'),
                              suffix: '%',
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _readoutField(
                              controller: _rewardRisk,
                              key: const ValueKey('trade-reward-risk-input'),
                              label: _copy(
                                'العائد / المخاطرة',
                                'Reward / risk',
                              ),
                              suffix: 'R',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _sectionCard(
                    context,
                    title: _copy('بيانات الصفقة', 'Trade details'),
                    icon: Icons.receipt_long_outlined,
                    tone: _dataTone,
                    gradientColors: const [
                      Color(0xFF123C75),
                      Color(0xFF0F3166),
                      Color(0xFF0B2750),
                      Color(0xFF071529),
                    ],
                    borderTone: const Color(0xFF2B64A6),
                    tint: .15,
                    children: [
                      LayoutBuilder(
                        builder: (context, constraints) {
                          // Keep the market/direction control intentionally
                          // slim and docked to the right edge in Arabic mode;
                          // the remaining width belongs to the anchor field
                          // so selected setup names can be shown in full.
                          final marketControlWidth = constraints.maxWidth < 280
                              ? 96.0
                              : 104.0;
                          return SizedBox(
                            key: const ValueKey(
                              'trade-entry-identifiers-available',
                            ),
                            width: constraints.maxWidth,
                            child: SizedBox(
                              key: const ValueKey(
                                'trade-entry-identifiers-row',
                              ),
                              width: constraints.maxWidth,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: marketControlWidth,
                                    child: InputDecorator(
                                      key: const ValueKey(
                                        'trade-market-direction-field',
                                      ),
                                      decoration: _blueSelectorDecoration(
                                        label: _copy(
                                          'السوق / الاتجاه',
                                          'Market / Direction',
                                        ),
                                      ),
                                      isEmpty: false,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: _compactPopupChoice<String>(
                                              key: const ValueKey(
                                                'trade-market-input',
                                              ),
                                              popupAnchorKey:
                                                  _marketPopupAnchorKey,
                                              itemKeyPrefix:
                                                  'trade-market-option',
                                              caption: _copy('الرمز', 'Symbol'),
                                              minMenuWidth: 176,
                                              valueDirection: TextDirection.ltr,
                                              selectedValue: _symbol,
                                              values: const ['NQ', 'ES', 'GC'],
                                              labelFor: (value) => value,
                                              onSelected: (value) => setState(
                                                () => _symbol = value,
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 3,
                                            ),
                                            child: Container(
                                              width: 1,
                                              height: 30,
                                              decoration: BoxDecoration(
                                                color: TdTokens.of(context)
                                                    .accent
                                                    .withValues(alpha: .38),
                                                borderRadius:
                                                    BorderRadius.circular(1),
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            child:
                                                _compactPopupChoice<TradeSide>(
                                                  key: const ValueKey(
                                                    'trade-direction-selector',
                                                  ),
                                                  popupAnchorKey:
                                                      _directionPopupAnchorKey,
                                                  itemKeyPrefix:
                                                      'trade-direction-option',
                                                  caption: _copy(
                                                    'الاتجاه',
                                                    'Direction',
                                                  ),
                                                  minMenuWidth: 176,
                                                  valueDirection: _ar
                                                      ? TextDirection.rtl
                                                      : TextDirection.ltr,
                                                  selectedValue: _side,
                                                  values: TradeSide.values,
                                                  labelFor: (value) => _copy(
                                                    value == TradeSide.buy
                                                        ? 'شراء'
                                                        : 'بيع',
                                                    value == TradeSide.buy
                                                        ? 'Buy'
                                                        : 'Sell',
                                                  ),
                                                  onSelected: (value) =>
                                                      setState(
                                                        () => _side =
                                                            _side == value
                                                            ? null
                                                            : value,
                                                      ),
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(child: _anchorMultiSelector()),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 18),
                      _setupSelectionBlock(
                        title: _copy('سبب الدخول', 'Entry reason'),
                        setups: _entrySetups
                            .map(
                              (item) => (
                                label: item.reason,
                                timeframe: item.timeframe,
                                item: item,
                              ),
                            )
                            .toList(),
                        onAdd: _addEntrySetup,
                        onRemove: (item) =>
                            _removeEntrySetup(item as TradeEntrySetup),
                        onEdit: (item) =>
                            _editEntrySetup(item as TradeEntrySetup),
                        addKey: const ValueKey('add-entry-setup'),
                      ),
                      const SizedBox(height: 16),
                      _setupSelectionBlock(
                        title: _copy('تأكيد الدخول', 'Entry confirmation'),
                        setups: _confirmationSetups
                            .map(
                              (item) => (
                                label: _confirmationLabel(item.type),
                                timeframe: item.timeframe,
                                item: item,
                              ),
                            )
                            .toList(),
                        onAdd: _addConfirmationSetup,
                        onRemove: (item) => _removeConfirmationSetup(
                          item as TradeConfirmationSetup,
                        ),
                        onEdit: (item) => _editConfirmationSetup(
                          item as TradeConfirmationSetup,
                        ),
                        addKey: const ValueKey('add-confirmation-setup'),
                      ),
                      const SizedBox(height: 16),
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final mood = tradeMoodOptions.firstWhere(
                            (item) => item.key == _mood,
                            orElse: () => tradeMoodOptions.firstWhere(
                              (item) => item.key == 'moodUnknown',
                            ),
                          );
                          final popupWidth = constraints.maxWidth < 180
                              ? 180.0
                              : constraints.maxWidth;
                          return PopupMenuButton<String>(
                            key: const ValueKey('trade-mood-dropdown'),
                            tooltip: _copy('الحالة النفسية', 'Mindset'),
                            padding: EdgeInsets.zero,
                            position: PopupMenuPosition.under,
                            popUpAnimationStyle: tdPopupMenuAnimationStyle,
                            constraints: BoxConstraints.tightFor(
                              width: popupWidth,
                            ),
                            onSelected: (value) =>
                                setState(() => _mood = value),
                            itemBuilder: (menuContext) => [
                              for (final item in tradeMoodOptions)
                                PopupMenuItem<String>(
                                  key: ValueKey(
                                    'trade-mood-option-${item.key}',
                                  ),
                                  value: item.key,
                                  height: 42,
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(_ar ? item.ar : item.en),
                                      ),
                                      if (item.key == _mood)
                                        Icon(
                                          Icons.check_rounded,
                                          size: 16,
                                          color: TdTokens.of(menuContext)
                                              .accent,
                                        ),
                                    ],
                                  ),
                                ),
                            ],
                            child: InputDecorator(
                              decoration: InputDecoration(
                                labelText: _copy('الحالة النفسية', 'Mindset'),
                                prefixIcon: const Icon(
                                  Icons.psychology_outlined,
                                ),
                              ),
                              isEmpty: false,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      _ar ? mood.ar : mood.en,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    size: 18,
                                    color: TdTokens.of(context).text3,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 14),
                      OutlinedButton.icon(
                        onPressed: _pickDateTime,
                        icon: const Icon(Icons.calendar_month_outlined),
                        label: Text(
                          '${_copy('تاريخ ووقت الصفقة', 'Trade date & time')}: ${shortDate(_tradedAt)} · ${TimeOfDay.fromDateTime(_tradedAt).format(context)}',
                        ),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size.fromHeight(48),
                          alignment: AlignmentDirectional.centerStart,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _buildEntryBehaviorSections(context),
                  const SizedBox(height: 14),
                  _sectionCard(
                    context,
                    title: _copy('صور الصفقة', 'Trade images'),
                    icon: Icons.photo_library_outlined,
                    tone: _imagesTone,
                    gradientColors: const [
                      Color(0xFF232A33),
                      Color(0xFF1A2029),
                      Color(0xFF141920),
                    ],
                    borderTone: const Color(0xFF626B74),
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: ImageAttachmentTile(
                              label: _copy('قبل الدخول', 'Before entry'),
                              path: _beforePath,
                              onTap: () => _pickImage(_TradeImageSlot.before),
                              onRemove: _beforePath == null
                                  ? null
                                  : () => setState(() => _beforePath = null),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ImageAttachmentTile(
                              label: _copy('بعد الدخول', 'After entry'),
                              path: _afterPath,
                              onTap: () => _pickImage(_TradeImageSlot.after),
                              onRemove: _afterPath == null
                                  ? null
                                  : () => setState(() => _afterPath = null),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      ImageAttachmentTile(
                        key: const ValueKey('confirmation-image-attachment'),
                        label: _copy('تأكيد الدخول', 'Entry confirmation'),
                        path: _confirmationImagePath,
                        onTap: () => _pickImage(_TradeImageSlot.confirmation),
                        onRemove: _confirmationImagePath == null
                            ? null
                            : () =>
                                  setState(() => _confirmationImagePath = null),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  if (_classification == null)
                    OutlinedButton.icon(
                      key: const ValueKey('choose-trade-classification-button'),
                      onPressed: _busy ? null : _chooseClassification,
                      icon: const Icon(Icons.tune_rounded, size: 19),
                      label: Text(tr(context, 'classifyTrade')),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                        backgroundColor: tokens.surface2,
                        foregroundColor: tokens.text1,
                        side: BorderSide(
                          color: tokens.lineStrong.withValues(alpha: .72),
                          width: .9,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    )
                  else ...[
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${tr(context, 'tradeClassification')}: ${_classificationLabel(_classification!)}',
                            style: Theme.of(context).textTheme.labelMedium
                                ?.copyWith(
                                  color: tokens.text2,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                        TextButton(
                          key: const ValueKey(
                            'change-trade-classification-button',
                          ),
                          onPressed: _busy ? null : _chooseClassification,
                          style: TextButton.styleFrom(
                            foregroundColor: tokens.text2,
                            visualDensity: VisualDensity.compact,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                          ),
                          child: Text(tr(context, 'changeClassification')),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    FilledButton.icon(
                      key: const ValueKey('save-trade-button'),
                      onPressed: _busy ? null : _save,
                      icon: _busy
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.save_outlined),
                      label: Text(tr(context, 'save')),
                      style: FilledButton.styleFrom(
                        minimumSize: const Size.fromHeight(52),
                      ),
                    ),
                  ],
                ],
              ),
              if (_busy)
                Positioned.fill(
                  child: ColoredBox(
                    color: tokens.scrim.withValues(alpha: .26),
                    child: const Center(child: CircularProgressIndicator()),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  String _confirmationLabel(String type) {
    final known = tradeConfirmationOptions
        .where((item) => item.key == type)
        .firstOrNull;
    if (known != null) return _ar ? known.ar : known.en;
    return type;
  }

  Widget _sectionCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required List<Widget> children,
    Color? tone,
    Color? borderTone,
    List<Color>? gradientColors,
    double tint = .10,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: tone == null
                    ? tokens.surface3
                    : tone.withValues(alpha: isDark ? .16 : .11),
                borderRadius: BorderRadius.circular(10),
                border: tone == null
                    ? null
                    : Border.all(
                        color: tone.withValues(alpha: .14),
                        width: 0.8,
                      ),
              ),
              child: Icon(icon, size: 18, color: tone ?? tokens.accent),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                style: Theme.of(context).textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        ...children,
      ],
    );

    if (tone == null) {
      return AppCard(
        padding: const EdgeInsets.all(16),
        sheen: false,
        child: content,
      );
    }
    Widget sectionContent = content;
    if (identical(tone, _dataTone) || tone == _dataTone) {
      final baseTheme = Theme.of(context);
      final fieldFill = isDark
          ? const Color(0xFF071834)
          : Color.alphaBlend(_dataTone.withValues(alpha: .10), tokens.inset);
      final fieldBorder = OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(
          color: isDark
              ? const Color(0xFF21405B).withValues(alpha: .52)
              : tokens.lineSubtle.withValues(alpha: .68),
          width: 0.78,
        ),
      );
      sectionContent = Theme(
        data: baseTheme.copyWith(
          inputDecorationTheme: baseTheme.inputDecorationTheme.copyWith(
            filled: true,
            fillColor: fieldFill,
            enabledBorder: fieldBorder,
            border: fieldBorder,
            focusedBorder: fieldBorder.copyWith(
              borderSide: BorderSide(
                color: _dataTone.withValues(alpha: .78),
                width: 1.05,
              ),
            ),
          ),
        ),
        child: content,
      );
    }
    final neutralSurface = tone == _resultTone || tone == _imagesTone;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          tone.withValues(alpha: isDark ? tint : tint * .58),
          tokens.surface1,
        ),
        gradient: !isDark || gradientColors == null
            ? null
            : neutralSurface
            ? LinearGradient(
                begin: AlignmentDirectional.topStart,
                end: AlignmentDirectional.bottomEnd,
                colors: [tokens.surface2, tokens.surface1],
              )
            : LinearGradient(
                begin: AlignmentDirectional.topStart,
                end: AlignmentDirectional.bottomEnd,
                colors: gradientColors,
                stops: gradientColors.length == 4
                    ? const [0, .32, .68, 1]
                    : null,
              ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: neutralSurface && isDark
              ? tokens.lineSubtle
              : (borderTone ?? tone).withValues(alpha: isDark ? .17 : .13),
          width: 0.8,
        ),
      ),
      child: sectionContent,
    );
  }

  Widget _numericField({
    required TextEditingController controller,
    required Key key,
    required String label,
    required String suffix,
    required String? Function(String?) validator,
    bool signed = false,
    bool readOnly = false,
    ValueChanged<String>? onChanged,
  }) => TextFormField(
    key: key,
    controller: controller,
    validator: validator,
    readOnly: readOnly,
    onChanged: onChanged,
    keyboardType: TextInputType.numberWithOptions(
      decimal: true,
      signed: signed,
    ),
    textDirection: TextDirection.ltr,
    textAlign: TextAlign.start,
    decoration: InputDecoration(labelText: label, suffixText: suffix),
  );

  Widget _readoutField({
    required TextEditingController controller,
    required Key key,
    required String label,
    required String suffix,
  }) => TextFormField(
    key: key,
    controller: controller,
    readOnly: true,
    textDirection: TextDirection.ltr,
    decoration: InputDecoration(
      labelText: label,
      suffixText: suffix,
      filled: true,
      fillColor: TdTokens.of(context).inset,
    ),
  );

  Widget _fieldLabel(String label) => Text(
    label,
    style: Theme.of(context).textTheme.labelLarge
        ?.copyWith(fontWeight: FontWeight.w700),
  );

  List<String> get _orderedAnchorKeys {
    final known = tradeAnchorOptions
        .where((option) => _anchors.contains(option.key))
        .map((option) => option.key);
    final knownSet = known.toSet();
    final legacyOrUnknown = _anchors.where((key) => !knownSet.contains(key));
    return [...known, ...legacyOrUnknown].toList(growable: false);
  }

  Future<void> _pickAnchors() async {
    final anchorContext = _anchorMenuAnchorKey.currentContext;
    final anchorBox = anchorContext?.findRenderObject();
    final overlayBox = Overlay.of(
      context,
      rootOverlay: true,
    ).context.findRenderObject();
    if (anchorBox is! RenderBox ||
        overlayBox is! RenderBox ||
        !anchorBox.hasSize ||
        !overlayBox.hasSize) {
      return;
    }

    final anchorTopLeft = anchorBox.localToGlobal(
      Offset.zero,
      ancestor: overlayBox,
    );
    final anchorRect = anchorTopLeft & anchorBox.size;
    final overlayRect = Offset.zero & overlayBox.size;
    final position = RelativeRect.fromRect(
      anchorRect.shift(const Offset(0, 6)),
      overlayRect,
    );
    final maxWidth = overlayBox.size.width - 24;
    final popupWidth = anchorBox.size.width < 220
        ? (maxWidth < 220 ? maxWidth : 220.0)
        : anchorBox.size.width;
    final selected = {..._anchors};
    final popupColor = tdPopupMenuColor(Theme.of(context).brightness);
    final popupShape = tdPopupMenuShape(Theme.of(context).brightness);

    await showMenu<void>(
      context: context,
      position: position,
      color: popupColor,
      surfaceTintColor: Colors.transparent,
      elevation: 9,
      shape: popupShape,
      menuPadding: EdgeInsets.zero,
      constraints: BoxConstraints.tightFor(width: popupWidth),
      popUpAnimationStyle: tdPopupMenuAnimationStyle,
      items: [
        PopupMenuItem<void>(
          enabled: false,
          height: (tradeAnchorOptions.length * 47).toDouble(),
          padding: EdgeInsets.zero,
          child: StatefulBuilder(
            builder: (menuContext, setMenuState) => Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final option in tradeAnchorOptions)
                  InkWell(
                    key: ValueKey('trade-anchor-option-${option.key}'),
                    onTap: () async {
                      if (selected.contains(option.key)) {
                        // Older saved anchors may not have a timeframe yet.
                        // Complete that missing value before treating a tap as
                        // a deliberate deselection.
                        if (_anchorTimeframes[option.key] == null) {
                          final timeframe = await _showTimeframeSheet(
                            title: _copy('فريم الارتكاز', 'Anchor timeframe'),
                            centered: true,
                          );
                          if (timeframe == null || !mounted) return;
                          setState(
                            () => _anchorTimeframes[option.key] = timeframe,
                          );
                        } else {
                          setMenuState(() => selected.remove(option.key));
                          if (mounted) {
                            setState(() {
                              _anchors.remove(option.key);
                              _anchorTimeframes.remove(option.key);
                            });
                          }
                        }
                        return;
                      }
                      final timeframe = await _showTimeframeSheet(
                        title: _copy('فريم الارتكاز', 'Anchor timeframe'),
                        centered: true,
                      );
                      if (timeframe == null || !mounted) return;
                      setMenuState(() => selected.add(option.key));
                      setState(() {
                        _anchors.add(option.key);
                        _anchorTimeframes[option.key] = timeframe;
                      });
                    },
                    child: SizedBox(
                      height: 47,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 13),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                _ar ? option.ar : option.en,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(menuContext).textTheme.bodySmall
                                    ?.copyWith(
                                      color: TdTokens.of(menuContext).text1,
                                      fontSize: 14.5,
                                      fontWeight: selected.contains(option.key)
                                          ? FontWeight.w700
                                          : FontWeight.w500,
                                    ),
                              ),
                            ),
                            Icon(
                              selected.contains(option.key)
                                  ? Icons.check_box_rounded
                                  : Icons.check_box_outline_blank_rounded,
                              size: 18,
                              color: selected.contains(option.key)
                                  ? TdTokens.of(menuContext).accent
                                  : TdTokens.of(menuContext).text3,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _anchorMultiSelector() {
    final labels = _orderedAnchorKeys
        .map((key) {
          final option = tradeAnchorOptions
              .where((item) => item.key == key)
              .firstOrNull;
          final label = option == null ? key : (_ar ? option.ar : option.en);
          final timeframe = _anchorTimeframes[key];
          return timeframe == null ? label : '$label $timeframe';
        })
        .toList(growable: false);
    // Show every selected anchor label without abbreviation or ellipsis.
    // The expanded field to the left provides room for natural line wrapping.
    final value = labels.join('، ');
    return KeyedSubtree(
      key: const ValueKey('trade-anchor-selector'),
      child: InkWell(
        key: _anchorMenuAnchorKey,
        onTap: _pickAnchors,
        borderRadius: BorderRadius.circular(14),
        child: InputDecorator(
          decoration: _blueSelectorDecoration(
            label: _copy('الارتكاز', 'Anchor'),
          ),
          isEmpty: value.isEmpty,
          child: SizedBox(
            width: double.infinity,
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 32),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  value,
                  key: const ValueKey('trade-anchor-selected-values'),
                  softWrap: true,
                  textDirection: TextDirection.ltr,
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: TdTokens.of(context).text1,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _setupSelectionBlock({
    required String title,
    required List<({String label, String timeframe, Object item})> setups,
    required Future<void> Function() onAdd,
    required void Function(Object) onRemove,
    required void Function(Object) onEdit,
    required Key addKey,
  }) {
    final tokens = TdTokens.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(child: _fieldLabel(title)),
            Text(
              '${setups.length}',
              style: Theme.of(context).textTheme.labelMedium
                  ?.copyWith(color: tokens.text3, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        if (setups.isNotEmpty) ...[
          const SizedBox(height: 9),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              for (final setup in setups)
                InputChip(
                  label: Text(
                    '${setup.label} ${setup.timeframe.isEmpty ? _copy('دون فريم', 'No timeframe') : setup.timeframe}',
                  ),
                  onPressed: () => onEdit(setup.item),
                  onDeleted: () => onRemove(setup.item),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  deleteIconColor: tokens.text3,
                  backgroundColor: tokens.surface2,
                  side: BorderSide(
                    color: tokens.lineSubtle.withValues(alpha: .78),
                    width: 0.8,
                  ),
                  labelStyle: Theme.of(context).textTheme.labelMedium
                      ?.copyWith(fontWeight: FontWeight.w700),
                  visualDensity: VisualDensity.compact,
                ),
            ],
          ),
        ],
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: OutlinedButton.icon(
            key: addKey,
            onPressed: onAdd,
            icon: const Icon(Icons.add, size: 18),
            label: Text(_copy('إضافة', 'Add')),
            style: OutlinedButton.styleFrom(
              visualDensity: VisualDensity.compact,
            ),
          ),
        ),
      ],
    );
  }

  Widget _entryConditionSelectionBlock({
    required List<TradeEntryConditionSetup> setups,
    required List<TradeEntryOption> options,
    required Future<void> Function() onAdd,
    required void Function(Object) onRemove,
    required void Function(Object) onEdit,
    required Key addKey,
    required Color tone,
  }) {
    final tokens = TdTokens.of(context);
    String optionLabel(String key) =>
        options
            .where((option) => option.key == key)
            .map((option) => _ar ? option.ar : option.en)
            .firstOrNull ??
        key;

    String setupLabel(TradeEntryConditionSetup setup) =>
        formatTradeEntryConditionSetupLabel(
          setup: setup,
          optionLabel: optionLabel(setup.optionKey),
          arabic: _ar,
          side: _side,
        );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (setups.isNotEmpty) ...[
          const SizedBox(height: 4),
          Column(
            children: [
              for (final setup in setups)
                Container(
                  key: ValueKey(
                    'entry-condition-${setup.optionKey}-${setup.timeframe}-${setup.secondaryTimeframe ?? ''}-${setup.touch2}',
                  ),
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 7),
                  decoration: BoxDecoration(
                    color: Color.alphaBlend(
                      tone.withValues(alpha: .09),
                      tokens.surface2,
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: tone.withValues(alpha: .16),
                      width: .8,
                    ),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => onEdit(setup),
                      borderRadius: BorderRadius.circular(10),
                      child: Padding(
                        padding: const EdgeInsetsDirectional.fromSTEB(
                          11,
                          9,
                          5,
                          9,
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsetsDirectional.only(
                                  top: 5,
                                  bottom: 5,
                                ),
                                child: Text(
                                  setupLabel(setup),
                                  key: ValueKey(
                                    'entry-condition-label-${setup.optionKey}-${setup.timeframe}-${setup.secondaryTimeframe ?? ''}-${setup.touch2}',
                                  ),
                                  softWrap: true,
                                  maxLines: null,
                                  style: Theme.of(context).textTheme.bodySmall
                                      ?.copyWith(
                                        color: tokens.text1,
                                        fontSize: 13.5,
                                        fontWeight: FontWeight.w700,
                                        height: 1.45,
                                      ),
                                ),
                              ),
                            ),
                            IconButton(
                              tooltip: _copy(
                                'حذف الاختيار',
                                'Remove selection',
                              ),
                              visualDensity: VisualDensity.compact,
                              constraints: const BoxConstraints.tightFor(
                                width: 34,
                                height: 34,
                              ),
                              padding: EdgeInsets.zero,
                              onPressed: () => onRemove(setup),
                              icon: Icon(
                                Icons.close_rounded,
                                size: 17,
                                color: tokens.text3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: OutlinedButton(
            key: addKey,
            onPressed: onAdd,
            style: OutlinedButton.styleFrom(
              foregroundColor: tone,
              side: BorderSide(color: tone.withValues(alpha: .22), width: 0.8),
              visualDensity: VisualDensity.compact,
            ),
            child: Text(_copy('اختيار', 'Select')),
          ),
        ),
      ],
    );
  }

  Widget _entryConditionCategory({
    required Key key,
    GlobalKey? linkKey,
    Key? surfaceKey,
    required String title,
    required int count,
    required Color tone,
    required VoidCallback onTap,
    required Widget child,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      key: surfaceKey,
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          tone.withValues(alpha: isDark ? .14 : .08),
          tokens.surface2,
        ),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: tone.withValues(alpha: isDark ? .17 : .13),
          width: .8,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              key: key,
              borderRadius: BorderRadius.circular(13),
              onTap: onTap,
              child: Padding(
                key: linkKey,
                padding: const EdgeInsetsDirectional.fromSTEB(13, 13, 13, 12),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: Theme.of(context).textTheme.titleSmall
                            ?.copyWith(fontWeight: FontWeight.w800),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: count > 0
                            ? tone.withValues(alpha: .16)
                            : tokens.surface3,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: tone.withValues(alpha: count > 0 ? .20 : .10),
                          width: .8,
                        ),
                      ),
                      child: Text(
                        '$count',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: count > 0 ? tone : tokens.text3,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(10, 0, 10, 10),
            child: child,
          ),
        ],
      ),
    );
  }

  Widget _buildEntryBehaviorSections(BuildContext context) {
    final hasNoEntryReason = _noEntryReasons.isNotEmpty;
    final reverseSignalTone = hasNoEntryReason
        ? _noEntryTone
        : _reverseSignalsTone;

    return Stack(
      key: _behaviorLinkStackKey,
      clipBehavior: Clip.none,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _sectionCard(
              context,
              title: _copy('ظروف الدخول', 'Entry conditions'),
              icon: Icons.radar_rounded,
              tone: _entryConditionsTone,
              gradientColors: const [
                Color(0xFF1B3948),
                Color(0xFF162F3D),
                Color(0xFF122936),
                Color(0xFF0E202B),
              ],
              borderTone: const Color(0xFF456F82),
              tint: .12,
              children: [
                _entryConditionCategory(
                  key: const ValueKey('reverse-signal-category-trigger'),
                  linkKey: _reverseSignalsHeaderKey,
                  surfaceKey: const ValueKey('reverse-signal-category-surface'),
                  title: _copy('إشارات عكسية', 'Opposing signals'),
                  count: _reverseSignalSetups.length,
                  tone: reverseSignalTone,
                  onTap: _addReverseSignalSetup,
                  child: _entryConditionSelectionBlock(
                    setups: _reverseSignalSetups,
                    options: tradeReverseSignalOptions,
                    onAdd: _addReverseSignalSetup,
                    onRemove: (setup) => _removeReverseSignalSetup(
                      setup as TradeEntryConditionSetup,
                    ),
                    onEdit: (setup) => _editReverseSignalSetup(
                      setup as TradeEntryConditionSetup,
                    ),
                    addKey: const ValueKey('add-reverse-signal-setup'),
                    tone: reverseSignalTone,
                  ),
                ),
                const SizedBox(height: 8),
                _entryConditionCategory(
                  key: const ValueKey('bounce-zone-category-trigger'),
                  title: _copy('منطقة الارتداد', 'Bounce area'),
                  count: _bounceZoneSetups.length,
                  tone: _bounceZoneTone,
                  onTap: _addBounceZoneSetup,
                  child: _entryConditionSelectionBlock(
                    setups: _bounceZoneSetups,
                    options: tradeBounceZoneOptions,
                    onAdd: _addBounceZoneSetup,
                    onRemove: (setup) => _removeBounceZoneSetup(
                      setup as TradeEntryConditionSetup,
                    ),
                    onEdit: (setup) =>
                        _editBounceZoneSetup(setup as TradeEntryConditionSetup),
                    addKey: const ValueKey('add-bounce-zone-setup'),
                    tone: _bounceZoneTone,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _buildBehaviorCard(context),
          ],
        ),
        if (hasNoEntryReason)
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                key: const ValueKey('no-entry-signal-connector'),
                painter: _NoEntrySignalConnectorPainter(
                  stackKey: _behaviorLinkStackKey,
                  sourceKey: _reverseSignalsHeaderKey,
                  destinationKey: _noEntryHeaderKey,
                  color: _noEntryTone.withValues(alpha: .62),
                  isRtl: _ar,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildBehaviorCard(BuildContext context) {
    final tokens = TdTokens.of(context);
    final decisionCount = tradeReviewGroups
        .expand((group) => group.options)
        .where((option) => _executionReviewKeys.contains(option.key))
        .length;
    final noEntryCount = _noEntryReasons.length;
    return _sectionCard(
      context,
      title: _copy('التصرفات', 'Trading behavior'),
      icon: Icons.fact_check_outlined,
      tone: _behaviorTone,
      gradientColors: const [
        Color(0xFF312A57),
        Color(0xFF2B2549),
        Color(0xFF241F3E),
        Color(0xFF1D1933),
      ],
      borderTone: const Color(0xFF7863C4),
      tint: .14,
      children: [
        _behaviorExpansion(
          title: _copy('القرارات', 'Decisions'),
          count: decisionCount,
          tone: _decisionTone,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (final group in tradeReviewGroups) ...[
                Padding(
                  padding: const EdgeInsets.only(top: 9, bottom: 5),
                  child: Text(
                    _ar ? group.titleAr : group.titleEn,
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                      color: tokens.text2,
                    ),
                  ),
                ),
                for (final option in group.options)
                  _selectionRow(
                    option,
                    _executionReviewKeys,
                    keyPrefix: 'review',
                    accent: _decisionTone,
                  ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 8),
        _behaviorExpansion(
          title: _copy('الالتزام', 'Plan commitment'),
          count: tradeCommitmentOptions
              .where((item) => _executionReviewKeys.contains(item.key))
              .length,
          tone: _commitmentTone,
          child: Column(
            children: [
              for (final option in tradeCommitmentOptions)
                _selectionRow(
                  option,
                  _executionReviewKeys,
                  keyPrefix: 'review',
                  accent: _commitmentTone,
                ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _behaviorExpansion(
          title: _copy('أسباب عدم الدخول', 'Reasons for not entering'),
          count: noEntryCount,
          tone: _noEntryTone,
          headerKey: _noEntryHeaderKey,
          surfaceKey: const ValueKey('no-entry-category-surface'),
          child: Column(
            children: [
              for (final option in tradeNoEntryOptions)
                _selectionRow(
                  option,
                  _noEntryReasons,
                  keyPrefix: 'no-entry',
                  accent: _noEntryTone,
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _behaviorExpansion({
    required String title,
    required int count,
    required Color tone,
    required Widget child,
    Widget? leading,
    Key? headerKey,
    Key? surfaceKey,
  }) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      key: surfaceKey,
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          tone.withValues(alpha: isDark ? .14 : .08),
          tokens.surface2,
        ),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: tone.withValues(alpha: isDark ? .17 : .13),
          width: 0.8,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(
              horizontal: 13,
              vertical: 2,
            ),
            childrenPadding: const EdgeInsets.fromLTRB(4, 0, 4, 12),
            title: Row(
              key: headerKey,
              children: [
                if (leading != null) ...[leading, const SizedBox(width: 7)],
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: isDark ? Colors.white : tokens.text1,
                      fontSize: 15.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: count > 0
                        ? tone.withValues(alpha: .16)
                        : tokens.surface3,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: tone.withValues(alpha: count > 0 ? .20 : .10),
                      width: 0.8,
                    ),
                  ),
                  child: Text(
                    '$count',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: count > 0 ? tone : tokens.text3,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            children: [child],
          ),
        ),
      ),
    );
  }

  Widget _selectionRow(
    TradeEntryOption option,
    Set<String> selected, {
    required String keyPrefix,
    required Color accent,
  }) {
    final tokens = TdTokens.of(context);
    final isSelected = selected.contains(option.key);
    final hasReviewArtwork = tradeReviewOptionEmojiAssets.containsKey(
      option.key,
    );
    return InkWell(
      key: ValueKey('$keyPrefix-${option.key}'),
      onTap: () => _toggleSet(selected, option.key, !isSelected),
      borderRadius: BorderRadius.circular(9),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              width: 23,
              height: 23,
              margin: EdgeInsetsDirectional.only(
                top: 1,
                end: hasReviewArtwork ? 6 : 9,
              ),
              decoration: BoxDecoration(
                color: isSelected ? accent : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: isSelected
                      ? accent
                      : tokens.lineStrong.withValues(alpha: .62),
                  width: 1.0,
                ),
              ),
              child: isSelected
                  ? const Icon(Icons.check, size: 15, color: Colors.white)
                  : null,
            ),
            if (hasReviewArtwork) ...[
              const SizedBox(width: 2),
              TradeReviewOptionEmoji(
                key: ValueKey('review-art-${option.key}'),
                optionKey: option.key,
                size: 28,
              ),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Text(
                _ar ? option.ar : option.en,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: isSelected ? tokens.text1 : tokens.text2,
                  fontSize: 14.5,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  height: 1.45,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoEntrySignalConnectorPainter extends CustomPainter {
  const _NoEntrySignalConnectorPainter({
    required this.stackKey,
    required this.sourceKey,
    required this.destinationKey,
    required this.color,
    required this.isRtl,
  });

  final GlobalKey stackKey;
  final GlobalKey sourceKey;
  final GlobalKey destinationKey;
  final Color color;
  final bool isRtl;

  @override
  void paint(Canvas canvas, Size size) {
    final stackObject = stackKey.currentContext?.findRenderObject();
    final sourceObject = sourceKey.currentContext?.findRenderObject();
    final destinationObject = destinationKey.currentContext?.findRenderObject();
    if (stackObject is! RenderBox ||
        sourceObject is! RenderBox ||
        destinationObject is! RenderBox ||
        !stackObject.hasSize ||
        !sourceObject.hasSize ||
        !destinationObject.hasSize) {
      return;
    }

    final sourceSide = sourceObject.localToGlobal(
      Offset(isRtl ? sourceObject.size.width : 0, sourceObject.size.height / 2),
      ancestor: stackObject,
    );
    final destinationSide = destinationObject.localToGlobal(
      Offset(
        isRtl ? destinationObject.size.width : 0,
        destinationObject.size.height / 2,
      ),
      ancestor: stackObject,
    );
    final railX = isRtl ? size.width - 5 : 5.0;
    final linkPaint = Paint()
      ..color = color
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round
      ..isAntiAlias = true;

    canvas.drawLine(
      Offset(railX, sourceSide.dy),
      Offset(railX, destinationSide.dy),
      linkPaint,
    );
    canvas.drawLine(sourceSide, Offset(railX, sourceSide.dy), linkPaint);
    canvas.drawLine(
      destinationSide,
      Offset(railX, destinationSide.dy),
      linkPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _NoEntrySignalConnectorPainter oldDelegate) =>
      oldDelegate.stackKey != stackKey ||
      oldDelegate.sourceKey != sourceKey ||
      oldDelegate.destinationKey != destinationKey ||
      oldDelegate.color != color ||
      oldDelegate.isRtl != isRtl;
}
