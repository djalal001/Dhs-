import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_behavior_link_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'behavior-link-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'behavior-link-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets(
    'links opposing signals styling to the selected no-entry reason',
    (tester) async {
      tester.view.physicalSize = const Size(420, 1800);
      tester.view.devicePixelRatio = 1;
      await tester.pumpWidget(
        AppScope(
          controller: app,
          child: MaterialApp(
            theme: buildAppTheme(Brightness.dark),
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar'), Locale('en')],
            localizationsDelegates: GlobalMaterialLocalizations.delegates,
            home: const TradeFormScreen(),
          ),
        ),
      );
      await tester.pumpAndSettle();

      const reverseSurfaceKey = ValueKey('reverse-signal-category-surface');
      const noEntrySurfaceKey = ValueKey('no-entry-category-surface');
      const connectorKey = ValueKey('no-entry-signal-connector');
      Color surfaceColor(Key key) =>
          (tester.widget<Container>(find.byKey(key)).decoration
                  as BoxDecoration)
              .color!;

      final inactiveReverseColor = surfaceColor(reverseSurfaceKey);
      expect(inactiveReverseColor, isNot(surfaceColor(noEntrySurfaceKey)));
      expect(find.byKey(connectorKey), findsNothing);

      final noEntryHeader = find.text('أسباب عدم الدخول');
      await tester.tap(noEntryHeader);
      await tester.pumpAndSettle();

      final reason = find.byKey(
        const ValueKey('no-entry-fearRepeatLossAfterLoss'),
      );
      await tester.tap(reason);
      await tester.pumpAndSettle();

      expect(find.byKey(connectorKey), findsOneWidget);
      expect(surfaceColor(reverseSurfaceKey), surfaceColor(noEntrySurfaceKey));
      for (final title in const ['القرارات', 'الالتزام', 'أسباب عدم الدخول']) {
        final heading = tester.widget<Text>(find.text(title));
        expect(heading.style?.color, Colors.white);
        expect(heading.style?.fontSize, 15.5);
      }
      final reasonText = tester.widget<Text>(
        find.descendant(of: reason, matching: find.byType(Text)),
      );
      expect(reasonText.style?.fontSize, 14.5);

      await tester.tap(reason);
      await tester.pumpAndSettle();
      expect(find.byKey(connectorKey), findsNothing);
      expect(surfaceColor(reverseSurfaceKey), inactiveReverseColor);
    },
  );
}
