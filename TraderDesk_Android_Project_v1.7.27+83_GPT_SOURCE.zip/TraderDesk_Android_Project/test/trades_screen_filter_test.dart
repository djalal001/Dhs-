import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/main.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/state/app_controller.dart';

void main() {
  late Directory temp;
  late AppController app;
  late TradingAccount account;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp(
      'trader_desk_trades_filter_',
    );
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    account = TradingAccount(
      id: 'trades-filter-account',
      name: 'Filter account',
      type: AccountType.demo,
      startingBalance: 10000,
      currency: 'USD',
      createdAt: DateTime(2024, 1, 1),
    );
    app.accounts = [account];
    app.selectedAccountId = account.id;
    app.trades = [
      _trade(id: 'winner', result: 25),
      _trade(id: 'loser', result: -12),
      // A saved setup with a no-entry reason belongs to the missed filter,
      // irrespective of any legacy result amount on the record.
      _trade(
        id: 'missed',
        result: 7,
        noEntryReasons: const ['fearLossNoHistory'],
      ),
    ];
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(390, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }

  Future<void> openTrades(WidgetTester tester) async {
    await tester.pumpWidget(TraderDeskApp(controller: app));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الصفقات').last);
    await tester.pumpAndSettle();
  }

  testWidgets('missed filter shows saved setups marked with no-entry reasons', (
    tester,
  ) async {
    usePhoneViewport(tester);
    await openTrades(tester);

    expect(find.byKey(const ValueKey('trades-filter-all')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-wins')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-losses')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-missed')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-missed')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-winner')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-loser')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('trades-filter-wins')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-winner')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('trades-filter-losses')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-loser')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'floating add button becomes clearer while scrolling and fades at rest',
    (tester) async {
      usePhoneViewport(tester);
      app.trades = List.generate(
        24,
        (index) => _trade(
          id: 'scroll-$index',
          result: index.isEven ? 10 : -5,
        ),
      );
      await openTrades(tester);

      final button = find.byKey(const ValueKey('trades-add-floating'));
      final opacity = find.byKey(
        const ValueKey('trades-add-floating-opacity'),
      );
      expect(button, findsOneWidget);
      expect(find.byKey(const ValueKey('trades-list')), findsOneWidget);
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.58);

      await tester.drag(
        find.byKey(const ValueKey('trades-list')),
        const Offset(0, -380),
      );
      await tester.pump();
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);

      await tester.pump(const Duration(milliseconds: 800));
      await tester.pump(const Duration(milliseconds: 200));
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.58);
      expect(tester.takeException(), isNull);
    },
  );
}

Trade _trade({
  required String id,
  required double result,
  List<String> noEntryReasons = const [],
}) => Trade(
  id: id,
  accountId: 'trades-filter-account',
  market: 'EURUSD',
  reason: 'Breakout',
  result: result,
  riskPercent: 0.25,
  side: TradeSide.buy,
  confirmation: 'confirmTechnical',
  sequence: '',
  mood: 'moodCalm',
  tradedAt: DateTime(2024, 1, 1),
  noEntryReasons: noEntryReasons,
);
