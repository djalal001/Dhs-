#!/usr/bin/env python3
"""Static regression checks for result sign, classification gating, and Mindset parity."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
APP_TEST = (ROOT / "test/trading_app_test.dart").read_text(encoding="utf-8")
CUSTOM_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
checks: list[tuple[str, bool]] = []
def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))

def section(text: str, start: str, end: str) -> str:
    return text.split(start, 1)[1].split(end, 1)[0] if start in text and end in text else ""

# Canonicalize legacy raw labels as well as semantic keys.
anchor_formatter = section(CATALOG, "String formatTradeAnchorLabel", "const tradeAnchorOptions")
check("legacy raw Bearish engulfing label is normalized", "case 'Bearish engulfing':" in anchor_formatter and "return 'Bearish Engulfing';" in anchor_formatter)
check("legacy raw Bullish engulfing label is normalized", "case 'Bullish engulfing':" in anchor_formatter and "return 'Bullish Engulfing';" in anchor_formatter)
check("catalog widget tests cover legacy lowercase labels", all(x in CATALOG_TEST for x in ["anchorKey: 'Bearish engulfing'", "anchorKey: 'bearish engulfing'", "Bearish Engulfing"]))
confirmation_display = section(CATALOG, "String tradeConfirmationDisplayKey", "const tradeReverseSignalOptions")
check("legacy raw confirmation labels normalize to canonical Bearish/Bullish Engulfing display keys", all(x in confirmation_display for x in ["type == 'Bearish engulfing'", "type == 'bearish engulfing'", "type == 'Bullish engulfing'", "return 'confirmBearishEngulfing';", "return 'confirmBullishEngulfing';"]))
check("catalog tests cover legacy raw confirmation capitalization", all(x in CATALOG_TEST for x in ["type: 'Bearish engulfing'", "type: 'bearish engulfing'", "type: 'Bullish engulfing'", "confirmBearishEngulfing"]))

# Mindset uses the same field border/fill geometry, with only its value content dimmed.
mindset = section(FORM, "Widget _buildMindsetSelector", "Widget _setupSelectionField")
check("Mindset uses the shared blue selector decoration", "_blueSelectorDecoration(" in mindset)
check("Mindset uses the same inset geometry as Market/Direction", all(x in mindset for x in ["EdgeInsetsDirectional.fromSTEB(", "10,", "8,", "8,"]))
check("Mindset opacity is applied only to value content, not around the field outline", "child: InputDecorator(" in mindset and "child: Opacity(\n                  opacity: enabled ? 1 : .52" in mindset and not mindset.lstrip().startswith("return Opacity("))
check("Mindset tests compare enabled, focused, and content padding", all(x in ENTRY_TEST for x in ["Mindset enabled border must match", "Mindset focused border must match", "Mindset content inset must match"]))

# Result field: show +/− on tap, hide after selection, store signed numeric result.
result_field = section(FORM, "Widget _resultAmountField", "Widget _numericField")
check("result amount is magnitude-only and does not accept manual sign", "FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))" in result_field and "signed: true" not in result_field)
check("result field is read-only until a sign or missed-only state is known", "readOnly: _resultSign == null || _hasEntryConditionsNoEntryLink" in result_field)
check("tap exposes sign choices inside the field", "onTap:" in result_field and "_showResultSignChoices = true" in result_field and "prefix: _ar ? null : _resultSignPrefix()" in result_field and "suffix: _ar ? _resultSignPrefix() : null" in result_field)
check("selected sign remains beside amount and can be changed", "trade-result-sign-indicator" in FORM and "_reopenResultSignChoices" in FORM)
check("positive and negative selections are tested for button disappearance and persistent indicator", all(x in ENTRY_TEST for x in ["the +/- choices disappear after a sign is selected", "trade-result-sign-indicator"]))
check("positive sign restricts result classification to Win", "if (_resultSign == 1) return const [TradeClassification.win];" in FORM and "a positive result permits only the win classification" in ENTRY_TEST)
check("negative sign restricts result classification to Loss", "if (_resultSign == -1) return const [TradeClassification.loss];" in FORM and "a negative result permits only the loss classification" in APP_TEST)

# Any no-entry evidence takes precedence over sign and clears the result.
check("psychological no-entry reason forces Missed only", "_noEntryReasons.isNotEmpty || _hasPracticalNoEntryReason" in FORM and "return const [TradeClassification.missed];" in FORM)
check("selecting a psychological no-entry reason clears current result/sign", "identical(values, _noEntryReasons) && selected" in FORM and "_enforceMissedOnlyOutcome();" in FORM)
check("practical reverse-signal long-press clears current result/sign", "_practicalNoEntryReverseSignalSetups.add(setup);" in FORM and "_enforceMissedOnlyOutcome();" in FORM)
check("save rejects classifications incompatible with current sign or no-entry evidence", "!_availableClassifications.contains(selectedClassification)" in FORM and "_classificationMatchesResult" in FORM)
check("psychological no-entry test verifies sign indicator is removed", "no-entry evidence removes the previously selected positive sign" in CUSTOM_TEST)
check("practical no-entry test verifies the realized amount and sign are cleared", "clears any realized P/L amount" in ENTRY_TEST and "practical-no-entry-link-reverseSr-30MIN" in ENTRY_TEST)

check("release version is 1.7.93+149", "version: 1.7.93+149" in PUBSPEC)
check("workflow metadata uses build149", "TraderDesk 1.7.93+149" in WORKFLOW and "traderdesk-1.7.93-build149-arm64-v8a-release" in WORKFLOW)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
