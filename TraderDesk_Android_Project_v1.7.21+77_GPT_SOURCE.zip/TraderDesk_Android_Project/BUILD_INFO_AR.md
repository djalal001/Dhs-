# معلومات البناء والتسليم — TraderDesk 1.7.21+77

- رقم الإصدار: `1.7.21`؛ رقم البناء: `77`.
- اسم الحزمة: `com.traderdesk.trader_desk`.
- نوع التسليم: مشروع Flutter كامل بصيغة ZIP، وليس APK.
- يستخدم سير عمل GitHub Actions إصدار Flutter المثبت `3.47.7` لبناء ARM64 Release.
- يشغّل `scripts/build_release_apk.sh` بناء AOT Release لمنصة `android-arm64` بعد `flutter clean` و`flutter pub get`، ثم يتحقق من بنية APK عبر `scripts/verify_arm64_apk.sh`.
- تمت إضافة ضبط `chmod +x android/gradlew` داخل سكربت البناء لضمان صلاحية Gradle Wrapper بعد فك ZIP.
- لم يُشغّل بناء Flutter هنا لعدم توفر Flutter/Dart SDK في بيئة التنفيذ. لذلك يجب اعتبار APK ونتيجة GitHub Actions غير متحققين حتى تنفيذ سير العمل.
