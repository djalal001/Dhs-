#!/usr/bin/env python3
"""Static checks for 1.7.104+160: break-even popup anchored on the save slot and
tinted Opposing signals / Bounce area inner fields."""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
TEST_CC = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
TEST_EC = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
failed = []

def check(name, ok):
    print(('PASS' if ok else 'FAIL'), name)
    if not ok:
        failed.append(name)

def body(start_marker, end_marker):
    a = FORM.index(start_marker)
    return FORM[a:FORM.index(end_marker, a)]

check('release is 1.7.104+160', 'version: 1.7.104+160' in PUBSPEC)
check('workflow identity updated', 'TraderDesk 1.7.104+160' in WORKFLOW and 'traderdesk-1.7.104-build160-arm64-v8a-release' in WORKFLOW)
check('update report exists', (ROOT / 'UPDATE_REPORT_1.7.104+160.md').exists())

# --- Request 1: popup in place of the save button -------------------------
check('inline stacked chooser removed', '_buildBreakEvenTypeChoice' not in FORM)
check('save slot key exists', "_saveSlotKey = GlobalKey(debugLabel: 'trade-save-slot')" in FORM)
popup = body('Future<void> _chooseBreakEvenType()', 'void _cycleMissedOutcome()')
check('popup is a dialog route (not inline)', 'showGeneralDialog<BreakEvenType>' in popup)
check('popup anchored to slot rect', '_saveSlotKey.currentContext' in popup and 'slotRect.bottom' in popup)
check('slot scrolled into view first', 'Scrollable.ensureVisible' in popup)
check('popup positioned by bottom edge', 'bottom: bottom' in popup and 'Positioned(' in popup)
check('both options keep their test keys', "ValueKey('break-even-type-${value.name}')" in popup and 'option(BreakEvenType.balanced)' in popup and 'option(BreakEvenType.atEntry)' in popup)
check('option min height >= 48', 'minHeight: 52' in popup)
check('one tap selects and closes', 'Navigator.of(dialogContext).pop(value)' in popup)
check('re-entrancy guard', '_breakEvenPopupOpen' in popup)
choose = body('Future<void> _chooseClassification()', 'String _breakEvenTypeLabel')
check('popup opens automatically only for break-even without type',
      'selected == TradeClassification.breakEven && _breakEvenType == null' in choose and 'addPostFrameCallback' in choose and '_chooseBreakEvenType()' in choose)
check('original classification sheet untouched', "ValueKey('trade-classification-option-${value.name}')" in choose and 'chooseTradeClassification' in choose)
slot = body('key: _saveSlotKey,', 'if (_busy) Positioned.fill')
check('slot holds prompt until subtype chosen',
      '_classification == TradeClassification.breakEven' in slot and '_breakEvenType == null' in slot and "choose-break-even-type-button" in slot)
check('save button lives in the same slot', "ValueKey('save-trade-button')" in slot and 'height: 52' in slot)
check('save button not rendered outside slot', FORM.count("ValueKey('save-trade-button')") == 1)
check('chip shows chosen subtype and reopens popup', 'trade-break-even-type-chip' in FORM and 'onTap: _busy ? null : _chooseBreakEvenType' in FORM)
check('save gate for missing subtype preserved', 'Choose the break-even type before saving.' in FORM)
check('missed chip flow preserved', '_buildMissedOutcomeChip(tokens)' in FORM and '_cycleMissedOutcome' in FORM)

# --- Request 2: tinted inner fields ---------------------------------------
check('shared surface helper exists', 'Color _entryConditionsSurface({' in FORM)
dialog = body('Future<T?> _showCenteredTradeChoiceDialog<T>', 'Future<String?> _showTimeframeSheet')
check('timeframe/choice popup uses shared helper', '_entryConditionsSurface(' in dialog)
field = body('Widget _entryConditionField({', 'Widget _buildLinkedEntryBehaviorSections')
check('fields use shared helper when unlinked', '_entryConditionsSurface(' in field and ': tokens.surface2;' not in field)
check('purple linked fill untouched', 'TradeDetailPalette.linkedEntryConditionsFieldDark' in field and '_noEntryTone.withValues(alpha: .075)' in field)
check('both fields still go through the helper-backed widget', FORM.count('_entryConditionField(') >= 3)
check('tests updated for tinted fills', 'neutralConditionFill' not in TEST_EC and 'reverseConditionFill' in TEST_EC and 'bounceConditionFill' in TEST_EC)
check('popup widget test added', 'break-even subtypes pop up in place of the save button' in TEST_CC)

# --- Hygiene ---------------------------------------------------------------
check('no localStorage/cartoon assets introduced', 'localStorage' not in FORM)
sys.exit(1 if failed else 0)
