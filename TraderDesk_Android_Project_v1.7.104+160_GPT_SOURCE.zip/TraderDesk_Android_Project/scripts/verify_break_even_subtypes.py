#!/usr/bin/env python3
"""Static regression checks for explicit break-even subtype capture and filtering."""
import re
from pathlib import Path
root = Path(__file__).resolve().parents[1]
form = (root / 'lib/screens/trade_form_screen.dart').read_text()
trades = (root / 'lib/screens/trades_screen.dart').read_text()
model = (root / 'lib/models/trade.dart').read_text()
store = (root / 'lib/data/local_store.dart').read_text()
strings = (root / 'lib/l10n/app_strings.dart').read_text()
model_test = (root / 'test/trade_classification_test.dart').read_text()
filter_test = (root / 'test/trades_screen_filter_test.dart').read_text()
backup_test = (root / 'test/local_store_test.dart').read_text()
form_test = (root / 'test/custom_confirmation_test.dart').read_text()
pubspec = (root / 'pubspec.yaml').read_text()
checks = {
 'Subtype enum defines only balanced and at-entry': 'enum BreakEvenType {\n  balanced,\n  atEntry;' in model,
 'Subtype persists through JSON and supports legacy null': "'breakEvenType': breakEvenType?.name" in model and "BreakEvenType.tryParse(json['breakEvenType'])" in model,
 'Subtype survives strategy-adherence copy': 'breakEvenType: breakEvenType' in model,
 'Backup/restore copies subtype': 'breakEvenType: trade.breakEvenType' in store,
 'Selecting break-even automatically opens the subtype popup': "selected == TradeClassification.breakEven && _breakEvenType == null" in form and "showGeneralDialog<BreakEvenType>" in form and "option(BreakEvenType.balanced)" in form and "option(BreakEvenType.atEntry)" in form,
 'Save button stays hidden until a subtype is selected': re.search(r"_classification == TradeClassification\.breakEven\s*&&\s*_breakEvenType == null\s*\?\s*OutlinedButton\.icon\(\s*key: const ValueKey\('choose-break-even-type-button'\)", form) is not None and form.count("ValueKey('save-trade-button')") == 1,
 'Save method independently blocks missing subtype': 'selectedClassification == TradeClassification.breakEven &&\n        _breakEvenType == null' in form,
 'Save persists subtype only for break-even records': 'breakEvenType: selectedClassification == TradeClassification.breakEven' in form,
 'Filter submenu is adjacent to break-even category': 'trades-filter-break-even-submenu' in trades,
 'Filter distinguishes both subtype values and keeps All': '_BreakEvenTradeFilter.all => true' in trades and 'trade.breakEvenType == BreakEvenType.balanced' in trades and 'trade.breakEvenType == BreakEvenType.atEntry' in trades,
 'Arabic and English labels are present': "'breakEvenBalanced': 'متساوي'" in strings and "'breakEvenAtEntry': 'عند منطقة الدخول'" in strings and "'breakEvenBalanced': 'Balanced'" in strings and "'breakEvenAtEntry': 'At entry area'" in strings,
 'Model tests cover subtype JSON, copy and legacy': 'persists the selected break-even subtype' in model_test and 'legacy break-even records without subtype' in model_test,
 'Filter widget tests cover both precise choices': 'break-even submenu filters balanced and entry-area exits' in filter_test and 'trades-break-even-subfilter-balanced' in filter_test and 'trades-break-even-subfilter-atEntry' in filter_test,
 'Form widget test proves save gate and automatic subtype popup': 'break-even subtype choices gate the save button' in form_test and 'save action stays absent until a break-even subtype is chosen' in form_test,
 'Backup test round-trips both break-even subtypes': 'preserves break-even subtype through backup and restore' in backup_test and 'restored.trades.single.breakEvenType, subtype' in backup_test,
 'Release version updated': 'version: 1.7.104+160' in pubspec,
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' | ' + label)
print(f'RESULT: {sum(checks.values())}/{len(checks)}')
raise SystemExit(0 if all(checks.values()) else 1)
