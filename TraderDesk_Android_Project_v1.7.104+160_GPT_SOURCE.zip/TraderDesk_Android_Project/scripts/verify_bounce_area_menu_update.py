#!/usr/bin/env python3
"""Static regression checks for the 1.7.104+160 Bounce area menu update."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
read = lambda rel: (ROOT / rel).read_text(encoding='utf-8')
CATALOG = read('lib/domain/trade_entry_catalog.dart')
FORM = read('lib/screens/trade_form_screen.dart')
TRADES = read('lib/screens/trades_screen.dart')
STRINGS = read('lib/l10n/app_strings.dart')
ENTRY_TEST = read('test/entry_conditions_test.dart')
CATALOG_TEST = read('test/trade_entry_catalog_test.dart')
PUBSPEC = read('pubspec.yaml')
WORKFLOW = read('.github/workflows/android-build.yml')

checks = []
def check(label, ok):
    checks.append((label, bool(ok)))

def block(source, start_marker, end_marker='];'):
    start = source.index(start_marker)
    return source[start:source.index(end_marker, start)]

picker = block(CATALOG, 'const tradeBounceZoneOptions')
liquidity = block(CATALOG, 'const tradeLiquiditySweepOptions')
trendline = block(CATALOG, 'const tradeTrendlineBounceOptions')
labels = block(CATALOG, 'const tradeBounceZoneLabelOptions')

# 1) Top-level picker: S/R, one liquidity row, one trendline row, Zone S/D.
check('picker has exactly four rows', picker.count('TradeEntryOption(') == 4)
for ar in ["'سحب سيولة'", "'إرتداد من Trendline'", "'ارتداد من Zone S/D'", "'ارتداد من منطقة S/R'"]:
    check(f'picker contains {ar}', ar in picker)
for gone in ["'سحب سيولة داخلي'", "'سحب السيولة خارجي'", "'ارتداد من ترند لاين'", "ترند لاين و Supply Zone"]:
    check(f'picker no longer contains {gone}', gone not in picker)
order = [picker.index(k) for k in ["'bounceFromSrZone'", 'tradeLiquiditySweepMenuKey', 'tradeTrendlineBounceMenuKey', "'bounceFromZoneSd'"]]
check('picker order: S/R, liquidity, trendline, Zone S/D', order == sorted(order))

# 2) Liquidity popup.
check('liquidity popup has the two requested choices', "'سيولة داخلية'" in liquidity and "'سيولة خارجية'" in liquidity and liquidity.count('TradeEntryOption(') == 2)
check('liquidity popup keeps the original storage keys', "'internalLiquiditySweep'" in liquidity and "'majorStructureLiquiditySweep'" in liquidity)

# 3) Trendline popup.
check('trendline popup has Touch 3-4 and Touch 3-4 Breakout', "'Trendline Touch 3-4'" in trendline and "'Trend Line Touch 3-4 Breakout'" in trendline and trendline.count('TradeEntryOption(') == 2)

# 4) Zone S/D direction mapping and wording.
check('Zone S/D: BUY resolves to Supply Zone, SELL to Demand Zone',
      "TradeSide.buy => 'Supply Zone'" in CATALOG and "TradeSide.sell => 'Demand Zone'" in CATALOG)
check('Zone S/D label is prefixed with the bounce wording and followed by the timeframe',
      "setup.optionKey == 'bounceFromZoneSd'" in CATALOG and "'ارتداد من'" in CATALOG)

# 5) Saved-label coverage, including legacy keys.
for key in ['bounceFromSrZone', 'internalLiquiditySweep', 'majorStructureLiquiditySweep', 'bounceFromTrendlineTouch34',
            'bounceFromTrendlineTouch34Breakout', 'bounceFromZoneSd', 'bounceFromTrendline', 'bounceFromTrendlineAndSupplyZone']:
    check(f'saved-label list covers {key}', f"TradeEntryOption('{key}'" in labels)
check('legacy combined formatter branch retained', "setup.optionKey == 'bounceFromTrendlineAndSupplyZone'" in CATALOG)
check('saved trade detail resolves labels from the full list', 'tradeBounceZoneLabelOptions' in TRADES and 'tradeBounceZoneOptions)' not in TRADES)
check('bounce field chips resolve labels from the full list', 'options: tradeBounceZoneLabelOptions' in FORM)

# 6) Form flow.
flow = block(FORM, 'Future<TradeEntryConditionSetup?> _showEntryConditionSetup', 'String _touch2DialogTitle')
check('flow opens a sub-choice popup before the timeframe list',
      flow.index('tradeBounceZoneSubOptions(menuKey)') < flow.index('_showTimeframeSheet('))
check('flow highlights the grouped row when editing', 'tradeBounceZoneMenuKey(current.optionKey)' in flow)
check('flow shares the choice dialog and tone with the other pickers', flow.count('accentTone: choiceTone') >= 3)
check('Touch 2 remains S/R only', "if (optionKey == 'bounceFromSrZone')" in flow)
check('old two-timeframe Trendline + Supply flow removed from the form', 'isTrendlineAndSupplyZone' not in FORM and 'supplyZoneTimeframe' not in FORM)
check('sub popup carries the Entry conditions subtitle', 'subtitle: entryConditionsPrefix' in flow)

# 7) Localized strings.
for literal in ["'internalLiquiditySweep': 'سحب سيولة داخلية'", "'majorStructureLiquiditySweep': 'سحب سيولة خارجية'",
                "'bounceFromTrendline': 'إرتداد من Trendline'", "'bounceFromZoneSd': 'ارتداد من Zone S/D'",
                "'bounceFromZoneSd': 'Bounce from Zone S/D'"]:
    check(f'localized string {literal}', literal in STRINGS)

# 8) Tests.
for expected in ['سحب سيولة داخلية 15MIN', 'إرتداد من Trendline Touch 3-4 1H', 'إرتداد من Trend Line Touch 3-4 Breakout 30MIN',
                 'ارتداد من Supply Zone 5MIN', 'ارتداد من Demand Zone 5MIN']:
    check(f'widget test asserts {expected}', expected in ENTRY_TEST)
for expected in ["'ارتداد من Supply Zone 15MIN'", "'ارتداد من Demand Zone 15MIN'", "'Bounce from Demand Zone 15MIN'", "'liquiditySweepMenu'", "'trendlineBounceMenu'"]:
    check(f'catalog test asserts {expected}', expected in CATALOG_TEST)

# 9) Release metadata.
check('version is 1.7.104+160', 'version: 1.7.104+160' in PUBSPEC)
check('workflow release name and artifact IDs match 1.7.104/160', 'TraderDesk 1.7.104+160' in WORKFLOW and 'traderdesk-1.7.104-build160' in WORKFLOW)
check('update report exists', (ROOT / 'UPDATE_REPORT_1.7.104+160.md').exists())

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
