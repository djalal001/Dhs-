#!/usr/bin/env python3
"""Static regression checks for TraderDesk 1.7.96+152 UI refinements."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
REVIEW_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
README = (ROOT / "README.md").read_text(encoding="utf-8")
RELEASE = (ROOT / "RELEASE_NOTES_AR.md").read_text(encoding="utf-8")
BUILD_INFO = (ROOT / "BUILD_INFO_AR.md").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))

def section(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[1].split(end, 1)[0]

selection = section(FORM, "Widget _selectionRow(", "Widget _buildBehaviorCard")
mood = section(FORM, "Widget _buildMindsetSelector(", "Widget _setupSelectionField")

check("release is 1.7.96+152", "version: 1.7.96+152" in PUBSPEC)
check("workflow uses build 152", "TraderDesk 1.7.96+152" in WORKFLOW and "traderdesk-1.7.96-build152-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.96-build152-arm64-dart-symbols" in WORKFLOW)
check("mindset field is explicitly compact at 48dp", "const double _mindsetControlHeight = 48;" in FORM and "height: _mindsetControlHeight" in mood)
check("market and standard data fields remain 72dp", "const double _tradeDataControlHeight = 72;" in FORM and "height: _tradeDataControlHeight" in FORM)
check("mindset remains vertically aligned by its parent row", "crossAxisAlignment: CrossAxisAlignment.center" in FORM)
check("Not recorded uses secondary/muted text color", "_mood == 'moodUnknown'" in mood and "TdTokens.of(context).text2" in mood)
check("Not recorded uses medium rather than selected-bold weight", "_mood == 'moodUnknown'\n                                      ? FontWeight.w600" in mood)
check("mindset menu still uses compact 42dp rows", "itemHeight: 42" in mood)
check("behavior selection has no checkbox rectangle", "width: 23" not in selection and "height: 23" not in selection and "Icons.check" not in selection)
check("behavior selection retains toggle callback and selected-state lookup", "selected.contains(option.key)" in selection and "_toggleSet(selected, option.key, !isSelected)" in selection)
check("selected behavior item uses a low-intensity accent tint", "accent.withValues(alpha: isDark ? .14 : .09)" in selection)
check("unselected behavior rows remain transparent", "Colors.transparent" in selection)
check("decisions, commitment, and no-entry tests assert no checkbox", REVIEW_TEST.count("find.byType(Checkbox)") >= 3)
check("tests assert category-colored selected row surfaces", "trade-behavior-option-surface-enteredEarly" in REVIEW_TEST and "trade-behavior-option-surface-fullPlanCompliance" in REVIEW_TEST and "trade-behavior-option-surface-fearRepeatLossAfterLoss" in REVIEW_TEST)
check("tests assert compact mindset size and muted default label", "Mindset uses the compact 48dp height" in ENTRY_TEST and "same muted tone as other unselected fields" in ENTRY_TEST)
check("release notes and README document the two requested changes", "48dp" in README and "مربعات الاختيار الصغيرة" in README and "48dp" in RELEASE)
check("build info identifies source-only delivery and correct parent", "1.7.96+152" in BUILD_INFO and "TraderDesk_Android_Project_v1.7.95+151_GPT_SOURCE.zip" in BUILD_INFO and "لا يتضمن هذا التسليم APK" in BUILD_INFO)

for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{sum(ok for _, ok in checks)}/{len(checks)} checks passed")
if not all(ok for _, ok in checks):
    raise SystemExit(1)
