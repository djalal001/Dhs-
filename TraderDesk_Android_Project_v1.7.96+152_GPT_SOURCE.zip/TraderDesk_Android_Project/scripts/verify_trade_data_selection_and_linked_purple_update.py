#!/usr/bin/env python3
"""Focused static regressions for the 1.7.96+152 visual corrections."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
DETAIL_TESTS = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
checks = {
    "release is 1.7.96+152": "version: 1.7.96+152" in PUBSPEC,
    "workflow release uses build 151": "TraderDesk 1.7.96+152" in WORKFLOW and "traderdesk-1.7.96-build152-arm64-v8a-release" in WORKFLOW,
    "no nested selected-value pill helper remains": "_selectedTradeDataValueDecoration" not in FORM,
    "selected market/direction value renders as plain text": "key: selectedValueKey == null ? null : ValueKey(selectedValueKey)" in FORM and "child: displayedValue" in FORM,
    "selected Mindset value renders as plain text": "trade-mood-selected-value" in FORM and "_selectedTradeDataValueDecoration" not in FORM,
    "selected popup row uses a subtle accent-family tint": "TdTokens.of(context).accent.withValues(alpha: .11)" in FORM,
    "popup options have no checkmark": "Icons.check_rounded" not in FORM[FORM.index("Future<void> _showCompactPopupChoice"):FORM.index("Widget _compactPopupChoice")],
    "all market options remain in the popup source": "values: const ['NQ', 'ES', 'GC']" in FORM,
    "original direction toggle behavior is preserved while popup highlighting is added": "_side == value ? null : value" in FORM and "clearing BUY must re-lock the market selector" in TESTS,
    "Mindset field uses the requested compact 48dp geometry": "height: _mindsetControlHeight" in FORM and "const double _mindsetControlHeight = 48;" in FORM,
    "Mindset popup restores original 42dp row height": "itemHeight: 42" in FORM and "height: itemHeight" in FORM,
    "test protects 48dp Mindset and 72dp Market/Direction field heights": "Mindset uses the compact 48dp height" in TESTS and "Market / Direction keeps its original 72dp field height" in TESTS,
    "unrecorded Mindset uses muted placeholder styling": "_mood == 'moodUnknown'" in FORM and "TdTokens.of(context).text2" in FORM,
    "decisions and no-entry selections have no checkbox square": "AnimatedContainer(" in FORM and "trade-behavior-option-surface-${option.key}" in FORM and "Icons.check, size: 15" not in FORM[FORM.index("Widget _selectionRow"):FORM.index("Widget _buildBehaviorCard")],
    "selected behavior row uses a quiet section accent tint": "accent.withValues(alpha: isDark ? .14 : .09)" in FORM,
    "tests cover checkbox-free decision and no-entry selections": "selected decisions use a subtle category-tinted row" in (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8") and "selected no-entry reasons use a subtle purple row tint" in (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8"),
    "test protects original compact Mindset menu row height": "Mindset popup row height retains its original compact 42dp geometry" in TESTS,
    "only explicit practical opposing-signal link colors its field violet": "final reverseSignalTone = _practicalNoEntryReverseSignalSetups.isNotEmpty" in FORM and "tone: reverseSignalTone" in FORM,
    "Bounce area field keeps its normal blue tone": "tone: _entryConditionsTone" in FORM and "Bounce area keeps its original blue field palette" in FORM,
    "long-press purple fill applies only to the linked opposing-signal field": "practicalNoEntrySetups.isNotEmpty" in FORM and "fillColorOverride: entryConditionFieldFill" in FORM,
    "saved detail purple state is tied to practical signal markers": "final reverseSignalsLinkedToNoEntry = trade.hasPracticalNoEntryReason;" in TRADES,
    "saved detail Bounce area stays in blue palette": "fill: TradeDetailPalette.entryConditionsFieldDark" in TRADES and "optionFill: TradeDetailPalette.entryConditionsChipDark" in TRADES,
    "saved detail tests distinguish purple opposing signal from blue Bounce area": "Bounce area chips keep their original blue surface" in DETAIL_TESTS and "Bounce area heading stays in its established blue-grey palette" in DETAIL_TESTS,
    "form tests verify Bounce area does not inherit violet after long-press": "linking an opposing signal must not recolor the Bounce area inner field" in TESTS,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{sum(checks.values())}/{len(checks)} checks passed")
if not all(checks.values()):
    raise SystemExit(1)
