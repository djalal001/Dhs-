# معلومات البناء والتسليم — TraderDesk 1.7.30+86

- رقم الإصدار: `1.7.30`؛ رقم البناء: `86`.
- اسم الحزمة: `com.traderdesk.trader_desk`.
- نوع التسليم: مشروع Flutter كامل بصيغة ZIP، وليس APK.
- تم الحفاظ على إعدادات بناء ARM64 وسكربت البناء الرسمي دون تغيير.
- لم يتوفر Flutter أو Dart SDK في بيئة التحرير؛ لذلك لم تُشغّل أوامر `flutter pub get` أو `flutter analyze` أو `flutter test` أو `flutter build apk --release`.
- لا يتضمن هذا التسليم APK، ولا ندّعي نجاح بناء أو تشغيل التطبيق على جهاز.
