import 'package:flutter/material.dart';

import '../data/trade_file_service.dart';
import '../domain/trade_analytics.dart';
import '../domain/trade_ordering.dart';
import '../domain/trade_csv_exporter.dart';
import '../domain/trade_entry_catalog.dart';
import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/trade_image_preview.dart';
import '../widgets/trade_execution_journal.dart';
import '../widgets/trade_entry_setup_chips.dart';
import '../widgets/strategy_adherence_chip.dart';
import '../widgets/trade_info_tile.dart';
import 'trade_form_screen.dart';

class TradesScreen extends StatefulWidget {
  const TradesScreen({super.key});
  @override
  State<TradesScreen> createState() => _TradesScreenState();
}

class _TradesScreenState extends State<TradesScreen> {
  final _search = TextEditingController();
  bool? _winsOnly;
  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _openForm({Trade? trade}) async {
    final app = AppScope.of(context);
    final result = await Navigator.of(context).push<Trade>(
      MaterialPageRoute(builder: (_) => TradeFormScreen(trade: trade)),
    );
    if (result != null) {
      if (trade == null) {
        await app.addTrade(result);
      } else {
        await app.updateTrade(result);
      }
    }
  }

  Future<void> _openDetails(Trade trade, String currency) =>
      Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => TradeDetailScreen(trade: trade, currency: currency),
        ),
      );

  Future<void> _delete(Trade trade) async {
    final app = AppScope.of(context);
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(tr(context, 'deleteTrade')),
        content: Text(tr(context, 'deleteTradePrompt')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(tr(context, 'cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(tr(context, 'delete')),
          ),
        ],
      ),
    );
    if (yes == true) await app.deleteTrade(trade.id);
  }

  Future<void> _exportAccountCsv(List<Trade> trades) async {
    if (trades.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(tr(context, 'noTradesToExport'))));
      return;
    }
    try {
      final app = AppScope.of(context);
      final csv = TradeCsvExporter.generate(
        accounts: app.accounts,
        trades: trades,
        translate: (key) => tr(context, key),
      );
      final saved = await TradeFileService.saveCsv(
        csv,
        fileName: TradeFileService.csvFileName(),
      );
      if (saved == null || !mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(tr(context, 'csvExported'))));
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${tr(context, 'operationFailed')}: $error')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final account = app.accounts
        .where((item) => item.id == app.selectedAccountId)
        .firstOrNull;
    final accountTrades = account == null
        ? <Trade>[]
        : app.trades.where((trade) => trade.accountId == account.id).toList();
    final query = _search.text.trim().toLowerCase();
    final visible = accountTrades.where((trade) {
      final journalSearchText = trade.executionJournal
          .map((entry) => tr(context, 'journalStatus_${entry.status.name}'))
          .join(' ');
      final behaviorSearchText = [
        ...trade.executionReviewKeys,
        ...trade.noEntryReasons,
      ].map((key) => tradeEntryLabel(key, arabic: AppStrings.isArabic(context))).join(' ');
      final matchesQuery =
          query.isEmpty ||
          '${trade.market} ${trade.entrySetupSummary} ${trade.confirmationSetupSummary} ${trade.sequence} ${trade.notes} $journalSearchText $behaviorSearchText'
              .toLowerCase()
              .contains(query);
      final matchesResult =
          _winsOnly == null ||
          (_winsOnly! ? trade.result > 0 : trade.result < 0);
      return matchesQuery && matchesResult;
    }).toList()..sort(compareTradesDescending);
    final metrics = TradeAnalytics.calculate(accountTrades);
    final currency = account?.currency ?? 'USD';
    final header = <Widget>[
      PageTitle(
        tr(context, 'trades'),
        subtitle: account?.name ?? tr(context, 'selectAccount'),
        action: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              onPressed: account == null || accountTrades.isEmpty
                  ? null
                  : () => _exportAccountCsv(accountTrades),
              icon: const Icon(Icons.download_outlined),
              tooltip: tr(context, 'exportCurrentAccountCsv'),
            ),
            IconButton.filled(
              onPressed: account == null ? null : () => _openForm(),
              icon: const Icon(Icons.add),
              tooltip: tr(context, 'addTrade'),
            ),
          ],
        ),
      ),
    ];
    if (account == null) {
      header.add(
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: EmptyState(
            title: tr(context, 'noAccounts'),
            detail: tr(context, 'addFirstAccount'),
          ),
        ),
      );
    } else {
      header.addAll([
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.65,
            children: [
              MetricCard(
                label: tr(context, 'netProfit'),
                value: money(metrics.netProfit, currency),
                color: metrics.netProfit > 0
                    ? TdTokens.of(context).profit
                    : metrics.netProfit < 0
                    ? TdTokens.of(context).loss
                    : TdTokens.of(context).neutral,
              ),
              MetricCard(
                label: tr(context, 'winRate'),
                value: '${metrics.winRatePercent.toStringAsFixed(1)}%',
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: tr(context, 'search'),
              suffixIcon: _search.text.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () {
                        _search.clear();
                        setState(() {});
                      },
                      icon: const Icon(Icons.close),
                    ),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            children: [
              _FilterChip(
                label: tr(context, 'all'),
                selected: _winsOnly == null,
                onTap: () => setState(() => _winsOnly = null),
              ),
              const SizedBox(width: 8),
              _FilterChip(
                label: tr(context, 'wins'),
                selected: _winsOnly == true,
                onTap: () => setState(() => _winsOnly = true),
              ),
              const SizedBox(width: 8),
              _FilterChip(
                label: tr(context, 'losses'),
                selected: _winsOnly == false,
                onTap: () => setState(() => _winsOnly = false),
              ),
            ],
          ),
        ),
      ]);
    }

    final visibleCount = account == null
        ? 0
        : visible.isEmpty
        ? 1
        : visible.length;
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 28),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      itemCount: header.length + visibleCount,
      itemBuilder: (context, index) {
        if (index < header.length) return header[index];
        if (visible.isEmpty) {
          return EmptyState(
            title: tr(context, 'noTrades'),
            detail: tr(context, 'addFirstTrade'),
            action: FilledButton.icon(
              onPressed: () => _openForm(),
              icon: const Icon(Icons.add),
              label: Text(tr(context, 'addTrade')),
            ),
          );
        }
        final trade = visible[index - header.length];
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: _TradeSummaryCard(
            trade: trade,
            currency: currency,
            onOpen: () => _openDetails(trade, currency),
            onEdit: () => _openForm(trade: trade),
            onDelete: () => _delete(trade),
            onStrategyAdherenceChanged: (value) =>
                app.updateTrade(trade.withStrategyAdherence(value)),
          ),
        );
      },
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ChoiceChip(
    label: Text(label),
    selected: selected,
    onSelected: (_) => onTap(),
  );
}

class _TradeSummaryCard extends StatelessWidget {
  const _TradeSummaryCard({
    required this.trade,
    required this.currency,
    required this.onOpen,
    required this.onEdit,
    required this.onDelete,
    required this.onStrategyAdherenceChanged,
  });

  final Trade trade;
  final String currency;
  final VoidCallback onOpen;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final ValueChanged<StrategyAdherence> onStrategyAdherenceChanged;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final resultColor = trade.result > 0
        ? tokens.profit
        : trade.result < 0
        ? tokens.loss
        : tokens.neutral;
    final resultDeep = trade.result > 0
        ? tokens.profitDeep
        : trade.result < 0
        ? tokens.lossDeep
        : tokens.text3;
    final tradedTime = TimeOfDay.fromDateTime(trade.tradedAt).format(context);
    final confirmation = trade.effectiveConfirmationSetups
        .map((setup) {
          final type = tr(context, setup.type);
          return setup.timeframe.isEmpty ? type : '$type · ${setup.timeframe}';
        })
        .join('، ');
    final info = <(String, String)>[
      if (confirmation.isNotEmpty) (tr(context, 'confirmation'), confirmation),
      if (trade.mood.isNotEmpty) (tr(context, 'mood'), tr(context, trade.mood)),
    ];
    return AppCard(
      key: ValueKey('trade-summary-${trade.id}'),
      onTap: onOpen,
      padding: EdgeInsets.zero,
      variant: AppCardVariant.tint,
      tintColor: resultColor,
      child: Stack(
        children: [
          PositionedDirectional(
            start: 0,
            top: 14,
            bottom: 14,
            width: 3,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(99),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [resultDeep, resultDeep.withValues(alpha: 0.4)],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(14, 12, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Wrap(
                            spacing: 8,
                            runSpacing: 2,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                trade.market,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w700,
                                    ),
                              ),
                              _DirectionBadge(side: trade.side),
                              StrategyAdherenceChip(
                                value: trade.strategyAdherence,
                                onChanged: onStrategyAdherenceChanged,
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${shortDate(trade.tradedAt)} · $tradedTime',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: tokens.text3),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 132),
                      child: Container(
                        height: 34,
                        padding: const EdgeInsetsDirectional.fromSTEB(
                          8,
                          0,
                          9,
                          0,
                        ),
                        decoration: BoxDecoration(
                          color: resultColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: resultColor.withValues(alpha: 0.30),
                          ),
                        ),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: AlignmentDirectional.centerStart,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                trade.result > 0
                                    ? Icons.arrow_upward_rounded
                                    : trade.result < 0
                                    ? Icons.arrow_downward_rounded
                                    : Icons.remove_rounded,
                                size: 15,
                                color: resultColor,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                money(trade.result, currency),
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w700,
                                      color: resultColor,
                                      fontFeatures: const [
                                        FontFeature.tabularFigures(),
                                      ],
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    PopupMenuButton<String>(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(
                        minWidth: 40,
                        minHeight: 40,
                      ),
                      iconSize: 22,
                      onSelected: (value) {
                        if (value == 'edit') onEdit();
                        if (value == 'delete') onDelete();
                      },
                      itemBuilder: (_) => [
                        PopupMenuItem(
                          value: 'edit',
                          child: Text(tr(context, 'edit')),
                        ),
                        PopupMenuItem(
                          value: 'delete',
                          child: Text(tr(context, 'delete')),
                        ),
                      ],
                    ),
                  ],
                ),
                const Divider(height: 18),
                if (trade.executionJournal.isNotEmpty ||
                    trade.effectiveEntrySetups.isNotEmpty)
                  LayoutBuilder(
                    builder: (context, constraints) {
                      if (trade.executionJournal.isNotEmpty &&
                          trade.effectiveEntrySetups.isNotEmpty) {
                        final journalWidth = (constraints.maxWidth * 0.42)
                            .clamp(108.0, 150.0);
                        return Row(
                          textDirection: TextDirection.ltr,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              key: ValueKey('trade-journal-icons-${trade.id}'),
                              width: journalWidth,
                              child: Directionality(
                                textDirection: TextDirection.ltr,
                                child: TradeExecutionJournalSummary(
                                  entries: trade.executionJournal,
                                  compact: true,
                                  iconSize: 32,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: SizedBox(
                                key: ValueKey('trade-entry-setups-${trade.id}'),
                                child: TradeEntrySetupChips(
                                  label: tr(context, 'entryReason'),
                                  setups: trade.effectiveEntrySetups,
                                  compact: true,
                                  showLabel: false,
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                      if (trade.executionJournal.isNotEmpty) {
                        return SizedBox(
                          key: ValueKey('trade-journal-icons-${trade.id}'),
                          width: double.infinity,
                          child: Directionality(
                            textDirection: TextDirection.ltr,
                            child: TradeExecutionJournalSummary(
                              entries: trade.executionJournal,
                              compact: true,
                              iconSize: 32,
                            ),
                          ),
                        );
                      }
                      return SizedBox(
                        key: ValueKey('trade-entry-setups-${trade.id}'),
                        width: double.infinity,
                        child: TradeEntrySetupChips(
                          label: tr(context, 'entryReason'),
                          setups: trade.effectiveEntrySetups,
                          compact: true,
                          showLabel: false,
                        ),
                      );
                    },
                  ),
                if (info.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  for (final (label, value) in info)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 3),
                      child: Row(
                        children: [
                          Text(
                            '$label: ',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: tokens.text3),
                          ),
                          Expanded(
                            child: Text(
                              value,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.labelMedium
                                  ?.copyWith(color: tokens.text1),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TradeCard extends StatelessWidget {
  const _TradeCard({required this.trade, required this.currency});
  final Trade trade;
  final String currency;
  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final resultColor = trade.result > 0
        ? tokens.profit
        : trade.result < 0
        ? tokens.loss
        : tokens.neutral;
    final tradedTime = TimeOfDay.fromDateTime(trade.tradedAt).format(context);
    final compactInfo = <(String, String)>[
      (tr(context, 'riskPercent'), '${trade.riskPercent.toStringAsFixed(2)}%'),
      if (trade.expectedLoss != null)
        (tr(context, 'expectedLoss'), money(trade.expectedLoss!, currency)),
      if (trade.expectedLoss != null && trade.expectedLoss! > 0)
        (
          tr(context, 'rewardRisk'),
          '${(trade.result / trade.expectedLoss!).toStringAsFixed(2)}R',
        ),
      if (trade.mood.isNotEmpty) (tr(context, 'mood'), tr(context, trade.mood)),
    ];
    final longInfo = <(String, String)>[
      if (trade.effectiveConfirmationSetups.isNotEmpty)
        (
          tr(context, 'confirmation'),
          trade.effectiveConfirmationSetups
              .map((setup) {
                final type = tr(context, setup.type);
                return setup.timeframe.isEmpty
                    ? type
                    : '$type · ${setup.timeframe}';
              })
              .join('، '),
        ),
      if (trade.sequence.isNotEmpty) (tr(context, 'sequence'), trade.sequence),
    ];
    final images = <({String path, String label, String prefix})>[
      if (trade.beforeImagePath != null)
        (
          path: trade.beforeImagePath!,
          label: tr(context, 'beforeImage'),
          prefix: 'traderdesk_before_${trade.id}',
        ),
      if (trade.confirmationImagePath != null)
        (
          path: trade.confirmationImagePath!,
          label: tr(context, 'confirmationImage'),
          prefix: 'traderdesk_confirmation_${trade.id}',
        ),
      if (trade.afterImagePath != null)
        (
          path: trade.afterImagePath!,
          label: tr(context, 'afterImage'),
          prefix: 'traderdesk_after_${trade.id}',
        ),
    ];
    return AppCard(
      variant: AppCardVariant.hero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 2,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(
                          trade.market,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        _DirectionBadge(side: trade.side),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${shortDate(trade.tradedAt)} · $tradedTime',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                constraints: const BoxConstraints(maxWidth: 120),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: resultColor.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: resultColor.withValues(alpha: 0.22),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      tr(context, 'result'),
                      style: Theme.of(context).textTheme.labelSmall
                          ?.copyWith(color: tokens.text3),
                    ),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        money(trade.result, currency),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: resultColor,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Divider(height: 20),
          if (compactInfo.isNotEmpty ||
              longInfo.isNotEmpty ||
              trade.effectiveEntrySetups.isNotEmpty)
            LayoutBuilder(
              builder: (context, constraints) {
                final width = (constraints.maxWidth - 8) / 2;
                return Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final (label, value) in compactInfo)
                      SizedBox(
                        width: width,
                        child: TradeInfoTile(label: label, value: value),
                      ),
                    for (final (label, value) in longInfo)
                      SizedBox(
                        width: constraints.maxWidth,
                        child: TradeInfoTile(label: label, value: value),
                      ),
                    if (trade.effectiveEntrySetups.isNotEmpty)
                      SizedBox(
                        width: constraints.maxWidth,
                        child: TradeEntrySetupChips(
                          label: tr(context, 'entryReason'),
                          setups: trade.effectiveEntrySetups,
                        ),
                      ),
                  ],
                );
              },
            ),
          if (trade.executionJournal.isNotEmpty) ...[
            const SizedBox(height: 12),
            TradeExecutionJournalSummary(
              entries: trade.executionJournal,
              showHeading: trade.sequence.isEmpty,
            ),
          ],
          if (trade.notes.isNotEmpty) ...[
            const SizedBox(height: 8),
            _TradeTextBlock(label: tr(context, 'notes'), value: trade.notes),
          ],
          if (trade.executionReviewKeys.isNotEmpty || trade.noEntryReasons.isNotEmpty) ...[
            const SizedBox(height: 10),
            _TradeBehaviorSummary(trade: trade),
          ],
          if (images.isNotEmpty) ...[
            const SizedBox(height: 12),
            LayoutBuilder(
              builder: (context, constraints) {
                final width = (constraints.maxWidth - 8) / 2;
                return Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final image in images)
                      SizedBox(
                        width: width,
                        child: TradeImagePreview(
                          path: image.path,
                          label: image.label,
                          fileNamePrefix: image.prefix,
                          height: 120,
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}

class TradeDetailScreen extends StatelessWidget {
  const TradeDetailScreen({
    super.key,
    required this.trade,
    required this.currency,
  });

  final Trade trade;
  final String currency;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(tr(context, 'tradeDetails'))),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [_TradeCard(trade: trade, currency: currency)],
    ),
  );
}

class _TradeBehaviorSummary extends StatelessWidget {
  const _TradeBehaviorSummary({required this.trade});
  final Trade trade;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final arabic = AppStrings.isArabic(context);
    Widget group(String title, List<String> keys) {
      if (keys.isEmpty) return const SizedBox.shrink();
      return Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: tokens.text3, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final key in keys)
                  Container(
                    constraints: const BoxConstraints(maxWidth: 320),
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                    decoration: BoxDecoration(color: tokens.surface2, borderRadius: BorderRadius.circular(9), border: Border.all(color: tokens.lineSubtle)),
                    child: Text(tradeEntryLabel(key, arabic: arabic), style: Theme.of(context).textTheme.labelSmall?.copyWith(color: tokens.text2, height: 1.35)),
                  ),
              ],
            ),
          ],
        ),
      );
    }

    final reviewKeys = trade.executionReviewKeys;
    final decisionOptions = tradeReviewGroups.expand((item) => item.options).map((item) => item.key).toSet();
    final commitmentOptions = tradeCommitmentOptions.map((item) => item.key).toSet();
    final decisionKeys = reviewKeys.where(decisionOptions.contains).toList();
    final commitmentKeys = reviewKeys.where(commitmentOptions.contains).toList();
    // Unknown keys are retained and displayed rather than silently discarded.
    final known = {...decisionOptions, ...commitmentOptions};
    final unknown = reviewKeys.where((key) => !known.contains(key)).toList();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: tokens.inset, borderRadius: BorderRadius.circular(13), border: Border.all(color: tokens.lineSubtle)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(arabic ? 'مراجعة الصفقة' : 'Trade review', style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800)),
        group(arabic ? 'القرارات' : 'Decisions', [...decisionKeys, ...unknown]),
        group(arabic ? 'الالتزام' : 'Commitment', commitmentKeys),
        group(arabic ? 'أسباب عدم الدخول' : 'Reasons for not entering', trade.noEntryReasons),
      ]),
    );
  }
}

class _DirectionBadge extends StatelessWidget {
  const _DirectionBadge({required this.side});
  final TradeSide side;

  @override
  Widget build(BuildContext context) {
    final isBuy = side == TradeSide.buy;
    final tokens = TdTokens.of(context);
    final color = isBuy ? tokens.profit : tokens.loss;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isBuy ? Icons.north_east_rounded : Icons.south_east_rounded,
            size: 13,
            color: color,
          ),
          const SizedBox(width: 3),
          Text(
            tr(context, isBuy ? 'buy' : 'sell'),
            style: TextStyle(
              color: color,
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _TradeTextBlock extends StatelessWidget {
  const _TradeTextBlock({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsetsDirectional.fromSTEB(14, 12, 12, 12),
      decoration: BoxDecoration(
        color: tokens.surface2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: tokens.lineSubtle),
      ),
      child: Stack(
        children: [
          PositionedDirectional(
            top: 0,
            bottom: 0,
            start: 0,
            width: 3,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: tokens.accent.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.labelSmall
                      ?.copyWith(color: tokens.text3),
                ),
                const SizedBox(height: 4),
                Text(value, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
