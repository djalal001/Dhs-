# TraderDesk Android Project 1.5.1+37

تحتوي هذه الحزمة على مصدر مشروع Flutter الكامل لتطبيق دفتر المتداول.

- رقم الإصدار: `1.5.1+37`
- ملف التسليم: `TraderDesk_Android_Project_v1.5.1+37.zip`
- المشروع: `TraderDesk_Android_Project/`
- معلومات الإصدار وحدود التحقق: `BUILD_INFO_AR.md`
- ملاحظات الإصدار: `RELEASE_NOTES_AR.md`

هذه الحزمة مصدر المشروع وليست APK مبنياً. تعذّر تشغيل Flutter analyzer والاختبارات في بيئة التحرير لعدم توفر Flutter/Dart SDK؛ راجع `BUILD_INFO_AR.md` قبل بناء إصدار Android.
