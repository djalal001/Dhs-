import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('light and dark application themes use Noto Sans Arabic UI globally', () {
    for (final brightness in [Brightness.light, Brightness.dark]) {
      final theme = buildAppTheme(brightness);
      expect(theme.fontFamily, 'NotoSansArabicUI');
      expect(theme.fontFamilyFallback, ['NotoSans']);

      for (final style in [
        theme.textTheme.displayLarge,
        theme.textTheme.headlineSmall,
        theme.textTheme.titleLarge,
        theme.textTheme.titleMedium,
        theme.textTheme.bodyLarge,
        theme.textTheme.bodyMedium,
        theme.textTheme.bodySmall,
        theme.textTheme.labelLarge,
        theme.textTheme.labelMedium,
        theme.textTheme.labelSmall,
      ]) {
        expect(style?.fontFamily, 'NotoSansArabicUI');
        expect(style?.fontFamilyFallback, ['NotoSans']);
      }
    }
  });

  test('all Noto font files are bundled and available locally', () async {
    const fontAssets = [
      'assets/fonts/NotoSansArabicUI-Regular.ttf',
      'assets/fonts/NotoSansArabicUI-Bold.ttf',
      'assets/fonts/NotoSans-Regular.ttf',
      'assets/fonts/NotoSans-Medium.ttf',
      'assets/fonts/NotoSans-SemiBold.ttf',
      'assets/fonts/NotoSans-Bold.ttf',
    ];

    for (final asset in fontAssets) {
      final data = await rootBundle.load(asset);
      expect(data.lengthInBytes, greaterThan(100000), reason: asset);
    }

    final license = await rootBundle.loadString(
      'assets/fonts/NOTO_FONTS_OFL_LICENSE.txt',
    );
    expect(license, contains('SIL Open Font License'));
  });
}
