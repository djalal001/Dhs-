#!/usr/bin/env python3
"""Static regression checks for popup, field geometry and selected text."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))
check('release metadata is 1.7.95+151', 'version: 1.7.95+151' in PUBSPEC and 'TraderDesk 1.7.95+151' in WORKFLOW)
check('workflow artifacts use build151', 'traderdesk-1.7.95-build151-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.95-build151-arm64-dart-symbols' in WORKFLOW)
check('shared selected-item font token remains 14.5dp', 'const double _tradeDataItemFontSize = 14.5;' in FORM)
check('selected trade-data values retain the common font token', FORM.count('fontSize: _tradeDataItemFontSize') >= 7)
check('market/direction and mindset fields render plain selected text', '_selectedTradeDataValueDecoration' not in FORM and 'trade-mood-selected-value' in FORM and 'child: displayedValue' in FORM)
check('popup menu items retain all option labels', 'for (final value in values)' in FORM and 'labelFor(value)' in FORM)
check('selected popup row gets a slight accent tint without checkmark', 'accent.withValues(alpha: .11)' in FORM and 'Icons.check_rounded' not in FORM[FORM.index('Future<void> _showCompactPopupChoice'):FORM.index('Widget _compactPopupChoice')])
check('mindset menu width follows its own field', 'final menuWidth = anchorRenderObject.size.width > screenWidthLimit' in FORM and 'constraints: BoxConstraints.tightFor(width: menuWidth)' in FORM)
check('mindset preserves original 42dp popup row height', 'itemHeight: 42' in FORM and 'height: itemHeight' in FORM)
check('mindset and market-direction selectors both remain 72dp high', 'const double _tradeDataControlHeight = 72;' in FORM and 'Mindset keeps its original 72dp field height' in TESTS)
check('all ordinary popups keep the shared trade-data surface', 'color: tdPopupMenuColor(Theme.of(context).brightness)' in FORM and 'shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness)' in FORM)
check('semantic dialogs retain contextual surfaces', 'accentTone.withValues(alpha: isDark ? .14 : .08)' in FORM and 'dialogBorderColor.withValues(alpha: .56)' in FORM)
check('entry reason and condition labels use common font size', FORM.count('fontSize: _tradeDataItemFontSize') >= 7)
check('result sign is part of editable amount text', "RegExp(r'^[+\\-−]?[0-9]*[.,]?[0-9]*$')" in FORM and 'onChanged: _handleResultChanged' in FORM)
check('test covers delete-and-reselect result sign flow', 'the result sign can be deleted from the amount and chosen again' in TESTS)
failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
