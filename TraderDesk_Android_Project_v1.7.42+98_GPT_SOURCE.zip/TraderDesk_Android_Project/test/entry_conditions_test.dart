import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_conditions_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'conditions-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'conditions-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('keeps market and direction compact and stores both entry-condition lists', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketField = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.ensureVisible(marketField);
    final marketRect = tester.getRect(marketField);
    final directionRect = tester.getRect(directionSelector);
    expect(
      (directionRect.top - marketRect.top).abs(),
      lessThan(20),
      reason: 'direction should share the compact market row, not move below it',
    );
    expect(
      directionRect.left >= marketRect.right || marketRect.left >= directionRect.right,
      isTrue,
      reason: 'direction and market fields should be horizontally adjacent',
    );
    expect((directionRect.width - marketRect.width).abs(), lessThan(1));
    final availableIdentifiersWidth = tester.getSize(
      find.byKey(const ValueKey('trade-entry-identifiers-available')),
    ).width;
    final compactIdentifiersWidth = tester.getSize(
      find.byKey(const ValueKey('trade-entry-identifiers-row')),
    ).width;
    expect(
      compactIdentifiersWidth,
      lessThan(availableIdentifiersWidth * .88),
      reason: 'the two fields should be visibly narrower than the available details-panel width',
    );

    expect(find.text('السوق / الاتجاه'), findsOneWidget);
    expect(find.text('الارتكاز'), findsOneWidget);
    expect(find.text('اختر الرمز'), findsNothing);
    expect(find.text('اختر الارتكاز'), findsNothing);
    final marketInput = tester.widget<InputDecorator>(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    expect(marketInput.decoration.fillColor, const Color(0xFF071834));
    final marketBorder = marketInput.decoration.border as OutlineInputBorder;
    expect(marketBorder.borderRadius, BorderRadius.circular(14));
    expect(marketBorder.borderSide.width, .78);
    expect(
      tester.widget<PopupMenuButton<String>>(marketField).color,
      const Color(0xFF102846),
    );
    expect(
      find.descendant(of: marketField, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    expect(
      find.descendant(of: directionSelector, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    final anchorSelector = find.byKey(const ValueKey('trade-anchor-selector'));
    final anchorInputFinder = find.descendant(
      of: anchorSelector,
      matching: find.byType(InputDecorator),
    );
    expect(anchorInputFinder, findsOneWidget);
    final anchorInput = tester.widget<InputDecorator>(anchorInputFinder);
    expect(anchorInput.decoration.fillColor, const Color(0xFF071834));
    final anchorBorder = anchorInput.decoration.border as OutlineInputBorder;
    expect(anchorBorder.borderRadius, BorderRadius.circular(14));
    expect(anchorBorder.borderSide.width, .78);
    await tester.tap(marketField);
    await tester.pumpAndSettle();
    expect(find.text('NQ'), findsWidgets);
    expect(find.text('ES'), findsOneWidget);
    expect(find.text('GC'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trade-market-option-NQ')));
    await tester.pumpAndSettle();

    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    final buyOption = find.byKey(const ValueKey('trade-direction-option-buy'));
    expect(find.text('شراء'), findsOneWidget);
    expect(find.text('بيع'), findsOneWidget);
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('شراء'), findsNothing);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('شراء'), findsOneWidget);

    await tester.tap(anchorSelector);
    await tester.pumpAndSettle();
    for (final option in [
      'Key Level',
      'Supply Zone',
      'Demand Zone',
      'Bullish Engulfing',
      'Bearish engulfing',
    ]) {
      expect(find.text(option), findsOneWidget);
    }
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-supplyZone')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-demandZone')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-anchor-save')));
    await tester.pumpAndSettle();
    expect(tester.getSize(anchorSelector).height, greaterThan(45));
    expect(tester.getSize(anchorSelector).height, lessThan(90));
    expect(find.text('Supply Zone +1'), findsOneWidget);
    await tester.enterText(find.byKey(const ValueKey('trade-result-input')), '42.5');
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    expect(find.descendant(of: addEntry, matching: find.text('إضافة')), findsOneWidget);
    expect(find.descendant(of: addConfirmation, matching: find.text('إضافة')), findsOneWidget);
    await tester.ensureVisible(addEntry);
    await tester.tap(addEntry);
    await tester.pumpAndSettle();
    await tester.tap(find.text('RFS').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    await tester.ensureVisible(addConfirmation);
    await tester.tap(addConfirmation);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Bearish engulfing').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();

    final addReverse = find.byKey(const ValueKey('add-reverse-signal-setup'));
    final reverseHeader = find.text('إشارات عكسية');
    await tester.ensureVisible(reverseHeader);
    await tester.tap(reverseHeader);
    await tester.pumpAndSettle();
    await tester.ensureVisible(addReverse);
    await tester.tap(addReverse);
    await tester.pumpAndSettle();
    expect(find.text('تشكل اغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقه الدخول'), findsOneWidget);
    await tester.tap(find.text('تشكل اغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقه الدخول'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();

    final addBounce = find.byKey(const ValueKey('add-bounce-zone-setup'));
    final bounceHeader = find.text('منطقة الارتداد');
    await tester.ensureVisible(bounceHeader);
    await tester.tap(bounceHeader);
    await tester.pumpAndSettle();
    await tester.ensureVisible(addBounce);
    await tester.tap(addBounce);
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من ترند لاين و Supply Zone'));
    await tester.pumpAndSettle();
    expect(find.text('فريم ترند لاين'), findsOneWidget);
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();
    expect(find.text('فريم Supply Zone'), findsOneWidget,
        reason: 'the Supply Zone timeframe picker should open automatically');
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();

    expect(find.textContaining('ارتداد من Trend Line 1H - Supply Zone 5MIN'), findsOneWidget);

    await tester.ensureVisible(addBounce);
    await tester.tap(addBounce);
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    expect(find.text('تفصيل ارتداد S/R — اختياري'), findsOneWidget);
    final srTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(srTouch2, findsOneWidget);
    await tester.tap(srTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    final srTouch2Chip = find.text('ارتداد من دعم - لمسة 2 15MIN');
    expect(srTouch2Chip, findsOneWidget);

    // Editing an S/R bounce restores the previous Touch 2 choice.
    await tester.ensureVisible(srTouch2Chip);
    await tester.tap(srTouch2Chip);
    await tester.pumpAndSettle();
    final selectedSrTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(tester.widget<ListTile>(selectedSrTouch2).selected, isTrue);
    await tester.tap(selectedSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    // The dropdown keeps one direction selected; switching to sell and back
    // updates the directional interpretation of the S/R bounce.
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من مقاومة - لمسة 2 15MIN'), findsOneWidget);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من دعم - لمسة 2 15MIN'), findsOneWidget);

    // A second S/R bounce can explicitly skip the optional Touch 2 qualifier.
    await tester.ensureVisible(addBounce);
    await tester.tap(addBounce);
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    final skipSrTouch2 = find.byKey(
      const ValueKey('skip-touch2-bounceFromSrZone'),
    );
    expect(skipSrTouch2, findsOneWidget);
    await tester.tap(skipSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من دعم 4H'), findsOneWidget);

    final classify = find.byKey(
      const ValueKey('choose-trade-classification-button'),
    );
    await tester.ensureVisible(classify);
    expect(find.byKey(const ValueKey('save-trade-button')), findsNothing);
    await tester.tap(classify);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-classification-option-win')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-loss')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-breakEven')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-classification-option-missed')),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-classification-option-win')),
    );
    await tester.pumpAndSettle();
    expect(classify, findsNothing);

    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.win);
    expect(savedTrade!.effectiveClassification, TradeClassification.win);
    expect(savedTrade!.market, 'NQ');
    expect(savedTrade!.side, TradeSide.buy);
    expect(savedTrade!.anchor, 'supplyZone');
    expect(savedTrade!.effectiveAnchors, ['supplyZone', 'demandZone']);
    expect(savedTrade!.reverseSignalSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'negativeCloseAgainstDirection',
        timeframe: '30MIN',
      ),
    ]);
    expect(savedTrade!.bounceZoneSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'bounceFromTrendlineAndSupplyZone',
        timeframe: '1H',
        secondaryTimeframe: '5MIN',
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '15MIN',
        touch2: true,
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '4H',
      ),
    ]);
    expect(savedTrade!.entrySetups.single, const TradeEntrySetup(reason: 'RFS', timeframe: '15MIN'));
    expect(savedTrade!.confirmationSetups.single, const TradeConfirmationSetup(type: 'confirmBearishEngulfing', timeframe: '5MIN'));
  });

  test('new conditions remain backward compatible with existing trade JSON', () {
    final legacy = <String, dynamic>{
      'id': 'legacy',
      'accountId': 'conditions-account',
      'market': 'EURUSD',
      'reason': 'SBR',
      'result': 5,
      'riskPercent': .5,
      'side': 'buy',
      'confirmation': 'confirmBearishEngulfing',
      'sequence': '',
      'mood': 'moodCalm',
      'tradedAt': DateTime(2025, 1, 2).toIso8601String(),
    };
    final restored = Trade.fromJson(legacy);
    expect(restored.reverseSignalSetups, isEmpty);
    expect(restored.bounceZoneSetups, isEmpty);
    expect(restored.anchor, isNull);
    expect(restored.effectiveAnchors, isEmpty);
  });
}
