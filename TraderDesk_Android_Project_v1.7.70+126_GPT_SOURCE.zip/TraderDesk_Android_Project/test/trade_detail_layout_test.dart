import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/screens/trades_screen.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/theme/trade_detail_palette.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';
import 'package:trader_desk/widgets/decision_section_logo.dart';

void main() {
  testWidgets('saved trade details preserve the Windows panel separation and review art', (
    tester,
  ) async {
    final trade = Trade(
      id: 'detail-layout-test',
      accountId: 'account-test',
      market: 'US100',
      reason: 'RBS Touch 2',
      result: 12.5,
      expectedLoss: 5,
      riskPercent: 1.25,
      side: TradeSide.buy,
      confirmation: 'confirmBreakoutPullback',
      entrySetups: const [
        TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '5MIN'),
        TradeEntrySetup(reason: 'SBR Touch 2', timeframe: '1MIN'),
      ],
      confirmationSetups: const [
        TradeConfirmationSetup(type: 'confirmBreakoutPullback', timeframe: '15MIN'),
      ],
      reverseSignalSetups: const [
        TradeEntryConditionSetup(
          optionKey: 'strongRejectionWickAgainstDirection',
          timeframe: '5MIN',
        ),
      ],
      bounceZoneSetups: const [
        TradeEntryConditionSetup(
          optionKey: 'bounceFromTrendlineAndSupplyZone',
          timeframe: '1H',
          secondaryTimeframe: '15MIN',
        ),
        TradeEntryConditionSetup(
          optionKey: 'bounceFromSrZone',
          timeframe: '30MIN',
          touch2: true,
        ),
      ],
      sequence: 'Session opening',
      mood: 'moodUnsureAnalysis',
      strategyAdherence: StrategyAdherence.followed,
      executionJournal: const [
        TradeExecutionJournalEntry(status: TradeExecutionStatus.enteredEarly),
      ],
      tradedAt: DateTime(2026, 11, 5, 11, 21),
      anchor: 'supplyZone',
      anchors: const ['supplyZone', 'demandZone'],
      anchorTimeframes: const {'supplyZone': '15MIN', 'demandZone': '4H'},
      executionReviewKeys: const [
        'enteredEarly',
        'missedHigherTimeframeBounceArea',
        'stopLossIncreasedForLiquiditySafety',
        'fullPlanCompliance',
      ],
      noEntryReasons: const ['fearLossNoHistory'],
    );

    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(Brightness.dark),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: TradeDetailScreen(trade: trade, currency: 'USD'),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('trade-detail-result-panel')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-data-panel')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-result-expected-loss-pair')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-risk-reward-pair')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-review-panel')), findsOneWidget);
    final reviewSurface = tester.widget<Container>(
      find.byKey(const ValueKey('trade-detail-review-panel-surface')),
    );
    expect(
      (reviewSurface.decoration as BoxDecoration).color,
      const Color(0xFF292B36),
      reason: 'the collapsed review panel must have a filled surface, not only a purple outline',
    );
    expect(find.text('النتيجة والمخاطرة'), findsOneWidget);
    expect(find.text('بيانات الصفقة'), findsOneWidget);
    expect(find.text('مراجعة الصفقة'), findsOneWidget);
    final resultToggle = find.byKey(
      const ValueKey('trade-detail-result-panel-toggle'),
    );
    await tester.tap(resultToggle);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-detail-result-value')), findsNothing);
    await tester.tap(resultToggle);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-detail-result-value')), findsOneWidget);
    expect(find.text('US100'), findsNothing, reason: 'trade data starts folded');
    expect(find.text('مخالفات التنفيذ'), findsNothing, reason: 'review starts folded');
    final reviewToggle = find.byKey(
      const ValueKey('trade-detail-review-panel-toggle'),
    );
    await tester.ensureVisible(reviewToggle);
    await tester.tap(reviewToggle);
    await tester.pumpAndSettle();
    expect(find.text('مخالفات التنفيذ'), findsOneWidget);
    expect(find.text('جودة التحليل والإعداد'), findsOneWidget);
    expect(find.text('قرارات الدخول وإدارة المخاطرة'), findsOneWidget);
    final selectedReviewValue = tester.widget<Text>(
      find.descendant(
        of: find.byKey(const ValueKey('trade-review-option-tile-enteredEarly')),
        matching: find.byType(Text),
      ).first,
    );
    expect(selectedReviewValue.style!.fontSize, 13);
    expect(selectedReviewValue.style!.fontWeight, FontWeight.w700);
    final referenceHeadingStyle =
        tester.widget<Text>(find.text('مخالفات التنفيذ')).style!;
    expect(referenceHeadingStyle.fontSize, 13);
    expect(referenceHeadingStyle.fontWeight, FontWeight.w800);
    expect(referenceHeadingStyle.color, const Color(0xFFE0C49F));
    expect(
      find.text('هذه قرارات تحتاج إلى تقييم بحسب خطة التداول؛ اختيارها لا يعني أنها مخالفة أو خطأ.'),
      findsNothing,
    );
    expect(find.text('الالتزام'), findsOneWidget);
    expect(find.text('أسباب عدم الدخول'), findsOneWidget);
    expect(find.byType(TradeReviewOptionEmoji), findsNWidgets(5));
    expect(find.byType(DecisionSectionLogo), findsNothing);
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-review-group-decisions')),
        matching: find.byIcon(Icons.rule_rounded),
      ),
      findsOneWidget,
      reason: 'saved decisions use a distinct rule icon rather than the opposing-signal warning icon',
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-review-group-decisions')),
        matching: find.byIcon(Icons.warning_amber_rounded),
      ),
      findsNothing,
    );
    final decisionsGroupRect = tester.getRect(
      find.byKey(const ValueKey('trade-review-group-decisions')),
    );
    final selectedDecisionRect = tester.getRect(
      find.byKey(const ValueKey('trade-review-option-tile-enteredEarly')),
    );
    expect(
      selectedDecisionRect.width,
      greaterThan(decisionsGroupRect.width - 20),
      reason: 'review option tiles should retain only a slim left and right inset',
    );
    final commitmentToggle = find.byKey(
      const ValueKey('trade-review-group-commitment-toggle'),
    );
    await tester.tap(commitmentToggle);
    await tester.pumpAndSettle();
    expect(find.text('التزمت بالخطة كاملة دون مخالفة.'), findsNothing);
    expect(find.text('أسباب عدم الدخول'), findsOneWidget);
    await tester.tap(commitmentToggle);
    await tester.pumpAndSettle();
    expect(find.text('التزمت بالخطة كاملة دون مخالفة.'), findsOneWidget);

    final dataToggle = find.byKey(
      const ValueKey('trade-detail-data-panel-toggle'),
    );
    await tester.ensureVisible(dataToggle);
    await tester.tap(dataToggle);
    await tester.pumpAndSettle();
    expect(find.text('US100'), findsOneWidget);
    expect(find.text('السوق / الاتجاه'), findsOneWidget);
    expect(find.text('الرمز'), findsNothing);
    expect(find.text('الاتجاه'), findsNothing);
    expect(find.text('BUY'), findsOneWidget);
    expect(find.text('غير واثق من التحليل'), findsOneWidget);
    expect(find.text('تاريخ / الوقت'), findsOneWidget);
    final tradedAtValue = tester.widget<Text>(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-traded-at')),
        matching: find.byType(Text),
      ).last,
    );
    expect(tradedAtValue.style!.fontSize, 15);
    expect(tradedAtValue.style!.fontWeight, FontWeight.w700);

    final dataPanelSurfaceContainer = tester.widget<Container>(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-data-panel')),
        matching: find.byType(Container),
      ).first,
    );
    final dataPanelDecoration =
        dataPanelSurfaceContainer.decoration as BoxDecoration;
    expect(dataPanelDecoration.color, const Color(0xFF172E4D));
    expect(
      (dataPanelDecoration.border as Border).top.color,
      const Color(0xFF29415E),
    );
    final dataIconSurface = tester.widget<Container>(
      find.byKey(const ValueKey('trade-detail-data-panel-icon-surface')),
    );
    expect(
      (dataIconSurface.decoration as BoxDecoration).color,
      const Color(0xFF203D60),
    );
    final marketSurface = tester.widget<Container>(
      find.byKey(const ValueKey('trade-detail-market-direction-surface')),
    );
    final marketDecoration = marketSurface.decoration as BoxDecoration;
    expect(marketDecoration.color, const Color(0xFF142A46));
    expect(
      (marketDecoration.border as Border).top.color,
      const Color(0xFF142A46),
    );
    expect(
      tester.widget<Text>(find.text('US100')).style!.color,
      const Color(0xFFE7EDF4),
    );
    final entryReasonValue = tester.widget<Container>(
      find.byKey(
        const ValueKey(
          'trade-detail-entry-condition-value-RBS Touch 2 5MIN',
        ),
      ),
    );
    final entryReasonValueDecoration =
        entryReasonValue.decoration as BoxDecoration;
    expect(entryReasonValueDecoration.color, const Color(0xFF19314E));
    expect(
      (entryReasonValueDecoration.border as Border).top.color,
      const Color(0xFF19314E),
    );
    expect(
      tester.widget<Text>(find.text('RBS Touch 2 5MIN')).style!.color,
      const Color(0xFFE7EDF4),
    );
    final confirmationValue = tester.widget<Container>(
      find.byKey(
        const ValueKey(
          'trade-detail-entry-condition-value-Breakout–Pullback 15MIN',
        ),
      ),
    );
    expect(
      (confirmationValue.decoration as BoxDecoration).color,
      const Color(0xFF19314E),
    );
    final confirmationValueStyle =
        tester.widget<Text>(find.text('Breakout–Pullback 15MIN')).style!;
    expect(confirmationValueStyle.color, const Color(0xFFE7EDF4));
    expect(confirmationValueStyle.fontSize, 13.5);
    expect(confirmationValueStyle.fontWeight, FontWeight.w700);
    expect(find.text('تاريخ ووقت الصفقة'), findsNothing);
    expect(find.byKey(const ValueKey('trade-detail-anchor')), findsOneWidget);
    expect(find.text('Supply Zone 15MIN، Demand Zone 4H'), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-market-mindset-pair')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-market-direction-field')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-mindset')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-entry-reasons')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-confirmations')), findsOneWidget);
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-entry-reasons')),
        matching: find.byIcon(Icons.gps_fixed_rounded),
      ),
      findsNothing,
      reason: 'Entry reason heading uses text only in saved trade details',
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-confirmations')),
        matching: find.byIcon(Icons.verified_outlined),
      ),
      findsNothing,
      reason: 'confirmation heading uses text only in saved trade details',
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-anchor')),
        matching: find.byIcon(Icons.gps_fixed_rounded),
      ),
      findsNothing,
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-traded-at')),
        matching: find.byIcon(Icons.calendar_month_outlined),
      ),
      findsNothing,
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-detail-mindset-surface')),
        matching: find.byIcon(Icons.psychology_alt_outlined),
      ),
      findsNothing,
    );
    final dataPanel = find.byKey(const ValueKey('trade-detail-data-panel'));
    expect(
      find.descendant(
        of: dataPanel,
        matching: find.byIcon(Icons.verified_user_outlined),
      ),
      findsNothing,
      reason: 'Plan adherence heading is text-only',
    );
    expect(
      find.descendant(
        of: dataPanel,
        matching: find.byIcon(Icons.timeline_rounded),
      ),
      findsOneWidget,
      reason: 'the unmarked Sequence icon remains unchanged',
    );
    expect(find.text('الالتزام بالخطة'), findsOneWidget);
    expect(find.text('ملتزم'), findsOneWidget);
    expect(find.text('RBS Touch 2 5MIN'), findsOneWidget);
    expect(find.text('SBR Touch 2 1MIN'), findsOneWidget);
    expect(find.text('Breakout–Pullback 15MIN'), findsOneWidget);
    final savedValueStyle = tester.widget<Text>(find.text('US100')).style!;
    expect(savedValueStyle.fontSize, 15);
    expect(savedValueStyle.fontWeight, FontWeight.w700);
    final mindsetValueStyle =
        tester.widget<Text>(find.text('غير واثق من التحليل')).style!;
    expect(mindsetValueStyle.fontSize, 15);
    expect(mindsetValueStyle.fontWeight, FontWeight.w700);
    final selectedChipStyle =
        tester.widget<Text>(find.text('RBS Touch 2 5MIN')).style!;
    expect(selectedChipStyle.fontSize, 13.5);
    expect(selectedChipStyle.fontWeight, FontWeight.w700);
    final anchorValueStyle = tester
        .widget<Text>(find.text('Supply Zone 15MIN، Demand Zone 4H'))
        .style!;
    expect(anchorValueStyle.fontSize, 15);
    expect(anchorValueStyle.fontWeight, FontWeight.w700);

    // Data labels keep their established typography but use a softer,
    // less saturated slate-blue accent for comfortable reading.
    for (final label in [
      'السوق / الاتجاه',
      'الارتكاز',
      'سبب الدخول',
      'نوع التأكيد',
      'الحالة النفسية',
      'تاريخ / الوقت',
    ]) {
      final style = tester.widget<Text>(find.text(label)).style!;
      expect(style.fontSize, referenceHeadingStyle.fontSize, reason: label);
      expect(style.fontWeight, referenceHeadingStyle.fontWeight, reason: label);
      expect(
        style.color,
        const Color(0xFFA8B8C9),
        reason: '$label should use the approved Model 3 muted blue-grey accent',
      );
    }

    final conditionsToggle = find.byKey(
      const ValueKey('trade-detail-entry-conditions-toggle'),
    );
    await tester.ensureVisible(conditionsToggle);
    await tester.tap(conditionsToggle);
    await tester.pumpAndSettle();
    expect(find.text('إشارات عكسية'), findsOneWidget);
    expect(find.text('منطقة الارتداد'), findsOneWidget);
    final reverseSignalsField = find.byKey(
      const ValueKey('trade-detail-reverse-signals'),
    );
    final reverseSignalsContainer = tester.widget<Container>(
      find.descendant(
        of: reverseSignalsField,
        matching: find.byType(Container),
      ).first,
    );
    expect(
      (reverseSignalsContainer.decoration as BoxDecoration).color,
      const Color(0xFF243140),
      reason: 'Entry Conditions retains its previous independent field surface',
    );
    final entryConditionChip = tester.widget<Container>(
      find.byKey(
        const ValueKey(
          'trade-detail-entry-condition-value-ارتداد من Trend Line 1H - Supply Zone 15MIN',
        ),
      ),
    );
    expect(
      (entryConditionChip.decoration as BoxDecoration).color,
      const Color(0xFF1E3041),
      reason: 'Entry Conditions chip fill remains independent from saved data chips',
    );
    for (final label in ['إشارات عكسية', 'منطقة الارتداد']) {
      final style = tester.widget<Text>(find.text(label)).style!;
      expect(style.fontSize, referenceHeadingStyle.fontSize, reason: label);
      expect(style.fontWeight, referenceHeadingStyle.fontWeight, reason: label);
      expect(
        style.color,
        TradeDetailPalette.entryConditionsLabelTone(Brightness.dark),
        reason: '$label should share the Entry Conditions panel accent',
      );
    }
    expect(find.textContaining('5MIN'), findsWidgets);
    expect(find.text('ارتداد من Trend Line 1H - Supply Zone 15MIN'), findsOneWidget);
    expect(find.text('ارتداد من دعم - لمسة 2 30MIN'), findsOneWidget);
    final entryConditionValueStyle = tester
        .widget<Text>(find.text('ارتداد من Trend Line 1H - Supply Zone 15MIN'))
        .style!;
    expect(entryConditionValueStyle.fontSize, 13.5);
    expect(entryConditionValueStyle.fontWeight, FontWeight.w700);

    final conditionsPanelRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-entry-conditions-panel')),
    );
    final reverseFieldRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-reverse-signals')),
    );
    expect(
      reverseFieldRect.width,
      greaterThan(conditionsPanelRect.width - 20),
      reason: 'entry-condition text fields should use the panel width with only a slim inset',
    );

    // Compact metric/identity fields occupy half-width slots instead of full rows.
    final resultWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-result-value')),
    ).width;
    final expectedLossWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-expected-loss-value')),
    ).width;
    final identityPairWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-market-mindset-pair')),
    ).width;
    final marketDirectionWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-market-direction-field')),
    ).width;
    final mindsetWidth = tester.getSize(
      find.byKey(const ValueKey('trade-detail-mindset')),
    ).width;
    expect((resultWidth - expectedLossWidth).abs(), lessThan(1));
    expect(marketDirectionWidth, lessThan(identityPairWidth));
    expect((marketDirectionWidth - mindsetWidth).abs(), lessThan(1));
    final marketDirectionHeight = tester.getSize(
      find.byKey(const ValueKey('trade-detail-market-direction-field')),
    ).height;
    final mindsetHeight = tester.getSize(
      find.byKey(const ValueKey('trade-detail-mindset')),
    ).height;
    final mindsetSurfaceRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-mindset-surface')),
    );
    final mindsetValueRect = tester.getRect(find.text('غير واثق من التحليل'));
    expect(mindsetValueRect.bottom, lessThanOrEqualTo(mindsetSurfaceRect.bottom + 1),
        reason: 'a long mindset value must wrap inside the compact rectangle without overflow');
    expect((marketDirectionHeight - mindsetHeight).abs(), lessThan(1));
    final anchorHeight = tester.getSize(
      find.byKey(const ValueKey('trade-detail-anchor')),
    ).height;
    expect(
      (marketDirectionHeight - anchorHeight).abs(),
      lessThan(1),
      reason: 'market/direction and mindset rectangles must be the same height as the anchor rectangle',
    );

    // Saved data is ordered exactly like the requested hierarchy.
    final identityRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-market-mindset-pair')),
    );
    final anchorRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-anchor')),
    );
    final entryReasonRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-entry-reasons')),
    );
    final confirmationRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-confirmations')),
    );
    final tradedAtRect = tester.getRect(
      find.byKey(const ValueKey('trade-detail-traded-at')),
    );
    expect(entryReasonRect.top, greaterThan(identityRect.bottom));
    expect(anchorRect.top, greaterThan(entryReasonRect.bottom));
    expect(confirmationRect.top, greaterThan(anchorRect.bottom));
    expect(tradedAtRect.top, greaterThan(confirmationRect.bottom));
    expect(find.byKey(const ValueKey('trade-detail-market-direction-divider')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-market-symbol-value')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-detail-market-direction-value')), findsOneWidget);

    final detailList = tester.widget<ListView>(
      find.byKey(const ValueKey('trade-detail-scroll-view')),
    );
    expect(detailList.padding, const EdgeInsetsDirectional.fromSTEB(8, 10, 8, 24));

    // The main trade-data panel can be folded with one tap and restored
    // without losing any of the saved detail values.
    await tester.tap(dataToggle);
    await tester.pumpAndSettle();
    expect(find.text('بيانات الصفقة'), findsOneWidget);
    expect(find.text('US100'), findsNothing);
    await tester.tap(dataToggle);
    await tester.pumpAndSettle();
    expect(find.text('US100'), findsOneWidget);
    expect(find.text('RBS Touch 2 5MIN'), findsOneWidget);

    final executionToggle = find.byKey(
      const ValueKey('trade-detail-execution-panel-toggle'),
    );
    await tester.ensureVisible(executionToggle);
    await tester.tap(executionToggle);
    await tester.pump(const Duration(milliseconds: 250));
    final executionStatusStyle =
        tester.widget<Text>(find.text('دخلت مبكراً')).style!;
    expect(executionStatusStyle.fontSize, 15);
    expect(executionStatusStyle.fontWeight, FontWeight.w600);
  });

  testWidgets(
    'saved sell trade presents the S/R bounce as resistance',
    (tester) async {
      final trade = Trade(
        id: 'detail-sell-sr-test',
        accountId: 'account-test',
        market: 'EURUSD',
        reason: 'RFS',
        result: -10,
        riskPercent: 1,
        side: TradeSide.sell,
        confirmation: 'confirmBearishEngulfing',
        bounceZoneSetups: const [
          TradeEntryConditionSetup(
            optionKey: 'bounceFromSrZone',
            timeframe: '15MIN',
            touch2: true,
          ),
        ],
        mood: 'moodCalm',
        tradedAt: DateTime(2026, 11, 14, 10),
      );

      await tester.pumpWidget(
        MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: TradeDetailScreen(trade: trade, currency: 'USD'),
        ),
      );
      await tester.pumpAndSettle();
      final dataToggle = find.byKey(
        const ValueKey('trade-detail-data-panel-toggle'),
      );
      await tester.tap(dataToggle);
      await tester.pumpAndSettle();
      expect(find.text('SELL'), findsOneWidget,
          reason: 'saved sell trades must display the uppercase English direction label');
      final conditionsToggle = find.byKey(
        const ValueKey('trade-detail-entry-conditions-toggle'),
      );
      await tester.ensureVisible(conditionsToggle);
      await tester.tap(conditionsToggle);
      await tester.pumpAndSettle();
      expect(find.text('ارتداد من مقاومة - لمسة 2 15MIN'), findsOneWidget);
      expect(find.text('ارتداد من منطقة S/R 15MIN'), findsNothing);
    },
  );

  testWidgets('saved trade field heading accents remain contrasted in light mode', (
    tester,
  ) async {
    final trade = Trade(
      id: 'detail-label-light-test',
      accountId: 'account-test',
      market: 'US100',
      reason: 'RBS Touch 2',
      result: 5,
      riskPercent: 1,
      side: TradeSide.buy,
      entrySetups: const [
        TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '5MIN'),
      ],
      confirmationSetups: const [
        TradeConfirmationSetup(type: 'confirmBreakoutPullback', timeframe: '15MIN'),
      ],
      reverseSignalSetups: const [
        TradeEntryConditionSetup(optionKey: 'reverseHns', timeframe: '15MIN'),
      ],
      bounceZoneSetups: const [
        TradeEntryConditionSetup(optionKey: 'bounceFromSrZone', timeframe: '30MIN'),
      ],
      mood: 'moodCalm',
      tradedAt: DateTime(2026, 11, 19, 18, 10),
      anchor: 'supplyZone',
      anchors: const ['supplyZone'],
      anchorTimeframes: const {'supplyZone': '15MIN'},
    );

    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(Brightness.light),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: TradeDetailScreen(trade: trade, currency: 'USD'),
      ),
    );
    await tester.pumpAndSettle();

    final dataToggle = find.byKey(
      const ValueKey('trade-detail-data-panel-toggle'),
    );
    await tester.tap(dataToggle);
    await tester.pumpAndSettle();
    final dataLabel = tester.widget<Text>(find.text('السوق / الاتجاه')).style!;
    expect(dataLabel.fontSize, 13);
    expect(dataLabel.fontWeight, FontWeight.w800);
    expect(
      dataLabel.color,
      TradeDetailPalette.dataLabelTone(Brightness.light),
    );

    final conditionsToggle = find.byKey(
      const ValueKey('trade-detail-entry-conditions-toggle'),
    );
    await tester.ensureVisible(conditionsToggle);
    await tester.tap(conditionsToggle);
    await tester.pumpAndSettle();
    for (final label in ['إشارات عكسية', 'منطقة الارتداد']) {
      final style = tester.widget<Text>(find.text(label)).style!;
      expect(style.fontSize, 13);
      expect(style.fontWeight, FontWeight.w800);
      expect(
        style.color,
        TradeDetailPalette.entryConditionsLabelTone(Brightness.light),
      );
    }
    expect(tester.takeException(), isNull);
  });


}
