# معلومات البناء والتسليم — TraderDesk 1.7.96+152

- رقم الإصدار: `1.7.96`؛ رقم البناء: `152`.
- النسخة الأم: `1.7.95+151`.
- المصدر المباشر: `TraderDesk_Android_Project_v1.7.95+151_GPT_SOURCE(1).zip`.
- نوع التسليم: المشروع المصدري الكامل بصيغة ZIP؛ لا يتضمن هذا التسليم APK.
- نطاق الطلب: مطابقة حجم مستطيل «الحالة النفسية» لمستطيل «السوق / الاتجاه» ووضعهما متجاورين في صف واحد ضمن نموذج إضافة الصفقة.
- نتيجة فحص المصدر: الشرطان موجودان بالفعل في `lib/screens/trade_form_screen.dart`؛ يشترك الحقلان في `marketControlWidth` و`_tradeDataControlHeight` (`72dp`) وتفصل بينهما فجوة `8dp`. لم يُغيّر كود الواجهة لعدم وجود نقص في التنفيذ.
- دليل اختبار الواجهة: `test/entry_conditions_test.dart`، اختبار `pairs mindset with market/direction and renders anchors as a full-width selection field`، ويتحقق من تساوي العرض والارتفاع وتطابق موضع الحافة العلوية والتجاور في RTL.
- أضيف فحص ساكن مخصص `scripts/verify_mindset_market_equal_layout.py` لحماية هندسة الحقلين في مراجعات المصدر المستقبلية.
- رُفعت بيانات الإصدار ومعرّفات GitHub Actions إلى `1.7.96+152` / `build152`.
- لم تتغير نماذج الصفقات أو صيغة JSON أو التخزين المحلي أو النسخ الاحتياطي؛ لم يمس هذا التحديث سوى بيانات الإصدار ووثائق التحقق.

## التحقق

- اجتازت 19 سكربتات تحقق ساكنة `442/442` تأكيداً.
- اجتاز `python -m py_compile scripts/*.py`.
- اجتاز `bash -n scripts/build_release_apk.sh scripts/verify_arm64_apk.sh`.
- اجتازت ملفات Android XML عدد `8/8` وملفات YAML عدد `2/2`.
- لم تتوفر Flutter وDart في بيئة التنفيذ؛ لذلك لم تُشغّل `flutter analyze` أو `flutter test` ولم يُبنَ APK.
- لم يُجرَ اختبار بصري على جهاز Android فعلي ضمن هذا التسليم.
