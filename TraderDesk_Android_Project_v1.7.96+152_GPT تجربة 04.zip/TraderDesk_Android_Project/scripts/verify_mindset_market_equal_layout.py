#!/usr/bin/env python3
"""Static regression checks for equal adjacent Market/Direction and Mindset fields."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []


def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))


# Both fields use a single width value calculated from the available row width.
check("equal two-column width is calculated once", "final marketControlWidth =\n                              (constraints.maxWidth - identifierGap) / 2;" in FORM)
check("market/direction uses the shared column width", "width: marketControlWidth," in FORM)
check("mindset uses the same shared column width", "width: marketControlWidth,\n                                    child: _buildMindsetSelector(" in FORM)
check("the two fields are separated by the fixed 8dp gap", "const identifierGap = 8.0;" in FORM and "const SizedBox(width: identifierGap)" in FORM)
check("both fields use the shared 72dp height", FORM.count("height: _tradeDataControlHeight") >= 2 and "const double _tradeDataControlHeight = 72;" in FORM)

# Widget assertions verify rendered geometry, not only source declarations.
check("widget test compares mindset and market widths", "moodRect.width,\n      closeTo(marketDirectionRect.width, 1)" in TESTS)
check("widget test verifies horizontal RTL adjacency", "moodRect.left,\n      lessThan(marketDirectionRect.left)" in TESTS)
check("widget test verifies matching top edges", "expect(moodRect.top, closeTo(marketDirectionRect.top, .1));" in TESTS)
check("widget test verifies both 72dp heights are equal", "expect(marketDirectionHeight, closeTo(72, .1)" in TESTS and "expect(moodHeight, closeTo(72, .1)" in TESTS and "expect(marketDirectionHeight, closeTo(moodHeight, .1)" in TESTS)
check("release metadata is 1.7.96+152", "version: 1.7.96+152" in PUBSPEC and "TraderDesk 1.7.96+152" in WORKFLOW)
check("workflow artifact identifiers use build152", "traderdesk-1.7.96-build152-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.96-build152-arm64-dart-symbols" in WORKFLOW)

failed = [label for label, passed in checks if not passed]
for label, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
