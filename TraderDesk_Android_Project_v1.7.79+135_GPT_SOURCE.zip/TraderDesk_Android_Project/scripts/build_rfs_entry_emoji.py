#!/usr/bin/env python3
"""Rebuild the RFS animated WebP from the supplied SVG/SMIL HTML source.

The source artwork, its path geometry, stroke colors, 3.8s timing, and delayed
resistance-line reveal are preserved. Only the SMIL animation is sampled into
transparent WebP frames for Flutter's native image decoder.
"""
from __future__ import annotations

import math
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from PIL import Image
import cairosvg

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'assets/emojis/entry_reasons/source/RFS_speed_updated_38.html'
OUTPUT = ROOT / 'assets/emojis/entry_reasons/rfs.webp'
FRAME_COUNT = 190  # 50 fps x 3.8 seconds, matching the supplied animation.
DURATION_MS = 20
OUTPUT_SIZE = 108
RENDER_SIZE = 432  # 4x supersampling before the final 108px downsample.

NUMBER_RE = re.compile(r'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?')


def local_name(tag: str) -> str:
    return tag.rsplit('}', 1)[-1]


def parse_numbers(value: str) -> list[float]:
    return [float(item) for item in NUMBER_RE.findall(value)]


def point_on_cubic(p0, p1, p2, p3, t: float) -> tuple[float, float]:
    u = 1.0 - t
    x = (u**3 * p0[0] + 3*u*u*t*p1[0] + 3*u*t*t*p2[0] + t**3*p3[0])
    y = (u**3 * p0[1] + 3*u*u*t*p1[1] + 3*u*t*t*p2[1] + t**3*p3[1])
    return x, y


def partial_cubic_path(d: str, progress: float) -> str:
    values = parse_numbers(d)
    if len(values) != 8:
        raise ValueError(f'Expected one M+C cubic path, got {d!r}')
    p0, p1, p2, p3 = (
        (values[0], values[1]),
        (values[2], values[3]),
        (values[4], values[5]),
        (values[6], values[7]),
    )
    steps = max(2, math.ceil(72 * progress))
    pts = [point_on_cubic(p0, p1, p2, p3, progress * i / steps)
           for i in range(steps + 1)]
    return 'M ' + ' L '.join(f'{x:.4f},{y:.4f}' for x, y in pts)


def find_animation(element: ET.Element, attribute: str) -> ET.Element:
    for child in element:
        if local_name(child.tag) == 'animate' and child.attrib.get('attributeName') == attribute:
            return child
    raise ValueError(f'Missing {attribute} animation in source SVG')


def build() -> None:
    html = SOURCE.read_text(encoding='utf-8')
    match = re.search(r'(<svg\b.*?</svg>)', html, flags=re.DOTALL | re.IGNORECASE)
    if not match:
        raise ValueError('No inline SVG found in supplied HTML source')
    svg = ET.fromstring(match.group(1))
    view_box = svg.attrib.get('viewBox', '0 0 256 256')
    view_values = parse_numbers(view_box)
    if len(view_values) != 4:
        raise ValueError(f'Invalid SVG viewBox: {view_box}')

    paths = [e for e in svg.iter() if local_name(e.tag) == 'path']
    if len(paths) != 8:
        raise ValueError(f'Expected 1 reference line + 7 price segments, found {len(paths)} paths')

    reference = paths[0]
    reference_d = reference.attrib['d']
    reference_clip = reference.attrib.get('clip-path', '')
    if not reference_clip.startswith('url(#'):
        raise ValueError('The delayed level line must retain its source clip-path')
    clip_id = reference_clip[5:-1]
    clip_paths = [e for e in svg.iter() if local_name(e.tag) == 'clipPath' and e.attrib.get('id') == clip_id]
    if len(clip_paths) != 1:
        raise ValueError('Could not resolve source clipPath for the delayed level line')
    clip_rect = next(e for e in clip_paths[0] if local_name(e.tag) == 'rect')
    rect_anim = find_animation(clip_rect, 'width')
    rect_values = parse_numbers(rect_anim.attrib['values'])
    rect_times = parse_numbers(rect_anim.attrib['keyTimes'])
    duration_s = float(rect_anim.attrib['dur'].removesuffix('s'))
    reveal_start = rect_times[1] * duration_s
    reveal_end = rect_times[2] * duration_s
    reveal_width = rect_values[2]

    segments = []
    for path in paths[1:]:
        dash_anim = find_animation(path, 'stroke-dashoffset')
        key_times = parse_numbers(dash_anim.attrib['keyTimes'])
        segments.append({
            'd': path.attrib['d'],
            'stroke': path.attrib.get('stroke', '#00c8a0'),
            'width': float(path.attrib.get('stroke-width', '3')),
            'start': key_times[1] * duration_s,
            'end': key_times[2] * duration_s,
        })

    x0, y0 = view_values[0], view_values[1]
    frames: list[Image.Image] = []
    for frame_no in range(FRAME_COUNT):
        time_s = frame_no * duration_s / FRAME_COUNT
        items = []
        # Keep the source's exact off-white resistance line and reveal it only
        # inside the supplied 0.615..0.683 portion of the 3.8s timeline.
        if time_s >= reveal_start:
            level_progress = min(1.0, max(0.0, (time_s - reveal_start) / (reveal_end - reveal_start)))
            if level_progress > 0:
                width = reveal_width * level_progress
                items.append(
                    f'<defs><clipPath id="levelClip"><rect x="{clip_rect.attrib["x"]}" '
                    f'y="{clip_rect.attrib["y"]}" width="{width:.5f}" '
                    f'height="{clip_rect.attrib["height"]}"/></clipPath></defs>'
                    f'<path d="{reference_d}" fill="none" '
                    f'stroke="{reference.attrib.get("stroke", "#ffffff")}" '
                    f'stroke-width="{reference.attrib.get("stroke-width", "1.85")}" '
                    f'stroke-linecap="round" clip-path="url(#levelClip)"/>'
                )
        for segment in segments:
            if time_s < segment['start']:
                continue
            progress = min(1.0, (time_s - segment['start']) / (segment['end'] - segment['start']))
            if progress <= 0:
                continue
            d = partial_cubic_path(segment['d'], progress)
            items.append(
                f'<path d="{d}" fill="none" stroke="{segment["stroke"]}" '
                f'stroke-width="{segment["width"]}" stroke-linecap="round" '
                f'stroke-linejoin="round"/>'
            )
        # The supplied HTML's dark body is only its preview canvas. The actual
        # SVG artwork is transparent, so no page background is rendered here.
        frame_svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{view_box}" '
            f'width="{RENDER_SIZE}" height="{RENDER_SIZE}">' + ''.join(items) + '</svg>'
        )
        png = cairosvg.svg2png(bytestring=frame_svg.encode('utf-8'),
                               output_width=RENDER_SIZE, output_height=RENDER_SIZE)
        import io
        image = Image.open(io.BytesIO(png)).convert('RGBA')
        image = image.resize((OUTPUT_SIZE, OUTPUT_SIZE), Image.Resampling.LANCZOS)
        frames.append(image)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    frames[0].save(
        OUTPUT,
        format='WEBP',
        save_all=True,
        append_images=frames[1:],
        duration=DURATION_MS,
        loop=0,
        lossless=True,
        quality=100,
        method=6,
        minimize_size=True,
    )
    print(f'Created {OUTPUT.relative_to(ROOT)}: {FRAME_COUNT} frames, '
          f'{FRAME_COUNT * DURATION_MS}ms, {OUTPUT_SIZE}x{OUTPUT_SIZE}, transparent')


if __name__ == '__main__':
    build()
