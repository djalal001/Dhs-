#!/usr/bin/env python3
"""Focused static/asset verification for TraderDesk 1.7.79+135."""
from __future__ import annotations

import re
import struct
import sys
from pathlib import Path

from PIL import Image, ImageSequence

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
passed = 0


def check(name: str, condition: bool) -> None:
    global passed
    if condition:
        passed += 1
        print(f'PASS  {name}')
    else:
        errors.append(name)
        print(f'FAIL  {name}')


def webp_frames_and_duration(data: bytes) -> tuple[int, int]:
    if data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        return 0, 0
    frames = 0
    duration = 0
    offset = 12
    while offset + 8 <= len(data):
        chunk = data[offset:offset + 4]
        size = struct.unpack_from('<I', data, offset + 4)[0]
        payload = offset + 8
        if chunk == b'ANMF' and size >= 16:
            frames += 1
            duration += int.from_bytes(data[payload + 12:payload + 15], 'little')
        offset = payload + size + (size & 1)
    return frames, duration


pubspec = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
form = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
trades = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
chips = (ROOT / 'lib/widgets/trade_entry_setup_chips.dart').read_text(encoding='utf-8')
widget = (ROOT / 'lib/widgets/entry_reason_emoji.dart').read_text(encoding='utf-8')
test = (ROOT / 'test/entry_reason_rfs_emoji_test.dart').read_text(encoding='utf-8')
source_path = ROOT / 'assets/emojis/entry_reasons/source/RFS_speed_updated_38.html'
asset_path = ROOT / 'assets/emojis/entry_reasons/rfs.webp'
source = source_path.read_text(encoding='utf-8') if source_path.exists() else ''
asset = asset_path.read_bytes() if asset_path.exists() else b''
frames, duration = webp_frames_and_duration(asset)

check('pubspec version is 1.7.79+135', 'version: 1.7.79+135' in pubspec)
check('release workflow uses version/build 1.7.79/135',
      'TraderDesk 1.7.79+135' in workflow and
      'traderdesk-1.7.79-build135-arm64-v8a-release' in workflow and
      'traderdesk-1.7.79-build135-arm64-dart-symbols' in workflow)
check('RFS WebP is explicitly declared as a Flutter asset',
      'assets/emojis/entry_reasons/rfs.webp' in pubspec)
check('supplied RFS HTML source is retained in the project', source_path.exists() and '<svg' in source)
check('RFS generated file is an animated WebP', len(asset) > 16 and asset[:4] == b'RIFF' and asset[8:12] == b'WEBP')
check('RFS animation has at least 100 decoded frames', frames >= 100)
check('RFS animation duration matches the supplied 3.8s cycle', duration == 3800)
check('RFS animation retains alpha channel', any(
    asset[i:i + 4] == b'VP8X' and (asset[i + 8] & 0x10) != 0
    for i in range(12, max(12, len(asset) - 8))))
# Confirm the generated level line is absent immediately before the source
# trigger and visible after the source reveal window.
if asset_path.exists():
    decoded = [frame.copy().convert('RGBA') for frame in ImageSequence.Iterator(Image.open(asset_path))]
    frame_durations = []
    offset = 12
    while offset + 8 <= len(asset):
        chunk = asset[offset:offset + 4]
        chunk_size = struct.unpack_from('<I', asset, offset + 4)[0]
        payload = offset + 8
        if chunk == b'ANMF' and chunk_size >= 16:
            frame_durations.append(int.from_bytes(asset[payload + 12:payload + 15], 'little'))
        offset = payload + chunk_size + (chunk_size & 1)

    def frame_at_time(target_ms: int):
        elapsed = 0
        for frame, frame_duration in zip(decoded, frame_durations):
            if elapsed + frame_duration > target_ms:
                return frame
            elapsed += frame_duration
        return decoded[-1]

    def horizontal_white_pixels(frame: Image.Image) -> int:
        row = round(125 / 256 * 108)
        return sum(
            1 for x in range(8, 101)
            if (lambda px: px[3] > 25 and min(px[:3]) > 220)(frame.getpixel((x, row)))
        )

    before_reveal = horizontal_white_pixels(frame_at_time(2320))
    after_reveal = horizontal_white_pixels(frame_at_time(2800))
else:
    before_reveal, after_reveal = -1, -1
check('generated level line is absent before 2.337s trigger', before_reveal == 0)
check('generated level line is present after breakout/retest phase', after_reveal >= 20)
check('supplied teal path color is retained', 'stroke="#00c8a0"' in source)
check('supplied white level-line color is retained', 'stroke="#ffffff"' in source)
check('level line reveal uses source keyTimes 0.615 to 0.683', 'keyTimes="0;0.615;0.683;1"' in source)
check('source animation duration remains 3.8 seconds', 'dur="3.8s"' in source)
check('only RFS has an entry-reason emoji mapping', "'RFS': 'assets/emojis/entry_reasons/rfs.webp'" in widget and len(re.findall(r"'[^']+': 'assets/emojis/entry_reasons/", widget)) == 1)
check('entry-reason selector enables its emoji lead-in', 'showEntryReasonEmoji: true' in form and 'EntryReasonEmoji(reason: \'RFS\'' in form)
check('normal saved trade chips do not render a permanent RFS emoji', 'EntryReasonPressPreview(reason: setup.reason, child: chip)' in chips)
check('saved detail preview is limited to RFS labels', 'pressPreviewValues: rfsEntryReasonLabels' in trades and "EntryReasonPressPreview(reason: 'RFS', child: chip)" in trades)
check('preview is removed on long-press end and cancellation', 'onLongPressEnd: (_) => _hidePreview()' in widget and 'onLongPressCancel: _hidePreview' in widget)
check('trade model and JSON schema remain untouched by this feature',
      not any(token in widget for token in ['toJson(', 'fromJson(', 'TradeEntrySetup(']))
check('asset and interaction regression tests are present', '3800' in test and 'saved RFS chip reveals the animation only while held' in test)

print(f'\nSummary: {passed} passed, {len(errors)} failed')
if errors:
    print('Failed checks: ' + '; '.join(errors))
    sys.exit(1)
