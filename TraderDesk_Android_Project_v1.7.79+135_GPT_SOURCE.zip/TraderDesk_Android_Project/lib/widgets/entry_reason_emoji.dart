import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Animated artwork available for selected entry reasons.
///
/// Keep this map keyed by the persisted reason value so adding artwork never
/// changes the trade JSON schema or older saved records.
const entryReasonEmojiAssets = <String, String>{
  'RFS': 'assets/emojis/entry_reasons/rfs.webp',
};

bool hasEntryReasonEmoji(String reason) =>
    entryReasonEmojiAssets.containsKey(reason);

/// Compact animated entry-reason artwork used only while choosing a reason.
class EntryReasonEmoji extends StatelessWidget {
  const EntryReasonEmoji({super.key, required this.reason, this.size = 28});

  final String reason;
  final double size;

  @override
  Widget build(BuildContext context) {
    final asset = entryReasonEmojiAssets[reason];
    if (asset == null) return const SizedBox.shrink();

    return RepaintBoundary(
      child: ExcludeSemantics(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Image.asset(
            asset,
            key: ValueKey('entry-reason-emoji-$reason'),
            width: size,
            height: size,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.medium,
            gaplessPlayback: true,
          ),
        ),
      ),
    );
  }
}

/// A saved entry-reason chip remains visually clean until it is pressed and
/// held. The matching animated pictogram then appears beside the chip and is
/// removed immediately when the pointer is released or the gesture cancels.
class EntryReasonPressPreview extends StatefulWidget {
  const EntryReasonPressPreview({
    super.key,
    required this.reason,
    required this.child,
    this.previewSize = 108,
  });

  final String reason;
  final Widget child;
  final double previewSize;

  @override
  State<EntryReasonPressPreview> createState() =>
      _EntryReasonPressPreviewState();
}

class _EntryReasonPressPreviewState extends State<EntryReasonPressPreview> {
  OverlayEntry? _previewEntry;

  void _showPreview() {
    if (_previewEntry != null || !hasEntryReasonEmoji(widget.reason)) return;

    final anchorObject = context.findRenderObject();
    if (anchorObject is! RenderBox || !anchorObject.hasSize) return;

    final overlay = Overlay.of(context, rootOverlay: true);
    final overlayObject = overlay.context.findRenderObject();
    if (overlayObject is! RenderBox || !overlayObject.hasSize) return;

    final anchor = anchorObject.localToGlobal(
      Offset.zero,
      ancestor: overlayObject,
    );
    final anchorSize = anchorObject.size;
    final overlaySize = overlayObject.size;
    const popupPadding = 8.0;
    final popupExtent = widget.previewSize + 8;
    final rightCandidate = anchor.dx + anchorSize.width + popupPadding;
    final canPlaceRight = rightCandidate + popupExtent <= overlaySize.width - 8;
    final left = canPlaceRight
        ? rightCandidate
        : (anchor.dx - popupExtent - popupPadding)
            .clamp(8.0, math.max(8.0, overlaySize.width - popupExtent - 8));
    final top = (anchor.dy + (anchorSize.height - popupExtent) / 2)
        .clamp(8.0, math.max(8.0, overlaySize.height - popupExtent - 8));

    final asset = entryReasonEmojiAssets[widget.reason]!;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final previewSurface = theme.brightness == Brightness.dark
        ? colorScheme.surface
        : const Color(0xFF142A46);
    _previewEntry = OverlayEntry(
      builder: (_) => Positioned(
        left: left.toDouble(),
        top: top.toDouble(),
        width: popupExtent,
        height: popupExtent,
        child: IgnorePointer(
          child: Material(
            key: ValueKey('entry-reason-preview-${widget.reason}'),
            color: previewSurface,
            elevation: 7,
            shadowColor: Colors.black.withValues(alpha: .24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(11),
              side: BorderSide(
                color: colorScheme.outlineVariant.withValues(alpha: .72),
                width: .8,
              ),
            ),
            clipBehavior: Clip.antiAlias,
            child: Center(
              child: Image.asset(
                asset,
                width: widget.previewSize,
                height: widget.previewSize,
                fit: BoxFit.contain,
                filterQuality: FilterQuality.medium,
                gaplessPlayback: true,
              ),
            ),
          ),
        ),
      ),
    );
    overlay.insert(_previewEntry!);
  }

  void _hidePreview() {
    _previewEntry?.remove();
    _previewEntry?.dispose();
    _previewEntry = null;
  }

  @override
  void dispose() {
    _hidePreview();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onLongPressStart: (_) => _showPreview(),
        onLongPressEnd: (_) => _hidePreview(),
        onLongPressCancel: _hidePreview,
        child: widget.child,
      );
}
