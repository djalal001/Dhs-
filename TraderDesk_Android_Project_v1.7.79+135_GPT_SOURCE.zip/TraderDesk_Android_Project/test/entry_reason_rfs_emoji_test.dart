import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/widgets/entry_reason_emoji.dart';

const _rfsAsset = 'assets/emojis/entry_reasons/rfs.webp';
const _rfsSource = 'assets/emojis/entry_reasons/source/RFS_speed_updated_38.html';

int _countChunk(List<int> bytes, String chunkName) {
  var count = 0;
  var offset = 12;
  while (offset + 8 <= bytes.length) {
    final name = String.fromCharCodes(bytes.sublist(offset, offset + 4));
    final size = bytes[offset + 4] |
        (bytes[offset + 5] << 8) |
        (bytes[offset + 6] << 16) |
        (bytes[offset + 7] << 24);
    if (name == chunkName) count++;
    offset += 8 + size + (size.isOdd ? 1 : 0);
  }
  return count;
}

int _webpAnimationDuration(List<int> bytes) {
  var total = 0;
  var offset = 12;
  while (offset + 8 <= bytes.length) {
    final name = String.fromCharCodes(bytes.sublist(offset, offset + 4));
    final size = bytes[offset + 4] |
        (bytes[offset + 5] << 8) |
        (bytes[offset + 6] << 16) |
        (bytes[offset + 7] << 24);
    final data = offset + 8;
    if (name == 'ANMF' && size >= 16) {
      total += bytes[data + 12] |
          (bytes[data + 13] << 8) |
          (bytes[data + 14] << 16);
    }
    offset += 8 + size + (size.isOdd ? 1 : 0);
  }
  return total;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('RFS is the only entry-reason illustration currently mapped', () {
    expect(entryReasonEmojiAssets, {'RFS': _rfsAsset});
  });

  test('RFS asset is transparent animated WebP at the project emoji size', () {
    final file = File(_rfsAsset);
    expect(file.existsSync(), isTrue);
    final bytes = file.readAsBytesSync();
    expect(String.fromCharCodes(bytes.sublist(0, 4)), 'RIFF');
    expect(String.fromCharCodes(bytes.sublist(8, 12)), 'WEBP');
    expect(_countChunk(bytes, 'ANMF'), greaterThanOrEqualTo(50));
    expect(_webpAnimationDuration(bytes), 3800);

    final vp8x = <int>[];
    for (var i = 12; i + 8 < bytes.length; i++) {
      if (String.fromCharCodes(bytes.sublist(i, i + 4)) == 'VP8X') {
        vp8x.add(bytes[i + 8]);
      }
    }
    expect(vp8x, isNotEmpty);
    expect(vp8x.first & 0x10, isNot(0), reason: 'RFS must retain alpha');
  });

  test('the original supplied RFS vector and delayed level reveal are retained', () {
    final source = File(_rfsSource).readAsStringSync();
    expect(source, contains('stroke="#00c8a0"'));
    expect(source, contains('stroke="#ffffff"'));
    expect(source, contains('keyTimes="0;0.615;0.683;1"'));
    expect(source, contains('dur="3.8s"'));
  });

  testWidgets('RFS option artwork can be rendered as a compact animated lead-in', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Center(child: EntryReasonEmoji(reason: 'RFS', size: 28)),
        ),
      ),
    );
    expect(find.byKey(const ValueKey('entry-reason-emoji-RFS')), findsOneWidget);
  });

  testWidgets('saved RFS chip reveals the animation only while held', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: EntryReasonPressPreview(
              reason: 'RFS',
              child: const Text('RFS 15MIN', key: ValueKey('rfs-saved-chip')),
            ),
          ),
        ),
      ),
    );

    expect(find.byKey(const ValueKey('entry-reason-preview-RFS')), findsNothing);
    final gesture = await tester.startGesture(
      tester.getCenter(find.byKey(const ValueKey('rfs-saved-chip'))),
    );
    await tester.pump(const Duration(milliseconds: 600));
    expect(find.byKey(const ValueKey('entry-reason-preview-RFS')), findsOneWidget);

    await gesture.up();
    await tester.pump();
    expect(find.byKey(const ValueKey('entry-reason-preview-RFS')), findsNothing);
  });

  testWidgets('reasons without a supplied illustration do not show a preview', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: EntryReasonPressPreview(
              reason: 'SBR',
              child: const Text('SBR', key: ValueKey('sbr-saved-chip')),
            ),
          ),
        ),
      ),
    );

    final gesture = await tester.startGesture(
      tester.getCenter(find.byKey(const ValueKey('sbr-saved-chip'))),
    );
    await tester.pump(const Duration(milliseconds: 600));
    expect(find.byKey(const ValueKey('entry-reason-preview-SBR')), findsNothing);
    await gesture.up();
    await tester.pump();
  });
}
