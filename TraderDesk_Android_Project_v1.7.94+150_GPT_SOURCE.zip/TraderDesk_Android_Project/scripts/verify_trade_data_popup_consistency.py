#!/usr/bin/env python3
"""Static regression checks for unified Trade Data popups and selected-value typography."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
THEME = (ROOT / 'lib/theme/app_theme.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []
def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))

check('release metadata is 1.7.94+150', 'version: 1.7.94+150' in PUBSPEC and 'TraderDesk 1.7.94+150' in WORKFLOW)
check('workflow artifacts use build150', 'traderdesk-1.7.94-build150-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.94-build150-arm64-dart-symbols' in WORKFLOW)
check('shared selected-item font token is 14.5dp', 'const double _tradeDataItemFontSize = 14.5;' in FORM)
check('selected entry/confirmation/condition labels use shared font token', FORM.count('fontSize: _tradeDataItemFontSize') >= 7 and 'fontSize: 13.5' not in FORM)
check('anchor selected labels use shared font token', "'trade-anchor-selected-values'" in FORM and 'fontSize: _tradeDataItemFontSize' in FORM[FORM.index('Widget _anchorMultiSelector'):FORM.index('Widget _setupSelectionField')])
check('entry/confirmation selected values use shared font token', 'fontSize: _tradeDataItemFontSize' in FORM[FORM.index('Widget _setupSelectionField'):FORM.index('Widget _entryConditionField')])
check('entry-condition selected values use shared font token', 'fontSize: _tradeDataItemFontSize' in FORM[FORM.index('Widget _entryConditionField'):FORM.index('Widget _buildLinkedEntryBehaviorSections')])
check('mindset selected value uses shared font token', 'fontSize: _tradeDataItemFontSize' in FORM[FORM.index('Widget _buildMindsetSelector'):FORM.index('Widget _setupSelectionField')])
check('market/direction selected values use shared font token', 'fontSize: hasSelectedValue ? _tradeDataItemFontSize : 10.5' in FORM)
check('mindset popup is anchored to a GlobalKey on its own field', '_moodPopupAnchorKey' in FORM and 'key: _moodPopupAnchorKey' in FORM and 'anchorKey: _moodPopupAnchorKey' in FORM)
check('mindset popup uses the shared showMenu helper', "key: const ValueKey('trade-mood-dropdown')" in FORM and "itemKeyPrefix: 'trade-mood-option'" in FORM and 'PopupMenuButton<String>' not in FORM)
check('all compact selector popup widths follow their own anchor width', 'final menuWidth = anchorRenderObject.size.width > screenWidthLimit' in FORM and 'constraints: BoxConstraints.tightFor(width: menuWidth)' in FORM)
check('compact popups use the shared background and border', 'color: tdPopupMenuColor(Theme.of(context).brightness)' in FORM and 'shape: tdTradeDataPopupMenuShape(Theme.of(context).brightness)' in FORM)
check('centered dialogs preserve contextual surfaces when accentTone is supplied', 'final dialogSurfaceColor = accentTone == null' in FORM and 'Color.alphaBlend(' in FORM and 'accentTone.withValues(alpha: isDark ? .14 : .08)' in FORM and 'final dialogBorderColor = accentTone == null' in FORM)
check('centered dialogs retain the standard Trade Data surface when no semantic tone is supplied', '? tdPopupMenuColor(brightness)' in FORM and '? tdTradeDataPopupMenuBorderColor(brightness)' in FORM)
check('anchor multi-select dialog uses the same popup background and border', "backgroundColor: tdPopupMenuColor(brightness)" in FORM and 'shape: tdTradeDataPopupMenuShape(brightness)' in FORM)
check('entry-reason bottom list shares the trade-data popup surface', 'backgroundColor: tdPopupMenuColor(Theme.of(context).brightness)' in FORM and 'fontSize: _tradeDataItemFontSize' in FORM[FORM.index('Future<String?> _showChoiceSheet'):FORM.index('Future<String?> _showTimeframeSheet')])
check('popup theme centralizes background, tint and typography', 'color: tdPopupMenuColor(baseTheme.brightness)' in FORM and 'surfaceTintColor: Colors.transparent' in FORM and 'shape: tdTradeDataPopupMenuShape(baseTheme.brightness)' in FORM)
check('all menu rows use the common item font token', FORM.count('fontSize: _tradeDataItemFontSize') >= 7 and 'fontSize: 14.5' not in FORM)
check('result sign is placed on visual left for RTL and LTR', "prefix: _ar ? null : _resultSignPrefix()" in FORM and "prefixText: _ar ? suffix : null" in FORM and "suffix: _ar ? _resultSignPrefix() : null" in FORM and "suffixText: _ar ? null : suffix" in FORM)
check('widget tests cover exact mindset popup width and background', 'mindset popup must match its own field width' in TESTS and 'trade-data popup menus share the same neutral dark-blue surface' in TESTS)
check('compact selector popup rows display text without selection checkmarks', 'labelFor(value),' in FORM and 'Icons.check_rounded' not in FORM[FORM.index('Future<void> _showCompactPopupChoice'):FORM.index('BoxDecoration _selectedTradeDataValueDecoration')])
check('market/direction selected values use a subtle same-family field highlight', "final selectedValueKey = hasSelectedValue" in FORM and "key: ValueKey(selectedValueKey!)" in FORM and '_selectedTradeDataValueDecoration(tokens)' in FORM)
check('mindset selected value uses the same subtle field highlight', "ValueKey('trade-mood-selected-value')" in FORM and '_selectedTradeDataValueDecoration(' in FORM)
check('practical long-press state tints the opposing-signal inner field with saved-trade purple', 'isPracticallyLinked' in FORM and 'TradeDetailPalette.linkedEntryConditionsFieldDark' in FORM and 'fillColorOverride: entryConditionFieldFill' in FORM)
check('widget tests cover visible selected text and removed popup checkmarks', 'selected direction must remain readable when the popup is reopened' in TESTS and 'selected mindset option must remain readable when reopening the list' in TESTS and 'find.byIcon(Icons.check_rounded)' in TESTS)
check('widget tests cover linked purple fill and return to neutral on unlink', 'same muted purple surface as saved trades' in TESTS and 'removing the no-entry reason must restore the accent only' in TESTS)
check('widget tests cover common selected-value size in mindset, anchor, confirmation, entry reason and entry conditions', all(x in TESTS for x in [
    'selected Mindset value must use the common 14.5dp data-item size',
    'Mindset popup rows must use the common 14.5dp menu-item size',
    'selected anchor labels use the agreed common 14.5dp size',
    'selected confirmation values must use the same size as Anchor values',
    'selected entry-reason text matches the anchor item size',
    'selected Bounce area values must use the same size as Anchor values',
    'selected Opposing signal values must use the same size as Anchor values',
]))
check('widget tests cover Arabic sign placement and common selected-value size', "signedResultDecoration.prefixText, 'USD'" in TESTS and "signedResultDecoration.suffix, isNotNull" in TESTS and 'selected anchor labels use the agreed common 14.5dp size' in TESTS and 'selected entry-reason text matches the anchor item size' in TESTS)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
