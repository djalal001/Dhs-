#!/usr/bin/env python3
"""Focused static regression checks for TraderDesk 1.7.94+150 UI fixes."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
PALETTE = (ROOT / "lib/theme/trade_detail_palette.dart").read_text(encoding="utf-8")
TESTS = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
DETAIL_TESTS = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
SAVED_FLOW_TESTS = (ROOT / "test/trades_screen_filter_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks = {
    "version is 1.7.94+150": "version: 1.7.94+150" in PUBSPEC,
    "workflow metadata is build 150": "TraderDesk 1.7.94+150" in WORKFLOW and "traderdesk-1.7.94-build150-arm64-v8a-release" in WORKFLOW,
    "semantic popup background is restored": "final dialogSurfaceColor = accentTone == null" in FORM and "Color.alphaBlend(" in FORM and "accentTone.withValues(alpha: isDark ? .14 : .08)" in FORM,
    "semantic popup border and divider are restored": "accentTone.withValues(alpha: isDark ? .17 : .13)" in FORM and "dialogBorderColor.withValues(alpha: .56)" in FORM,
    "ordinary trade-data popups keep the shared blue surface": "? tdPopupMenuColor(brightness)" in FORM and "color: tdPopupMenuColor(Theme.of(context).brightness)" in FORM,
    "popup selection checkmark removed": "Icons.check_rounded" not in FORM[FORM.index("Future<void> _showCompactPopupChoice"):FORM.index("BoxDecoration _selectedTradeDataValueDecoration")],
    "market/direction selection uses an in-field highlight": "final selectedValueKey = hasSelectedValue" in FORM and "key: ValueKey(selectedValueKey!)" in FORM and "_selectedTradeDataValueDecoration(tokens)" in FORM,
    "mindset selection uses an in-field highlight": "trade-mood-selected-value" in FORM and "_selectedTradeDataValueDecoration(" in FORM,
    "all options remain passed into showMenu": "for (final value in values)" in FORM and "value: value" in FORM,
    "practical opposing signal activates the shared muted purple field": "practicalNoEntrySetups.isNotEmpty" in FORM and "TradeDetailPalette.linkedEntryConditionsFieldDark" in FORM,
    "practical opposing signal uses the restrained violet field edge": "borderColorOverride: isPracticallyLinked" in FORM and "linkedEntryConditionsFieldEdge" in FORM,
    "field returns to neutral when practical link is removed": " : tokens.surface2;" in FORM and "fillColorOverride: entryConditionFieldFill" in FORM,
    "saved detail uses the same linked field palette": "TradeDetailPalette.linkedEntryConditionsFieldDark" in TRADES and "TradeDetailPalette.linkedEntryConditionsChipDark" in TRADES,
    "shared palette defines muted violet inner field": "linkedEntryConditionsFieldDark = Color(0xFF332D42)" in PALETTE,
    "widget tests cover readable reopened direction/mindset options": "selected direction must remain readable when the popup is reopened" in TESTS and "selected mindset option must remain readable when reopening the list" in TESTS,
    "widget tests cover popup mark removal": TESTS.count("find.byIcon(Icons.check_rounded)") >= 2,
    "widget tests cover purple field while linked": "same muted purple surface as saved trades" in TESTS,
    "saved trade tests assert linked purple field and chip": "TradeDetailPalette.linkedEntryConditionsFieldDark" in DETAIL_TESTS and "TradeDetailPalette.linkedEntryConditionsChipDark" in DETAIL_TESTS,
    "practical-link saved-flow test asserts the same purple inner field after saving": "practical opposing-signal marker keeps the same muted purple inner field after saving" in SAVED_FLOW_TESTS,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{sum(checks.values())}/{len(checks)} checks passed")
if not all(checks.values()):
    raise SystemExit(1)
