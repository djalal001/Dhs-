import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/screens/trades_screen.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/widgets/decision_option_emoji.dart';

void main() {
  testWidgets('trade review keeps decisions, commitment and no-entry grouped', (
    tester,
  ) async {
    final trade = Trade(
      id: 'review-test',
      accountId: 'account-test',
      market: 'US100',
      reason: 'RBS',
      result: 12,
      riskPercent: 1,
      side: TradeSide.buy,
      confirmation: 'Breakout–Pullback',
      sequence: '',
      mood: 'moodCalm',
      tradedAt: DateTime(2026, 11, 5, 11, 21),
      executionReviewKeys: const [
        'enteredEarly',
        'missedRbs',
        'missedTrendlineTouch3Buy',
        'stopLossIncreasedForLiquiditySafety',
        'noBreakoutPositiveClose',
        'fullPlanCompliance',
      ],
      noEntryReasons: const ['fearLossNoHistory', 'noEntryNearbyRejectionZone'],
    );

    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(Brightness.dark),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: Scaffold(
          body: ListView(children: [TradeBehaviorSummary(trade: trade)]),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('مراجعة الصفقة'), findsOneWidget);
    expect(find.text('القرارات'), findsOneWidget);
    expect(find.text('الالتزام'), findsOneWidget);
    expect(find.text('أسباب عدم الدخول'), findsOneWidget);
    expect(find.text('مخالفات'), findsOneWidget);
    expect(find.text('جودة تحليل'), findsOneWidget);
    expect(find.text('إدارة المخاطرة'), findsOneWidget);
    expect(find.text('دخول مبكر'), findsOneWidget);
    expect(find.text('RBS'), findsOneWidget);
    expect(find.text('Trendline Touch 3 Buy'), findsOneWidget);
    expect(find.text('لم أنتبه لوجود سيناريو'), findsOneWidget,
        reason: 'two analysis items read as a scenario sentence');
    // A key saved by an earlier version stays readable, in its own group.
    expect(find.text('الكسر والإغلاق الإيجابي ضعيفان'), findsOneWidget);
    expect(find.text('عناصر محفوظة من إصدار سابق'), findsOneWidget);
    expect(find.text('التزمت بالخطة كاملة.'), findsOneWidget);
    expect(find.text('خوف من الخسارة دون وجود ربح أو خسارة سابقة'), findsOneWidget);

    // No-entry reasons are split like the form: psychological · structural.
    expect(find.text('أسباب نفسية'), findsOneWidget);
    expect(find.text('أسباب هيكلية'), findsOneWidget);
    expect(find.text('وجود منطقة اعتراض قريبة من تأكيد دخول'), findsOneWidget);
    // …and carry no illustration any more.
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-review-option-tile-fearLossNoHistory')),
        matching: find.byType(TradeReviewOptionEmoji),
      ),
      findsNothing,
    );

    // Analysis quality: the sentence first, the chosen items below it as plain
    // text on one line (not boxed one per row).
    final inline = find.byKey(const ValueKey('trade-review-analysis-inline'));
    expect(inline, findsOneWidget);
    final sentenceRect = tester.getRect(find.text('لم أنتبه لوجود سيناريو'));
    final firstItemRect = tester.getRect(find.text('RBS'));
    final secondItemRect = tester.getRect(find.text('Trendline Touch 3 Buy'));
    expect(firstItemRect.top, greaterThanOrEqualTo(sentenceRect.bottom));
    expect(firstItemRect.center.dy, closeTo(secondItemRect.center.dy, 1));
    expect(
      find.byKey(const ValueKey('trade-review-option-tile-missedRbs')),
      findsNothing,
      reason: 'analysis items are inline text, not separate tiles',
    );
  });
}
