import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';

void main() {
  test('exit section title follows the result classification', () {
    expect(tradeExitSectionTitle(TradeClassification.win, arabic: true), 'أسباب الخروج');
    expect(tradeExitSectionTitle(TradeClassification.loss, arabic: true), 'أسباب الخروج');
    expect(tradeExitSectionTitle(TradeClassification.breakEven, arabic: true), 'قرار الاحتفاظ');
    expect(tradeExitSectionTitle(TradeClassification.missed, arabic: true), isNull);
    expect(tradeExitSectionTitle(null, arabic: true), isNull);
  });

  test('exit reason list holds the six abbreviations in table order', () {
    expect(
      tradeExitReasonOptions.map((o) => o.en).toList(),
      [
        'SBR - RBS',
        'RFS - SFR',
        'Trend Line Touch 3',
        'Trend Line Touch 3 Breakout',
        'Zone S/D',
        'HNS',
      ],
    );
  });

  test('exit reason labels resolve from the trade direction', () {
    String l(String k, TradeSide? s) =>
        tradeExitReasonLabel(k, arabic: false, side: s);
    expect(l('exitDirectionalSbrRbs', TradeSide.buy), 'SBR');
    expect(l('exitDirectionalSbrRbs', TradeSide.sell), 'RBS');
    expect(l('exitDirectionalRfsSfr', TradeSide.buy), 'SFR');
    expect(l('exitDirectionalRfsSfr', TradeSide.sell), 'RFS');
    expect(l('exitDirectionalTrendlineTouch3', TradeSide.buy),
        'Trend Line Touch 3 Sell');
    expect(l('exitDirectionalTrendlineTouch3', TradeSide.sell),
        'Trend Line Touch 3 Buy');
    expect(l('exitDirectionalTrendlineTouch3Breakout', TradeSide.buy),
        'Trend Line Touch 3 Sell Breakout');
    expect(l('exitDirectionalTrendlineTouch3Breakout', TradeSide.sell),
        'Trend Line Touch 3 Buy Breakout');
    expect(l('exitZoneSd', TradeSide.buy), 'Supply Zone');
    expect(l('exitZoneSd', TradeSide.sell), 'Demand Zone');
    expect(l('exitHns', TradeSide.buy), 'HNS');
    expect(l('exitDirectionalSbrRbs', null), 'SBR - RBS');
  });

  test('legacy exit keys stay readable and map to the new rows', () {
    expect(tradeExitReasonLabel('exitRbs', arabic: false, side: TradeSide.buy),
        'RBS');
    expect(tradeExitReasonSelectionKey('exitRbs'), 'exitDirectionalSbrRbs');
    expect(tradeExitReasonSelectionKey('exitSfr'), 'exitDirectionalRfsSfr');
    expect(tradeExitReasonSelectionKey('exitDemandZone'), 'exitZoneSd');
    expect(tradeExitReasonSelectionKey('exitTrendlineTouch3Buy'),
        'exitDirectionalTrendlineTouch3');
    expect(tradeExitReasonSelectionKey('exitTrendlineTouch3SellBreakout'),
        'exitDirectionalTrendlineTouch3Breakout');
  });

  test('exit reasons survive JSON round trip and default to empty', () {
    final trade = Trade(
      id: '1', accountId: 'a', market: 'NQ', reason: 'HNS', result: 10,
      riskPercent: 1, side: TradeSide.buy, confirmation: '', sequence: '',
      mood: 'moodUnknown', tradedAt: DateTime(2026, 1, 1),
      exitReasonSetups: const [
        TradeConfirmationSetup(type: 'exitHns', timeframe: '5MIN'),
      ],
    );
    final decoded = Trade.fromJson(trade.toJson());
    expect(decoded.exitReasonSetups, trade.exitReasonSetups);
    final legacy = Map<String, dynamic>.from(trade.toJson())..remove('exitReasonSetups');
    expect(Trade.fromJson(legacy).exitReasonSetups, isEmpty);
  });
}
