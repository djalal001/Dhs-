import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';

void main() {
  late Directory temp;
  late AppController controller;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_scope_');
    controller = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
  });

  tearDown(() async {
    controller.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('only the active tab scope rebuilds for data notifications', (
    tester,
  ) async {
    var activeBuilds = 0;
    var inactiveBuilds = 0;

    await tester.pumpWidget(
      AppScope(
        controller: controller,
        listen: false,
        child: MaterialApp(
          home: Column(
            children: [
              AppScope(
                controller: controller,
                listen: true,
                child: Builder(
                  builder: (context) {
                    AppScope.of(context);
                    activeBuilds++;
                    return const SizedBox.shrink();
                  },
                ),
              ),
              AppScope(
                controller: controller,
                listen: false,
                child: Builder(
                  builder: (context) {
                    AppScope.of(context);
                    inactiveBuilds++;
                    return const SizedBox.shrink();
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );

    expect(activeBuilds, 1);
    expect(inactiveBuilds, 1);

    await controller.setLanguage('en');
    await tester.pump();

    expect(activeBuilds, 2);
    expect(inactiveBuilds, 1);
    expect(tester.takeException(), isNull);
  });
}
