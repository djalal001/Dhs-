import 'package:flutter/widgets.dart';

import 'app_controller.dart';

/// Exposes the controller to a subtree and optionally subscribes that subtree
/// to data changes. AppShell enables the subscription only for the visible tab.
/// The root scope keeps access available to routes that are pushed above tabs
/// without causing every tab to rebuild for each persisted change.
class AppScope extends InheritedNotifier<AppController> {
  const AppScope({
    Key? key,
    required this.controller,
    required Widget child,
    bool listen = true,
  }) : super(
         key: key,
         child: child,
         notifier: listen ? controller : null,
       );

  final AppController controller;

  @override
  bool updateShouldNotify(covariant AppScope oldWidget) =>
      controller != oldWidget.controller || notifier != oldWidget.notifier;

  static AppController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found in widget tree');
    return scope!.controller;
  }
}
