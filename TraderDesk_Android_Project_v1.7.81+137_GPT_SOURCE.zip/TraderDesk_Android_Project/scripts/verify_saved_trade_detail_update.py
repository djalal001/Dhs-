#!/usr/bin/env python3
"""Static verification for saved-trade detail layout/text updates (1.7.81+137)."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
STRINGS = (ROOT / "lib/l10n/app_strings.dart").read_text(encoding="utf-8")
DETAIL_TEST = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
DAYS_TEST = (ROOT / "test/days_calendar_test.dart").read_text(encoding="utf-8")
APP_TEST = (ROOT / "test/trading_app_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []

# Anchor selections must use the same chip field implementation as entry reasons.
anchor_block = re.search(
    r"if \(selectedAnchors\.isNotEmpty\)\s*\{(?P<body>.*?)\n\s*\}\n\s*if \(confirmationLabels",
    TRADES,
    re.S,
)
checks.append(("saved anchor selection block exists", anchor_block is not None))
if anchor_block:
    body = anchor_block.group("body")
    checks.append(("anchors render through _TradeDetailChipField", "_TradeDetailChipField(" in body))
    checks.append(("each selected anchor is passed as an individual value", "values: selectedAnchors" in body))
    checks.append(("anchor uses the saved-data chip palette", "optionFill: TradeDetailPalette.dataChipDark" in body and "optionEdge: TradeDetailPalette.dataChipEdgeDark" in body))
    checks.append(("anchor no longer uses a joined row value", "selectedAnchors.join" not in body and "_TradeDetailRow(" not in body))

# Match the two top headings using equal label slots and equal top padding.
checks.append(("market/direction heading has stable 18px heading slot", "key: const ValueKey('trade-detail-market-direction-heading')" in TRADES and "SizedBox(\n            height: 18" in TRADES))
checks.append(("mindset heading has stable 18px heading slot", "key: const ValueKey('trade-detail-mindset-heading')" in TRADES and "SizedBox(\n            height: 18" in TRADES))
checks.append(("both paired fields use the same top padding", TRADES.count("EdgeInsetsDirectional.fromSTEB(9, 7, 9, 6)") >= 2))
checks.append(("both paired headings start at the top of their fields", TRADES.count("mainAxisAlignment: MainAxisAlignment.start") >= 2))

# Exact Arabic and English title translations.
required_strings = [
    "'result': 'ربح / خسارة'",
    "'riskPercent': 'المخاطرة'",
    "'rewardRisk': 'العائد / المخاطرة'",
    "'beforeImage': 'قبل الدخول'",
    "'afterImage': 'بعد الدخول'",
    "'confirmationImage': 'تأكيد الدخول'",
    "'result': 'Profit / Loss'",
    "'riskPercent': 'Risk'",
    "'rewardRisk': 'Return / Risk'",
    "'beforeImage': 'Before entry'",
    "'afterImage': 'After entry'",
    "'confirmationImage': 'Entry confirmation'",
]
for expected in required_strings:
    checks.append((f"translation present: {expected}", expected in STRINGS))

# Regression tests assert chip layout, heading alignment and new captions.
checks.append(("widget test verifies separate anchor chips", "find.text('Supply Zone 15MIN')" in DETAIL_TEST and "find.text('Demand Zone 4H')" in DETAIL_TEST))
checks.append(("widget test verifies anchor chip matches entry chip surface", "anchor choices must use the same chip surface as entry reasons" in DETAIL_TEST))
checks.append(("widget test verifies heading top alignment", "Market/direction and mindset headings must share the same top baseline" in DETAIL_TEST))
checks.append(("widget test verifies new result/risk titles", "find.text('ربح / خسارة')" in DETAIL_TEST and "find.text('العائد / المخاطرة')" in DETAIL_TEST))
checks.append(("calendar test verifies concise image captions", all(x in DAYS_TEST for x in ["find.text('قبل الدخول')", "find.text('بعد الدخول')", "find.text('تأكيد الدخول')"])))
checks.append(("app test uses the updated risk label", "find.text('المخاطرة')" in APP_TEST))

checks.append(("pubspec version is 1.7.81+137", "version: 1.7.81+137" in PUBSPEC))
checks.append(("GitHub Actions workflow version is 1.7.81+137", "TraderDesk 1.7.81+137" in WORKFLOW and "traderdesk-1.7.81-build137" in WORKFLOW))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed:", "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
