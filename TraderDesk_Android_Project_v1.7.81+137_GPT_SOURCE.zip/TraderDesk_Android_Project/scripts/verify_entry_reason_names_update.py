#!/usr/bin/env python3
"""Static regression checks for TraderDesk entry-reason names and Zone S/D mapping."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / 'lib/domain/trade_entry_catalog.dart').read_text(encoding='utf-8')
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
DAYS = (ROOT / 'lib/screens/days_screen.dart').read_text(encoding='utf-8')
CHIPS = (ROOT / 'lib/widgets/trade_entry_setup_chips.dart').read_text(encoding='utf-8')
CATALOG_TEST = (ROOT / 'test/trade_entry_catalog_test.dart').read_text(encoding='utf-8')
WIDGET_TEST = (ROOT / 'test/custom_confirmation_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

expected = {
    'Trend Line SELL': 'Trendline Sell 3 Touch',
    'Trend Line BUY': 'Trendline Buy 3 Touch',
    'Trend Line BREAKOUT SELL': 'Trend Line Touch 3 Sell Breakout',
    'Trend Line BREAKOUT BUY': 'Trend Line Touch 3 Buy Breakout',
}
for key, label in expected.items():
    check(f'catalog keeps legacy key {key}', f"'{key}'," in CATALOG)
    check(f'catalog shows new label {label}', label in CATALOG)
    check(f'formatter maps legacy {key}', f"case '{key}':" in CATALOG and f"return '{label}';" in CATALOG)

reason_block = CATALOG.split('const tradeEntryReasons', 1)[1].split('tradeEntryTouch2EligibleReasons', 1)[0]
check('direct entry-reason list contains Zone S/D', "TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D')" in reason_block)
check('direct entry-reason list no longer offers Supply Zone', "TradeEntryOption('Supply Zone'" not in reason_block)
check('Zone S/D maps BUY to Demand Zone', "if (side == TradeSide.buy) return 'Demand Zone';" in CATALOG)
check('Zone S/D maps SELL to Supply Zone', "if (side == TradeSide.sell) return 'Supply Zone';" in CATALOG)
check('legacy Supply Zone remains readable', "return reason;" in CATALOG and "base == 'Supply Zone'" in CATALOG)
check('legacy Supply Zone editing resolves to the new Zone S/D row', "tradeEntryReasonSelectionKey(currentBase)" in FORM and "return 'zoneSd';" in CATALOG)

check('add-timeframe context uses the formatted reason', "formatTradeEntryReasonLabel(reason: reason, side: _side)" in FORM)
check('edit-timeframe context uses the formatted reason', FORM.count("formatTradeEntryReasonLabel(reason: reason, side: _side)") >= 2)
check('selected-entry field displays the formatted reason', "label: formatTradeEntryReasonLabel(" in FORM)
check('saved trade detail labels use trade direction', "formatTradeEntryReasonLabel(" in TRADES and "side: trade.side" in TRADES)
check('saved trade cards pass direction to entry chips', TRADES.count('side: trade.side') >= 2)
check('entry chips format labels with the saved direction', "formatTradeEntryReasonLabel(" in CHIPS and "final TradeSide side;" in CHIPS)
check('day-summary labels use the direction-aware formatter', "_dayEntryReasonSummary" in DAYS and "formatTradeEntryReasonLabel(" in DAYS)

check('catalog unit tests cover all revised Trendline labels', all(label in CATALOG_TEST for label in expected.values()))
check('catalog unit tests cover Zone S/D BUY and SELL output', all(x in CATALOG_TEST for x in ["reason: 'zoneSd', side: TradeSide.buy", "'Demand Zone'", "reason: 'zoneSd', side: TradeSide.sell", "'Supply Zone'"]))
check('widget test covers Zone S/D selection and dynamic direction mapping', all(x in WIDGET_TEST for x in ["find.text('Zone S/D')", "find.text('Demand Zone 15MIN')", "find.text('Supply Zone 15MIN')", "trade-direction-option-sell"]))
check('widget test saves semantic Zone S/D key', "TradeEntrySetup(reason: 'zoneSd', timeframe: '15MIN')" in WIDGET_TEST)

check('pubspec version is 1.7.81+137', 'version: 1.7.81+137' in PUBSPEC)
check('workflow metadata is 1.7.81+137', 'TraderDesk 1.7.81+137' in WORKFLOW and 'traderdesk-1.7.81-build137-arm64-v8a-release' in WORKFLOW and 'traderdesk-1.7.81-build137-arm64-dart-symbols' in WORKFLOW)
check('release notes describe all new entry reason names', all(label in RELEASE for label in expected.values()) and 'Zone S/D' in RELEASE)
check('build info identifies the exact 1.7.78+134 source', 'TraderDesk_Android_Project_v1.7.78+134_GPT_SOURCE.zip' in BUILD_INFO)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
