# تعليمات البناء الإلزامية

هذا المشروع مخصص لإنتاج APK واحدة لمعمارية الهواتف الحديثة `arm64-v8a` فقط.

## الأمر المفضل

```bash
flutter pub get
flutter build apk --release --target-platform android-arm64
```

## حماية داخل المشروع

تم وضع القيد داخل `android/app/build.gradle.kts` عبر استبعاد مكتبات المعماريات الأخرى من تغليف JNI:

```kotlin
excludes += setOf("lib/armeabi-v7a/**", "lib/x86_64/**")
```

لذلك حتى عند استخدام الأمر العام التالي:

```bash
flutter build apk --release
```

لن تُضمّن APK معماريات `armeabi-v7a` أو `x86_64`.

لا تستخدم `flutter build apk` بدون `--release`، ولا تجمع ملفات البناء أو مجلد المشروع بدل تسليم ملف `app-release.apk`. الناتج الصحيح هو APK Release واحدة، وقد أثبت الاختبار أن حجمها 24.5MB وتحتوي `arm64-v8a` فقط.
