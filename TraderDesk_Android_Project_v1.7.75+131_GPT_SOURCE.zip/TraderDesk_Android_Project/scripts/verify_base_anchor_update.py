#!/usr/bin/env python3
"""Static contract checks for TraderDesk 1.7.75+131 Base anchor update."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
MODEL = (ROOT / "lib/models/trade.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
WIDGET_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

# One Base option only; all existing anchor choices stay present.
anchor_block = CATALOG.split("const tradeAnchorOptions", 1)[1].split("const tradeMoodOptions", 1)[0]
base_lines = [line for line in anchor_block.splitlines() if "TradeEntryOption('base'" in line]
check("anchor catalog contains exactly one Base option", len(base_lines) == 1)
check("Base is presented as Base in both locales", "TradeEntryOption('base', 'Base', 'Base')" in anchor_block)
check("the five existing anchors remain unchanged", all(key in anchor_block for key in ["'keyLevel'", "'supplyZone'", "'demandZone'", "'bullishEngulfing'", "'bearishEngulfing'"]))

# Both initial selection paths and subsequent edit use the dynamic title helper.
helper = FORM.split("String _anchorTimeframeDialogTitle", 1)[1].split("Future<void> _pickAnchors", 1)[0]
check("Base Buy Arabic title is exact", "'فريم Base Buy'" in helper)
check("Base Sell Arabic title is exact", "'فريم Base Sell'" in helper)
check("English direction-aware titles are provided", "'Base Buy timeframe'" in helper and "'Base Sell timeframe'" in helper)
check("the direction is read from the actual selected TradeSide", "TradeSide.buy" in helper and "TradeSide.sell" in helper and "_side" in helper)
anchor_flow = FORM.split("Future<void> _pickAnchors", 1)[1].split("void _removeAnchor", 1)[0]
check("new and legacy-missing Base selections both call the shared title helper", anchor_flow.count("_anchorTimeframeDialogTitle(") >= 2)
check("editing Base timeframe also calls the shared title helper", "title: _anchorTimeframeDialogTitle(anchorKey)" in anchor_flow)

# Existing UI and data model remain in use.
check("timeframe choices remain the existing eight-frame catalog", "tradeEntryTimeframes" in CATALOG and "['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H']" in CATALOG)
check("the original centered choice dialog and row ListTile rendering remain", "_showCenteredTradeChoiceDialog<String>(" in FORM and "ListTile(" in FORM and "centered: true" in anchor_flow)
check("anchor/timeframe pairs continue using the existing map", "final Map<String, String> anchorTimeframes" in MODEL and "'anchorTimeframes': anchorTimeframes" in MODEL and "_anchorTimeframes[option.key] = timeframe" in FORM)
check("saved trade details still resolve anchor label and timeframe from catalog/map", "tradeAnchorOptions" in TRADES and "trade.anchorTimeframes[key]" in TRADES)
check("widget test covers Base Buy and Base Sell title behavior", "فريم Base Buy" in WIDGET_TEST and "فريم Base Sell" in WIDGET_TEST)
check("widget test covers saved Base timeframe value", "'base': '4H'" in WIDGET_TEST and "Base 4H" in WIDGET_TEST)
check("catalog test asserts Base and six unique options", "Base" in CATALOG_TEST and "toSet().length, 6" in CATALOG_TEST)
check("Base key and timeframe are tested through JSON round-trip", "Base anchor and timeframe round-trip" in CATALOG_TEST and "Trade.fromJson(original.toJson())" in CATALOG_TEST)

# Release metadata.
check("pubspec version is 1.7.75+131", "version: 1.7.75+131" in PUBSPEC)
check("workflow name matches 1.7.75+131", "TraderDesk 1.7.75+131" in WORKFLOW)
check("release artifact IDs match build 131", "traderdesk-1.7.75-build131-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.75-build131-arm64-dart-symbols" in WORKFLOW)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
