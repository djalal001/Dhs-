#!/usr/bin/env python3
"""Static verification for the TraderDesk Noto typography migration."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBSPEC = ROOT / "pubspec.yaml"
THEME = ROOT / "lib/theme/app_theme.dart"

required_fonts = {
    "NotoSansArabicUI-Regular.ttf",
    "NotoSansArabicUI-Bold.ttf",
    "NotoSans-Regular.ttf",
    "NotoSans-Medium.ttf",
    "NotoSans-SemiBold.ttf",
    "NotoSans-Bold.ttf",
}

pubspec = PUBSPEC.read_text(encoding="utf-8")
theme = THEME.read_text(encoding="utf-8")
all_dart = "\n".join(
    path.read_text(encoding="utf-8")
    for path in (ROOT / "lib").rglob("*.dart")
)

checks: list[tuple[str, bool]] = []
checks.append(("pubspec registers NotoSansArabicUI", "family: NotoSansArabicUI" in pubspec))
checks.append(("pubspec registers NotoSans fallback", "family: NotoSans" in pubspec))
checks.append(("theme primary family is NotoSansArabicUI", "_appFontFamily = 'NotoSansArabicUI'" in theme))
checks.append(("theme fallback family is NotoSans", "_appFontFamilyFallback = ['NotoSans']" in theme))
checks.append(("TextTheme.apply uses primary and fallback families", "fontFamily: _appFontFamily" in theme and "fontFamilyFallback: _appFontFamilyFallback" in theme))
checks.append(("ThemeData uses primary and fallback families", theme.count("fontFamily: _appFontFamily") >= 2 and theme.count("fontFamilyFallback: _appFontFamilyFallback") >= 2))
checks.append(("no active IBM Plex family remains in app source", "IBMPlexSansArabic" not in pubspec + all_dart))
checks.append(("workflow release metadata matches 1.7.75+131", "1.7.75+131" in (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")))
font_assignments = []
for path in (ROOT / "lib").rglob("*.dart"):
    content = path.read_text(encoding="utf-8")
    font_assignments.extend((path.relative_to(ROOT).as_posix(), value.strip()) for value in re.findall(r"\bfontFamily\s*:\s*([^,]+)", content))
checks.append(("all explicit app font assignments are centralized in the theme", len(font_assignments) == 2 and all(path == "lib/theme/app_theme.dart" and value == "_appFontFamily" for path, value in font_assignments)))

for filename in sorted(required_fonts):
    path = ROOT / "assets/fonts" / filename
    checks.append((f"font asset exists: {filename}", path.is_file() and path.stat().st_size > 100_000))

checks.append(("SIL OFL notice included and declared as an asset", "SIL Open Font License" in (ROOT / "assets/fonts/NOTO_FONTS_OFL_LICENSE.txt").read_text(encoding="utf-8") and "assets/fonts/NOTO_FONTS_OFL_LICENSE.txt" in (ROOT / "pubspec.yaml").read_text(encoding="utf-8")))
checks.append(("legacy IBM font assets and license removed", not any((ROOT / "assets/fonts").glob("IBMPlexSansArabic-*.ttf")) and not (ROOT / "assets/fonts/OFL.txt").exists()))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks:", "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)

# FontTools is available in the authoring environment; verify glyph coverage.
try:
    from fontTools.ttLib import TTFont  # type: ignore
except ImportError:
    print("SKIP: fontTools not installed; glyph cmap check not run")
else:
    def codepoints(font_path: Path) -> set[int]:
        font = TTFont(str(font_path))
        result: set[int] = set()
        for table in font["cmap"].tables:
            result.update(table.cmap.keys())
        return result

    arabic = codepoints(ROOT / "assets/fonts/NotoSansArabicUI-Regular.ttf")
    latin = codepoints(ROOT / "assets/fonts/NotoSans-Regular.ttf")
    arabic_sample = "الصفقة"
    latin_sample = "BUY SELL NQ SBR 123"
    arabic_ok = all(ord(char) in arabic for char in arabic_sample)
    latin_ok = all(ord(char) in latin for char in latin_sample)
    print(f"{'PASS' if arabic_ok else 'FAIL'}: Arabic glyph coverage sample")
    print(f"{'PASS' if latin_ok else 'FAIL'}: Latin/digit glyph coverage sample")
    if not arabic_ok or not latin_ok:
        raise SystemExit(1)
