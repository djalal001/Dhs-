# متابعة المشروع الحالي — TraderDesk 1.7.4+60

رقم الإصدار الحالي `1.7.4+60`. يعتمد المشروع على Flutter، ويستخدم لوحة ألوان موحدة للوضعين الداكن والفاتح مع درجات دلالية متناسقة عبر نموذج الصفقة وتفاصيلها ومراجعة القرارات والالتزام وأسباب عدم الدخول ولوحات الأداء والتقويم.

- شاشة إدخال الصفقة: `lib/screens/trade_form_screen.dart`.
- كتالوج أسباب الدخول والتأكيدات والتصرفات: `lib/domain/trade_entry_catalog.dart`.
- نموذج البيانات: `lib/models/trade.dart`.
- التخزين والنسخ الاحتياطي: `lib/data/local_store.dart` و`lib/data/streaming_backup_decoder.dart`.
- إصلاحات ثبات التخزين: `lib/state/app_controller.dart`، واختبارها في `test/app_controller_storage_failure_test.dart`.
- رسومات مراجعة الصفقة الـ25 (قرارات/التزام/عدم دخول): `lib/widgets/decision_option_emoji.dart` و`assets/emojis/decisions/` و`assets/emojis/commitment/` و`assets/emojis/no_entry/`.
- تفاصيل النسخة: `RELEASE_NOTES_AR.md` و`BUILD_INFO_AR.md`.
- تقرير التحقق وما لم يمكن تشغيله: `QA_REPORT_AR.md`.

حافظ على قراءة بيانات JSON السابقة؛ لا تحذف أو تعِد تسمية حقول `executionJournal` و`sequence` و`notes` دون ترحيل صريح. قبل بناء APK على جهاز تطوير مجهز، شغّل `flutter pub get` ثم `flutter analyze` و`flutter test`، وبعد معالجة أي نتائج ابنِ النسخة الوحيدة المعتمدة بالأمر `flutter build apk --release --target-platform android-arm64` ثم تحقق منها عبر `bash scripts/verify_arm64_apk.sh build/app/outputs/flutter-apk/app-release.apk`. لا تستخدم `--split-per-abi` أو `--splits-per-abi`. اختبار الحمولة الكبيرة اختياري ويتطلب `TRADERDESK_LARGE_BACKUP`. إعداد توقيع Android الحالي يستخدم debug للتجارب فقط ويجب استبداله بتوقيع إصدار خاص قبل التوزيع.
