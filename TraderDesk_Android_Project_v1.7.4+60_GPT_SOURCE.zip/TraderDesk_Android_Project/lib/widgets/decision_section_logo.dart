import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// The exact Decisions mark from TraderDesk_Decisions_Logo_Concept.html,
/// recreated as a small vector painter for crisp rendering at any size.
class DecisionSectionLogo extends StatelessWidget {
  const DecisionSectionLogo({
    super.key,
    this.size = 26,
    this.label = 'Decisions logo',
  });

  final double size;
  final String label;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final accent = tokens.decisionTone;
    return Semantics(
      image: true,
      label: label,
      child: SizedBox.square(
        dimension: size,
        child: CustomPaint(
          painter: _DecisionSectionLogoPainter(
            accent: accent,
            metalLight: Color.lerp(accent, tokens.text1, .48)!,
            metalDeep: accent,
            tileTop: tokens.surface3,
            tileBottom: tokens.surface1,
            nodeFill: tokens.surface2,
            diamondFill: Color.alphaBlend(
              accent.withValues(alpha: .12),
              tokens.surface2,
            ),
            checkColor: tokens.text1,
          ),
        ),
      ),
    );
  }
}

class _DecisionSectionLogoPainter extends CustomPainter {
  const _DecisionSectionLogoPainter({
    required this.accent,
    required this.metalLight,
    required this.metalDeep,
    required this.tileTop,
    required this.tileBottom,
    required this.nodeFill,
    required this.diamondFill,
    required this.checkColor,
  });

  final Color accent;
  final Color metalLight;
  final Color metalDeep;
  final Color tileTop;
  final Color tileBottom;
  final Color nodeFill;
  final Color diamondFill;
  final Color checkColor;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 80, size.height / 80);

    final tileRect = RRect.fromLTRBR(
      5.5,
      5.5,
      74.5,
      74.5,
      const Radius.circular(19),
    );
    canvas.drawRRect(
      tileRect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment(-1.0, -1.0),
          end: Alignment(1.0, 1.0),
          colors: [tileTop, tileBottom],
        ).createShader(const Rect.fromLTWH(10, 8, 58, 64)),
    );
    canvas.drawRRect(
      tileRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = accent.withValues(alpha: .48),
    );

    final metalShader = LinearGradient(
      begin: Alignment(-1, -1),
      end: Alignment(1, 1),
      colors: [metalLight, metalDeep],
    ).createShader(const Rect.fromLTWH(17, 14, 45, 48));

    final stem = Path()
      ..moveTo(40, 63)
      ..lineTo(40, 51);
    canvas.drawPath(
      stem,
      Paint()
        ..shader = metalShader
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawCircle(const Offset(40, 64), 3.1, Paint()..color = accent);

    final branches = Path()
      ..moveTo(29, 33)
      ..cubicTo(23, 30, 19.5, 25.8, 17.8, 19.5)
      ..moveTo(51, 33)
      ..cubicTo(57, 30, 60.5, 25.8, 62.2, 19.5)
      ..moveTo(40, 25)
      ..lineTo(40, 15.5);
    canvas.drawPath(
      branches,
      Paint()
        ..color = accent.withValues(alpha: .78)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round,
    );

    final nodePaint = Paint()
      ..color = nodeFill
      ..style = PaintingStyle.fill;
    final nodeBorder = Paint()
      ..color = accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    for (final center in const [Offset(17, 16), Offset(63, 16)]) {
      canvas.drawCircle(center, 3.25, nodePaint);
      canvas.drawCircle(center, 3.25, nodeBorder);
    }
    canvas.drawCircle(
      const Offset(40, 13),
      3.1,
      Paint()..color = metalLight,
    );

    final diamond = Path()
      ..moveTo(40, 24)
      ..lineTo(52, 36.5)
      ..lineTo(40, 49)
      ..lineTo(28, 36.5)
      ..close();
    canvas.drawPath(diamond, Paint()..color = diamondFill);
    canvas.drawPath(
      diamond,
      Paint()
        ..shader = metalShader
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.35
        ..strokeJoin = StrokeJoin.round,
    );

    final check = Path()
      ..moveTo(34.7, 36.6)
      ..lineTo(38.5, 40.2)
      ..lineTo(45.6, 32.9);
    canvas.drawPath(
      check,
      Paint()
        ..color = checkColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.45
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );

    final fineDetails = Path()
      ..moveTo(12, 58.5)
      ..lineTo(16, 58.5)
      ..moveTo(64, 58.5)
      ..lineTo(68, 58.5);
    canvas.drawPath(
      fineDetails,
      Paint()
        ..color = accent.withValues(alpha: .42)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..strokeCap = StrokeCap.round,
    );

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _DecisionSectionLogoPainter oldDelegate) =>
      accent != oldDelegate.accent ||
      metalLight != oldDelegate.metalLight ||
      metalDeep != oldDelegate.metalDeep ||
      tileTop != oldDelegate.tileTop ||
      tileBottom != oldDelegate.tileBottom ||
      nodeFill != oldDelegate.nodeFill ||
      diamondFill != oldDelegate.diamondFill ||
      checkColor != oldDelegate.checkColor;
}
