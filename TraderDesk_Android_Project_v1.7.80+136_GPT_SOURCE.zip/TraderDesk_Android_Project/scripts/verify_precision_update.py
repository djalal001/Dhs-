#!/usr/bin/env python3
"""Static regression checks for the requested TraderDesk 1.7.80+136 refinements."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
ANCHOR_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
TOUCH_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
DETAIL_TEST = (ROOT / "test/trade_detail_layout_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(label: str, ok: bool) -> None:
    checks.append((label, bool(ok)))

# 1. The Arabic text changed, while the stable storage key is unchanged.
check("repeat-loss reason has the requested Arabic wording", "TradeEntryOption('fearRepeatLossAfterLoss', 'الخوف من تكرار الخسارة بعد خسارة سابقة'" in CATALOG)
check("old repeat-loss wording is absent from the active catalog", "الخوف من تكرار خسارة سابقة." not in CATALOG)
check("repeat-loss reason retains its existing key", "'fearRepeatLossAfterLoss'" in CATALOG and "key == 'fearRepeatLossAfterLoss'" in CATALOG_TEST)

# 2. Exactly 15 decision items + 5 commitment items, with no terminal periods.
def section(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[1].split(end, 1)[0]

review = section(CATALOG, "const tradeReviewGroups", "const tradeCommitmentOptions")
commitment = section(CATALOG, "const tradeCommitmentOptions", "const tradeNoEntryOptions")
behavior_items = re.findall(r"TradeEntryOption\([^\n]*\)", review + commitment)
check("behavior catalog contains exactly 20 options", len(behavior_items) == 20)
terminal_periods = []
for index, item in enumerate(behavior_items, start=1):
    labels = re.findall(r"'((?:[^'\\]|\\.)*)'", item)
    if len(labels) >= 3:
        for label in labels[1:3]:
            if label.endswith("."):
                terminal_periods.append((index, label))
    else:
        terminal_periods.append((index, "unparsed label"))
check("all Arabic and English behavior labels omit terminal periods", not terminal_periods)
check("catalog test asserts count and both locale endings", "hasLength(20)" in CATALOG_TEST and "option.ar.endsWith('.')" in CATALOG_TEST and "option.en.endsWith('.')" in CATALOG_TEST)

# 3. Keep the two card headings and values, but no heading icon arguments.
conditions_card = section(TRADES, "key: const ValueKey('trade-detail-entry-conditions-panel')", "if (trade.executionJournal.isNotEmpty)")
reverse_field = section(conditions_card, "key: const ValueKey('trade-detail-reverse-signals')", "if (reverseSignalLabels.isNotEmpty && bounceZoneLabels.isNotEmpty)")
bounce_field = section(conditions_card, "key: const ValueKey('trade-detail-bounce-zone')", "if (trade.executionJournal.isNotEmpty)")
check("saved-card headings and values remain", "إشارات عكسية" in reverse_field and "منطقة الارتداد" in bounce_field and "values: reverseSignalLabels" in reverse_field and "values: bounceZoneLabels" in bounce_field)
check("saved-card opposing-signal and bounce fields omit decorative icons", "icon:" not in reverse_field and "icon:" not in bounce_field)
check("widget tests assert no icons in either saved field", "saved opposing-signals field should not show a decorative logo" in DETAIL_TEST and "saved bounce-area field should not show a decorative logo" in DETAIL_TEST)

# 4. SBR/RBS keeps the existing Trade Details copy; Bounce S/R uses the exact
# requested English qualifier and concise Arabic continuation label.
touch_sheet = section(FORM, "Future<bool?> _showTouch2Sheet", "Future<String?> _showEntryReasonSheet")
check("SBR/RBS invokes the existing compact Touch 2 wording", "compactLabels: true" in FORM)
check("SBR/RBS retains Touch 2 while continuation copy is concise", "_copy('Touch 2', 'Touch 2')" in touch_sheet and "_copy('متابعة', 'Continue')" in touch_sheet)
check("Bounce S/R uses the exact 2 Touch label", "label: baseReason == 'bounceFromSrZone'\n              ? '2 Touch'" in touch_sheet)
check("Bounce S/R no longer presents the long Arabic continuation phrase", "'تجاوزها والمتابعة إلى الفريم الزمني'" not in touch_sheet)
check("SBR/RBS tests preserve its Trade Details wording", "find.text('Touch 2')" in TOUCH_TEST and "find.text('متابعة')" in TOUCH_TEST)
check("Bounce S/R widget test asserts 2 Touch and متابعة", "find.text('2 Touch'), findsOneWidget" in ANCHOR_TEST and "find.text('متابعة'), findsOneWidget" in ANCHOR_TEST)
check("Bounce S/R widget test rejects old text", "find.text('لمسة 2'), findsNothing" in ANCHOR_TEST and "find.text('تجاوزها والمتابعة إلى الفريم الزمني'), findsNothing" in ANCHOR_TEST)
check("Bounce S/R detail list inherits the category accent", "accentTone: accentTone" in touch_sheet and "accentTone: choiceTone" in FORM[FORM.index("if (optionKey == 'bounceFromSrZone')"):FORM.index("final selectedOption = options")])
check("Bounce S/R tests compare detail and timeframe dialog colors", "srTouch2Background" in ANCHOR_TEST and "same color" in ANCHOR_TEST)

# 5. Anchor picker follows the restrained entry-reason list markers without changing multi-select.
anchor_picker = section(FORM, "Future<void> _pickAnchors()", "Future<void> _editAnchorTimeframe")
check("anchor selected rows use circular check markers", "Icons.check_circle_rounded" in anchor_picker)
check("anchor unselected rows use chevrons", "Icons.chevron_left_rounded" in anchor_picker)
check("anchor picker no longer uses checkbox-square icons", "check_box_" not in anchor_picker)
check("anchor still opens a timeframe picker per selected option", "_showTimeframeSheet(" in anchor_picker and "_anchorTimeframes[option.key] = timeframe" in anchor_picker)
check("anchor test covers both marker states", "Icons.check_circle_rounded" in ANCHOR_TEST and "Icons.chevron_left_rounded" in ANCHOR_TEST)

# Release metadata.
check("pubspec release is 1.7.80+136", "version: 1.7.80+136" in PUBSPEC)
check("GitHub workflow artifact names are 1.7.80 build 136", "TraderDesk 1.7.80+136" in WORKFLOW and "traderdesk-1.7.80-build136" in WORKFLOW)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed), file=sys.stderr)
    if terminal_periods:
        print("Terminal periods found:", terminal_periods, file=sys.stderr)
    raise SystemExit(1)
