# تقرير إصلاح سير عمل GitHub Actions — TraderDesk 1.7.120+176

## المصدر والفحص
- المصدر المباشر: `TraderDesk_Android_Project_v1_7_119_175_GPT_SOURCE.zip`، الإصدار `1.7.119+175`.
- رسالة GitHub Actions أشارت إلى `.github/workflows/release-arm64.yml` والسطر 102.
- **نتيجة فحص المصدر المرفق:** لم يكن ملف `release-arm64.yml` موجوداً داخل أرشيف 1.7.119+175. كان الملف الموجود الوحيد داخل `.github/workflows/` هو `android-build.yml`، وكان طوله 88 سطراً. لذلك لا يمكن إثبات محتوى السطر 102 أو تحديد العبارة النصية التي سببت خطأ YAML في النسخة الموجودة على GitHub؛ فهي ليست ضمن المصدر المرفق.
- بدلاً من اختراع تصحيح لسطر غير متاح، أُنشئ ملف بديل كامل وصالح للمسار نفسه `.github/workflows/release-arm64.yml` اعتماداً على خطوات ARM64 الموجودة فعلياً في `android-build.yml` السابق.

## ما تم تغييره
1. إضافة `.github/workflows/release-arm64.yml` كسير عمل reusable عبر `workflow_call`، وقابل للتشغيل اليدوي عبر `workflow_dispatch`.
2. تحويل `.github/workflows/android-build.yml` إلى مشغّل واحد يستدعي سير العمل القابل لإعادة الاستخدام؛ وبذلك لا تتكرر عملية البناء على push أو tag.
3. تحديث أسماء ملفات Artifacts لتعكس `1.7.120` وBuild `176`.
4. تحديث `pubspec.yaml` و`BUILD_INFO_AR.md` و`RELEASE_NOTES_AR.md`.
5. تحديث فاحص الانحدار `scripts/verify_guided_trade_entry_reliability_update.py` ليتحقق من الإصدار الحالي وسير العمل القابل لإعادة الاستخدام بدلاً من توقع الصيغة السابقة.
6. لم تتغير شيفرة التطبيق أو موارد التطبيق أو إعدادات Gradle أو `scripts/build_release_apk.sh`.

## نتائج التحقق الفعلية
- جميع ملفات YAML في المشروع أمكن تحليلها باستخدام PyYAML 6.0.3 دون أخطاء صياغة.
- تم التحقق من وجود trigger `workflow_call` في `release-arm64.yml` ومن تطابق مسار الاستدعاء المحلي في `android-build.yml` مع الملف الفعلي.
- تم التحقق من وجود خطوات checkout وJava 21 وFlutter pinned وARM64 build والتحقق ورفع artifact ونشر Release tag.
- `bash -n scripts/build_release_apk.sh`: ناجح.
- فاحص تدفق الإدخال والانحدار المحدّث: **30/30 ناجح**.
- تم التحقق من رقم الإصدار `1.7.120+176` في `pubspec.yaml` وبيانات البناء.
- تم فتح أرشيف ZIP النهائي واختبار سلامته وفحص وجود ملفي workflow داخله.

## حدود التحقق
- لم يتوفر `actionlint` أو GitHub-hosted runner في بيئة التنفيذ؛ لذا لم يتم تنفيذ GitHub Actions فعلياً.
- لم يُنفّذ بناء APK في هذه البيئة. صحة صياغة YAML والتحقق البنيوي لا يثبتان اكتمال البناء على GitHub، لكنهما يمنعان إعادة إرسال الملف المفقود أو YAML غير القابل للتحليل.
