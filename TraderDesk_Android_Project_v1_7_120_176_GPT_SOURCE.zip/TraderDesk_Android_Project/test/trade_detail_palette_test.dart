import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/theme/trade_detail_palette.dart';

void main() {
  test('trade-data popup border uses the approved muted outline', () {
    expect(tdTradeDataPopupMenuBorderColor(Brightness.dark), const Color(0xFF294055));
    expect(tdTradeDataPopupMenuBorderColor(Brightness.light), const Color(0xFFC7D1DC));
    final shape = tdTradeDataPopupMenuShape(Brightness.dark) as RoundedRectangleBorder;
    expect(shape.side.color, const Color(0xFF294055));
    expect(shape.side.width, .8);
    // Menus outside the Trade Data form retain the original app-wide outline.
    expect(tdPopupMenuBorderColor(Brightness.dark), const Color(0xFF315C8C));
    final legacyShape = tdPopupMenuShape(Brightness.dark) as RoundedRectangleBorder;
    expect(legacyShape.side.color, const Color(0xFF315C8C));
    expect(legacyShape.side.width, .85);
  });

  test(
    'Model 4 dark palette preserves light mode',
    () {
      expect(
        TradeDetailPalette.dataLabelTone(Brightness.dark),
        const Color(0xFFA8B8C9),
      );
      expect(
        TradeDetailPalette.dataLabelTone(Brightness.light),
        const Color(0xFF355F86),
      );
      expect(
        TradeDetailPalette.dataToneFor(Brightness.dark),
        const Color(0xFF76AEE8),
      );
      expect(
        TradeDetailPalette.dataToneFor(Brightness.light),
        const Color(0xFF8AB4D9),
      );
      final foregroundLuminance = const Color(0xFFA8B8C9).computeLuminance();
      expect(
        TradeDetailPalette.dataValueTone(Brightness.dark),
        const Color(0xFFE7EDF4),
      );
      expect(TradeDetailPalette.dataValueTone(Brightness.light), isNull);
      final backgroundLuminance = const Color(0xFF142A46).computeLuminance();
      final lighter = foregroundLuminance > backgroundLuminance
          ? foregroundLuminance
          : backgroundLuminance;
      final darker = foregroundLuminance > backgroundLuminance
          ? backgroundLuminance
          : foregroundLuminance;
      expect((lighter + .05) / (darker + .05), greaterThan(7.0));

      final chipForeground = const Color(0xFFE7EDF4).computeLuminance();
      final chipBackground = const Color(0xFF19314E).computeLuminance();
      final chipLighter = chipForeground > chipBackground
          ? chipForeground
          : chipBackground;
      final chipDarker = chipForeground > chipBackground
          ? chipBackground
          : chipForeground;
      expect((chipLighter + .05) / (chipDarker + .05), greaterThan(7.0));

      final cardLuminance = const Color(0xFF172E4D).computeLuminance();
      final fieldLuminance = const Color(0xFF142A46).computeLuminance();
      final chipLuminance = const Color(0xFF19314E).computeLuminance();
      expect((cardLuminance - fieldLuminance).abs(), greaterThan(0.004));
      expect((cardLuminance - fieldLuminance).abs(), lessThan(0.005));
      expect((fieldLuminance - chipLuminance).abs(), greaterThan(0.006));
      expect((fieldLuminance - chipLuminance).abs(), lessThan(0.008));
    },
  );

  test('saved trade data panel uses the exact approved Model 4 surfaces', () {
    expect(TradeDetailPalette.dataSurfaceDark, const Color(0xFF172E4D));
    expect(TradeDetailPalette.dataPanelBorderDark, const Color(0xFF29415E));
    expect(TradeDetailPalette.dataPanelIconSurfaceDark, const Color(0xFF203D60));
    expect(TradeDetailPalette.dataFieldDark, const Color(0xFF142A46));
    expect(TradeDetailPalette.dataFieldEdgeDark, const Color(0xFF142A46));
    expect(TradeDetailPalette.dataChipDark, const Color(0xFF19314E));
    expect(TradeDetailPalette.dataChipEdgeDark, const Color(0xFF19314E));
    expect(TradeDetailPalette.dataValueToneDark, const Color(0xFFE7EDF4));
  });

  test('add-trade navigation reuses the saved detail card surfaces', () {
    expect(
      TradeDetailPalette.dataSurfaceDark,
      const Color(0xFF172E4D),
    );
    expect(
      TradeDetailPalette.entryConditionsPanelDark,
      const Color(0xFF1B3542),
    );
    expect(
      TradeDetailPalette.reviewOuterDark,
      const Color(0xFF292B36),
    );
  });

  test('behavior subsection surfaces reuse saved review colors in both themes', () {
    expect(TradeDetailPalette.reviewDecisionDark, const Color(0xFF242526));
    expect(TradeDetailPalette.reviewCommitmentDark, const Color(0xFF172F2F));
    expect(TradeDetailPalette.reviewNoEntryDark, const Color(0xFF2A2635));
    expect(TradeDetailPalette.reviewDecisionLight, const Color(0xFFFAF5EF));
    expect(TradeDetailPalette.reviewCommitmentLight, const Color(0xFFF0F8F4));
    expect(TradeDetailPalette.reviewNoEntryLight, const Color(0xFFF6F1FC));
  });

  test('saved Entry Conditions keeps its surfaces with softer outlines', () {
    expect(
      TradeDetailPalette.entryConditionsFieldDark,
      const Color(0xFF243140),
    );
    expect(
      TradeDetailPalette.entryConditionsFieldEdge,
      const Color(0xFF344653),
    );
    expect(
      TradeDetailPalette.linkedEntryConditionsFieldEdge,
      const Color(0xFF453B56),
    );
    expect(
      TradeDetailPalette.linkedEntryConditionsPanelBorderDark,
      const Color(0xFF4B425B),
    );
    expect(
      TradeDetailPalette.linkedEntryConditionsPanelDividerDark,
      const Color(0xFF41384F),
    );
  });

  test('trade review panel preserves the original 1.7.17+73 colors', () {
    expect(TradeDetailPalette.reviewTone, const Color(0xFFB7A6F2));
    expect(TradeDetailPalette.reviewOuterDark, const Color(0xFF292B36));
    expect(TradeDetailPalette.reviewDecisionDark, const Color(0xFF242526));
    expect(TradeDetailPalette.reviewCommitmentDark, const Color(0xFF172F2F));
    expect(TradeDetailPalette.reviewNoEntryDark, const Color(0xFF2A2635));
    expect(TradeDetailPalette.reviewDecisionOptionDark, const Color(0xFF383638));
    expect(TradeDetailPalette.reviewCommitmentOptionDark, const Color(0xFF203B39));
    expect(TradeDetailPalette.reviewNoEntryOptionDark, const Color(0xFF373047));
  });

  test('dark theme uses a restrained graphite ramp rather than pure black', () {
    final tokens = TdTokens.forBrightness(Brightness.dark);
    expect(tokens.bgBase, const Color(0xFF0B0D10));
    expect(tokens.surface1, const Color(0xFF101418));
    expect(tokens.surface2, const Color(0xFF151A20));
    expect(tokens.surface3, const Color(0xFF1B2128));
    expect(tokens.inset, const Color(0xFF0D1115));
    expect(tokens.bgBase, isNot(const Color(0xFF000000)));
    expect(tokens.surface1.computeLuminance(), greaterThan(tokens.bgBase.computeLuminance()));
    expect(tokens.surface2.computeLuminance(), greaterThan(tokens.surface1.computeLuminance()));
    expect(tokens.surface3.computeLuminance(), greaterThan(tokens.surface2.computeLuminance()));
  });
}

