#!/usr/bin/env python3
"""Static checks for 1.7.110+166: negative-close rows in Opposing signals and
the structural no-entry wording/addition. Reads the real project files."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
rd = lambda p: (ROOT / p).read_text(encoding="utf-8")
CATALOG, FORM, MODEL = rd("lib/domain/trade_entry_catalog.dart"), rd("lib/screens/trade_form_screen.dart"), rd("lib/models/trade.dart")
TRADES = rd("lib/screens/trades_screen.dart")
PUBSPEC, WORKFLOW = rd("pubspec.yaml"), rd(".github/workflows/android-build.yml")
T_ENTRY, T_CAT, T_ZONES = rd("test/entry_conditions_test.dart"), rd("test/trade_entry_catalog_test.dart"), rd("test/trade_no_entry_zones_test.dart")

fails = 0
def check(name, ok):
    global fails
    print(("PASS " if ok else "FAIL ") + name)
    fails += 0 if ok else 1

def block(src, start, end):
    i = src.index(start)
    return src[i:src.index(end, i)]

# --- release
check("pubspec is 1.7.110+166", "version: 1.7.110+166" in PUBSPEC)
check("workflow identity", "TraderDesk 1.7.110+166" in WORKFLOW and "traderdesk-1.7.110-build166-arm64-v8a-release" in WORKFLOW)
check("update report exists", (ROOT / "UPDATE_REPORT_1.7.110+166.md").exists())

# --- Opposing signals: two new rows
rev = block(CATALOG, "const tradeReverseSignalOptions", "];")
check("reverse list keeps the original four in order", [rev.index(k) for k in ["'reverseSr'", "'reverseSdZone'", "'reverseHns'", "'reverseLongCandleWick'"]] == sorted(rev.index(k) for k in ["'reverseSr'", "'reverseSdZone'", "'reverseHns'", "'reverseLongCandleWick'"]))
check("row 'إغلاق سلبي فوق المنطقة'", "'إغلاق سلبي فوق المنطقة'" in rev and "tradeNegativeCloseAboveZoneKey" in rev)
check("row 'إغلاق سلبي داخل المنطقة'", "'إغلاق سلبي داخل المنطقة'" in rev and "tradeNegativeCloseInsideZoneKey" in rev)
check("above row precedes inside row", rev.index("tradeNegativeCloseAboveZoneKey") < rev.index("tradeNegativeCloseInsideZoneKey"))
sub = block(CATALOG, "const tradeNegativeCloseTrendlineOptions", "];")
check("popup items are 'فوق Trendline' and 'تحت Trendline'", "'فوق Trendline'" in sub and "'تحت Trendline'" in sub and sub.index("'فوق Trendline'") < sub.index("'تحت Trendline'"))
check("legacy negativeCloseAgainstDirection label kept", "case 'negativeCloseAgainstDirection':" in CATALOG)

# --- label format
fmt = block(CATALOG, "String formatTradeEntryConditionSetupLabel", "const tradeEntryReasons")
check("label builder handles both keys and the qualifier", "tradeNegativeCloseKeys.contains(setup.optionKey)" in fmt and "closeRelation" in fmt)
check("Arabic joiner is 'معا' as typed in the request", "const tradeNegativeCloseJoinerAr = 'معا';" in CATALOG)
check("qualifier phrases 'إغلاق فوق/تحت Trendline'", "'إغلاق فوق Trendline'" in CATALOG and "'إغلاق تحت Trendline'" in CATALOG)
check("timeframe is appended last", "return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';" in fmt.split("tradeNegativeCloseKeys.contains")[1])

# --- model / persistence
check("model stores closeRelation (field, json, ==, hash)", all(x in MODEL for x in ["final String? closeRelation;", "if (closeRelation != null) 'closeRelation': closeRelation", "other.closeRelation == closeRelation", "touch2,\n    closeRelation,"]))
check("unknown stored qualifier is ignored", "value == 'aboveTrendline' || value == 'belowTrendline'" in MODEL)
check("old records stay readable (no key written without qualifier)", "if (closeRelation != null)" in MODEL)

# --- form flow
flow = block(FORM, "Future<TradeEntryConditionSetup?> _showEntryConditionSetup", "String _touch2DialogTitle")
check("popup shown only for the two negative-close keys", "tradeNegativeCloseKeys.contains(optionKey)" in flow)
check("popup precedes the timeframe picker", flow.index("negative-close-trendline") < flow.index("_showTimeframeSheet("))
check("popup offers both choices plus 'متابعة'", "tradeNegativeCloseTrendlineOptions" in flow and "_copy('متابعة', 'Continue')" in flow)
check("dismissing the popup cancels, 'متابعة' stores no qualifier", "if (selectedRelation == null || !mounted) return null;" in flow and "selectedRelation.isEmpty ? null : selectedRelation" in flow)
check("closeRelation reaches the context label and the returned setup", flow.count("closeRelation: closeRelation") == 2)
check("editing restores the stored qualifier", "current?.optionKey == optionKey" in flow and "current?.closeRelation" in flow)
check("add, edit and the field widget all use tradeReverseSignalOptions", FORM.count("options: tradeReverseSignalOptions") == 3)
check("saved trade label goes through the shared formatter", "formatTradeEntryConditionSetupLabel(" in TRADES and "tradeReverseSignalOptions" in TRADES)

# --- structural reasons
stru = block(CATALOG, "const tradeNoEntryStructuralOptions", "];")
check("old wording removed everywhere in lib", "سيولة عالية تجاوز" not in CATALOG + FORM + TRADES)
check("corrected wording, same storage key", "'noEntryLiquidityOvershootReturn', 'زخم عالي تجاوز سعر منطقة دخول قليلا وعاد اليها بدون إغلاق'" in stru)
check("new item 'زخم مرتفع على الفريم الاصغر'", "'noEntryHighMomentumLowerTimeframe', 'زخم مرتفع على الفريم الاصغر'" in stru)
check("structural group has 5 items, corrected one then new one last", len(re.findall(r"TradeEntryOption\('noEntry\w+'", stru)) == 5 and stru.index("noEntryLiquidityOvershootReturn") < stru.index("noEntryHighMomentumLowerTimeframe"))
check("flat list still spreads both groups", "...tradeNoEntryPsychologicalOptions,\n  ...tradeNoEntryStructuralOptions," in CATALOG)
check("psychological options untouched", all(k in CATALOG for k in ["fearRepeatLossAfterLoss", "fearGivingBackProfit", "fearLossNoHistory", "hesitationUnclearScenario", "waitedDeeperRetestDespiteConfirmation"]))

# --- tests written
check("widget test for both examples", "'إغلاق سلبي داخل المنطقة معا إغلاق تحت Trendline 15MIN'" in T_ENTRY and "'إغلاق سلبي فوق المنطقة 15MIN'" in T_ENTRY)
check("catalog tests cover labels and JSON", "negative-close labels follow the requested examples" in T_CAT and "keep their Trendline qualifier through JSON" in T_ENTRY)
check("zone test covers new wording", "زخم مرتفع على الفريم الاصغر" in T_ZONES and "زخم عالي تجاوز" in T_ZONES)

print(f"\n{fails} failing")
raise SystemExit(1 if fails else 0)
