#!/usr/bin/env python3
"""Static regression checks for selected-value cards across all eight trade-form lists."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
DECISIONS = (ROOT / "lib/widgets/trade_decision_zones.dart").read_text(encoding="utf-8")
NO_ENTRY = (ROOT / "lib/widgets/trade_no_entry_zones.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
REPORT = ROOT / "UPDATE_REPORT_1.7.116+172.md"
SUMMARY = DECISIONS[DECISIONS.index("class DecisionSelectionSummary"):DECISIONS.index("/// Plain tonal tile")]
checks: list[tuple[str, bool]] = []

def check(name: str, result: bool) -> None:
    checks.append((name, bool(result)))

check("project version is 1.7.116+172", "version: 1.7.116+172" in PUBSPEC)
check("Android workflow names version 1.7.116+172", "TraderDesk 1.7.116+172 Android Release APK" in WORKFLOW)
check("Android artifacts use build 172", "traderdesk-1.7.116-build172-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.116-build172-arm64-dart-symbols" in WORKFLOW)
check("release report exists", REPORT.is_file())

# One shared selected-value presentation is used for every folded field.
check("shared summary constructs one keyed container per selected label", "decision-selection-item-$itemKeyPrefix-$index" in SUMMARY and "for (var i = 0; i < labels.length; i++)" in SUMMARY)
check("each selected item has its own rounded tonal fill", "borderRadius: BorderRadius.circular(13)" in SUMMARY and "final itemFill = Color.alphaBlend(" in SUMMARY)
check("item surface uses subtle section tone and no border", "tone.withValues(alpha: isDark ? .115 : .085)" in SUMMARY and "border:" not in SUMMARY and "boxShadow:" not in SUMMARY)
check("items have independent vertical spacing", "if (i > 0) const SizedBox(height: 8)" in SUMMARY)
check("the summary remains tappable to reopen the source list", "onTap: onTap" in SUMMARY and "Icons.unfold_more_rounded" in SUMMARY)
check("practical-link trailing markers remain supported", "final List<Widget?> trailingWidgets" in SUMMARY and "trailing," in SUMMARY)
check("no checkbox or checkmark was added to selected cards", "Checkbox(" not in SUMMARY and "Icons.check" not in SUMMARY)

# Three data lists.
check("entry reason summary uses shared item-card renderer", "itemKeyPrefix: 'setup-$fieldId'" in FORM and "fieldId: 'entry-reason'" in FORM)
check("anchor summary uses shared item-card renderer", "itemKeyPrefix: 'anchor'" in FORM and "trade-anchor-selected-summary" in FORM)
check("entry confirmation summary uses shared item-card renderer", "fieldId: 'confirmation'" in FORM and "itemKeyPrefix: 'setup-$fieldId'" in FORM)

# Two entry-condition lists.
check("opposing-signal summary uses shared item-card renderer", "itemKeyPrefix: 'entry-condition-$fieldId'" in FORM and "fieldId: 'reverse-signals'" in FORM)
check("bounce-area summary uses shared item-card renderer", "fieldId: 'bounce-area'" in FORM and "entry-condition-summary-$fieldId" in FORM)

# Three behavior lists.
check("decision groups use shared item-card renderer", "itemKeyPrefix: 'decision-${group.id}'" in DECISIONS)
check("commitment uses shared item-card renderer", "itemKeyPrefix: 'commitment'" in FORM and "trade-commitment-selection-summary" in FORM)
check("no-entry groups use shared item-card renderer", "itemKeyPrefix: 'no-entry-${group.id}'" in NO_ENTRY)

# Existing interaction and presentation contracts remain present.
check("setup edit and remove handlers remain wired", "onTap: enabled" in FORM and "onRemove(setups[index].item)" in FORM)
check("anchor timeframe edit and remove handlers remain wired", "_editAnchorTimeframe(anchorKey)" in FORM and "_removeAnchor(anchorKey)" in FORM)
check("practical no-entry link indicator remains in entry-condition summaries", "practicalNoEntrySetups.contains(setup)" in FORM and "Icons.link_rounded" in FORM)
check("decision selection toggles remain wired", "onToggle: (key) => _toggleSet(" in FORM)
check("no-entry selection toggles remain wired", "onToggle: (key) => _toggleSet(" in FORM)

# Regression tests for multiple item cards and borderless visual treatment.
ENTRY_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
DECISION_TEST = (ROOT / "test/trade_decision_zones_test.dart").read_text(encoding="utf-8")
NO_ENTRY_TEST = (ROOT / "test/trade_no_entry_zones_test.dart").read_text(encoding="utf-8")
COMMITMENT_TEST = (ROOT / "test/custom_confirmation_test.dart").read_text(encoding="utf-8")
check("entry-reason, anchor, confirmation and reverse-signal card keys are tested", all(key in ENTRY_TEST for key in ("decision-selection-item-anchor-0", "decision-selection-item-setup-entry-reason-0", "decision-selection-item-setup-confirmation-0", "decision-selection-item-entry-condition-reverse-signals-0")))
check("decision and no-entry cards test independent surfaces", "decision-selection-item-decision-violations-0" in DECISION_TEST and "decision-selection-item-no-entry-psychological-0" in NO_ENTRY_TEST)
check("commitment card presentation is tested", "decision-selection-item-commitment-0" in COMMITMENT_TEST)

failed = [name for name, passed in checks if not passed]
for name, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
