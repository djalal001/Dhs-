#!/usr/bin/env python3
"""Static checks for 1.7.110+166: commitment lock, SELL menu width, no commitment emoji."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
rd = lambda p: (ROOT / p).read_text(encoding="utf-8")
FORM, TRADES, CAT = rd("lib/screens/trade_form_screen.dart"), rd("lib/screens/trades_screen.dart"), rd("lib/domain/trade_entry_catalog.dart")
PUB, CUSTOM, ENTRY = rd("pubspec.yaml"), rd("test/custom_confirmation_test.dart"), rd("test/entry_conditions_test.dart")
checks = []
def check(label, ok): checks.append((label, bool(ok)))

check("release is 1.7.110+166", "version: 1.7.110+166" in PUB)
check("update report exists", (ROOT / "UPDATE_REPORT_1.7.110+166.md").exists())
check("exclusive commitment keys are the two requested", "tradeCommitmentExclusiveKeys = <String>{\n  'fullPlanCompliance',\n  'enteredDespiteFear',\n}" in CAT)
check("flaw keys come from violations and analysis only", "group.id == 'violations' || group.id == 'analysis'" in CAT and "'risk'" not in CAT[CAT.index("tradeExecutionFlawKeys"):CAT.index("const tradeCommitmentOptions")])
check("form locks the exclusive commitments while a flaw is chosen", "bool _commitmentLocked(String key)" in FORM and "!_commitmentLocked(tradeCommitmentOptions[i].key)" in FORM)
check("an already-selected commitment stays tappable (can be cleared)", "!_executionReviewKeys.contains(key)" in FORM[FORM.index("bool _commitmentLocked"):FORM.index("void _toggleSet")])
check("choosing a flaw releases the exclusive commitments", "values.removeAll(tradeCommitmentExclusiveKeys)" in FORM and "tradeExecutionFlawKeys.contains(key)" in FORM)
check("commitment rows render without artwork in the form", "showArtwork: false," in FORM[FORM.index("title: _copy('الالتزام'"):FORM.index("أسباب عدم الدخول', 'Reasons for not entering'")])
check("commitment tiles render without artwork in the saved trade", "reviewCommitmentOptionDark : const Color(0xFFE4F1EB),\n              showArtwork: false," in TRADES)
check("emoji asset files are untouched", all((ROOT / f"assets/emojis/commitment/{k}.webp").exists() for k in ["breakevenStopToEntry","manualExitNearTarget","autoExitAtTarget","enteredDespiteFear","fullPlanCompliance"]))
check("direction and symbol popups use a minimum menu width", "const double _shortChoiceMenuWidth = 104;" in FORM and FORM.count("minMenuWidth: _shortChoiceMenuWidth,") == 2)
check("popup labels shrink instead of ellipsizing", "fit: BoxFit.scaleDown," in FORM[FORM.index("Future<void> _showCompactPopupChoice"):FORM.index("Widget _compactPopupChoice")] and "softWrap: false," in FORM)
check("tests cover lock, release and SELL width", "contradicts a chosen violation" in CUSTOM and "a violation and full plan compliance never coexist" in CUSTOM and "SELL fits inside its menu row" in ENTRY)

for label, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
failed = [l for l, ok in checks if not ok]
if failed:
    print("Failed checks:", ", ".join(failed)); sys.exit(1)
print(f"All {len(checks)} checks passed")
