#!/usr/bin/env python3
"""Static regression checks for the 1.7.110+166 Decisions-area redesign.

Everything here is read from the project files; nothing is assumed.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
read = lambda p: (ROOT / p).read_text(encoding="utf-8")
CATALOG = read("lib/domain/trade_entry_catalog.dart")
FORM = read("lib/screens/trade_form_screen.dart")
TRADES = read("lib/screens/trades_screen.dart")
ZONES = read("lib/widgets/trade_decision_zones.dart")
EMOJI = read("lib/widgets/decision_option_emoji.dart")
PUBSPEC = read("pubspec.yaml")
WORKFLOW = read(".github/workflows/android-build.yml")
ZONES_TEST = read("test/trade_decision_zones_test.dart")

checks = []
def check(label, cond):
    checks.append((label, bool(cond)))

def section(src, start, end):
    return src.split(start, 1)[1].split(end, 1)[0]

review = section(CATALOG, "const tradeReviewGroups", "/// Analysis-quality rows")
def group(gid):
    return section(review, f"id: '{gid}'", "TradeReviewGroup(") if gid != "risk" else review.split("id: 'risk'", 1)[1]

check("release version is 1.7.110+166", "version: 1.7.110+166" in PUBSPEC)
check("workflow metadata matches", "TraderDesk 1.7.110+166" in WORKFLOW and "traderdesk-1.7.110-build166-arm64-v8a-release" in WORKFLOW)

# --- catalog: three zones, exact items
check("three zones in the requested order", [m for m in re.findall(r"id: '(\w+)'", review)] == ["violations", "analysis", "risk"])
check("zone titles shortened", all(t in review for t in ["titleAr: 'مخالفات التنفيذ'", "titleAr: 'جودة تحليل'", "titleAr: 'إدارة المخاطرة'"]))
viol = group("violations")
for ar in ["دخول مبكر", "دخول متأخر", "لم أفتح الحجم الكامل بسبب تردد",
           "تغيير وقف الخسارة لتقليل المخاطرة بلا سبب", "تغيير وقف الخسارة لزيادة المخاطرة بلا سبب",
           "خروج مبكر خوفًا من ضياع الأرباح"]:
    check(f"violations item: {ar}", f"'{ar}'" in viol)
check("violations has exactly 6 items", len(re.findall(r"TradeEntryOption\(", viol)) == 6)
ana = group("analysis")
for en in ["RBS", "RBS Touch 2", "RFS", "SBR", "SBR Touch 2", "SFR", "Zone Supply", "Zone Demand",
           "Trendline Touch 3 Sell", "Trendline Touch 3 Buy",
           "Trend Line Touch 3 Sell Breakout", "Trend Line Touch 3 Buy Breakout"]:
    check(f"analysis item: {en}", f"'{en}', '{en}')" in ana)
check("analysis has exactly 12 items", len(re.findall(r"TradeEntryOption\(", ana)) == 12)
risk = group("risk")
for ar in ["زيادة المخاطرة لسبب منطقي: سيولة عالية مع وجود منطقة أمان أبعد قليلًا",
           "تقليل المخاطرة لسبب منطقي: إغلاق سلبي لا يدعم اتجاه الصفقة",
           "لم أفتح الحجم الكامل انتظارًا لتصحيح أعمق لمنطقة الدخول"]:
    check(f"risk item: {ar[:30]}…", f"'{ar}'" in risk)
check("risk has exactly 3 items", len(re.findall(r"TradeEntryOption\(", risk)) == 3)
check("old analysis items are not offered", all(k not in review for k in [
    "missedHigherTimeframeBounceArea", "missedLowerTimeframeBounceArea", "missedTrendlineFromCandleWicks",
    "noBreakoutPositiveClose", "noTrendlineSupportsEntryZone", "missedHigherTimeframeTrendlineIntegration"]))
check("old keys remain readable for saved trades", "tradeLegacyReviewOptions" in CATALOG and "...tradeLegacyReviewOptions" in CATALOG)
layout = section(CATALOG, "const tradeAnalysisRowLayout", "];")
rows = re.findall(r"\[([^\]]*)\]", layout.split("=", 1)[1])
check("analysis layout is 3-3-2-1-1-1-1", [len([x for x in r.split(",") if x.strip()]) for r in rows] == [3, 3, 2, 1, 1, 1, 1])
check("analysis sentences", "لم أنتبه لوجود سيناريو" in CATALOG and "'لم أنتبه لوجود'" in CATALOG)

# --- emoji removal
check("decision emoji folder deleted", not (ROOT / "assets/emojis/decisions").exists())
check("no decisions assets in pubspec", "emojis/decisions" not in PUBSPEC)
check("decision emoji map and widget removed", "decisionOptionEmojiAssets" not in EMOJI and "class DecisionOptionEmoji" not in EMOJI)
check("commitment and no-entry artwork kept", "assets/emojis/commitment/" in PUBSPEC and "assets/emojis/no_entry/" in PUBSPEC and "fullPlanCompliance" in EMOJI)

# --- form wiring
behavior = section(FORM, "Widget _buildBehaviorCard", "Widget _behaviorExpansion")
check("form uses the zones widget", "TradeDecisionZones(" in behavior and "trade_decision_zones.dart" in FORM)
check("old per-group headings removed from form", "trade-review-group-heading" not in FORM)
check("side padding reduced for the decisions area", "bodyHorizontalPadding: 6" in behavior and "EdgeInsets.fromLTRB(2, 2, 2, 10)" in behavior)
check("other behavior sections keep their geometry", behavior.count("_insetBehaviorSection(") == 3)
check("selection gate preserved", "enabled: _hasTradeDirection" in behavior and "onToggle: (key) => _toggleSet(" in behavior)

# --- zones widget
check("three equal rectangles in one Row", "Expanded(" in ZONES and "decision-zone-tabs" in ZONES and "decision-zone-tab-" in ZONES)
check("sideways transition, not a pop-up", "SlideTransition" in ZONES and "AnimatedSwitcher" in ZONES and "showDialog" not in ZONES and "showModalBottomSheet" not in ZONES and "PopupMenu" not in ZONES)
check("direction follows reading direction", "TextDirection.rtl" in ZONES)
check("tapping the open analysis name folds it", "_analysisCollapsed = !_analysisCollapsed" in ZONES and "group.id == 'analysis'" in ZONES)
check("summary sentence uses the catalog helper", "tradeAnalysisMissedSentence(" in ZONES)
tile = section(ZONES, "class _AnalysisTile", "class _AnalysisSummary")
check("analysis tiles: tonal fill only (no border, shadow, glow)", "border:" not in tile and "boxShadow" not in tile and "BoxShadow" not in tile and "Icons.check" not in tile)
check("analysis tiles are gated by trade direction", "onTap: enabled ? onTap : null" in tile)

# --- saved trade view
check("saved view builds the sentence from the count", "tradeAnalysisMissedSentence(count: keys.length" in TRADES)
check("saved decision rows no longer draw a placeholder icon", "label_outline_rounded" not in TRADES)

# --- tests exist
check("widget test covers fold/summary sentences", "لم أنتبه لوجود سيناريو" in ZONES_TEST and "decision-analysis-summary" in ZONES_TEST)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(("PASS: " if ok else "FAIL: ") + label)
print(f"{len(checks) - len(failed)}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
