import 'package:flutter/material.dart';

import '../domain/trade_entry_catalog.dart';
import 'trade_decision_zones.dart';

/// «أسباب عدم الدخول» as two sections side by side — psychological and
/// structural — built from the same components as the Decisions area.
///
/// Choosing a section slides its content in place (no dialog). Tapping the
/// name of the open section folds it into a summary of what was chosen, one
/// reason per line; tapping the summary (or the name again) unfolds it.
class TradeNoEntryZones extends StatefulWidget {
  const TradeNoEntryZones({
    super.key,
    required this.groups,
    required this.selected,
    required this.onToggle,
    required this.enabled,
    required this.arabic,
    required this.tone,
    this.initialZone = 0,
    this.initialCollapsed = const <String>{},
    this.onZoneChanged,
    this.onCollapsedChanged,
  });

  final List<TradeReviewGroup> groups;
  final Set<String> selected;
  final ValueChanged<String> onToggle;
  final bool enabled;
  final bool arabic;
  final Color tone;
  final int initialZone;

  /// Ids of the sections that were folded when the widget was last built, so
  /// a rebuild (e.g. after the parent expansion tile closes) keeps the state.
  final Set<String> initialCollapsed;
  final ValueChanged<int>? onZoneChanged;
  final ValueChanged<Set<String>>? onCollapsedChanged;

  @override
  State<TradeNoEntryZones> createState() => _TradeNoEntryZonesState();
}

class _TradeNoEntryZonesState extends State<TradeNoEntryZones> {
  static const _switchDuration = Duration(milliseconds: 240);
  static const _tileGap = 6.0;

  /// Same size as every other trading-behavior row in the form.
  static const _labelFontSize = 14.5;

  late int _index = widget.initialZone < 0
      ? 0
      : (widget.initialZone >= widget.groups.length
          ? widget.groups.length - 1
          : widget.initialZone);
  late int _previous = _index;
  late final Set<String> _collapsed = {...widget.initialCollapsed};

  TradeReviewGroup get _active => widget.groups[_index];

  List<TradeEntryOption> _selectedOf(TradeReviewGroup group) => [
        for (final option in group.options)
          if (widget.selected.contains(option.key)) option,
      ];

  void _onTabTap(int index) {
    final group = widget.groups[index];
    if (index == _index) {
      // Folding only makes sense once there is something to summarise.
      if (_selectedOf(group).isNotEmpty) {
        _setCollapsed(group.id, !_collapsed.contains(group.id));
      }
      return;
    }
    setState(() {
      _previous = _index;
      _index = index;
    });
    widget.onZoneChanged?.call(index);
  }

  void _setCollapsed(String id, bool value) {
    setState(() {
      if (value) {
        _collapsed.add(id);
      } else {
        _collapsed.remove(id);
      }
    });
    widget.onCollapsedChanged?.call({..._collapsed});
  }

  @override
  Widget build(BuildContext context) {
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final forward = _index >= _previous;
    final direction = (forward ? 1.0 : -1.0) * (rtl ? -1.0 : 1.0);
    final activeKey = ValueKey<String>('no-entry-zone-panel-${_active.id}');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          key: const ValueKey('no-entry-zone-tabs'),
          children: [
            for (var i = 0; i < widget.groups.length; i++) ...[
              if (i > 0) const SizedBox(width: 6),
              Expanded(
                child: DecisionZoneTab(
                  key: ValueKey('no-entry-zone-tab-${widget.groups[i].id}'),
                  title: widget.arabic
                      ? widget.groups[i].titleAr
                      : widget.groups[i].titleEn,
                  count: _selectedOf(widget.groups[i]).length,
                  active: i == _index,
                  tone: widget.tone,
                  onTap: () => _onTabTap(i),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        AnimatedSize(
          duration: _switchDuration,
          curve: Curves.easeOutCubic,
          alignment: Alignment.topCenter,
          child: AnimatedSwitcher(
            duration: _switchDuration,
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            layoutBuilder: (current, previous) => Stack(
              alignment: Alignment.topCenter,
              children: [
                for (final old in previous)
                  Positioned(top: 0, left: 0, right: 0, child: old),
                if (current != null) current,
              ],
            ),
            transitionBuilder: (child, animation) {
              final incoming = child.key == activeKey;
              final begin = Offset(incoming ? direction * .10 : -direction * .10, 0);
              return FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: Tween<Offset>(begin: begin, end: Offset.zero)
                      .animate(animation),
                  child: child,
                ),
              );
            },
            child: KeyedSubtree(
              key: activeKey,
              child: _buildPanel(_active),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPanel(TradeReviewGroup group) {
    final selectedOptions = _selectedOf(group);
    final collapsed =
        _collapsed.contains(group.id) && selectedOptions.isNotEmpty;

    final list = Column(
      key: ValueKey('no-entry-zone-list-${group.id}'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < group.options.length; i++) ...[
          if (i > 0) const SizedBox(height: _tileGap),
          DecisionOptionTile(
            inkKey: ValueKey('no-entry-${group.options[i].key}'),
            surfaceKey: ValueKey(
              'trade-behavior-option-surface-${group.options[i].key}',
            ),
            label: widget.arabic ? group.options[i].ar : group.options[i].en,
            selected: widget.selected.contains(group.options[i].key),
            enabled: widget.enabled,
            tone: widget.tone,
            fontSize: _labelFontSize,
            onTap: () => widget.onToggle(group.options[i].key),
          ),
        ],
      ],
    );

    final summary = DecisionSelectionSummary(
      key: ValueKey('no-entry-zone-summary-${group.id}'),
      itemKeyPrefix: 'no-entry-${group.id}',
      stacked: true,
      latinLabels: !widget.arabic,
      labels: [
        for (final option in selectedOptions)
          widget.arabic ? option.ar : option.en,
      ],
      tone: widget.tone,
      onTap: () => _setCollapsed(group.id, false),
    );

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      layoutBuilder: (current, previous) => Stack(
        alignment: Alignment.topCenter,
        children: [
          for (final old in previous)
            Positioned(top: 0, left: 0, right: 0, child: old),
          if (current != null) current,
        ],
      ),
      transitionBuilder: (child, animation) =>
          FadeTransition(opacity: animation, child: child),
      child: collapsed ? summary : list,
    );
  }
}
