import 'package:flutter/material.dart';

/// Review artwork that remains in the app: 5 commitment illustrations and
/// 5 no-entry illustrations. The Decisions area (violations, analysis quality,
/// risk management) deliberately carries no emoji artwork.
const tradeReviewOptionEmojiAssets = <String, String>{
  'breakevenStopToEntry':
      'assets/emojis/commitment/breakevenStopToEntry.webp',
  'manualExitNearTarget':
      'assets/emojis/commitment/manualExitNearTarget.webp',
  'autoExitAtTarget': 'assets/emojis/commitment/autoExitAtTarget.webp',
  'enteredDespiteFear': 'assets/emojis/commitment/enteredDespiteFear.webp',
  'fullPlanCompliance': 'assets/emojis/commitment/fullPlanCompliance.webp',
  'fearRepeatLossAfterLoss':
      'assets/emojis/no_entry/fearRepeatLossAfterLoss.webp',
  'fearGivingBackProfit':
      'assets/emojis/no_entry/fearGivingBackProfit.webp',
  'fearLossNoHistory': 'assets/emojis/no_entry/fearLossNoHistory.webp',
  'hesitationUnclearScenario':
      'assets/emojis/no_entry/hesitationUnclearScenario.webp',
  'waitedDeeperRetestDespiteConfirmation':
      'assets/emojis/no_entry/waitedDeeperRetestDespiteConfirmation.webp',
};

/// Compact illustration used by the commitment and no-entry review rows.
class TradeReviewOptionEmoji extends StatelessWidget {
  const TradeReviewOptionEmoji({super.key, required this.optionKey, this.size = 26});

  final String optionKey;
  final double size;

  @override
  Widget build(BuildContext context) {
    final asset = tradeReviewOptionEmojiAssets[optionKey];
    if (asset == null) return const SizedBox.shrink();

    return RepaintBoundary(
      child: ExcludeSemantics(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Image.asset(
            asset,
            width: size,
            height: size,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.medium,
            gaplessPlayback: true,
          ),
        ),
      ),
    );
  }
}
