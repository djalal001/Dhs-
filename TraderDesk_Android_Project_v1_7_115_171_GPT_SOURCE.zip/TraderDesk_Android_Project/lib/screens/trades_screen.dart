import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart' show ScrollDirection;

import '../domain/trade_analytics.dart';
import '../domain/trade_ordering.dart';
import '../domain/trade_entry_catalog.dart';
import '../l10n/app_strings.dart';
import '../models/trade.dart';
import '../state/app_scope.dart';
import '../theme/app_theme.dart';
import '../theme/trade_detail_palette.dart';
import '../theme/trade_outcome_palette.dart';
import '../widgets/common.dart';
import '../widgets/trade_image_preview.dart';
import '../widgets/trade_execution_journal.dart';
import '../widgets/decision_option_emoji.dart';
import '../widgets/trade_entry_setup_chips.dart';
import '../widgets/strategy_adherence_chip.dart';
import 'trade_form_screen.dart';

class TradesScreen extends StatefulWidget {
  const TradesScreen({super.key});
  @override
  State<TradesScreen> createState() => _TradesScreenState();
}

enum _TradeFilter { all, wins, losses, breakEven, missed }

enum _MissedTradeFilter { all, wins, losses }
enum _BreakEvenTradeFilter { all, balanced, atEntry }

enum _TradePeriod { all, week, month, year, custom }

TradeClassification? _outcomeOf(Trade trade) => trade.effectiveClassification;

String _classificationLabel(BuildContext context, TradeClassification? value) =>
    switch (value) {
      TradeClassification.win => tr(context, 'classificationWin'),
      TradeClassification.loss => tr(context, 'classificationLoss'),
      TradeClassification.breakEven => tr(context, 'classificationBreakEven'),
      TradeClassification.missed => tr(context, 'classificationMissed'),
      null => tr(context, 'unclassifiedTrade'),
    };

Color _classificationColor(BuildContext context, TradeClassification? value) {
  final tokens = TdTokens.of(context);
  return switch (value) {
    TradeClassification.win => tokens.profit,
    TradeClassification.loss => tokens.loss,
    TradeClassification.breakEven => TradeOutcomePalette.breakEven(Theme.of(context).brightness),
    TradeClassification.missed => TradeOutcomePalette.missed(Theme.of(context).brightness),
    null => tokens.text3,
  };
}

// Saved-trade values receive a restrained typography lift while field
// headings retain their established size, weight, and color.
const double _savedTradeDetailValueFontSize = 15;
const double _savedTradeDetailChipFontSize = 13.5;
const double _savedTradeReviewValueFontSize = 13;

// Saved-trade field headings reuse the same typography as the decision-group
// headings in TradeBehaviorSummary (labelMedium, 13sp, w800).
TextStyle? _tradeSectionHeadingStyle(
  BuildContext context, {
  required Color color,
}) => Theme.of(context).textTheme.labelMedium?.copyWith(
  color: color,
  fontWeight: FontWeight.w800,
);

String _savedEntryConditionLabel(
  BuildContext context,
  TradeEntryConditionSetup setup,
  List<TradeEntryOption> options,
  TradeSide side,
) {
  final arabic = AppStrings.isArabic(context);
  final optionLabel = options
          .where((option) => option.key == setup.optionKey)
          .map((option) => arabic ? option.ar : option.en)
          .firstOrNull ??
      setup.optionKey;
  return formatTradeEntryConditionSetupLabel(
    setup: setup,
    optionLabel: optionLabel,
    arabic: arabic,
    side: side,
  );
}

class _TradeClassificationIndicator extends StatelessWidget {
  const _TradeClassificationIndicator({
    required this.tradeId,
    required this.classification,
    required this.color,
  });

  final String tradeId;
  final TradeClassification classification;
  final Color color;

  @override
  Widget build(BuildContext context) => Semantics(
    key: ValueKey('trade-classification-indicator-$tradeId'),
    container: true,
    label: _classificationLabel(context, classification),
    child: ExcludeSemantics(
      child: Container(
        width: 7,
        height: 7,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
    ),
  );
}

class _TradesScreenState extends State<TradesScreen> {
  _TradeFilter _filter = _TradeFilter.all;
  _MissedTradeFilter _missedTradeFilter = _MissedTradeFilter.all;
  _BreakEvenTradeFilter _breakEvenTradeFilter = _BreakEvenTradeFilter.all;
  _TradePeriod _period = _TradePeriod.all;
  DateTimeRange? _customPeriodRange;
  Timer? _fabIdleTimer;
  double _fabOpacity = 0.96;

  @override
  void dispose() {
    _fabIdleTimer?.cancel();
    super.dispose();
  }

  String _periodLabel(BuildContext context, _TradePeriod period) =>
      switch (period) {
        _TradePeriod.all => tr(context, 'equityRangeAll'),
        _TradePeriod.week => tr(context, 'equityRangeWeek'),
        _TradePeriod.month => tr(context, 'equityRangeMonth'),
        _TradePeriod.year => tr(context, 'equityRangeYear'),
        _TradePeriod.custom => tr(context, 'equityRangeCustom'),
      };

  String _filterLabel(BuildContext context, _TradeFilter filter) =>
      switch (filter) {
        _TradeFilter.all => tr(context, 'all'),
        _TradeFilter.wins => tr(context, 'classificationWin'),
        _TradeFilter.losses => tr(context, 'classificationLoss'),
        _TradeFilter.breakEven => tr(context, 'classificationBreakEven'),
        _TradeFilter.missed => tr(context, 'classificationMissed'),
      };

  Color _filterColor(BuildContext context, _TradeFilter filter) {
    final tokens = TdTokens.of(context);
    return switch (filter) {
      _TradeFilter.all => tokens.text3,
      _TradeFilter.wins => tokens.profit,
      _TradeFilter.losses => tokens.loss,
      _TradeFilter.breakEven =>
        TradeOutcomePalette.breakEven(Theme.of(context).brightness),
      _TradeFilter.missed =>
        TradeOutcomePalette.missed(Theme.of(context).brightness),
    };
  }

  String _filterOptionKey(_TradeFilter filter) => switch (filter) {
    _TradeFilter.all => 'trades-filter-all',
    _TradeFilter.wins => 'trades-filter-wins',
    _TradeFilter.losses => 'trades-filter-losses',
    _TradeFilter.breakEven => 'trades-filter-break-even',
    _TradeFilter.missed => 'trades-filter-missed',
  };

  /// Count column of the classification popup. Every row reserves the same
  /// width (measured from the widest count), so the small sub-filter buttons of
  /// "break-even" and "missed" always sit on one vertical line regardless of how
  /// many digits each category count has.
  Widget _classificationCount(
    BuildContext itemContext,
    TdTokens tokens,
    Map<_TradeFilter, int> counts,
    _TradeFilter filter,
  ) {
    final style = Theme.of(itemContext).textTheme.titleSmall?.copyWith(
          color: tokens.text2,
          fontWeight: FontWeight.w600,
          fontFeatures: const [FontFeature.tabularFigures()],
        );
    var widestDigits = 1;
    for (final value in counts.values) {
      final digits = '$value'.length;
      if (digits > widestDigits) widestDigits = digits;
    }
    final painter = TextPainter(
      text: TextSpan(text: '8' * widestDigits, style: style),
      textDirection: Directionality.of(itemContext),
      textScaler: MediaQuery.textScalerOf(itemContext),
      maxLines: 1,
    )..layout();
    final width = painter.width.ceilToDouble() + 1;
    painter.dispose();
    return SizedBox(
      key: ValueKey('trades-filter-count-${filter.name}'),
      width: width,
      child: Align(
        alignment: AlignmentDirectional.centerEnd,
        child: Text('${counts[filter] ?? 0}', style: style),
      ),
    );
  }

  String _breakEvenFilterLabel(BuildContext context, _BreakEvenTradeFilter filter) =>
      switch (filter) {
        _BreakEvenTradeFilter.all => tr(context, 'all'),
        _BreakEvenTradeFilter.balanced => tr(context, 'breakEvenBalanced'),
        _BreakEvenTradeFilter.atEntry => tr(context, 'breakEvenAtEntry'),
      };

  String _missedFilterLabel(BuildContext context, _MissedTradeFilter filter) =>
      switch (filter) {
        _MissedTradeFilter.all => tr(context, 'all'),
        _MissedTradeFilter.wins => tr(context, 'classificationWin'),
        _MissedTradeFilter.losses => tr(context, 'classificationLoss'),
      };

  Color _missedFilterColor(BuildContext context, _MissedTradeFilter filter) {
    final tokens = TdTokens.of(context);
    return switch (filter) {
      _MissedTradeFilter.all => tokens.text3,
      _MissedTradeFilter.wins => tokens.profit,
      _MissedTradeFilter.losses => tokens.loss,
    };
  }

  DateTimeRange? _selectedPeriodBounds() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    DateTime? start;
    DateTime? endExclusive;
    switch (_period) {
      case _TradePeriod.all:
        return null;
      case _TradePeriod.week:
        start = today.subtract(const Duration(days: 6));
        endExclusive = today.add(const Duration(days: 1));
        break;
      case _TradePeriod.month:
        start = today.subtract(const Duration(days: 29));
        endExclusive = today.add(const Duration(days: 1));
        break;
      case _TradePeriod.year:
        start = today.subtract(const Duration(days: 364));
        endExclusive = today.add(const Duration(days: 1));
        break;
      case _TradePeriod.custom:
        final range = _customPeriodRange;
        if (range == null) return null;
        start = DateTime(
          range.start.year,
          range.start.month,
          range.start.day,
        );
        endExclusive = DateTime(
          range.end.year,
          range.end.month,
          range.end.day + 1,
        );
        break;
    }
    if (start == null || endExclusive == null) return null;
    return DateTimeRange(start: start, end: endExclusive);
  }

  Future<void> _choosePeriod(_TradePeriod period) async {
    if (period == _TradePeriod.custom) {
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final picked = await showDateRangePicker(
        context: context,
        firstDate: DateTime(2000, 1, 1),
        lastDate: today,
        initialDateRange: _customPeriodRange ??
            DateTimeRange(
              start: today.subtract(const Duration(days: 29)),
              end: today,
            ),
        helpText: tr(context, 'equitySelectRange'),
        cancelText: tr(context, 'cancel'),
        confirmText: tr(context, 'confirm'),
      );
      if (!mounted || picked == null) return;
      final start = DateTime(
        picked.start.year,
        picked.start.month,
        picked.start.day,
      );
      final end = DateTime(
        picked.end.year,
        picked.end.month,
        picked.end.day,
      );
      setState(() {
        _period = _TradePeriod.custom;
        _customPeriodRange = DateTimeRange(start: start, end: end);
      });
      return;
    }
    setState(() => _period = period);
  }

  bool _isWithinPeriod(Trade trade, DateTimeRange? periodBounds) {
    if (periodBounds == null) return true;
    // Persisted/imported timestamps may carry a UTC offset. Compare their
    // local calendar day with the local DatePicker bounds to avoid shifting
    // trades across midnight or into the wrong selected period.
    final localTradeTime = trade.tradedAt.toLocal();
    final tradeDay = DateTime(
      localTradeTime.year,
      localTradeTime.month,
      localTradeTime.day,
    );
    return !tradeDay.isBefore(periodBounds.start) &&
        tradeDay.isBefore(periodBounds.end);
  }

  bool _matchesFilter(Trade trade) {
    switch (_filter) {
      case _TradeFilter.all:
        return true;
      case _TradeFilter.wins:
        return _outcomeOf(trade) == TradeClassification.win;
      case _TradeFilter.losses:
        return _outcomeOf(trade) == TradeClassification.loss;
      case _TradeFilter.breakEven:
        if (_outcomeOf(trade) != TradeClassification.breakEven) return false;
        return switch (_breakEvenTradeFilter) {
          _BreakEvenTradeFilter.all => true,
          _BreakEvenTradeFilter.balanced => trade.breakEvenType == BreakEvenType.balanced,
          _BreakEvenTradeFilter.atEntry => trade.breakEvenType == BreakEvenType.atEntry,
        };
      case _TradeFilter.missed:
        if (_outcomeOf(trade) != TradeClassification.missed) return false;
        return switch (_missedTradeFilter) {
          _MissedTradeFilter.all => true,
          _MissedTradeFilter.wins => trade.missedOutcome == MissedTradeOutcome.win,
          _MissedTradeFilter.losses => trade.missedOutcome == MissedTradeOutcome.loss,
        };
    }
  }

  bool _handleListScroll(ScrollNotification notification) {
    if (notification.depth == 0 &&
        (notification is ScrollStartNotification ||
            notification is ScrollUpdateNotification ||
            (notification is UserScrollNotification &&
                notification.direction != ScrollDirection.idle))) {
      _fabIdleTimer?.cancel();
      if (_fabOpacity > 0.32 && mounted) {
        setState(() => _fabOpacity = 0.30);
      }
      _fabIdleTimer = Timer(const Duration(milliseconds: 750), () {
        if (mounted) setState(() => _fabOpacity = 0.96);
      });
    }
    return false;
  }

  Future<void> _openForm({Trade? trade}) async {
    final app = AppScope.of(context);
    final result = await Navigator.of(context).push<Trade>(
      MaterialPageRoute(builder: (_) => TradeFormScreen(trade: trade)),
    );
    if (result != null) {
      if (trade == null) {
        await app.addTrade(result);
      } else {
        await app.updateTrade(result);
      }
    }
  }

  Future<void> _openDetails(Trade trade, String currency) =>
      Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => TradeDetailScreen(trade: trade, currency: currency),
        ),
      );

  Future<void> _delete(Trade trade) async {
    final app = AppScope.of(context);
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(tr(context, 'deleteTrade')),
        content: Text(tr(context, 'deleteTradePrompt')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(tr(context, 'cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(tr(context, 'delete')),
          ),
        ],
      ),
    );
    if (yes == true) await app.deleteTrade(trade.id);
  }


  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final account = app.accounts
        .where((item) => item.id == app.selectedAccountId)
        .firstOrNull;
    final accountTrades = account == null
        ? <Trade>[]
        : app.trades.where((trade) => trade.accountId == account.id).toList();
    final periodBounds = _selectedPeriodBounds();
    // Every count, metric and visible card is derived from this same period
    // snapshot. This prevents the selector and the summary numbers from
    // silently using different sets of trades.
    final periodTrades = accountTrades
        .where((trade) => _isWithinPeriod(trade, periodBounds))
        .toList(growable: false);
    final visible = periodTrades.where(_matchesFilter).toList()
      ..sort(compareTradesDescending);
    final metrics = TradeAnalytics.calculate(periodTrades);
    final winsCount = periodTrades
        .where((trade) => _outcomeOf(trade) == TradeClassification.win)
        .length;
    final lossesCount = periodTrades
        .where((trade) => _outcomeOf(trade) == TradeClassification.loss)
        .length;
    final breakEvenCount = periodTrades
        .where((trade) => _outcomeOf(trade) == TradeClassification.breakEven)
        .length;
    final missedCount = periodTrades
        .where((trade) => _outcomeOf(trade) == TradeClassification.missed)
        .length;
    final unclassifiedCount = periodTrades.where((trade) => trade.isUnclassified).length;
    final filterCounts = <_TradeFilter, int>{
      _TradeFilter.all: periodTrades.length,
      _TradeFilter.wins: winsCount,
      _TradeFilter.losses: lossesCount,
      _TradeFilter.breakEven: breakEvenCount,
      _TradeFilter.missed: missedCount,
    };
    final currency = account?.currency ?? 'USD';
    final header = <Widget>[];
    if (account == null) {
      header.add(
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: EmptyState(
            title: tr(context, 'noAccounts'),
            detail: tr(context, 'addFirstAccount'),
          ),
        ),
      );
    } else {
      header.addAll([
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.65,
            children: [
              MetricCard(
                key: const ValueKey('trades-net-profit-metric'),
                label: tr(context, 'netProfit'),
                value: money(metrics.netProfit, currency),
                color: metrics.netProfit > 0
                    ? TdTokens.of(context).profit
                    : metrics.netProfit < 0
                    ? TdTokens.of(context).loss
                    : TdTokens.of(context).neutral,
              ),
              MetricCard(
                key: const ValueKey('trades-win-rate-metric'),
                label: tr(context, 'winRate'),
                value: '${metrics.winRatePercent.toStringAsFixed(1)}%',
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          child: SizedBox(
            height: 48,
            child: Row(
              key: const ValueKey('trades-filter-row'),
              children: [
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, selectorConstraints) {
                      return PopupMenuButton<_TradeFilter>(
                        popUpAnimationStyle: tdPopupMenuAnimationStyle,
                        key: const ValueKey('trades-filter-menu'),
                        tooltip: tr(context, 'filter'),
                        padding: EdgeInsets.zero,
                        borderRadius: BorderRadius.circular(13),
                        position: PopupMenuPosition.under,
                        offset: const Offset(0, 8),
                        surfaceTintColor: Colors.transparent,
                        elevation: 9,
                        // Keep the popup no wider than the selector rectangle.
                        constraints: BoxConstraints.tightFor(
                          width: selectorConstraints.maxWidth,
                        ),
                        menuPadding: const EdgeInsets.symmetric(vertical: 6),
                        onSelected: (filter) => setState(() => _filter = filter),
                        itemBuilder: (menuContext) => [
                          PopupMenuItem<_TradeFilter>(
                            enabled: false,
                            height: 42,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Align(
                              alignment: AlignmentDirectional.centerStart,
                              child: Text(
                                tr(menuContext, 'tradesClassificationTitle'),
                                key: const ValueKey('trades-filter-menu-title'),
                                style: Theme.of(menuContext)
                                    .textTheme
                                    .titleSmall
                                    ?.copyWith(
                                      color: TdTokens.of(menuContext).text2,
                                      fontWeight: FontWeight.w700,
                                    ),
                              ),
                            ),
                          ),
                          const PopupMenuDivider(height: 1),
                          for (final filter in _TradeFilter.values)
                            PopupMenuItem<_TradeFilter>(
                              key: ValueKey(_filterOptionKey(filter)),
                              value: filter,
                              enabled: filter != _TradeFilter.missed,
                              height: 48,
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Builder(
                                builder: (itemContext) {
                                  final selected = filter == _filter;
                                  final tokens = TdTokens.of(itemContext);
                                  return Row(
                                    children: [
                                      SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: Center(
                                          child: selected
                                              ? Icon(
                                                  Icons.check_rounded,
                                                  size: 18,
                                                  color: tokens.text1,
                                                )
                                              : Container(
                                                  width: 9,
                                                  height: 9,
                                                  decoration: BoxDecoration(
                                                    color: _filterColor(
                                                      itemContext,
                                                      filter,
                                                    ),
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: filter == _TradeFilter.missed
                                            ? InkWell(
                                                key: const ValueKey('trades-filter-missed-select'),
                                                borderRadius: BorderRadius.circular(7),
                                                onTap: () {
                                                  setState(() {
                                                    _filter = _TradeFilter.missed;
                                                    _missedTradeFilter = _MissedTradeFilter.all;
                                                  });
                                                  Navigator.of(itemContext).pop();
                                                },
                                                child: Align(
                                                  alignment: AlignmentDirectional.centerStart,
                                                  child: Text(
                                                    _filterLabel(itemContext, filter),
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                    style: Theme.of(itemContext)
                                                        .textTheme
                                                        .bodyMedium
                                                        ?.copyWith(
                                                          color: selected
                                                              ? tokens.text1
                                                              : tokens.text2,
                                                          fontWeight: selected
                                                              ? FontWeight.w700
                                                              : FontWeight.w500,
                                                        ),
                                                  ),
                                                ),
                                              )
                                            : Text(
                                                _filterLabel(itemContext, filter),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: Theme.of(itemContext)
                                                    .textTheme
                                                    .bodyMedium
                                                    ?.copyWith(
                                                      color: selected
                                                          ? tokens.text1
                                                          : tokens.text2,
                                                      fontWeight: selected
                                                          ? FontWeight.w700
                                                          : FontWeight.w500,
                                                    ),
                                              ),
                                      ),
                                      if (filter == _TradeFilter.breakEven) ...[
                                        _ClassificationSubmenuButton<_BreakEvenTradeFilter>(
                                          key: const ValueKey('trades-filter-break-even-submenu'),
                                          tooltip: tr(itemContext, 'filter'),
                                          onSelected: (selection) {
                                            setState(() {
                                              _filter = _TradeFilter.breakEven;
                                              _breakEvenTradeFilter = selection;
                                            });
                                            Navigator.of(itemContext).pop();
                                          },
                                          itemBuilder: (submenuContext) => [
                                            for (final selection in _BreakEvenTradeFilter.values)
                                              PopupMenuItem<_BreakEvenTradeFilter>(
                                                key: ValueKey('trades-break-even-subfilter-${selection.name}'),
                                                value: selection,
                                                height: 42,
                                                child: Text(
                                                  _breakEvenFilterLabel(submenuContext, selection),
                                                  style: Theme.of(submenuContext).textTheme.bodyMedium?.copyWith(
                                                        color: selection == _BreakEvenTradeFilter.all
                                                            ? tokens.text3
                                                            : tokens.text2,
                                                        fontWeight: FontWeight.w700,
                                                      ),
                                                ),
                                              ),
                                          ],
                                        ),
                                        const SizedBox(width: 8),
                                      ] else if (filter == _TradeFilter.missed) ...[
                                        _ClassificationSubmenuButton<_MissedTradeFilter>(
                                          key: const ValueKey('trades-filter-missed-submenu'),
                                          tooltip: tr(itemContext, 'filter'),
                                          onSelected: (selection) {
                                            setState(() {
                                              _filter = _TradeFilter.missed;
                                              _missedTradeFilter = selection;
                                            });
                                            // Close the parent classification popup after the nested
                                            // missed-trade filter has been chosen.
                                            Navigator.of(itemContext).pop();
                                          },
                                          itemBuilder: (submenuContext) => [
                                            for (final selection in _MissedTradeFilter.values)
                                              PopupMenuItem<_MissedTradeFilter>(
                                                key: ValueKey('trades-missed-subfilter-${selection.name}'),
                                                value: selection,
                                                height: 42,
                                                child: Text(
                                                  _missedFilterLabel(submenuContext, selection),
                                                  style: Theme.of(submenuContext).textTheme.bodyMedium?.copyWith(
                                                        color: _missedFilterColor(submenuContext, selection),
                                                        fontWeight: FontWeight.w700,
                                                      ),
                                                ),
                                              ),
                                          ],
                                        ),
                                        const SizedBox(width: 8),
                                      ] else
                                        const SizedBox(width: 12),
                                      _classificationCount(itemContext, tokens, filterCounts, filter),
                                    ],
                                  );
                                },
                              ),
                            ),
                        ],
                        child: _TradesDropdownSurface(
                          controlKey: const ValueKey('trades-filter-selector'),
                          label: _filterLabel(context, _filter),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, selectorConstraints) {
                      return PopupMenuButton<_TradePeriod>(
                        popUpAnimationStyle: tdPopupMenuAnimationStyle,
                        key: const ValueKey('trades-period-menu'),
                        tooltip: tr(context, 'equitySelectRange'),
                        padding: EdgeInsets.zero,
                        borderRadius: BorderRadius.circular(13),
                        position: PopupMenuPosition.under,
                        offset: const Offset(0, 8),
                        surfaceTintColor: Colors.transparent,
                        elevation: 9,
                        // Match the period menu width to its selector rectangle.
                        constraints: BoxConstraints.tightFor(
                          width: selectorConstraints.maxWidth,
                        ),
                        menuPadding: const EdgeInsets.symmetric(vertical: 6),
                        onSelected: _choosePeriod,
                        itemBuilder: (menuContext) => [
                          for (final period in _TradePeriod.values)
                            PopupMenuItem<_TradePeriod>(
                              key: ValueKey('trades-period-${period.name}'),
                              value: period,
                              height: 46,
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 20,
                                    child: period == _period
                                        ? Icon(
                                            Icons.check_rounded,
                                            size: 17,
                                            color: TdTokens.of(menuContext).text1,
                                          )
                                        : null,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      _periodLabel(menuContext, period),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                        child: _TradesDropdownSurface(
                          controlKey: const ValueKey('trades-period-selector'),
                          label: _periodLabel(context, _period),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        if (unclassifiedCount > 0)
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(14, 0, 14, 6),
            child: Text(
              '$unclassifiedCount ${tr(context, 'unclassifiedTradeHint')}',
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: TdTokens.of(context).text3,
              ),
            ),
          ),
      ]);
    }

    final visibleCount = account == null
        ? 0
        : visible.isEmpty
        ? 1
        : visible.length;
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(
          child: NotificationListener<ScrollNotification>(
            onNotification: _handleListScroll,
            child: ListView.builder(
              key: const ValueKey('trades-list'),
              // Leave scrollable clearance for the floating control without
              // reserving a footer strip or reducing the list viewport.
              padding: const EdgeInsets.only(bottom: 76),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              itemCount: header.length + visibleCount,
              itemBuilder: (context, index) {
                if (index < header.length) return header[index];
                if (visible.isEmpty) {
                  return EmptyState(
                    title: tr(context, 'noTrades'),
                    detail: tr(context, 'addFirstTrade'),
                    action: FilledButton.icon(
                      onPressed: () => _openForm(),
                      icon: const Icon(Icons.add),
                      label: Text(tr(context, 'addTrade')),
                      style: FilledButton.styleFrom(
                        backgroundColor: TdTokens.of(context).surface3,
                        foregroundColor: TdTokens.of(context).text1,
                        side: BorderSide(
                          color: TdTokens.of(context).lineStrong,
                          width: 0.8,
                        ),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(13),
                        ),
                      ),
                    ),
                  );
                }
                final trade = visible[index - header.length];
                return Padding(
                  padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
                  child: _TradeSummaryCard(
                    trade: trade,
                    currency: currency,
                    onOpen: () => _openDetails(trade, currency),
                    onEdit: () => _openForm(trade: trade),
                    onDelete: () => _delete(trade),
                    onStrategyAdherenceChanged: (value) =>
                        app.updateTrade(trade.withStrategyAdherence(value)),
                  ),
                );
              },
            ),
          ),
        ),
        if (account != null)
          Positioned(
            left: 14,
            bottom: 14,
            child: AnimatedOpacity(
              key: const ValueKey('trades-add-floating-opacity'),
              opacity: _fabOpacity,
              duration: const Duration(milliseconds: 180),
              curve: Curves.easeOutCubic,
              child: FloatingActionButton.small(
                key: const ValueKey('trades-add-floating'),
                heroTag: 'trades-add-floating',
                onPressed: () => _openForm(),
                tooltip: tr(context, 'addTrade'),
                backgroundColor: TdTokens.of(context).surface3,
                foregroundColor: TdTokens.of(context).text1,
                elevation: 2,
                highlightElevation: 3,
                shape: CircleBorder(
                  side: BorderSide(
                    color: TdTokens.of(context).lineStrong,
                    width: 0.8,
                  ),
                ),
                child: const Icon(Icons.add_rounded, size: 21),
              ),
            ),
          ),
      ],
    );
  }
}

/// Small "tune" button shown next to a classification row of the filter popup.
///
/// Both the break-even and the missed rows use this single widget, so the
/// geometry (28x32 hit area, 16dp glyph) and the colour are identical. The
/// missed row is a disabled [PopupMenuItem] (its label owns its own tap target)
/// and Flutter dims icons inside disabled menu items; the effective colour is
/// therefore resolved here explicitly and the inherited icon opacity is reset,
/// so the tone no longer depends on whether the host row is enabled.
class _ClassificationSubmenuButton<T> extends StatelessWidget {
  const _ClassificationSubmenuButton({
    super.key,
    required this.tooltip,
    required this.itemBuilder,
    required this.onSelected,
  });

  final String tooltip;
  final PopupMenuItemBuilder<T> itemBuilder;
  final PopupMenuItemSelected<T> onSelected;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final dark = Theme.of(context).brightness == Brightness.dark;
    // Same tone the missed row has always rendered (Flutter's disabled-item
    // icon opacity: 0.5 in dark mode, 0.38 in light mode).
    final iconColor = tokens.text3.withValues(
      alpha: tokens.text3.a * (dark ? .5 : .38),
    );
    return PopupMenuButton<T>(
      tooltip: tooltip,
      padding: EdgeInsets.zero,
      popUpAnimationStyle: tdPopupMenuAnimationStyle,
      offset: const Offset(0, 6),
      surfaceTintColor: Colors.transparent,
      elevation: 8,
      onSelected: onSelected,
      itemBuilder: itemBuilder,
      child: IconTheme.merge(
        data: const IconThemeData(opacity: 1),
        child: SizedBox(
          key: const ValueKey('trades-filter-submenu-glyph'),
          width: 28,
          height: 32,
          child: Icon(Icons.tune_rounded, size: 16, color: iconColor),
        ),
      ),
    );
  }
}

class _TradesDropdownSurface extends StatelessWidget {
  const _TradesDropdownSurface({
    required this.controlKey,
    required this.label,
  });

  final Key controlKey;
  final String label;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    return Container(
      key: controlKey,
      height: 48,
      padding: const EdgeInsetsDirectional.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: tokens.surface3,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: tokens.lineStrong, width: 0.8),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.start,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: tokens.text1,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Icon(
            Icons.keyboard_arrow_down_rounded,
            size: 21,
            color: tokens.text2,
          ),
        ],
      ),
    );
  }
}

class _TradeSummaryCard extends StatelessWidget {
  const _TradeSummaryCard({
    required this.trade,
    required this.currency,
    required this.onOpen,
    required this.onEdit,
    required this.onDelete,
    required this.onStrategyAdherenceChanged,
  });

  final Trade trade;
  final String currency;
  final VoidCallback onOpen;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final ValueChanged<StrategyAdherence> onStrategyAdherenceChanged;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final outcome = _outcomeOf(trade);
    final resultColor = _classificationColor(context, outcome);
    final resultDeep = switch (outcome) {
      TradeClassification.win => tokens.profitDeep,
      TradeClassification.loss => tokens.lossDeep,
      TradeClassification.breakEven => TradeOutcomePalette.breakEven(Theme.of(context).brightness),
      TradeClassification.missed => TradeOutcomePalette.missed(Theme.of(context).brightness),
      null => tokens.text3,
    };
    final localTradedAt = trade.tradedAt.toLocal();
    final tradedTime = TimeOfDay.fromDateTime(localTradedAt).format(context);
    final confirmation = trade.effectiveConfirmationSetups
        .map((setup) {
          final displayKey = tradeConfirmationDisplayKey(
            type: setup.type,
            side: trade.side,
          );
          final type = displayKey == 'confirmEngulfing'
              ? 'Engulfing'
              : tr(context, displayKey);
          return setup.timeframe.isEmpty ? type : '$type ${setup.timeframe}';
        })
        .join('، ');
    final info = <(String, String)>[
      if (confirmation.isNotEmpty) (tr(context, 'confirmation'), confirmation),
      if (trade.mood.isNotEmpty) (tr(context, 'mood'), tr(context, trade.mood)),
    ];
    return AppCard(
      key: ValueKey('trade-summary-${trade.id}'),
      onTap: onOpen,
      padding: EdgeInsets.zero,
      variant: AppCardVariant.tint,
      tintColor: resultColor,
      tintBorderAlpha: .12,
      child: Stack(
        children: [
          PositionedDirectional(
            start: 0,
            top: 14,
            bottom: 14,
            width: 3,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(99),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [resultDeep, resultDeep.withValues(alpha: 0.4)],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(14, 12, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Wrap(
                            spacing: 8,
                            runSpacing: 2,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                trade.market,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w700,
                                    ),
                              ),
                              StrategyAdherenceChip(
                                value: trade.strategyAdherence,
                                onChanged: onStrategyAdherenceChanged,
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              if (outcome != null) ...[
                                _TradeClassificationIndicator(
                                  tradeId: trade.id,
                                  classification: outcome,
                                  color: resultColor,
                                ),
                                const SizedBox(width: 6),
                              ],
                              Flexible(
                                child: Text(
                                  '${shortDate(localTradedAt)} · $tradedTime',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.labelSmall
                                      ?.copyWith(
                                        color: resultColor,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 132),
                      child: Container(
                        height: 34,
                        padding: const EdgeInsetsDirectional.fromSTEB(
                          8,
                          0,
                          9,
                          0,
                        ),
                        decoration: BoxDecoration(
                          color: resultColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: resultColor.withValues(alpha: 0.15),
                            width: 0.8,
                          ),
                        ),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: AlignmentDirectional.centerStart,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                trade.result > 0
                                    ? Icons.arrow_upward_rounded
                                    : trade.result < 0
                                    ? Icons.arrow_downward_rounded
                                    : Icons.remove_rounded,
                                size: 15,
                                color: resultColor,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                money(trade.result, currency),
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w700,
                                      color: resultColor,
                                      fontFeatures: const [
                                        FontFeature.tabularFigures(),
                                      ],
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    PopupMenuButton<String>(
                      popUpAnimationStyle: tdPopupMenuAnimationStyle,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(
                        minWidth: 40,
                        minHeight: 40,
                      ),
                      iconSize: 22,
                      onSelected: (value) {
                        if (value == 'edit') onEdit();
                        if (value == 'delete') onDelete();
                      },
                      itemBuilder: (_) => [
                        PopupMenuItem(
                          value: 'edit',
                          child: Text(tr(context, 'edit')),
                        ),
                        PopupMenuItem(
                          value: 'delete',
                          child: Text(tr(context, 'delete')),
                        ),
                      ],
                    ),
                  ],
                ),
                const Divider(height: 18),
                if (trade.executionJournal.isNotEmpty ||
                    trade.effectiveEntrySetups.isNotEmpty)
                  LayoutBuilder(
                    builder: (context, constraints) {
                      if (trade.executionJournal.isNotEmpty &&
                          trade.effectiveEntrySetups.isNotEmpty) {
                        final journalWidth = (constraints.maxWidth * 0.42)
                            .clamp(108.0, 150.0);
                        return Row(
                          textDirection: TextDirection.ltr,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              key: ValueKey('trade-journal-icons-${trade.id}'),
                              width: journalWidth,
                              child: Directionality(
                                textDirection: TextDirection.ltr,
                                child: TradeExecutionJournalSummary(
                                  entries: trade.executionJournal,
                                  compact: true,
                                  iconSize: 32,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: SizedBox(
                                key: ValueKey('trade-entry-setups-${trade.id}'),
                                child: TradeEntrySetupChips(
                                  label: tr(context, 'entryReason'),
                                  setups: trade.effectiveEntrySetups,
                                  side: trade.side,
                                  compact: true,
                                  showLabel: false,
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                      if (trade.executionJournal.isNotEmpty) {
                        return SizedBox(
                          key: ValueKey('trade-journal-icons-${trade.id}'),
                          width: double.infinity,
                          child: Directionality(
                            textDirection: TextDirection.ltr,
                            child: TradeExecutionJournalSummary(
                              entries: trade.executionJournal,
                              compact: true,
                              iconSize: 32,
                            ),
                          ),
                        );
                      }
                      return SizedBox(
                        key: ValueKey('trade-entry-setups-${trade.id}'),
                        width: double.infinity,
                        child: TradeEntrySetupChips(
                          label: tr(context, 'entryReason'),
                          setups: trade.effectiveEntrySetups,
                          side: trade.side,
                          compact: true,
                          showLabel: false,
                        ),
                      );
                    },
                  ),
                if (info.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  for (final (label, value) in info)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 3),
                      child: Row(
                        children: [
                          Text(
                            '$label: ',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: tokens.text3),
                          ),
                          Expanded(
                            child: Text(
                              value,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.labelMedium
                                  ?.copyWith(color: tokens.text1),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TradeDetailScreen extends StatelessWidget {
  const TradeDetailScreen({
    super.key,
    required this.trade,
    required this.currency,
  });

  final Trade trade;
  final String currency;

  String _entryConditionLabel(
    BuildContext context,
    TradeEntryConditionSetup setup,
    List<TradeEntryOption> options,
  ) {
    return _savedEntryConditionLabel(context, setup, options, trade.side);
  }

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final softenedTokens = tokens.copyWith(
      lineSubtle: tokens.lineSubtle.withValues(alpha: .68),
      lineStrong: tokens.lineStrong.withValues(alpha: .54),
    );
    final arabic = AppStrings.isArabic(context);
    final resultColor = _classificationColor(context, trade.effectiveClassification);
    final expectedLoss = trade.expectedLoss;
    final rewardRisk = expectedLoss != null && expectedLoss > 0
        ? '${(trade.result / expectedLoss).toStringAsFixed(2)}R'
        : '—';
    final tradedTime = TimeOfDay.fromDateTime(trade.tradedAt).format(context);
    final entryReasonLabels = trade.effectiveEntrySetups
        .map((setup) {
          final label = formatTradeEntryReasonLabel(
            reason: setup.reason,
            side: trade.side,
          );
          return setup.timeframe.isEmpty
              ? label
              : '$label ${setup.timeframe}';
        })
        .where((label) => label.trim().isNotEmpty)
        .toList(growable: false);
    final reverseSignalLabels = trade.reverseSignalSetups
        .map((setup) => _entryConditionLabel(context, setup, tradeReverseSignalOptions))
        .toList(growable: false);
    final bounceZoneLabels = trade.bounceZoneSetups
        .map((setup) => _entryConditionLabel(context, setup, tradeBounceZoneLabelOptions))
        .toList(growable: false);
    // The saved Entry Conditions panel uses the same explicit visual link
    // state as the form: only a long-pressed selected opposing signal turns it
    // violet. Generic no-entry reasons still affect classification, not color.
    // Keep the prior auto-expand behavior for any no-entry evidence, while
    // limiting the violet visual treatment to an explicitly long-pressed
    // selected opposing signal.
    final entryConditionsHasNoEntryReason = trade.hasNoEntryEntryConditionLink;
    final entryConditionsLinkedToNoEntry = trade.hasPracticalNoEntryReason;
    final reverseSignalsLinkedToNoEntry = trade.hasPracticalNoEntryReason;
    final entryConditionsTone = entryConditionsLinkedToNoEntry
        ? TradeDetailPalette.noEntryTone
        : TradeDetailPalette.entryConditionsTone;
    final confirmationLabels = trade.effectiveConfirmationSetups
        .map((setup) {
          final displayKey = tradeConfirmationDisplayKey(
            type: setup.type,
            side: trade.side,
          );
          final type = displayKey == 'confirmEngulfing'
              ? 'Engulfing'
              : tr(context, displayKey);
          return setup.timeframe.isEmpty ? type : '$type ${setup.timeframe}';
        })
        .where((label) => label.trim().isNotEmpty)
        .toList(growable: false);
    final secondaryDataRows = <({
      String label,
      String value,
      IconData? icon,
      bool ltr,
    })>[
      if (trade.sequence.isNotEmpty)
        (
          label: tr(context, 'sequence'),
          value: trade.sequence,
          icon: Icons.timeline_rounded,
          ltr: false,
        ),
      if (trade.strategyAdherence != null)
        (
          label: arabic ? 'الالتزام بالخطة' : 'Plan adherence',
          value: trade.strategyAdherence == StrategyAdherence.followed
              ? (arabic ? 'ملتزم' : 'Followed')
              : (arabic ? 'لم ألتزم' : 'Not followed'),
          icon: null,
          ltr: false,
        ),
    ];
    final selectedAnchors = trade.effectiveAnchors.map((key) {
      final label = formatTradeAnchorLabel(
        anchorKey: key,
        arabic: arabic,
        side: trade.side,
      );
      final timeframe = trade.anchorTimeframes[key];
      return timeframe == null ? label : '$label $timeframe';
    }).toList(growable: false);
    // Keep the gallery order aligned with the trader's review sequence:
    // before entry -> after entry -> entry confirmation.
    final images = <TradeImageItem>[
      if (trade.beforeImagePath != null)
        TradeImageItem(
          path: trade.beforeImagePath!,
          label: tr(context, 'beforeImage'),
          fileNamePrefix: 'traderdesk_before_${trade.id}',
        ),
      if (trade.afterImagePath != null)
        TradeImageItem(
          path: trade.afterImagePath!,
          label: tr(context, 'afterImage'),
          fileNamePrefix: 'traderdesk_after_${trade.id}',
        ),
      if (trade.confirmationImagePath != null)
        TradeImageItem(
          path: trade.confirmationImagePath!,
          label: tr(context, 'confirmationImage'),
          fileNamePrefix: 'traderdesk_confirmation_${trade.id}',
        ),
    ];

    const resultTone = Color(0xFF9BA9B9);
    final brightness = Theme.of(context).brightness;
    final dataTone = TradeDetailPalette.dataToneFor(brightness);
    final dataValueColor = TradeDetailPalette.dataValueTone(brightness);
    final dataEdge = brightness == Brightness.dark
        ? TradeDetailPalette.dataFieldEdgeDark
        : TradeDetailPalette.entryConditionsFieldEdge;
    const imageTone = Color(0xFF9AA3AD);
    final resultSurface = tokens.surface2;
    final resultField = tokens.inset;
    const dataSurface = TradeDetailPalette.dataSurfaceDark;
    const dataField = TradeDetailPalette.dataFieldDark;

    final dataPanelChildren = <Widget>[];
    void appendDataField(Widget field) {
      if (dataPanelChildren.isNotEmpty) {
        dataPanelChildren.add(const SizedBox(height: 8));
      }
      dataPanelChildren.add(field);
    }

    // Saved details follow the requested hierarchy:
    // market/direction beside mindset, then entry reason, anchor,
    // confirmation, and finally the trade timestamp.
    final marketDirectionField = _TradeDetailMarketDirectionField(
      key: const ValueKey('trade-detail-market-direction-field'),
      edgeOpacity: 1,
      marketLabel: arabic ? 'السوق' : 'Market',
      directionLabel: arabic ? 'الاتجاه' : 'Direction',
      market: trade.market,
      direction: tr(context, trade.side == TradeSide.buy ? 'buy' : 'sell'),
      fill: dataField,
      edge: dataEdge,
      tone: dataTone,
      valueDirection: TextDirection.ltr,
      valueColor: dataValueColor,
    );
    final mindsetField = trade.mood.isNotEmpty && trade.mood != 'moodUnknown'
        ? _TradeDetailMindsetField(
            key: const ValueKey('trade-detail-mindset'),
            edgeOpacity: 1,
            label: tr(context, 'mood'),
            value: tr(context, trade.mood),
            fill: dataField,
            edge: dataEdge,
            tone: dataTone,
            valueColor: dataValueColor,
          )
        : null;

    appendDataField(
      mindsetField == null
          ? marketDirectionField
          : _TradeDetailPair(
              key: const ValueKey('trade-detail-market-mindset-pair'),
              first: marketDirectionField,
              second: mindsetField,
            ),
    );

    if (entryReasonLabels.isNotEmpty) {
      appendDataField(
        _TradeDetailChipField(
          key: const ValueKey('trade-detail-entry-reasons'),
          edgeOpacity: 1,
          label: tr(context, 'entryReason'),
          values: entryReasonLabels,
          fill: dataField,
          edge: dataEdge,
          tone: dataTone,
          optionFill: TradeDetailPalette.dataChipDark,
          optionEdge: TradeDetailPalette.dataChipEdgeDark,
          optionTextColor: dataValueColor,
        ),
      );
    }

    if (selectedAnchors.isNotEmpty) {
      appendDataField(
        _TradeDetailChipField(
          key: const ValueKey('trade-detail-anchor'),
          edgeOpacity: 1,
          label: arabic ? 'الارتكاز' : 'Anchor',
          values: selectedAnchors,
          fill: dataField,
          edge: dataEdge,
          tone: dataTone,
          optionFill: TradeDetailPalette.dataChipDark,
          optionEdge: TradeDetailPalette.dataChipEdgeDark,
          optionTextColor: dataValueColor,
        ),
      );
    }

    if (confirmationLabels.isNotEmpty) {
      appendDataField(
        _TradeDetailChipField(
          key: const ValueKey('trade-detail-confirmations'),
          edgeOpacity: 1,
          label: tr(context, 'confirmation'),
          values: confirmationLabels,
          fill: dataField,
          edge: dataEdge,
          tone: dataTone,
          optionFill: TradeDetailPalette.dataChipDark,
          optionEdge: TradeDetailPalette.dataChipEdgeDark,
          optionTextColor: dataValueColor,
        ),
      );
    }

    appendDataField(
      _TradeDetailRow(
        key: const ValueKey('trade-detail-traded-at'),
        edgeOpacity: 1,
        label: arabic ? 'تاريخ / الوقت' : 'Date / time',
        value: '${shortDate(trade.tradedAt)} · $tradedTime',
        icon: null,
        fill: dataField,
        edge: dataEdge,
        labelTone: dataTone,
        valueColor: dataValueColor,
        emphasizeLabel: true,
        valueLtr: false,
      ),
    );

    // Keep the existing optional metadata without interrupting the requested
    // primary information sequence.
    for (final row in secondaryDataRows) {
      appendDataField(
        _TradeDetailRow(
          label: row.label,
          value: row.value,
          icon: row.icon,
          fill: dataField,
          edge: dataEdge,
          edgeOpacity: 1,
          labelTone: dataTone,
          valueColor: dataValueColor,
          emphasizeLabel: true,
          valueLtr: row.ltr,
        ),
      );
    }

    return Theme(
      data: Theme.of(context).copyWith(
        dividerColor: softenedTokens.lineSubtle,
        extensions: [softenedTokens],
      ),
      child: Scaffold(
        appBar: AppBar(title: Text(tr(context, 'tradeDetails'))),
        body: ListView(
          key: const ValueKey('trade-detail-scroll-view'),
          padding: const EdgeInsetsDirectional.fromSTEB(8, 10, 8, 24),
          children: [
            _TradeDetailPanel(
              key: const ValueKey('trade-detail-result-panel'),
              title: arabic ? 'النتيجة والمخاطرة' : 'Result & risk',
              icon: Icons.tune_rounded,
              tone: resultTone,
              darkSurface: resultSurface,
              collapsible: true,
              toggleKey: const ValueKey('trade-detail-result-panel-toggle'),
              summary: '${_classificationLabel(context, trade.effectiveClassification)} · ${money(trade.result, currency)} · ${trade.riskPercent.toStringAsFixed(2)}% · $rewardRisk',
              child: Column(
                children: [
                  if (expectedLoss != null)
                    _TradeDetailPair(
                      key: const ValueKey('trade-detail-result-expected-loss-pair'),
                      first: _TradeDetailRow(
                        key: const ValueKey('trade-detail-result-value'),
                        label: tr(context, 'result'),
                        value: money(trade.result, currency),
                        icon: Icons.calculate_outlined,
                        fill: resultField,
                        edge: const Color(0xFF4A515B),
                        labelTone: resultTone,
                        valueColor: resultColor,
                        valueLtr: true,
                      ),
                      second: _TradeDetailRow(
                        key: const ValueKey('trade-detail-expected-loss-value'),
                        label: tr(context, 'expectedLoss'),
                        value: money(expectedLoss, currency),
                        icon: Icons.south_rounded,
                        fill: resultField,
                        edge: const Color(0xFF4A515B),
                        labelTone: resultTone,
                        valueLtr: true,
                      ),
                    )
                  else
                    _TradeDetailRow(
                      key: const ValueKey('trade-detail-result-value'),
                      label: tr(context, 'result'),
                      value: money(trade.result, currency),
                      icon: Icons.calculate_outlined,
                      fill: resultField,
                      edge: const Color(0xFF4A515B),
                      labelTone: resultTone,
                      valueColor: resultColor,
                      valueLtr: true,
                    ),
                  const SizedBox(height: 8),
                  _TradeDetailPair(
                    key: const ValueKey('trade-detail-risk-reward-pair'),
                    first: _TradeDetailRow(
                      key: const ValueKey('trade-detail-risk-percent-value'),
                      label: tr(context, 'riskPercent'),
                      value: '${trade.riskPercent.toStringAsFixed(2)}%',
                      icon: Icons.pie_chart_outline_rounded,
                      fill: resultField,
                      edge: const Color(0xFF4A515B),
                      labelTone: resultTone,
                      valueLtr: true,
                    ),
                    second: _TradeDetailRow(
                      key: const ValueKey('trade-detail-reward-risk-value'),
                      label: tr(context, 'rewardRisk'),
                      value: rewardRisk,
                      icon: Icons.flag_outlined,
                      fill: resultField,
                      edge: const Color(0xFF4A515B),
                      labelTone: resultTone,
                      valueColor: expectedLoss != null && expectedLoss > 0
                          ? (trade.result / expectedLoss >= 1
                                ? const Color(0xFF79C9A4)
                                : const Color(0xFFE3A0A0))
                          : tokens.text2,
                      valueLtr: true,
                    ),
                  ),
                ],
              ),
            ),
            if (images.isNotEmpty) ...[
              const SizedBox(height: 10),
              _TradeDetailPanel(
                title: arabic ? 'صور الصفقة' : 'Trade images',
                icon: Icons.photo_library_outlined,
                tone: imageTone,
                darkSurface: tokens.surface2,
                collapsible: true,
                initiallyExpanded: true,
                toggleKey: const ValueKey('trade-detail-images-panel-toggle'),
                summary: '${images.length} ${arabic ? 'صور' : 'images'}',
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final width = (constraints.maxWidth - 8) / 2;
                    return Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final image in images)
                          SizedBox(
                            width: width,
                            child: TradeImagePreview(
                              path: image.path,
                              label: image.label,
                              fileNamePrefix: image.fileNamePrefix,
                              height: 128,
                              galleryImages: images,
                              tradedAt: trade.tradedAt,
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ],
            const SizedBox(height: 10),
            _TradeDetailPanel(
              key: const ValueKey('trade-detail-data-panel'),
              title: arabic ? 'بيانات الصفقة' : 'Trade details',
              icon: Icons.receipt_long_outlined,
              tone: dataTone,
              darkSurface: dataSurface,
              darkBorder: TradeDetailPalette.dataPanelBorderDark,
              darkDivider: TradeDetailPalette.dataPanelBorderDark,
              iconSurfaceDark: TradeDetailPalette.dataPanelIconSurfaceDark,
              collapsible: true,
              initiallyExpanded: false,
              toggleKey: const ValueKey('trade-detail-data-panel-toggle'),
              summary: '${trade.market} · ${tr(context, trade.side == TradeSide.buy ? 'buy' : 'sell')}',
              child: Column(children: dataPanelChildren),
            ),
            if (reverseSignalLabels.isNotEmpty || bounceZoneLabels.isNotEmpty) ...[
              const SizedBox(height: 10),
              _TradeDetailPanel(
                key: const ValueKey('trade-detail-entry-conditions-panel'),
                title: arabic ? 'ظروف الدخول' : 'Entry conditions',
                icon: Icons.radar_rounded,
                tone: entryConditionsTone,
                darkSurface: entryConditionsLinkedToNoEntry
                    ? TradeDetailPalette.reviewNoEntryDark
                    : TradeDetailPalette.entryConditionsPanelDark,
                darkBorder: entryConditionsLinkedToNoEntry
                    ? TradeDetailPalette.linkedEntryConditionsPanelBorderDark
                    : null,
                darkDivider: entryConditionsLinkedToNoEntry
                    ? TradeDetailPalette.linkedEntryConditionsPanelDividerDark
                    : null,
                collapsible: true,
                initiallyExpanded: entryConditionsHasNoEntryReason,
                horizontalPadding: 6,
                toggleKey: const ValueKey('trade-detail-entry-conditions-toggle'),
                surfaceKey: const ValueKey('trade-detail-entry-conditions-panel-surface'),
                summary: '${reverseSignalLabels.length + bounceZoneLabels.length} ${arabic ? 'اختيارات' : 'selections'}',
                child: Column(
                  children: [
                    if (reverseSignalLabels.isNotEmpty)
                      _TradeDetailChipField(
                        key: const ValueKey('trade-detail-reverse-signals'),
                        edgeOpacity: .18,
                        label: arabic ? 'إشارات عكسية' : 'Opposing signals',
                        values: reverseSignalLabels,
                        fill: reverseSignalsLinkedToNoEntry
                            ? TradeDetailPalette.linkedEntryConditionsFieldDark
                            : TradeDetailPalette.entryConditionsFieldDark,
                        edge: reverseSignalsLinkedToNoEntry
                            ? TradeDetailPalette.linkedEntryConditionsFieldEdge
                            : TradeDetailPalette.entryConditionsFieldEdge,
                        tone: reverseSignalsLinkedToNoEntry
                            ? TradeDetailPalette.noEntryTone
                            : const Color(0xFF6E9FB6),
                        headingTone: reverseSignalsLinkedToNoEntry
                            ? TradeDetailPalette.noEntryTone
                            : TradeDetailPalette.entryConditionsLabelTone(
                                Theme.of(context).brightness,
                              ),
                        optionFill: reverseSignalsLinkedToNoEntry
                            ? TradeDetailPalette.linkedEntryConditionsChipDark
                            : TradeDetailPalette.entryConditionsChipDark,
                        optionEdge: reverseSignalsLinkedToNoEntry
                            ? TradeDetailPalette.linkedEntryConditionsChipEdgeDark
                            : TradeDetailPalette.entryConditionsChipEdgeDark,
                      ),
                    if (reverseSignalLabels.isNotEmpty && bounceZoneLabels.isNotEmpty)
                      const SizedBox(height: 8),
                    if (bounceZoneLabels.isNotEmpty)
                      _TradeDetailChipField(
                        key: const ValueKey('trade-detail-bounce-zone'),
                        edgeOpacity: .18,
                        label: arabic ? 'منطقة الارتداد' : 'Bounce area',
                        values: bounceZoneLabels,
                        // Only the opposing-signal field carries the practical
                        // no-entry violet state. Bounce area remains in its
                        // established blue palette even when both are present.
                        fill: TradeDetailPalette.entryConditionsFieldDark,
                        edge: TradeDetailPalette.entryConditionsFieldEdge,
                        tone: const Color(0xFF83B7C9),
                        headingTone: TradeDetailPalette.entryConditionsLabelTone(
                          Theme.of(context).brightness,
                        ),
                        optionFill: TradeDetailPalette.entryConditionsChipDark,
                        optionEdge: TradeDetailPalette.entryConditionsChipEdgeDark,
                      ),
                  ],
                ),
              ),
            ],
            if (trade.executionJournal.isNotEmpty) ...[
              const SizedBox(height: 10),
              _TradeDetailPanel(
                key: const ValueKey('trade-detail-execution-panel'),
                title: arabic ? 'سجل التنفيذ' : 'Execution log',
                icon: Icons.track_changes_outlined,
                tone: const Color(0xFF8CA8C8),
                darkSurface: tokens.surface2,
                collapsible: true,
                initiallyExpanded: false,
                toggleKey: const ValueKey('trade-detail-execution-panel-toggle'),
                summary: '${trade.executionJournal.length} ${arabic ? 'إجراءات' : 'entries'}',
                child: TradeExecutionJournalSummary(
                  entries: trade.executionJournal,
                  showHeading: false,
                  iconSize: 34,
                ),
              ),
            ],
            if (trade.executionReviewKeys.isNotEmpty ||
                trade.noEntryReasons.isNotEmpty) ...[
              const SizedBox(height: 10),
              TradeBehaviorSummary(trade: trade, initiallyExpanded: false),
            ],
            if (trade.notes.isNotEmpty) ...[
              const SizedBox(height: 10),
              _TradeDetailPanel(
                key: const ValueKey('trade-detail-notes-panel'),
                title: tr(context, 'notes'),
                icon: Icons.notes_rounded,
                tone: const Color(0xFF8FA3B8),
                darkSurface: tokens.surface2,
                collapsible: true,
                initiallyExpanded: false,
                toggleKey: const ValueKey('trade-detail-notes-panel-toggle'),
                summary: trade.notes.replaceAll('\n', ' '),
                child: _TradeTextBlock(value: trade.notes),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _TradeDetailPanel extends StatefulWidget {
  const _TradeDetailPanel({
    super.key,
    required this.title,
    required this.icon,
    required this.tone,
    required this.darkSurface,
    required this.child,
    this.collapsible = false,
    this.initiallyExpanded = true,
    this.toggleKey,
    this.summary,
    this.horizontalPadding = 6,
    this.surfaceKey,
    this.darkBorder,
    this.darkDivider,
    this.iconSurfaceDark,
  });

  final String title;
  final IconData icon;
  final Color tone;
  final Color darkSurface;
  final Widget child;
  final bool collapsible;
  final bool initiallyExpanded;
  final Key? toggleKey;
  final String? summary;
  final double horizontalPadding;
  final Key? surfaceKey;
  final Color? darkBorder;
  final Color? darkDivider;
  final Color? iconSurfaceDark;

  @override
  State<_TradeDetailPanel> createState() => _TradeDetailPanelState();
}

class _TradeDetailPanelState extends State<_TradeDetailPanel> {
  late bool _expanded = widget.initiallyExpanded;

  @override
  void didUpdateWidget(covariant _TradeDetailPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initiallyExpanded != widget.initiallyExpanded) {
      _expanded = widget.initiallyExpanded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final reduceMotion = MediaQuery.disableAnimationsOf(context);
    final surface = isDark
        ? widget.darkSurface
        : Color.alphaBlend(widget.tone.withValues(alpha: .075), tokens.surface1);

    final headerIcon = isDark && widget.iconSurfaceDark != null
        ? Container(
            key: const ValueKey('trade-detail-data-panel-icon-surface'),
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: widget.iconSurfaceDark,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(widget.icon, size: 21, color: widget.tone),
          )
        : Icon(widget.icon, size: 21, color: widget.tone);

    final header = Semantics(
      button: widget.collapsible,
      expanded: widget.collapsible ? _expanded : null,
      label: widget.title,
      child: InkWell(
        key: widget.collapsible
            ? (widget.toggleKey ?? const ValueKey('trade-detail-panel-toggle'))
            : null,
        onTap: widget.collapsible
            ? () => setState(() => _expanded = !_expanded)
            : null,
        borderRadius: BorderRadius.circular(9),
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: widget.collapsible ? 2 : 0,
            vertical: widget.collapsible ? 3 : 0,
          ),
          child: Row(
            children: [
              headerIcon,
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.title,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: tokens.text1,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    if (widget.collapsible && !_expanded &&
                        (widget.summary?.trim().isNotEmpty ?? false)) ...[
                      const SizedBox(height: 2),
                      Text(
                        widget.summary!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: tokens.text3,
                          height: 1.25,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (widget.collapsible) ...[
                const SizedBox(width: 6),
                AnimatedRotation(
                  turns: _expanded ? .5 : 0,
                  duration: reduceMotion
                      ? Duration.zero
                      : const Duration(milliseconds: 180),
                  child: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    size: 23,
                    color: widget.tone,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );

    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Divider(
          height: 1,
          color: isDark
              ? (widget.darkDivider ?? widget.tone.withValues(alpha: .16))
              : widget.tone.withValues(alpha: .16),
        ),
        const SizedBox(height: 10),
        widget.child,
      ],
    );

    return Container(
      key: widget.surfaceKey,
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: widget.horizontalPadding,
        vertical: 11,
      ),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark
              ? (widget.darkBorder ?? widget.tone.withValues(alpha: .16))
              : widget.tone.withValues(alpha: .12),
          width: 0.8,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          header,
          if (widget.collapsible)
            AnimatedSize(
              duration: reduceMotion
                  ? Duration.zero
                  : const Duration(milliseconds: 190),
              curve: Curves.easeInOutCubic,
              alignment: Alignment.topCenter,
              child: _expanded ? body : const SizedBox.shrink(),
            )
          else ...[
            const SizedBox(height: 10),
            body,
          ],
        ],
      ),
    );
  }
}

class _TradeDetailPair extends StatelessWidget {
  const _TradeDetailPair({
    super.key,
    required this.first,
    required this.second,
  });

  final Widget first;
  final Widget second;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: first),
        const SizedBox(width: 8),
        Expanded(child: second),
      ],
    );
  }
}

class _TradeDetailMarketDirectionField extends StatelessWidget {
  const _TradeDetailMarketDirectionField({
    super.key,
    required this.marketLabel,
    required this.directionLabel,
    required this.market,
    required this.direction,
    required this.fill,
    required this.edge,
    required this.tone,
    required this.valueDirection,
    this.valueColor,
    this.edgeOpacity = .24,
  });

  final String marketLabel;
  final String directionLabel;
  final String market;
  final String direction;
  final Color fill;
  final Color edge;
  final Color tone;
  final TextDirection valueDirection;
  final Color? valueColor;
  final double edgeOpacity;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final headingStyle = _tradeSectionHeadingStyle(
      context,
      color: TradeDetailPalette.dataLabelTone(Theme.of(context).brightness),
    );
    final valueStyle = Theme.of(context).textTheme.bodyMedium?.copyWith(
      color: valueColor ?? tokens.text1,
      fontWeight: FontWeight.w700,
      fontSize: _savedTradeDetailValueFontSize,
      height: 1.15,
    );

    return Container(
      key: const ValueKey('trade-detail-market-direction-surface'),
      width: double.infinity,
      constraints: const BoxConstraints(minHeight: 54),
      padding: const EdgeInsetsDirectional.fromSTEB(9, 7, 9, 6),
      decoration: BoxDecoration(
        color: isDark
            ? fill
            : Color.alphaBlend(tone.withValues(alpha: .045), tokens.surface2),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: edge.withValues(alpha: isDark ? edgeOpacity : .17),
          width: .8,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            height: 18,
            child: Center(
              child: Text(
                '$marketLabel / $directionLabel',
                key: const ValueKey('trade-detail-market-direction-heading'),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: headingStyle,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Row(
            children: [
              Expanded(
                child: Directionality(
                  textDirection: valueDirection,
                  child: Text(
                    market,
                    key: const ValueKey('trade-detail-market-symbol-value'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: valueStyle,
                  ),
                ),
              ),
              Container(
                key: const ValueKey('trade-detail-market-direction-divider'),
                width: 1,
                height: 24,
                decoration: BoxDecoration(
                  color: tone.withValues(alpha: .38),
                  borderRadius: BorderRadius.circular(1),
                ),
              ),
              Expanded(
                child: Text(
                  direction,
                  key: const ValueKey('trade-detail-market-direction-value'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: valueStyle,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TradeDetailMindsetField extends StatelessWidget {
  const _TradeDetailMindsetField({
    super.key,
    required this.label,
    required this.value,
    required this.fill,
    required this.edge,
    required this.tone,
    this.valueColor,
    this.edgeOpacity = .24,
  });

  final String label;
  final String value;
  final Color fill;
  final Color edge;
  final Color tone;
  final Color? valueColor;
  final double edgeOpacity;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final brightness = Theme.of(context).brightness;
    final isDark = brightness == Brightness.dark;
    return Container(
      key: const ValueKey('trade-detail-mindset-surface'),
      width: double.infinity,
      constraints: const BoxConstraints(minHeight: 54),
      padding: const EdgeInsetsDirectional.fromSTEB(9, 7, 9, 6),
      decoration: BoxDecoration(
        color: isDark
            ? fill
            : Color.alphaBlend(tone.withValues(alpha: .045), tokens.surface2),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: edge.withValues(alpha: isDark ? edgeOpacity : .17),
          width: .8,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 18,
            child: Center(
              child: Text(
                label,
                key: const ValueKey('trade-detail-mindset-heading'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: _tradeSectionHeadingStyle(
                  context,
                  color: TradeDetailPalette.dataLabelTone(brightness),
                ),
              ),
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 2,
            softWrap: true,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: valueColor ?? tokens.text1,
              fontWeight: FontWeight.w700,
              fontSize: _savedTradeDetailValueFontSize,
              height: 1.0,
            ),
          ),
        ],
      ),
    );
  }
}

class _TradeDetailRow extends StatelessWidget {
  const _TradeDetailRow({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.fill,
    required this.edge,
    required this.labelTone,
    this.valueColor,
    this.emphasizeLabel = false,
    this.valueLtr = false,
    this.minHeight = 54,
    this.edgeOpacity = .24,
  });

  final String label;
  final String value;
  final IconData? icon;
  final Color fill;
  final Color edge;
  final Color labelTone;
  final Color? valueColor;
  final bool emphasizeLabel;
  final bool valueLtr;
  final double minHeight;
  final double edgeOpacity;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final brightness = Theme.of(context).brightness;
    final isDark = brightness == Brightness.dark;
    final effectiveLabelTone = emphasizeLabel
        ? TradeDetailPalette.dataLabelTone(brightness)
        : labelTone;
    final background = isDark
        ? fill
        : Color.alphaBlend(labelTone.withValues(alpha: .045), tokens.surface2);
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(minHeight: minHeight),
      padding: const EdgeInsetsDirectional.fromSTEB(11, 10, 11, 10),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: edge.withValues(alpha: isDark ? edgeOpacity : .17),
          width: 0.8,
        ),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 178;
          final labelWidget = Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: emphasizeLabel
                ? _tradeSectionHeadingStyle(
                    context,
                    color: effectiveLabelTone,
                  )
                : Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: tokens.text2,
                    fontWeight: FontWeight.w600,
                  ),
          );
          final valueWidget = Directionality(
            textDirection: valueLtr
                ? TextDirection.ltr
                : Directionality.of(context),
            child: Text(
              value,
              textAlign: TextAlign.end,
              softWrap: true,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: valueColor ?? tokens.text1,
                fontWeight: FontWeight.w700,
                fontSize: _savedTradeDetailValueFontSize,
                height: 1.45,
              ),
            ),
          );

          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 17, color: labelTone),
                      const SizedBox(width: 7),
                    ],
                    Expanded(child: labelWidget),
                  ],
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: valueWidget,
                ),
              ],
            );
          }

          return Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 18, color: labelTone),
                const SizedBox(width: 9),
              ],
              Expanded(child: labelWidget),
              const SizedBox(width: 10),
              Flexible(flex: 2, child: valueWidget),
            ],
          );
        },
      ),
    );
  }
}


class _TradeDetailChipField extends StatelessWidget {
  const _TradeDetailChipField({
    super.key,
    required this.label,
    required this.values,
    this.icon,
    required this.fill,
    required this.edge,
    required this.tone,
    this.headingTone,
    this.optionFill,
    this.optionEdge,
    this.optionTextColor,
    this.edgeOpacity = .24,
    this.optionEdgeOpacity = 1,
  });

  final String label;
  final List<String> values;
  final IconData? icon;
  final Color fill;
  final Color edge;
  final Color tone;
  final Color? headingTone;
  final Color? optionFill;
  final Color? optionEdge;
  final Color? optionTextColor;
  final double edgeOpacity;
  final double optionEdgeOpacity;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final brightness = Theme.of(context).brightness;
    final isDark = brightness == Brightness.dark;
    final effectiveHeadingTone =
        headingTone ?? TradeDetailPalette.dataLabelTone(brightness);
    return Container(
      width: double.infinity,
      padding: const EdgeInsetsDirectional.fromSTEB(6, 10, 6, 11),
      decoration: BoxDecoration(
        color: isDark
            ? fill
            : Color.alphaBlend(tone.withValues(alpha: .045), tokens.surface2),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: edge.withValues(alpha: isDark ? edgeOpacity : .17),
          width: 0.8,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 18, color: tone),
                const SizedBox(width: 9),
              ],
              Expanded(
                child: Text(
                  label,
                  textAlign: TextAlign.start,
                  style: _tradeSectionHeadingStyle(
                    context,
                    color: effectiveHeadingTone,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          LayoutBuilder(
            builder: (context, constraints) => Wrap(
              spacing: 7,
              runSpacing: 7,
              alignment: WrapAlignment.start,
              children: [
                for (final value in values)
                  Container(
                    key: ValueKey('trade-detail-entry-condition-value-$value'),
                    constraints: BoxConstraints(
                      maxWidth: constraints.maxWidth,
                    ),
                    padding: const EdgeInsetsDirectional.fromSTEB(6, 7, 6, 7),
                    decoration: BoxDecoration(
                      color: isDark
                          ? (optionFill ?? const Color(0xFF1E3041))
                          : const Color(0xFFE6EEF5),
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(
                        color: isDark
                            ? (optionEdge ?? tone.withValues(alpha: .16))
                                  .withValues(alpha: optionEdgeOpacity)
                            : tone.withValues(alpha: .13),
                        width: 0.8,
                      ),
                    ),
                    child: Text(
                      value,
                      softWrap: true,
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: optionTextColor ?? tokens.text1,
                        fontWeight: FontWeight.w700,
                        fontSize: _savedTradeDetailChipFontSize,
                        height: 1.35,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TradeBehaviorSummary extends StatelessWidget {
  const TradeBehaviorSummary({
    super.key,
    required this.trade,
    this.initiallyExpanded = true,
  });
  final Trade trade;
  final bool initiallyExpanded;

  static const _decisionTone = TradeDetailPalette.decisionTone;
  static const _commitmentTone = TradeDetailPalette.commitmentTone;
  static const _noEntryTone = TradeDetailPalette.noEntryTone;

  @override
  Widget build(BuildContext context) {
    final arabic = AppStrings.isArabic(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final reviewKeys = trade.executionReviewKeys.toSet();
    final decisionCatalog = tradeReviewGroups
        .expand((group) => group.options)
        .map((option) => option.key)
        .toSet();
    final commitmentCatalog = tradeCommitmentOptions
        .map((option) => option.key)
        .toSet();
    final knownDecisionKeys = {...decisionCatalog, ...commitmentCatalog};
    final selectedDecisionCount = reviewKeys
        .where((key) => decisionCatalog.contains(key) || !knownDecisionKeys.contains(key))
        .length;
    final selectedCommitments = tradeCommitmentOptions
        .where((option) => reviewKeys.contains(option.key))
        .toList(growable: false);
    final unknownDecisionKeys = reviewKeys
        .where((key) => !knownDecisionKeys.contains(key))
        .toList(growable: false);
    final noEntryKeys = trade.noEntryReasons.toSet();
    final knownNoEntry = tradeNoEntryOptions.map((option) => option.key).toSet();
    final selectedNoEntry = tradeNoEntryOptions
        .where((option) => noEntryKeys.contains(option.key))
        .toList(growable: false);
    final unknownNoEntry = noEntryKeys
        .where((key) => !knownNoEntry.contains(key))
        .toList(growable: false);
    final selectedNoEntryCount = selectedNoEntry.length + unknownNoEntry.length;
    if (selectedDecisionCount == 0 &&
        selectedCommitments.isEmpty &&
        selectedNoEntryCount == 0) {
      return const SizedBox.shrink();
    }

    final outerFill = isDark ? TradeDetailPalette.reviewOuterDark : const Color(0xFFF2EFF8);
    final decisionSurface = isDark
        ? TradeDetailPalette.reviewDecisionDark
        : TradeDetailPalette.reviewDecisionLight;
    final commitmentSurface = isDark
        ? TradeDetailPalette.reviewCommitmentDark
        : TradeDetailPalette.reviewCommitmentLight;
    final noEntrySurface = isDark
        ? TradeDetailPalette.reviewNoEntryDark
        : TradeDetailPalette.reviewNoEntryLight;

    Widget optionTiles(
      List<String> keys,
      Color tone,
      Color itemFill, {
      bool showArtwork = true,
    }) =>
        Column(
      children: [
        for (var index = 0; index < keys.length; index++) ...[
          if (index > 0) const SizedBox(height: 6),
          _ReviewOptionTile(
            optionKey: keys[index],
            label: tradeEntryLabel(keys[index], arabic: arabic),
            tone: tone,
            fill: itemFill,
            isDark: isDark,
            showArtwork: showArtwork,
          ),
        ],
      ],
    );

    Widget subgroup({
      required String title,
      required List<String> keys,
      String? note,
      bool inline = false,
    }) {
      if (keys.isEmpty) return const SizedBox.shrink();
      return Padding(
        padding: const EdgeInsetsDirectional.only(top: 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: const Color(0xFFE0C49F),
                fontWeight: FontWeight.w800,
              ),
            ),
            if (note != null) ...[
              const SizedBox(height: 3),
              Text(
                note,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: isDark ? const Color(0xFFBFC5CE) : const Color(0xFF6D6257),
                  height: 1.5,
                ),
              ),
            ],
            const SizedBox(height: 6),
            if (inline)
              // Analysis quality: the chosen items sit under the sentence as
              // plain text on one tonal strip, e.g.
              // `RBS Touch 2    Trend Line Touch 3 Sell Breakout`.
              _SavedInlineSelection(
                key: const ValueKey('trade-review-analysis-inline'),
                labels: [
                  for (final key in keys) tradeEntryLabel(key, arabic: arabic),
                ],
                fill: isDark ? TradeDetailPalette.reviewDecisionOptionDark : const Color(0xFFF0E7DD),
                tone: _decisionTone,
                isDark: isDark,
              )
            else
              optionTiles(keys, _decisionTone, isDark ? TradeDetailPalette.reviewDecisionOptionDark : const Color(0xFFF0E7DD)),
          ],
        ),
      );
    }

    Widget reviewGroup({
      required String sectionKey,
      required String title,
      required List<String> keys,
      required Color tone,
      required Color surface,
      required IconData icon,
      Widget? leading,
      required Widget content,
    }) {
      if (keys.isEmpty) return const SizedBox.shrink();
      return _TradeReviewGroupPanel(
        key: ValueKey('trade-review-group-$sectionKey'),
        toggleKey: ValueKey('trade-review-group-$sectionKey-toggle'),
        title: title,
        count: keys.length,
        tone: tone,
        surface: surface,
        icon: icon,
        leading: leading,
        child: content,
      );
    }

    final decisionContent = <Widget>[];
    for (final category in tradeReviewGroups) {
      final keys = category.options
          .where((option) => reviewKeys.contains(option.key))
          .map((option) => option.key)
          .toList(growable: false);
      if (keys.isNotEmpty) {
        decisionContent.add(
          subgroup(
            title: arabic ? category.titleAr : category.titleEn,
            keys: keys,
            // Analysis quality reads as a sentence: one item → "لم أنتبه لوجود",
            // several → "لم أنتبه لوجود سيناريو".
            note: category.id == 'analysis'
                ? tradeAnalysisMissedSentence(count: keys.length, arabic: arabic)
                : (category.noteAr == null
                    ? null
                    : (arabic ? category.noteAr! : category.noteEn!)),
            inline: category.id == 'analysis',
          ),
        );
      }
    }
    if (unknownDecisionKeys.isNotEmpty) {
      decisionContent.add(
        subgroup(
          title: arabic ? 'عناصر محفوظة من إصدار سابق' : 'Items from an earlier version',
          keys: unknownDecisionKeys,
        ),
      );
    }

    final noEntryKeysOrdered = [
      ...selectedNoEntry.map((option) => option.key),
      ...unknownNoEntry,
    ];
    final noEntryOptionFill =
        isDark ? TradeDetailPalette.reviewNoEntryOptionDark : const Color(0xFFEFE8F8);

    // Two sections, like the form: psychological, then structural. Keys from
    // earlier versions that are in neither list stay visible under their own
    // heading instead of disappearing.
    Widget noEntrySubgroup(String title, List<String> keys, String sectionId) {
      if (keys.isEmpty) return const SizedBox.shrink();
      return Padding(
        key: ValueKey('trade-review-no-entry-$sectionId'),
        padding: const EdgeInsetsDirectional.only(top: 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: isDark ? const Color(0xFFD0C0F4) : const Color(0xFF6B54A8),
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            optionTiles(keys, _noEntryTone, noEntryOptionFill, showArtwork: false),
          ],
        ),
      );
    }

    final noEntryContent = <Widget>[
      for (final group in tradeNoEntryGroups)
        noEntrySubgroup(
          arabic ? group.titleAr : group.titleEn,
          [
            for (final option in group.options)
              if (noEntryKeys.contains(option.key)) option.key,
          ],
          group.id,
        ),
      noEntrySubgroup(
        arabic ? 'عناصر محفوظة من إصدار سابق' : 'Items from an earlier version',
        unknownNoEntry,
        'legacy',
      ),
    ];

    final reviewSelectionCount =
        selectedDecisionCount + selectedCommitments.length + selectedNoEntryCount;

    return _TradeDetailPanel(
      key: const ValueKey('trade-detail-review-panel'),
      title: arabic ? 'مراجعة الصفقة' : 'Trade review',
      icon: Icons.fact_check_outlined,
      tone: TradeDetailPalette.reviewTone,
      darkSurface: outerFill,
      collapsible: true,
      initiallyExpanded: initiallyExpanded,
      horizontalPadding: 6,
      toggleKey: const ValueKey('trade-detail-review-panel-toggle'),
      summary: '$reviewSelectionCount ${arabic ? 'اختيارات' : 'selections'}',
      surfaceKey: const ValueKey('trade-detail-review-panel-surface'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          reviewGroup(
            sectionKey: 'decisions',
            title: arabic ? 'القرارات' : 'Decisions',
            keys: [
              ...reviewKeys.where(decisionCatalog.contains),
              ...unknownDecisionKeys,
            ],
            tone: _decisionTone,
            surface: decisionSurface,
            icon: Icons.rule_rounded,
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: decisionContent,
            ),
          ),
          reviewGroup(
            sectionKey: 'commitment',
            title: arabic ? 'الالتزام' : 'Commitment',
            keys: selectedCommitments.map((option) => option.key).toList(),
            tone: _commitmentTone,
            surface: commitmentSurface,
            icon: Icons.verified_user_outlined,
            content: optionTiles(
              selectedCommitments.map((option) => option.key).toList(),
              _commitmentTone,
              isDark ? TradeDetailPalette.reviewCommitmentOptionDark : const Color(0xFFE4F1EB),
              showArtwork: false,
            ),
          ),
          reviewGroup(
            sectionKey: 'no-entry',
            title: arabic ? 'أسباب عدم الدخول' : 'Reasons for not entering',
            keys: noEntryKeysOrdered,
            tone: _noEntryTone,
            surface: noEntrySurface,
            icon: Icons.block_outlined,
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: noEntryContent,
            ),
          ),
        ],
      ),
    );
  }
}


/// The chosen analysis-quality items as plain text on one tonal strip,
/// separated by a wide gap — no per-item boxes.
class _SavedInlineSelection extends StatelessWidget {
  const _SavedInlineSelection({
    super.key,
    required this.labels,
    required this.fill,
    required this.tone,
    required this.isDark,
  });

  final List<String> labels;
  final Color fill;
  final Color tone;
  final bool isDark;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: fill,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: tone.withValues(alpha: isDark ? .16 : .12),
          width: 0.8,
        ),
      ),
      child: Wrap(
        spacing: 18,
        runSpacing: 6,
        children: [
          for (final label in labels)
            Text(
              label,
              textDirection: TextDirection.ltr,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: tokens.text1,
                    fontSize: _savedTradeReviewValueFontSize,
                    height: 1.4,
                    fontWeight: FontWeight.w700,
                  ),
            ),
        ],
      ),
    );
  }
}

class _TradeReviewGroupPanel extends StatefulWidget {
  const _TradeReviewGroupPanel({
    super.key,
    required this.toggleKey,
    required this.title,
    required this.count,
    required this.tone,
    required this.surface,
    required this.icon,
    this.leading,
    required this.child,
  });

  final Key toggleKey;
  final String title;
  final int count;
  final Color tone;
  final Color surface;
  final IconData icon;
  final Widget? leading;
  final Widget child;

  @override
  State<_TradeReviewGroupPanel> createState() => _TradeReviewGroupPanelState();
}

class _TradeReviewGroupPanelState extends State<_TradeReviewGroupPanel> {
  bool _expanded = true;

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.disableAnimationsOf(context);
    final titleStyle = Theme.of(context).textTheme.titleSmall?.copyWith(
      color: widget.tone,
      fontWeight: FontWeight.w800,
    );
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 9),
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
      decoration: BoxDecoration(
        color: widget.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: widget.tone.withValues(
            alpha: Theme.of(context).brightness == Brightness.dark ? .20 : .15,
          ),
          width: 0.8,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Semantics(
            button: true,
            expanded: _expanded,
            label: widget.title,
            child: InkWell(
              key: widget.toggleKey,
              onTap: () => setState(() => _expanded = !_expanded),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  children: [
                    widget.leading ?? Icon(widget.icon, size: 18, color: widget.tone),
                    const SizedBox(width: 8),
                    Expanded(child: Text(widget.title, style: titleStyle)),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: widget.tone.withValues(alpha: .14),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '${widget.count}',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: widget.tone,
                          fontWeight: FontWeight.w800,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                    const SizedBox(width: 5),
                    AnimatedRotation(
                      turns: _expanded ? .5 : 0,
                      duration: reduceMotion
                          ? Duration.zero
                          : const Duration(milliseconds: 160),
                      child: Icon(
                        Icons.keyboard_arrow_down_rounded,
                        size: 21,
                        color: widget.tone,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          AnimatedSize(
            duration: reduceMotion
                ? Duration.zero
                : const Duration(milliseconds: 180),
            curve: Curves.easeInOutCubic,
            alignment: Alignment.topCenter,
            child: _expanded
                ? Padding(
                    padding: const EdgeInsets.only(top: 7),
                    child: widget.child,
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

class _ReviewOptionTile extends StatelessWidget {
  const _ReviewOptionTile({
    required this.optionKey,
    required this.label,
    required this.tone,
    required this.fill,
    required this.isDark,
    this.showArtwork = true,
  });

  final String optionKey;
  final String label;
  final Color tone;
  final Color fill;
  final bool isDark;

  /// The no-entry reasons use plain text tiles, like the form.
  final bool showArtwork;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    final hasArtwork =
        showArtwork && tradeReviewOptionEmojiAssets.containsKey(optionKey);
    return Container(
      key: ValueKey('trade-review-option-tile-$optionKey'),
      width: double.infinity,
      constraints: const BoxConstraints(minHeight: 48),
      padding: const EdgeInsetsDirectional.fromSTEB(6, 7, 6, 7),
      decoration: BoxDecoration(
        color: fill,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: tone.withValues(alpha: isDark ? .16 : .12),
          width: 0.8,
        ),
      ),
      child: Row(
        children: [
          // Only commitment / no-entry rows carry artwork; decisions are text.
          if (hasArtwork) ...[
            TradeReviewOptionEmoji(optionKey: optionKey, size: 28),
            const SizedBox(width: 9),
          ] else
            const SizedBox(width: 4),
          Expanded(
            child: Text(
              label,
              softWrap: true,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: tokens.text1,
                fontSize: _savedTradeReviewValueFontSize,
                height: 1.48,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TradeTextBlock extends StatelessWidget {
  const _TradeTextBlock({required this.value});
  final String value;

  @override
  Widget build(BuildContext context) {
    final tokens = TdTokens.of(context);
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(4, 1, 4, 2),
      child: Text(
        value,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          color: tokens.text1,
          height: 1.55,
        ),
      ),
    );
  }
}
