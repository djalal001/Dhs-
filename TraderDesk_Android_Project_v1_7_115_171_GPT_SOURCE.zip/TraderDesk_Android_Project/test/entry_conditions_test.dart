import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/screens/trade_form_screen.dart';
import 'package:trader_desk/state/app_controller.dart';
import 'package:trader_desk/state/app_scope.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/theme/trade_detail_palette.dart';

Future<void> _selectTradeFormTab(
  WidgetTester tester,
  String section,
) async {
  final tab = find.byKey(ValueKey('trade-form-section-tab-$section'));
  await tester.ensureVisible(tab);
  await tester.tap(tab);
  await tester.pumpAndSettle();
}

Future<void> _enterSignedResult(
  WidgetTester tester,
  String amount, {
  required bool negative,
}) async {
  final input = find.byKey(const ValueKey('trade-result-input'));
  final signOption = find.byKey(ValueKey(
    negative ? 'trade-result-sign-negative' : 'trade-result-sign-positive',
  ));
  if (signOption.evaluate().isEmpty) {
    final resultField = tester.widget<TextFormField>(input);
    final existingText = resultField.controller?.text ?? '';
    final wasSigned = RegExp(r'^[+\-−]').hasMatch(existingText);
    if (wasSigned && !resultField.readOnly) {
      // Removing the leading symbol is the supported way to reopen sign choice.
      await tester.enterText(input, existingText.replaceFirst(RegExp(r'^[+\-−]'), ''));
    } else {
      await tester.tap(input);
    }
    await tester.pumpAndSettle();
  }
  expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsOneWidget,
      reason: 'the editable amount exposes + and − choices whenever its sign is absent');
  expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsOneWidget);
  await tester.tap(signOption);
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsNothing);
  expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsNothing);
  await tester.enterText(input, '${negative ? '−' : '+'}$amount');
  await tester.pumpAndSettle();
  expect(
    tester.widget<TextFormField>(input).controller!.text,
    '${negative ? '−' : '+'}$amount',
    reason: 'the selected sign is stored as an editable leading character in the amount',
  );
}

void main() {
  late Directory temp;
  late AppController app;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('trader_desk_conditions_');
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    app.accounts = [
      TradingAccount(
        id: 'conditions-account',
        name: 'Demo',
        type: AccountType.demo,
        startingBalance: 10000,
        currency: 'USD',
        createdAt: DateTime(2025, 1, 1),
      ),
    ];
    app.selectedAccountId = 'conditions-account';
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  testWidgets('the result sign can be deleted from the amount and chosen again', (
    tester,
  ) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () => Navigator.of(context).push<Trade>(
                    MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                  ),
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final resultInput = find.byKey(const ValueKey('trade-result-input'));
    await tester.tap(resultInput);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-result-sign-positive')));
    await tester.pumpAndSettle();
    await tester.enterText(resultInput, '+42.5');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(resultInput).controller!.text, '+42.5');

    // Removing only the leading sign returns the field to the sign picker
    // while preserving the digits for the trader's next sign selection.
    await tester.enterText(resultInput, '42.5');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(resultInput).readOnly, isTrue);
    expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trade-result-sign-negative')));
    await tester.pumpAndSettle();
    expect(
      tester.widget<TextFormField>(resultInput).controller!.text,
      '−42.5',
      reason: 'choosing a new sign preserves the existing digits and changes only the sign',
    );
    expect(tester.widget<TextFormField>(resultInput).readOnly, isFalse);
  });

  testWidgets('pairs mindset with market/direction and renders anchors as a full-width selection field', (tester) async {
    Trade? savedTrade;
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () async {
                    savedTrade = await Navigator.of(context).push<Trade>(
                      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                    );
                  },
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final marketField = find.byKey(const ValueKey('trade-market-input'));
    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    final moodMenu = find.byKey(const ValueKey('trade-mood-dropdown'));
    await tester.ensureVisible(marketField);
    final marketRect = tester.getRect(marketField);
    final directionRect = tester.getRect(directionSelector);
    expect(
      (directionRect.top - marketRect.top).abs(),
      lessThan(20),
      reason: 'direction should share the compact market row, not move below it',
    );
    expect(
      directionRect.left >= marketRect.right || marketRect.left >= directionRect.right,
      isTrue,
      reason: 'direction and market fields should be horizontally adjacent',
    );
    expect((directionRect.width - marketRect.width).abs(), lessThan(1));
    final marketDirectionRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    final anchorRect = tester.getRect(
      find.byKey(const ValueKey('trade-anchor-selector')),
    );
    final moodField = find.byKey(const ValueKey('trade-mood-field'));
    final moodRect = tester.getRect(moodField);
    final moodSurfaceRect = tester.getRect(
      find.byKey(const ValueKey('trade-mood-field-surface')),
    );
    final availableIdentifiers = tester.getRect(
      find.byKey(const ValueKey('trade-entry-identifiers-available')),
    );
    final availableRect = availableIdentifiers;
    expect(
      marketDirectionRect.width,
      closeTo((availableRect.width - 8) / 2, 1),
      reason: 'market/direction should occupy one half of the top row',
    );
    expect(
      moodRect.width,
      closeTo(marketDirectionRect.width, 1),
      reason: 'mindset must be beside market/direction with the same width',
    );
    expect(
      moodRect.left,
      lessThan(marketDirectionRect.left),
      reason: 'in RTL layout the mindset field sits to the left of market/direction',
    );
    expect(
      marketDirectionRect.left - moodRect.right,
      closeTo(8, .1),
      reason: 'mindset keeps the exact original 8dp gap and position beside Market / Direction',
    );
    expect(
      moodRect.center.dy,
      closeTo(marketDirectionRect.center.dy, .1),
      reason: 'Mindset stays vertically centered beside Market / Direction',
    );
    expect(
      marketDirectionRect.height,
      closeTo(72, .1),
      reason: 'Market / Direction is the 72dp reference field',
    );
    expect(
      moodRect.height,
      closeTo(marketDirectionRect.height, .1),
      reason: 'Mindset control bounds must match the Market / Direction rectangle exactly',
    );
    expect(
      moodSurfaceRect.top,
      closeTo(marketDirectionRect.top, .1),
      reason: 'the visible Mindset InputDecorator top edge must exactly match the Market / Direction top edge',
    );
    expect(
      moodSurfaceRect.bottom,
      closeTo(marketDirectionRect.bottom, .1),
      reason: 'the visible Mindset InputDecorator bottom edge must exactly match the Market / Direction bottom edge',
    );
    expect(
      moodSurfaceRect.height,
      closeTo(marketDirectionRect.height, .1),
      reason: 'compare the actual outlined surfaces, not only the outer popup child bounds',
    );
    expect(
      moodRect.top,
      closeTo(marketDirectionRect.top, .1),
      reason: 'the fixed Mindset control itself shares the exact upper edge with Market / Direction',
    );
    expect(
      moodRect.bottom,
      closeTo(marketDirectionRect.bottom, .1),
      reason: 'the fixed Mindset control itself shares the exact lower edge with Market / Direction',
    );

    // InputDecorator paints its outline from its CONTENT height, not from the
    // outer 72dp box, so equal outer bounds alone do not prove equal
    // rectangles. Both companion fields must hold equally tall content with the
    // same padding for the painted outlines to be identical.
    final moodContentSize = tester.getSize(
      find.byKey(const ValueKey('trade-mood-content')),
    );
    final marketContentSize = tester.getSize(
      find.byKey(const ValueKey('trade-market-direction-choices-row')),
    );
    expect(
      moodContentSize.height,
      closeTo(marketContentSize.height, .1),
      reason: 'Mindset content height must equal the Market / Direction content height',
    );
    expect(moodContentSize.height, closeTo(30, .1));
    expect(
      moodSurfaceRect.top,
      closeTo(moodRect.top, .1),
      reason: 'the visible Mindset border fills its fixed control bounds without an internal offset',
    );
    expect(
      moodSurfaceRect.bottom,
      closeTo(moodRect.bottom, .1),
      reason: 'the visible Mindset border fills its fixed control bounds without an internal offset',
    );
    final initialMoodValue = tester.widget<Text>(
      find.byKey(const ValueKey('trade-mood-selected-value')),
    );
    expect(initialMoodValue.data, 'غير مسجلة');
    expect(
      initialMoodValue.style?.color,
      TdTokens.of(tester.element(moodMenu)).text2,
      reason: 'the unrecorded Mindset placeholder uses the same muted tone as other unselected fields',
    );
    expect(
      initialMoodValue.style?.fontWeight,
      FontWeight.w600,
      reason: 'the unrecorded Mindset placeholder must not look like a bright selected value',
    );
    expect(
      anchorRect.width,
      closeTo(availableRect.width, 1),
      reason: 'anchor selector must move below the top row and use the full content width',
    );
    final identifiersRow = tester.getRect(
      find.byKey(const ValueKey('trade-entry-identifiers-row')),
    );
    expect(identifiersRow.width, closeTo(availableIdentifiers.width, 1));
    expect(
      anchorRect.top,
      greaterThan(identifiersRow.bottom),
      reason: 'the full-width anchor field must be below market/direction and mindset',
    );
    expect(
      (marketDirectionRect.right - identifiersRow.right).abs(),
      lessThan(1),
      reason: 'the market/direction selector must align to the right edge of the card content',
    );

    expect(find.byKey(const ValueKey('trade-market-direction-label')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-market-direction-label-divider')), findsOneWidget);
    expect(find.text('السوق'), findsOneWidget);
    expect(tester.widget<Text>(find.text('السوق')).style?.fontSize, 17.5);
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('trade-market-direction-label-divider')),
      ).style?.fontSize,
      17.5,
    );
    expect(find.text('الاتجاه'), findsNWidgets(2),
        reason: 'the direction wording appears once in the top floating label and once as the empty selector caption');
    expect(find.text('الارتكاز'), findsOneWidget);
    await _selectTradeFormTab(tester, 'conditions');
    final reverseField = find.byKey(
      const ValueKey('reverse-signal-category-trigger'),
    );
    final bounceField = find.byKey(
      const ValueKey('bounce-zone-category-trigger'),
    );
    expect(reverseField, findsOneWidget);
    expect(bounceField, findsOneWidget);
    for (final field in [reverseField, bounceField]) {
      final fieldInput = find.descendant(
        of: field,
        matching: find.byType(InputDecorator),
      );
      expect(fieldInput, findsOneWidget);
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.labelStyle?.fontSize,
        14,
        reason: 'inline labels retain 14dp while the selected floating state uses the enlarged size',
      );
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.floatingLabelStyle?.fontSize,
        17.5,
        reason: 'selected reverse/bounce titles must render at the enlarged floating-label size',
      );
    }
    expect(find.text('إشارات عكسية'), findsOneWidget);
    expect(find.text('منطقة الارتداد'), findsOneWidget);
    expect(find.text('اختر الرمز'), findsNothing);
    expect(find.text('اختر الارتكاز'), findsNothing);
    await _selectTradeFormTab(tester, 'details');
    // The Trade Data card has its own nested Theme. Assert that it preserves
    // the enlarged 17.5dp configured floating-label style (about 13.1dp
    // after Flutter's 75% floating-label scale) rather than falling back.
    for (final fieldKey in const [
      ValueKey('trade-result-input'),
      ValueKey('trade-expected-loss-input'),
      ValueKey('trade-risk-input'),
      ValueKey('trade-reward-risk-input'),
    ]) {
      final fieldInput = find.descendant(
        of: find.byKey(fieldKey),
        matching: find.byType(InputDecorator),
      );
      expect(fieldInput, findsOneWidget);
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.labelStyle?.fontSize,
        14,
        reason: 'numeric/readout inline labels retain the original 14dp size',
      );
      expect(
        tester.widget<InputDecorator>(fieldInput).decoration.floatingLabelStyle?.fontSize,
        17.5,
      );
    }

    final marketInput = tester.widget<InputDecorator>(
      find.byKey(const ValueKey('trade-market-direction-field')),
    );
    final moodInputFinder = find.descendant(
      of: find.byKey(const ValueKey('trade-mood-field')),
      matching: find.byType(InputDecorator),
    );
    final moodInput = tester.widget<InputDecorator>(moodInputFinder);
    expect(marketInput.decoration.fillColor, const Color(0xFF071834));
    expect(marketInput.decoration.floatingLabelStyle?.fontSize, 17.5,
        reason: 'market/direction title uses the enlarged floating-label scale');
    final marketCaption = tester.widget<Text>(
      find.descendant(of: marketField, matching: find.text('الرمز')),
    );
    expect(marketCaption.textAlign, TextAlign.center);
    final directionCaption = tester.widget<Text>(
      find.descendant(of: directionSelector, matching: find.text('الاتجاه')),
    );
    expect(directionCaption.textAlign, TextAlign.center);
    expect(
      marketInput.decoration.floatingLabelAlignment,
      FloatingLabelAlignment.center,
      reason: 'the separator in the market/direction title must align with the central divider below it',
    );
    final marketBorder = marketInput.decoration.border as OutlineInputBorder;
    expect(marketBorder.borderRadius, BorderRadius.circular(14));
    expect(marketBorder.borderSide.width, .78);
    expect(moodInput.decoration.fillColor, marketInput.decoration.fillColor,
        reason: 'the mindset selector must share the same surface as Market / Direction');
    final moodBorder = moodInput.decoration.border as OutlineInputBorder;
    expect(moodBorder.borderRadius, marketBorder.borderRadius);
    expect(moodBorder.borderSide.color, marketBorder.borderSide.color,
        reason: 'the mindset selector border must match the adjacent data selector');
    expect(moodBorder.borderSide.width, marketBorder.borderSide.width);
    expect(moodInput.decoration.enabledBorder, marketInput.decoration.enabledBorder,
        reason: 'Mindset enabled border must match Market / Direction');
    expect(moodInput.decoration.focusedBorder, marketInput.decoration.focusedBorder,
        reason: 'Mindset focused border must match Market / Direction');
    expect(moodInput.decoration.contentPadding, marketInput.decoration.contentPadding,
        reason: 'Mindset content inset must match the adjacent selector geometry');
    expect(
      find.ancestor(of: moodInputFinder, matching: find.byType(Opacity)),
      findsNothing,
      reason: 'a disabled Mindset value may dim, but the selector border and fill must stay at full opacity',
    );
    final popupTheme = Theme.of(tester.element(marketField)).popupMenuTheme;
    expect(popupTheme.color, const Color(0xFF102846));
    expect(popupTheme.surfaceTintColor, Colors.transparent);
    final popupShape = popupTheme.shape as RoundedRectangleBorder;
    expect(popupShape.borderRadius, BorderRadius.circular(12));
    expect(popupShape.side.color, const Color(0xFF294055));
    expect(popupShape.side.width, .8);
    expect(tdPopupMenuAnimationStyle.duration, const Duration(milliseconds: 105));
    expect(
      tdPopupMenuAnimationStyle.reverseDuration,
      const Duration(milliseconds: 85),
    );
    expect(
      find.descendant(of: marketField, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    expect(
      find.descendant(of: directionSelector, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)),
      findsNothing,
    );
    final anchorSelector = find.byKey(const ValueKey('trade-anchor-selector'));
    final anchorInputFinder = find.descendant(
      of: anchorSelector,
      matching: find.byType(InputDecorator),
    );
    expect(anchorInputFinder, findsOneWidget);
    final anchorInput = tester.widget<InputDecorator>(anchorInputFinder);
    expect(anchorInput.decoration.fillColor, const Color(0xFF071834));
    expect(anchorInput.decoration.labelStyle?.fontSize, 14,
        reason: 'the anchor inline label retains its original 14dp size');
    expect(anchorInput.decoration.floatingLabelStyle?.fontSize, 17.5,
        reason: 'the selected anchor title must remain readable after floating');
    final anchorBorder = anchorInput.decoration.border as OutlineInputBorder;
    expect(anchorBorder.borderRadius, BorderRadius.circular(14));
    expect(anchorBorder.borderSide.width, .78);
    final marketPopupWidth = marketRect.width;
    expect(
      tester.widget<InkWell>(marketField).onTap,
      isNull,
      reason: 'market selection stays locked until a trade direction is selected',
    );
    expect(
      tester.widget<InkWell>(directionSelector).onTap,
      isNotNull,
      reason: 'the direction selector remains available to unlock the form',
    );
    expect(
      tester.widget<PopupMenuButton<String>>(moodMenu).enabled,
      isFalse,
      reason: 'mindset must remain locked until a trade direction is selected',
    );
    final resultInput = find.byKey(const ValueKey('trade-result-input'));
    final expectedLossInput = find.byKey(
      const ValueKey('trade-expected-loss-input'),
    );
    expect(tester.widget<TextFormField>(resultInput).readOnly, isTrue,
        reason: 'the result requires choosing a sign before entering its magnitude');
    expect(tester.widget<TextFormField>(expectedLossInput).readOnly, isFalse);
    await _enterSignedResult(tester, '42.5', negative: false);
    final signedResultDecoration = tester
        .widget<TextFormField>(resultInput)
        .decoration;
    expect(signedResultDecoration.prefixText, 'USD',
        reason: 'in RTL, the currency stays on the visual right edge');
    expect(signedResultDecoration.prefix, isNull);
    expect(signedResultDecoration.suffixText, isNull);
    expect(signedResultDecoration.suffix, isNull,
        reason: 'the sign is part of the editable amount, not a decorative suffix');
    await tester.enterText(expectedLossInput, '100');
    await tester.pumpAndSettle();
    expect(tester.widget<TextFormField>(resultInput).controller!.text, '+42.5');
    expect(find.byKey(const ValueKey('trade-result-sign-indicator')), findsNothing);
    expect(tester.widget<TextFormField>(expectedLossInput).controller!.text, '100');

    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    final buyOption = find.byKey(const ValueKey('trade-direction-option-buy'));
    expect(
      find.byType(PopupMenuItem<TradeSide>),
      findsNWidgets(2),
      reason: 'the direction popup must display both choices together',
    );
    expect(find.text('BUY'), findsOneWidget);
    expect(find.text('SELL'), findsOneWidget);
    final directionPopupWidth = tester.getRect(buyOption).width;
    expect(directionPopupWidth, closeTo(marketPopupWidth, 1),
        reason: 'market and direction dropdowns must share the same compact width');
    expect(tester.widget<Text>(find.text('BUY')).style?.fontSize, 14.5);
    expect(directionPopupWidth, greaterThanOrEqualTo(104),
        reason: 'the menu is wide enough to show SELL in full instead of S…');
    expect(
      tester.getSize(find.text('SELL')).width,
      lessThan(directionPopupWidth - 16),
      reason: 'SELL fits inside its menu row without being cut',
    );
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: directionSelector, matching: find.text('الاتجاه')),
      findsNothing,
      reason: 'the direction caption must disappear after a side is selected',
    );
    expect(
      find.descendant(of: directionSelector, matching: find.text('BUY')),
      findsOneWidget,
    );
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: buyOption, matching: find.text('BUY')),
      findsOneWidget,
      reason: 'the already selected direction must remain readable when the popup is reopened',
    );
    expect(
      find.descendant(of: buyOption, matching: find.byIcon(Icons.check_rounded)),
      findsNothing,
      reason: 'selected direction is shown in its field, not by a checkmark in the popup',
    );
    final selectedDirectionValue = find.byKey(
      const ValueKey('trade-direction-option-buy-selected-value'),
    );
    expect(selectedDirectionValue, findsOneWidget);
    expect(tester.widget<Text>(selectedDirectionValue).style?.fontWeight,
        FontWeight.w700,
        reason: 'the selected direction is emphasized as plain text without a nested capsule');
    final selectedDirectionMenuRow = tester.widget<Container>(
      find.descendant(of: buyOption, matching: find.byType(Container)).first,
    );
    expect(
      (selectedDirectionMenuRow.decoration as BoxDecoration).color,
      TdTokens.of(tester.element(buyOption)).accent.withValues(alpha: .11),
      reason: 'the previously selected direction gets a restrained highlight in its reopened menu',
    );
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: directionSelector, matching: find.text('الاتجاه')),
      findsOneWidget,
      reason: 'tapping the selected direction again preserves the original clear-selection behavior',
    );
    expect(tester.widget<InkWell>(marketField).onTap, isNull,
        reason: 'clearing BUY must re-lock the market selector');
    expect(tester.widget<PopupMenuButton<String>>(moodMenu).enabled, isFalse,
        reason: 'clearing BUY must re-lock the Mindset selector');
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('BUY'), findsOneWidget);
    expect(tester.widget<InkWell>(marketField).onTap, isNotNull);
    expect(tester.widget<PopupMenuButton<String>>(moodMenu).enabled, isTrue);
    expect(
      tester.widget<InkWell>(find.byKey(const ValueKey('add-entry-setup'))).onTap,
      isNotNull,
    );

    for (final symbol in const ['NQ', 'ES', 'GC']) {
      await tester.tap(marketField);
      await tester.pumpAndSettle();
      expect(
        find.byType(PopupMenuItem<String>),
        findsNWidgets(3),
        reason: 'the symbol popup must render all three options at once',
      );
      expect(
        tester.widget<Text>(
          find.descendant(
            of: find.byKey(const ValueKey('trade-market-option-NQ')),
            matching: find.byType(Text),
          ),
        ).style?.fontSize,
        14.5,
      );
      for (final availableSymbol in const ['NQ', 'ES', 'GC']) {
        final optionFinder = find.byKey(
          ValueKey('trade-market-option-$availableSymbol'),
        );
        expect(
          optionFinder,
          findsOneWidget,
          reason: 'all supported market symbols must remain visible in the popup',
        );
        final optionRect = tester.getRect(optionFinder);
        expect(optionRect.width, closeTo(marketPopupWidth, 1));
        expect(optionRect.left, greaterThanOrEqualTo(0));
        expect(optionRect.right, lessThanOrEqualTo(tester.view.physicalSize.width / tester.view.devicePixelRatio));
      }
      await tester.tap(find.byKey(ValueKey('trade-market-option-$symbol')));
      await tester.pumpAndSettle();
      expect(
        find.descendant(of: marketField, matching: find.text(symbol)),
        findsOneWidget,
      );
      await tester.tap(marketField);
      await tester.pumpAndSettle();
      final reopenedMarketOption = find.byKey(
        ValueKey('trade-market-option-$symbol'),
      );
      expect(
        find.descendant(
          of: reopenedMarketOption,
          matching: find.text(symbol),
        ),
        findsOneWidget,
        reason: 'the selected market option must remain visible when the list is reopened',
      );
      expect(
        find.descendant(
          of: reopenedMarketOption,
          matching: find.byIcon(Icons.check_rounded),
        ),
        findsNothing,
        reason: 'the selected market is indicated in its field rather than by a popup checkmark',
      );
      await tester.tapAt(const Offset(4, 4));
      await tester.pumpAndSettle();
      final selectedMarketValue = find.byKey(
        ValueKey('trade-market-option-$symbol-selected-value'),
      );
      expect(selectedMarketValue, findsOneWidget);
      expect(tester.widget<Text>(selectedMarketValue).style?.fontWeight,
          FontWeight.w700,
          reason: 'the selected market remains plain text without an added inner rectangle');
      final selectedMarketMenuRow = tester.widget<Container>(
        find.descendant(
          of: reopenedMarketOption,
          matching: find.byType(Container),
        ).first,
      );
      expect(
        (selectedMarketMenuRow.decoration as BoxDecoration).color,
        TdTokens.of(tester.element(reopenedMarketOption)).accent.withValues(alpha: .11),
        reason: 'the selected market is subtly highlighted inside the reopened menu',
      );
      expect(
        find.descendant(of: marketField, matching: find.text('الرمز')),
        findsNothing,
        reason: 'the symbol caption must disappear after a symbol is selected',
      );
    }

    await tester.tap(anchorSelector);
    await tester.pumpAndSettle();
    final anchorDialog = find.byKey(
      const ValueKey('trade-centered-multi-choice-anchor'),
    );
    expect(anchorDialog, findsOneWidget);
    expect(find.text('الارتكاز'), findsNWidgets(2),
        reason: 'the field label and centered dialog title are both visible while the anchor picker is open');
    final anchorDialogRect = tester.getRect(anchorDialog);
    expect(
      tester.widget<Dialog>(anchorDialog).backgroundColor,
      const Color(0xFF102846),
      reason: 'anchor popup uses the same trade-data popup surface as nested selectors',
    );
    expect(anchorDialogRect.width, lessThan(340));
    expect(
      (anchorDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the anchor selection list must be centered like the entry-reason dialog',
    );
    for (final option in [
      'Key Level',
      'Zone S/D',
      'Engulfing',
      'Base',
    ]) {
      expect(find.text(option), findsOneWidget);
    }
    expect(tester.widget<Text>(find.text('Engulfing')).style?.fontSize, 14.5);
    expect(
      find.descendant(
        of: anchorDialog,
        matching: find.byIcon(Icons.check_box_rounded),
      ),
      findsNothing,
    );
    expect(
      find.descendant(
        of: anchorDialog,
        matching: find.byIcon(Icons.check_box_outline_blank_rounded),
      ),
      findsNothing,
    );
    expect(
      tester.widget<ListTile>(
        find.byKey(const ValueKey('trade-anchor-option-keyLevel')),
      ).trailing,
      isA<Icon>().having((icon) => icon.icon, 'icon', Icons.chevron_left_rounded),
    );
    expect(find.byKey(const ValueKey('trade-anchor-save')), findsNothing);
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-zoneSd')));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('الارتكاز · Demand Zone'), findsOneWidget,
        reason: 'Zone S/D resolves to Demand Zone for BUY');
    expect(find.byType(Dialog), findsNWidgets(2),
        reason: 'the timeframe selector is shown above the still-open centered multi-select anchor dialog');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-engulfing')));
    await tester.pumpAndSettle();
    expect(find.text('الارتكاز · Bullish Engulfing'), findsOneWidget,
        reason: 'Engulfing resolves to Bullish Engulfing for BUY');
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(
      tester.widget<ListTile>(
        find.byKey(const ValueKey('trade-anchor-option-zoneSd')),
      ).trailing,
      isA<Icon>().having((icon) => icon.icon, 'icon', Icons.check_circle_rounded),
    );

    // Base is a single catalog option. Its timeframe dialog retains the exact
    // existing centered row-list UI and uses the shared contextual header.
    await tester.tap(find.byKey(const ValueKey('trade-anchor-option-base')));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('الارتكاز · Base Buy'), findsOneWidget);
    expect(find.byType(Dialog), findsNWidgets(2));
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();

    // A tap outside the popup dismisses it; all selected anchor/timeframe pairs stay selected.
    final anchorTopLeft = tester.getTopLeft(anchorSelector);
    await tester.tapAt(Offset(4, anchorTopLeft.dy + 10));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-anchor-option-zoneSd')), findsNothing);
    expect(find.byKey(const ValueKey('trade-anchor-save')), findsNothing);
    expect(find.byKey(const ValueKey('trade-anchor-value-zoneSd')), findsOneWidget);
    expect(find.text('Demand Zone 15MIN'), findsOneWidget);
    expect(find.text('Bullish Engulfing 5MIN'), findsOneWidget);
    expect(
      tester.widget<Text>(find.text('Demand Zone 15MIN')).style?.fontSize,
      14.5,
      reason: 'selected anchor labels use the agreed common 14.5dp size',
    );
    expect(
      tester.widget<Text>(find.text('Bullish Engulfing 5MIN')).style?.fontSize,
      14.5,
    );
    expect(find.text('Supply Zone'), findsNothing);
    expect(find.text('Base Buy 1H'), findsOneWidget);

    // Editing Base after changing direction must use the new side-specific title.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Base Sell 1H'), findsOneWidget,
        reason: 'the selected Base value must immediately follow a direction change');
    expect(find.text('Supply Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D anchor changes to Supply Zone for SELL');
    expect(find.text('Bearish Engulfing 5MIN'), findsOneWidget,
        reason: 'the semantic Engulfing anchor changes to Bearish for SELL');
    await tester.ensureVisible(find.byKey(const ValueKey('trade-anchor-value-zoneSd')));
    await tester.tap(find.byKey(const ValueKey('trade-anchor-value-zoneSd')));
    await tester.pumpAndSettle();
    expect(find.text('الارتكاز · Supply Zone'), findsOneWidget,
        reason: 'the timeframe header follows the SELL-side Zone S/D label');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const ValueKey('trade-anchor-value-base')));
    await tester.tap(find.byKey(const ValueKey('trade-anchor-value-base')));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('الارتكاز · Base Sell'), findsOneWidget);
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('Base Sell 4H'), findsOneWidget);

    // Restore BUY for the pre-existing save-path assertions below.
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    expect(find.text('Base Buy 4H'), findsOneWidget,
        reason: 'the selected Base label must return to BUY without losing its timeframe');
    expect(find.text('Demand Zone 15MIN'), findsOneWidget,
        reason: 'Zone S/D anchor changes back to Demand Zone for BUY');

    final anchorLabelRect = tester.getRect(find.text('الارتكاز'));
    final firstAnchorValueRect = tester.getRect(
      find.byKey(const ValueKey('trade-anchor-value-zoneSd')),
    );
    expect(
      anchorLabelRect.bottom,
      lessThanOrEqualTo(firstAnchorValueRect.top + 1),
      reason: 'the enlarged anchor floating label must remain clear of selected content',
    );
    expect(find.byKey(const ValueKey('trade-anchor-remove-zoneSd')), findsOneWidget);
    // Tapping a selected anchor value edits its timeframe without opening the
    // multi-select list; the dropdown arrow remains the add/remove-list action.
    await tester.tap(find.byKey(const ValueKey('trade-anchor-value-zoneSd')));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('الارتكاز · Demand Zone'), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 5MIN'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('trade-anchor-value-zoneSd')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Demand Zone 15MIN'), findsOneWidget);
    await tester.ensureVisible(moodMenu);
    expect(tester.widget<PopupMenuButton<String>>(moodMenu).enabled, isTrue);
    await tester.tap(moodMenu);
    await tester.pumpAndSettle();
    final moodOptionFinder = find.byKey(
      const ValueKey('trade-mood-option-moodCalm'),
    );
    expect(moodOptionFinder, findsOneWidget);
    final moodOptionText = tester.widget<Text>(
      find.descendant(of: moodOptionFinder, matching: find.byType(Text)),
    );
    expect(
      moodOptionText.style?.fontSize,
      14.5,
      reason: 'Mindset popup rows must use the common 14.5dp menu-item size',
    );
    final moodOptionRect = tester.getRect(
      find.byKey(const ValueKey('trade-mood-option-moodCalm')),
    );
    expect(
      moodOptionRect.height,
      closeTo(42, .1),
      reason: 'Mindset popup row height retains its original compact 42dp geometry',
    );
    expect(
      moodOptionRect.width,
      closeTo(moodRect.width, 1),
      reason: 'the mindset popup must match its own field width without a blank overflow gutter',
    );
    expect(
      find.byWidgetPredicate(
        (widget) => widget is Material &&
            widget.type == MaterialType.card &&
            widget.color == const Color(0xFF102846),
      ),
      findsWidgets,
      reason: 'trade-data popup menus share the same neutral dark-blue surface',
    );
    await tester.tap(find.byKey(const ValueKey('trade-mood-option-moodCalm')));
    await tester.pumpAndSettle();
    final selectedMoodValue = find.byKey(
      const ValueKey('trade-mood-selected-value'),
    );
    expect(selectedMoodValue, findsOneWidget);
    expect(tester.widget<Text>(selectedMoodValue).style?.fontWeight,
        FontWeight.w700,
        reason: 'mindset remains plain selected text without an added capsule');
    await tester.tap(moodMenu);
    await tester.pumpAndSettle();
    expect(
      find.descendant(
        of: moodOptionFinder,
        matching: find.text('هادئ'),
      ),
      findsOneWidget,
      reason: 'the selected mindset option must remain readable when reopening the list',
    );
    expect(
      find.descendant(of: moodOptionFinder, matching: find.byIcon(Icons.check_rounded)),
      findsNothing,
      reason: 'the selected mindset is indicated by a subtle row tint rather than a checkmark',
    );
    final selectedMoodMenuRow = tester.widget<Container>(
      find.descendant(of: moodOptionFinder, matching: find.byType(Container)).first,
    );
    expect(
      (selectedMoodMenuRow.decoration as BoxDecoration).color,
      TdTokens.of(tester.element(moodOptionFinder)).accent.withValues(alpha: .11),
    );
    await tester.tapAt(const Offset(4, 4));
    await tester.pumpAndSettle();
    final moodTitleRect = tester.getRect(
      find.descendant(of: find.byKey(const ValueKey('trade-mood-field')), matching: find.text('الحالة النفسية')),
    );
    final moodValueFinder = find.descendant(
      of: find.byKey(const ValueKey('trade-mood-field')),
      matching: find.text('هادئ'),
    );
    final moodValueRect = tester.getRect(moodValueFinder);
    expect(moodTitleRect.bottom, lessThanOrEqualTo(moodValueRect.top + 1),
        reason: 'larger Mindset title must not overlap the selected mood');
    expect(
      tester.widget<Text>(moodValueFinder).style?.fontSize,
      14.5,
      reason: 'selected Mindset value must use the common 14.5dp data-item size',
    );
    expect(tester.getSize(anchorSelector).height, greaterThan(45));
    expect(tester.getSize(anchorSelector).height, lessThan(180));
    final marketDirectionHeight = tester.getSize(
      find.byKey(const ValueKey('trade-market-direction-field')),
    ).height;
    final moodHeight = tester.getSize(moodField).height;
    expect(marketDirectionHeight, closeTo(72, .1),
        reason: 'Market / Direction keeps its original 72dp field height');
    expect(moodHeight, closeTo(72, .1),
        reason: 'Mindset and Market / Direction must have exactly equal 72dp heights');
    final dividerRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-divider')),
    );
    expect(dividerRect.width, closeTo(1, .1));
    expect(dividerRect.height, closeTo(30, .1));
    final choicesRowFinder = find.byKey(
      const ValueKey('trade-market-direction-choices-row'),
    );
    final choicesRowRect = tester.getRect(choicesRowFinder);
    final marketTitleRect = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-label')),
    );
    expect(
      marketTitleRect.bottom,
      lessThanOrEqualTo(choicesRowRect.top + 1),
      reason: 'the enlarged market/direction title must not overlap the field contents',
    );
    expect(dividerRect.center.dx, closeTo(choicesRowRect.center.dx, .5),
        reason: 'the market/direction separator must sit exactly between the two equal choices');
    expect(dividerRect.center.dx, closeTo(marketDirectionRect.center.dx, .5),
        reason: 'the separator must sit at the visual midpoint of the complete market/direction rectangle');
    final marketDirectionLabelDivider = tester.getRect(
      find.byKey(const ValueKey('trade-market-direction-label-divider')),
    );
    expect(
      marketDirectionLabelDivider.center.dx,
      closeTo(dividerRect.center.dx, 1),
      reason: 'the slash in the market/direction floating title must be vertically aligned with the divider between symbol and side',
    );
    expect(dividerRect.center.dy, closeTo(choicesRowRect.center.dy, .5),
        reason: 'the separator must align vertically with the symbol and direction choices');
    expect(
      find.byKey(const ValueKey('trade-anchor-selected-values')),
      findsOneWidget,
      reason: 'selected anchors must render as separated rows inside the same outlined field',
    );
    expect(find.text('Demand Zone 15MIN'), findsOneWidget);
    await tester.tap(
      find.byKey(const ValueKey('trade-selection-field-title-anchors')),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-anchor-selected-values')), findsNothing);
    expect(find.byKey(const ValueKey('trade-anchor-selected-summary')), findsOneWidget);
    expect(find.text('Demand Zone 15MIN'), findsOneWidget,
        reason: 'the collapsed anchor rectangle keeps the selected anchor and timeframe visible');
    await tester.tap(find.byKey(const ValueKey('trade-anchor-selected-summary')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-anchor-selected-values')), findsOneWidget);
    final moodInput = tester.widget<InputDecorator>(
      find.descendant(
        of: find.byKey(const ValueKey('trade-mood-field')),
        matching: find.byType(InputDecorator),
      ),
    );
    expect(moodInput.decoration.labelStyle?.fontSize, 14);
    expect(moodInput.decoration.floatingLabelStyle?.fontSize, 17.5,
        reason: 'mindset floating label uses the enlarged 17.5dp configured style');
    expect(moodInput.decoration.fillColor, marketInput.decoration.fillColor,
        reason: 'Mindset uses the same inset fill as Market / Direction');
    final moodBorder = moodInput.decoration.border as OutlineInputBorder;
    expect(moodBorder.borderRadius, marketBorder.borderRadius);
    expect(moodBorder.borderSide.color, marketBorder.borderSide.color,
        reason: 'Mindset border now matches the adjacent blue selector without a brighter outline');
    expect(moodBorder.borderSide.width, marketBorder.borderSide.width);
    expect(moodInput.decoration.prefixIcon, isNull,
        reason: 'Add Trade mindset selector no longer shows a decorative icon');
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('trade-mood-field')),
        matching: find.byIcon(Icons.psychology_outlined),
      ),
      findsNothing,
    );
    await _enterSignedResult(tester, '42.5', negative: false);
    await tester.enterText(find.byKey(const ValueKey('trade-expected-loss-input')), '100');
    await tester.pumpAndSettle();

    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    final addConfirmation = find.byKey(const ValueKey('add-confirmation-setup'));
    // Entry reason and confirmation now use the same floating-label input
    // container as Bounce area, with values rendered inside the field.
    final entryFieldInput = find.byKey(
      const ValueKey('entry-reason-field-input'),
    );
    final confirmationFieldInput = find.byKey(
      const ValueKey('confirmation-field-input'),
    );
    final dateTimeButton = find.byKey(
      const ValueKey('trade-date-time-picker-button'),
    );
    final formEntryRect = tester.getRect(addEntry);
    final formAnchorRect = tester.getRect(anchorSelector);
    final formConfirmationRect = tester.getRect(addConfirmation);
    final formDateTimeRect = tester.getRect(dateTimeButton);
    expect(formAnchorRect.top, greaterThan(formEntryRect.bottom),
        reason: 'Add Trade must show Entry Reason before Anchor');
    expect(formConfirmationRect.top, greaterThan(formAnchorRect.bottom),
        reason: 'Add Trade must show Anchor before Entry Confirmation');
    expect(formDateTimeRect.top, greaterThan(formConfirmationRect.bottom),
        reason: 'the Date / time button must follow Entry Confirmation');
    expect(find.text('تاريخ ووقت الصفقة'), findsNothing,
        reason: 'the old long caption is not shown');
    expect(dateTimeButton, findsOneWidget);
    final dateTimeValue = find.byKey(
      const ValueKey('trade-date-time-value'),
    );
    expect(dateTimeValue, findsOneWidget,
        reason: 'the selected trade date and time must be visible before saving');
    expect(
      find.descendant(of: dateTimeButton, matching: dateTimeValue),
      findsOneWidget,
      reason: 'the chosen date and time must be inside the date/time rectangle',
    );
    final dateTimeValueText = tester.widget<Text>(dateTimeValue);
    expect(
      dateTimeValueText.data,
      matches(RegExp(r'^\d{4}-\d{2}-\d{2} · .+$')),
      reason: 'the date and localized time must be displayed together',
    );
    final dateTimeButtonWidget = tester.widget<OutlinedButton>(dateTimeButton);
    expect(
      dateTimeButtonWidget.onPressed,
      isNotNull,
      reason: 'the text date/time control must keep its picker action',
    );
    expect(
      find.descendant(of: dateTimeButton, matching: find.text('تاريخ / الوقت')),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: dateTimeButton,
        matching: find.byIcon(Icons.calendar_month_outlined),
      ),
      findsNothing,
      reason: 'the date/time control is text-only, without a calendar logo',
    );
    expect(formDateTimeRect.height, closeTo(48, .1));
    expect(
      formDateTimeRect.width,
      greaterThan(48),
      reason: 'the restored transparent outline is rectangular, not square',
    );
    expect(
      dateTimeButtonWidget.style?.backgroundColor?.resolve(
        const <WidgetState>{},
      ),
      Colors.transparent,
      reason: 'date/time control retains a transparent fill',
    );
    expect(entryFieldInput, findsOneWidget);
    expect(confirmationFieldInput, findsOneWidget);
    final emptyEntryField = tester.widget<InputDecorator>(entryFieldInput);
    final emptyConfirmationField = tester.widget<InputDecorator>(
      confirmationFieldInput,
    );
    expect(
      find.byKey(const ValueKey('trade-selection-field-title-entry-reason')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-selection-field-title-confirmation')),
      findsOneWidget,
    );
    expect(emptyEntryField.decoration.label, isNotNull);
    expect(emptyConfirmationField.decoration.label, isNotNull);
    expect(emptyEntryField.decoration.labelStyle?.fontSize, 14);
    expect(emptyConfirmationField.decoration.labelStyle?.fontSize, 14);
    expect(emptyEntryField.decoration.floatingLabelStyle?.fontSize, 17.5);
    expect(emptyConfirmationField.decoration.floatingLabelStyle?.fontSize, 17.5);
    expect(emptyEntryField.isEmpty, isTrue);
    expect(emptyConfirmationField.isEmpty, isTrue);
    expect(emptyEntryField.decoration.suffixIcon, isNotNull);
    expect(emptyConfirmationField.decoration.suffixIcon, isNotNull);
    const expectedTradeDataFieldFill = Color(0xFF071834);
    expect(
      emptyEntryField.decoration.fillColor,
      expectedTradeDataFieldFill,
      reason: 'Entry reason must use the same dark-blue selector fill as Trade Data',
    );
    expect(
      emptyConfirmationField.decoration.fillColor,
      expectedTradeDataFieldFill,
      reason: 'Entry confirmation must use the same dark-blue selector fill as Trade Data',
    );
    final entryBorder = emptyEntryField.decoration.border as OutlineInputBorder;
    final confirmationBorder = emptyConfirmationField.decoration.border as OutlineInputBorder;
    expect(entryBorder.borderRadius, BorderRadius.circular(14));
    expect(confirmationBorder.borderRadius, BorderRadius.circular(14));
    expect(entryBorder.borderSide.color, const Color(0xFF76AEE8).withValues(alpha: .30));
    expect(confirmationBorder.borderSide.color, const Color(0xFF76AEE8).withValues(alpha: .30));
    expect(emptyEntryField.decoration.floatingLabelAlignment, FloatingLabelAlignment.start);
    expect(emptyConfirmationField.decoration.floatingLabelAlignment, FloatingLabelAlignment.start);
    await tester.ensureVisible(addEntry);
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    final entryReasonDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(entryReasonDialog, findsOneWidget);
    final entryReasonDialogRect = tester.getRect(entryReasonDialog);
    expect(entryReasonDialogRect.width, lessThan(340));
    expect(
      (entryReasonDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the entry-reason list must be centered, not full-screen width',
    );
    final entryReasonDialogWidget = tester.widget<Dialog>(entryReasonDialog);
    expect(entryReasonDialogWidget.backgroundColor, const Color(0xFF102846));
    final entryReasonDialogShape =
        entryReasonDialogWidget.shape as RoundedRectangleBorder;
    expect(entryReasonDialogShape.borderRadius, BorderRadius.circular(12));
    expect(entryReasonDialogShape.side.color, const Color(0xFF294055));
    expect(
      tester.widget<Text>(find.text('SFR / RFS')).style?.fontSize,
      14.5,
      reason: 'entry-reason options should match the anchor-menu text scale',
    );
    await tester.tap(find.text('SFR / RFS').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('سبب الدخول · RFS'), findsOneWidget);
    final timeframeHeading = tester.widget<Text>(
      find.text('اختيار الفريم الزمني'),
    );
    final timeframeContext = tester.widget<Text>(
      find.text('سبب الدخول · RFS'),
    );
    expect(timeframeHeading.style?.fontWeight, FontWeight.w800);
    expect(timeframeContext.style?.fontWeight, FontWeight.w600);
    expect(
      timeframeContext.style?.color,
      TdTokens.of(tester.element(find.text('سبب الدخول · RFS'))).text2,
      reason: 'context must remain a quieter secondary line under the common heading',
    );
    expect(
      tester.getRect(find.text('سبب الدخول · RFS')).top,
      greaterThan(tester.getRect(find.text('اختيار الفريم الزمني')).bottom),
    );
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 15MIN'), findsOneWidget);
    expect(
      tester.widget<Text>(find.text('RFS 15MIN')).style?.fontSize,
      14.5,
      reason: 'selected entry-reason text matches the anchor item size',
    );
    expect(tester.widget<InputDecorator>(entryFieldInput).isEmpty, isFalse);
    final entryTitleRect = tester.getRect(
      find.descendant(of: entryFieldInput, matching: find.text('سبب الدخول')),
    );
    final entryValueRect = tester.getRect(
      find.descendant(of: entryFieldInput, matching: find.text('RFS 15MIN')),
    );
    expect(entryTitleRect.bottom, lessThanOrEqualTo(entryValueRect.top + 1),
        reason: 'larger Entry Reason title must not overlap its selected value');
    expect(
      find.descendant(
        of: entryFieldInput,
        matching: find.text('RFS 15MIN'),
      ),
      findsOneWidget,
      reason: 'the chosen entry reason and timeframe must render inside its floating-label field',
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-selection-field-title-entry-reason')),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-setup-summary-entry-reason')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-setup-value-entry-reason-0')), findsNothing);
    await tester.tap(find.byKey(const ValueKey('trade-setup-summary-entry-reason')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-setup-value-entry-reason-0')), findsOneWidget);

    final removeEntryReason = find.byKey(
      const ValueKey('trade-setup-remove-entry-reason-0'),
    );
    expect(removeEntryReason, findsOneWidget);
    await tester.tap(removeEntryReason);
    await tester.pumpAndSettle();
    expect(find.text('RFS 15MIN'), findsNothing);
    expect(tester.widget<InputDecorator>(entryFieldInput).isEmpty, isTrue);
    // The dropdown edge remains the explicit add affordance after the field is populated.
    await tester.tap(find.descendant(
      of: addEntry,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('SFR / RFS').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('RFS 15MIN'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('trade-setup-edit-entry-reason-0')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('SFR / RFS').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('سبب الدخول · RFS'), findsOneWidget,
        reason: 'editing an entry reason must use the same contextual heading');
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    await tester.ensureVisible(addConfirmation);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    final confirmationDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    expect(confirmationDialog, findsOneWidget);
    final confirmationDialogRect = tester.getRect(confirmationDialog);
    expect(confirmationDialogRect.width, lessThan(340));
    expect(
      (confirmationDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
      reason: 'the confirmation list must remain centered and compact',
    );
    final confirmationDialogWidget = tester.widget<Dialog>(confirmationDialog);
    expect(confirmationDialogWidget.backgroundColor, const Color(0xFF102846));
    final confirmationDialogShape =
        confirmationDialogWidget.shape as RoundedRectangleBorder;
    expect(confirmationDialogShape.borderRadius, BorderRadius.circular(12));
    expect(confirmationDialogShape.side.color, const Color(0xFF294055));
    await tester.tap(find.text('Engulfing').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('تأكيد الدخول · Bullish Engulfing'), findsOneWidget);
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Bullish Engulfing 5MIN'), findsOneWidget);
    expect(
      tester.widget<Text>(find.text('Bullish Engulfing 5MIN')).style?.fontSize,
      14.5,
      reason: 'selected confirmation values must use the same size as Anchor values',
    );
    expect(tester.widget<InputDecorator>(confirmationFieldInput).isEmpty, isFalse);
    final confirmationTitleRect = tester.getRect(
      find.descendant(of: confirmationFieldInput, matching: find.text('تأكيد الدخول')),
    );
    final confirmationValueRect = tester.getRect(
      find.descendant(of: confirmationFieldInput, matching: find.text('Bullish Engulfing 5MIN')),
    );
    expect(confirmationTitleRect.bottom,
        lessThanOrEqualTo(confirmationValueRect.top + 1),
        reason: 'larger Entry Confirmation title must not overlap its selected value');
    expect(
      find.descendant(
        of: confirmationFieldInput,
        matching: find.text('Bullish Engulfing 5MIN'),
      ),
      findsOneWidget,
      reason: 'the chosen confirmation and timeframe must render inside its floating-label field',
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-selection-field-title-confirmation')),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-setup-summary-confirmation')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-setup-value-confirmation-0')),
      findsNothing,
    );
    await tester.tap(
      find.byKey(const ValueKey('trade-setup-summary-confirmation')),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-setup-value-confirmation-0')),
      findsOneWidget,
    );
    final removeConfirmation = find.byKey(
      const ValueKey('trade-setup-remove-confirmation-0'),
    );
    expect(removeConfirmation, findsOneWidget);
    await tester.tap(removeConfirmation);
    await tester.pumpAndSettle();
    expect(find.text('Bullish Engulfing 5MIN'), findsNothing);
    expect(tester.widget<InputDecorator>(confirmationFieldInput).isEmpty, isTrue);
    await tester.tap(find.descendant(
      of: addConfirmation,
      matching: find.byIcon(Icons.keyboard_arrow_down_rounded),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Engulfing').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Bullish Engulfing 5MIN'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('trade-setup-edit-confirmation-0')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Engulfing').last);
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('تأكيد الدخول · Bullish Engulfing'), findsOneWidget,
        reason: 'editing a confirmation must use the same contextual heading');
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('Bullish Engulfing 5MIN'), findsOneWidget);
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(find.text('Bearish Engulfing 5MIN'), findsOneWidget,
        reason: 'the semantic Engulfing confirmation follows SELL with consistent title casing');
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    await _selectTradeFormTab(tester, 'conditions');
    final addReverse = find.byKey(const ValueKey('add-reverse-signal-setup'));
    final reverseHeader = find.byKey(
      const ValueKey('reverse-signal-category-trigger'),
    );
    await tester.ensureVisible(reverseHeader);
    await tester.tap(reverseHeader);
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'tapping the opposing-signals rectangle must open its centered choices immediately');
    expect(
      tester.widget<Dialog>(find.byType(Dialog)).backgroundColor,
      const Color(0xFF102846),
      reason: 'without a no-entry reason, the opposing-signals menu retains the standard popup surface',
    );
    final reverseDialogRect = tester.getRect(find.byType(Dialog));
    expect(reverseDialogRect.width, lessThan(340));
    expect(
      (reverseDialogRect.center.dx - tester.view.physicalSize.width /
              tester.view.devicePixelRatio / 2)
          .abs(),
      lessThan(1),
    );
    expect(find.text('S/R عكسي'), findsOneWidget);
    expect(find.text('S - D Zone عكسي'), findsOneWidget);
    expect(find.text('HNS عكسي'), findsOneWidget);
    expect(find.text('ذيل شمعة طويل عكسي'), findsOneWidget);
    await tester.tap(find.text('S - D Zone عكسي'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(
      find.text('ظروف الدخول · إشارات عكسية · Supply Zone'),
      findsOneWidget,
      reason: 'the shared header must identify the entry-condition category and resolved signal',
    );
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'the timeframe list must use the same centered dialog');
    expect(
      tester.widget<Dialog>(find.byType(Dialog)).backgroundColor,
      const Color(0xFF102846),
      reason: 'without a no-entry reason, reverse-signal timeframes must retain the original blue dialog surface',
    );
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(addReverse, findsOneWidget);
    expect(find.text('Supply Zone 30MIN'), findsOneWidget,
        reason: 'a Buy trade maps reverse S-D Zone to Supply Zone automatically');
    final reverseInput = find.descendant(
      of: reverseHeader,
      matching: find.byType(InputDecorator),
    );
    expect(tester.widget<InputDecorator>(reverseInput).decoration.floatingLabelStyle?.fontSize, 17.5);
    final reverseTitleRect = tester.getRect(
      find.descendant(of: reverseInput, matching: find.text('إشارات عكسية')),
    );
    final reverseValueRect = tester.getRect(
      find.descendant(of: reverseInput, matching: find.text('Supply Zone 30MIN')),
    );
    expect(reverseTitleRect.bottom, lessThanOrEqualTo(reverseValueRect.top + 1),
        reason: 'larger Opposing Signals title must not overlap its selected value');

    // The direction selector is in Trade Details; switch there for the
    // direction change, then return to Entry Conditions for its content.
    await _selectTradeFormTab(tester, 'details');
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: directionSelector, matching: find.text('SELL')),
      findsOneWidget,
      reason: 'the selected sell direction must display as SELL before saving',
    );
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');
    expect(find.text('Supply Zone 30MIN'), findsOneWidget);

    // The two direct opposing signal types also lead to timeframe selection.
    await tester.ensureVisible(addReverse);
    await tester.tap(find.descendant(of: addReverse, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('HNS عكسي'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(find.text('ظروف الدخول · إشارات عكسية · HNS عكسي'), findsOneWidget);
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();
    expect(find.text('HNS عكسي 1H'), findsOneWidget);

    await tester.ensureVisible(addReverse);
    await tester.tap(find.descendant(of: addReverse, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ذيل شمعة طويل عكسي'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(
      find.text('ظروف الدخول · إشارات عكسية · ذيل شمعة طويل عكسي'),
      findsOneWidget,
    );
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('ذيل شمعة طويل عكسي 5MIN'), findsOneWidget);

    final addBounce = find.byKey(const ValueKey('add-bounce-zone-setup'));
    final bounceHeader = find.byKey(
      const ValueKey('bounce-zone-category-trigger'),
    );
    await tester.ensureVisible(bounceHeader);
    await tester.tap(bounceHeader);
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget,
        reason: 'tapping the bounce-area rectangle must open its centered choices immediately');
    final bounceChoiceDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    final bounceChoiceTokens = TdTokens.of(tester.element(bounceChoiceDialog));
    expect(
      tester.widget<Dialog>(bounceChoiceDialog).backgroundColor,
      Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        bounceChoiceTokens.surface2,
      ),
      reason: 'Bounce area choice list must match the Opposing signals color',
    );
    // The grouped rows replace the former separate liquidity / trendline rows.
    expect(find.text('سحب سيولة'), findsOneWidget);
    expect(find.text('إرتداد من Trendline'), findsOneWidget);
    expect(find.text('ارتداد من Zone S/D'), findsOneWidget);
    expect(find.text('ارتداد من ترند لاين و Supply Zone'), findsNothing);
    expect(find.text('سحب سيولة داخلي'), findsNothing);
    expect(find.text('سحب السيولة خارجي'), findsNothing);
    expect(find.text('ارتداد من ترند لاين'), findsNothing);
    await tester.tap(find.text('إرتداد من Trendline'));
    await tester.pumpAndSettle();
    expect(find.text('Trendline Touch 3-4'), findsOneWidget);
    expect(find.text('Trend Line Touch 3-4 Breakout'), findsOneWidget);
    expect(find.text('اختيار الفريم الزمني'), findsNothing,
        reason: 'the Trendline choices popup comes before the timeframe list');
    await tester.tap(find.text('Trendline Touch 3-4'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(
      find.text('ظروف الدخول · منطقة الارتداد · إرتداد من Trendline Touch 3-4'),
      findsOneWidget,
    );
    expect(find.byType(Dialog), findsOneWidget);
    final bounceTimeframeDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    final bounceTimeframeTokens = TdTokens.of(tester.element(bounceTimeframeDialog));
    expect(
      tester.widget<Dialog>(bounceTimeframeDialog).backgroundColor,
      Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        bounceTimeframeTokens.surface2,
      ),
      reason: 'Bounce area timeframe list must match the Opposing signals timeframe list',
    );
    await tester.tap(find.text('1H').last);
    await tester.pumpAndSettle();

    expect(find.textContaining('إرتداد من Trendline Touch 3-4 1H'), findsOneWidget);
    final selectedBounceDecorator = tester.widget<InputDecorator>(
      find.descendant(of: bounceField, matching: find.byType(InputDecorator)),
    );
    expect(selectedBounceDecorator.isEmpty, isFalse,
        reason: 'the Bounce area label must float above the selected value inside the same field');
    expect(selectedBounceDecorator.decoration.floatingLabelStyle?.fontSize, 17.5);
    final bounceTitleRect = tester.getRect(
      find.descendant(of: bounceField, matching: find.text('منطقة الارتداد')),
    );
    final bounceValueRect = tester.getRect(
      find.byKey(const ValueKey('entry-condition-label-bounceFromTrendlineTouch34-1H--false')),
    );
    expect(bounceTitleRect.bottom, lessThanOrEqualTo(bounceValueRect.top + 1),
        reason: 'larger Bounce area title must not overlap its selected text');
    final selectedReverseDecorator = tester.widget<InputDecorator>(
      find.descendant(of: reverseField, matching: find.byType(InputDecorator)),
    );
    expect(selectedReverseDecorator.isEmpty, isFalse,
        reason: 'the Opposing signals label must float above the selected value inside the same field');
    expect(selectedReverseDecorator.decoration.floatingLabelStyle?.fontSize, 17.5);
    final reverseTitleRect = tester.getRect(
      find.descendant(of: reverseField, matching: find.text('إشارات عكسية')),
    );
    final reverseValueRect = tester.getRect(
      find.byKey(const ValueKey('entry-condition-label-reverseSdZone-30MIN--false')),
    );
    expect(reverseTitleRect.bottom, lessThanOrEqualTo(reverseValueRect.top + 1),
        reason: 'larger Opposing Signals title must not overlap its selected text');
    final selectedBounceLabel = tester.widget<Text>(
      find.byKey(const ValueKey('entry-condition-label-bounceFromTrendlineTouch34-1H--false')),
    );
    expect(
      selectedBounceLabel.style?.fontSize,
      14.5,
      reason: 'selected Bounce area values must use the same size as Anchor values',
    );
    expect(selectedBounceLabel.softWrap, isTrue);
    expect(selectedBounceLabel.maxLines, isNull);
    expect(selectedBounceLabel.overflow, isNull);
    final selectedReverseLabel = tester.widget<Text>(
      find.byKey(const ValueKey('entry-condition-label-reverseSdZone-30MIN--false')),
    );
    expect(
      selectedReverseLabel.style?.fontSize,
      14.5,
      reason: 'selected Opposing signal values must use the same size as Anchor values',
    );
    expect(selectedReverseLabel.softWrap, isTrue);
    expect(selectedReverseLabel.maxLines, isNull);
    expect(selectedReverseLabel.overflow, isNull);
    expect(find.text('إضافة اختيار'), findsNothing);
    expect(find.text('اختيار'), findsNothing, reason: 'opposing and bounce selections are integrated inside their input fields');
    expect(find.descendant(of: reverseHeader, matching: find.byIcon(Icons.add_rounded)), findsNothing);
    expect(find.descendant(of: bounceHeader, matching: find.byIcon(Icons.add_rounded)), findsNothing);
    expect(find.descendant(of: addReverse, matching: find.byIcon(Icons.add)), findsNothing);
    expect(find.descendant(of: addBounce, matching: find.byIcon(Icons.add)), findsNothing);

    await tester.ensureVisible(addBounce);
    await tester.tap(find.descendant(of: addBounce, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من Support Touch — اختياري'), findsOneWidget,
        reason: 'the BUY-side S/R detail dialog identifies the selected Support scenario');
    final srTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    final skipSrTouch2Initial = find.byKey(
      const ValueKey('skip-touch2-bounceFromSrZone'),
    );
    expect(srTouch2, findsOneWidget);
    final srTouch2Dialog = find.byKey(
      const ValueKey('trade-centered-choice-touch2-bounceFromSrZone'),
    );
    final srTouch2Tokens = TdTokens.of(tester.element(srTouch2Dialog));
    final srTouch2Background =
        tester.widget<Dialog>(srTouch2Dialog).backgroundColor;
    expect(
      srTouch2Background,
      Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        srTouch2Tokens.surface2,
      ),
      reason: 'the S/R Touch 2 list must match the Bounce area timeframe color',
    );
    final srTouch2Shape = tester.widget<Dialog>(srTouch2Dialog).shape
        as RoundedRectangleBorder;
    expect(
      srTouch2Shape.side.color,
      const Color(0xFF6E9FB6).withValues(alpha: .17),
    );
    expect(find.text('2 Touch'), findsOneWidget);
    final srTouch2Option = tester.widget<ListTile>(srTouch2);
    expect(srTouch2Option.selected, isFalse,
        reason: 'a new optional Touch 2 dialog must not preselect Touch 2');
    expect(tester.widget<ListTile>(skipSrTouch2Initial).selected, isFalse,
        reason: 'Continue must not look selected before the user chooses it');
    expect(
      srTouch2Option.selectedTileColor,
      const Color(0xFF6E9FB6).withValues(alpha: .16),
      reason: 'the S/R detail choice must use the same semantic tint as the timeframe list',
    );
    expect(find.text('لمسة 2'), findsNothing);
    expect(find.text('متابعة'), findsOneWidget);
    expect(find.text('تجاوزها والمتابعة إلى الفريم الزمني'), findsNothing);
    await tester.tap(srTouch2);
    await tester.pumpAndSettle();
    final srTimeframeDialog = find.byKey(
      const ValueKey('trade-centered-choice-single-choice'),
    );
    final srTimeframeTokens = TdTokens.of(tester.element(srTimeframeDialog));
    expect(
      tester.widget<Dialog>(srTimeframeDialog).backgroundColor,
      srTouch2Background,
      reason: 'Touch 2 and its following timeframe list must share the same color',
    );
    expect(
      tester.widget<Dialog>(srTimeframeDialog).backgroundColor,
      Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        srTimeframeTokens.surface2,
      ),
    );
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    final srTouch2Chip = find.text('ارتداد من Support Touch 2 15MIN');
    expect(srTouch2Chip, findsOneWidget);

    // Editing an S/R bounce restores the previous Touch 2 choice.
    await tester.ensureVisible(srTouch2Chip);
    await tester.tap(srTouch2Chip);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من Support Touch — اختياري'), findsOneWidget);
    final selectedSrTouch2 = find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    );
    expect(tester.widget<ListTile>(selectedSrTouch2).selected, isTrue);
    await tester.tap(selectedSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    // The dropdown is in Trade Details; switch tabs for direction updates
    // while keeping the selected S/R bounce mounted in the other panel.
    await _selectTradeFormTab(tester, 'details');
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');
    expect(find.text('ارتداد من Resistan Touch 2 15MIN'), findsOneWidget);
    final sellBounceChip = find.text('ارتداد من Resistan Touch 2 15MIN');
    await tester.ensureVisible(sellBounceChip);
    await tester.tap(sellBounceChip);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من Resistan Touch — اختياري'), findsOneWidget,
        reason: 'the Touch 2 heading identifies the current SELL-side bounce scenario');
    expect(tester.widget<ListTile>(find.byKey(
      const ValueKey('touch2-choice-bounceFromSrZone'),
    )).selected, isTrue,
        reason: 'an existing Touch 2 qualifier remains selected while editing');
    await tester.tapAt(const Offset(4, 4));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'details');
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(buyOption);
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');
    expect(find.text('ارتداد من Support Touch 2 15MIN'), findsOneWidget);

    // A second S/R bounce can explicitly skip the optional Touch 2 qualifier.
    await tester.ensureVisible(addBounce);
    await tester.tap(find.descendant(of: addBounce, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من منطقة S/R'));
    await tester.pumpAndSettle();
    final skipSrTouch2 = find.byKey(
      const ValueKey('skip-touch2-bounceFromSrZone'),
    );
    expect(skipSrTouch2, findsOneWidget);
    await tester.tap(skipSrTouch2);
    await tester.pumpAndSettle();
    await tester.tap(find.text('4H').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من Support 4H'), findsOneWidget);

    // A positive result is a win: the merged save bar is already in the win
    // style, with no classification step and no outcome menu.
    final save = find.byKey(const ValueKey('save-trade-button'));
    await tester.ensureVisible(save);
    expect(find.byKey(const ValueKey('trade-save-bar')), findsOneWidget);
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('trade-outcome-pill-title'))).data,
      'رابحة',
    );
    expect(find.byKey(const ValueKey('choose-trade-classification-button')), findsNothing);
    expect(find.byKey(const ValueKey('trade-outcome-menu')), findsNothing);
    await tester.tap(save);
    await tester.pumpAndSettle();

    expect(savedTrade, isNotNull);
    expect(savedTrade!.classification, TradeClassification.win);
    expect(savedTrade!.effectiveClassification, TradeClassification.win);
    expect(savedTrade!.result, 42.5,
        reason: 'the selected + sign is applied to the entered unsigned magnitude when saving');
    expect(savedTrade!.market, 'GC');
    expect(savedTrade!.side, TradeSide.buy);
    expect(savedTrade!.anchor, 'zoneSd');
    expect(savedTrade!.effectiveAnchors, ['zoneSd', 'engulfing', 'base']);
    expect(savedTrade!.anchorTimeframes, {
      'zoneSd': '15MIN',
      'engulfing': '5MIN',
      'base': '4H',
    });
    expect(savedTrade!.reverseSignalSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'reverseSdZone',
        timeframe: '30MIN',
      ),
      TradeEntryConditionSetup(
        optionKey: 'reverseHns',
        timeframe: '1H',
      ),
      TradeEntryConditionSetup(
        optionKey: 'reverseLongCandleWick',
        timeframe: '5MIN',
      ),
    ]);
    expect(savedTrade!.bounceZoneSetups, const [
      TradeEntryConditionSetup(
        optionKey: 'bounceFromTrendlineTouch34',
        timeframe: '1H',
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '15MIN',
        touch2: true,
      ),
      TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '4H',
      ),
    ]);
    expect(savedTrade!.entrySetups.single, const TradeEntrySetup(reason: 'RFS', timeframe: '15MIN'));
    expect(savedTrade!.confirmationSetups.single, const TradeConfirmationSetup(type: 'confirmEngulfing', timeframe: '5MIN'));
  });

  testWidgets('entry-condition selected setups fold into the same summary rectangle', (tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final direction = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.ensureVisible(direction);
    await tester.tap(direction);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();

    await _selectTradeFormTab(tester, 'conditions');
    final reverseField = find.byKey(const ValueKey('reverse-signal-category-trigger'));
    await tester.ensureVisible(reverseField);
    await tester.tap(reverseField);
    await tester.pumpAndSettle();
    await tester.tap(find.text('S/R عكسي'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();

    final title = find.byKey(
      const ValueKey('trade-selection-field-title-reverse-signals'),
    );
    await tester.tap(title);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('entry-condition-summary-reverse-signals')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('entry-condition-label-reverseSr-15MIN--false')),
      findsNothing,
    );
    await tester.tap(
      find.byKey(const ValueKey('entry-condition-summary-reverse-signals')),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('entry-condition-summary-reverse-signals')),
      findsNothing,
    );
  });

  testWidgets('trade form section and behavior tabs are horizontal and preserve panel state', (tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final detailsTab = find.byKey(
      const ValueKey('trade-form-section-tab-details'),
    );
    final conditionsTab = find.byKey(
      const ValueKey('trade-form-section-tab-conditions'),
    );
    final behaviorTab = find.byKey(
      const ValueKey('trade-form-section-tab-behavior'),
    );
    await tester.ensureVisible(detailsTab);

    expect(detailsTab, findsOneWidget);
    expect(conditionsTab, findsOneWidget);
    expect(behaviorTab, findsOneWidget);
    expect(find.text('بيانات الصفقة'), findsOneWidget);
    expect(find.text('ظروف'), findsOneWidget);
    expect(find.text('سلوك'), findsOneWidget);
    expect(find.descendant(of: detailsTab, matching: find.byIcon(Icons.receipt_long_outlined)), findsOneWidget);
    expect(find.descendant(of: conditionsTab, matching: find.byIcon(Icons.radar_rounded)), findsOneWidget);
    expect(find.descendant(of: behaviorTab, matching: find.byIcon(Icons.fact_check_outlined)), findsOneWidget);
    expect(
      find.byKey(const ValueKey('trade-entry-identifiers-row')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('reverse-signal-category-trigger')),
      findsNothing,
    );
    expect(find.text('القرارات'), findsNothing);

    final detailsRect = tester.getRect(detailsTab);
    final conditionsRect = tester.getRect(conditionsTab);
    final behaviorRect = tester.getRect(behaviorTab);
    expect(detailsRect.top, closeTo(conditionsRect.top, .5));
    expect(conditionsRect.top, closeTo(behaviorRect.top, .5));
    expect(detailsRect.width, closeTo(conditionsRect.width, .5));
    expect(conditionsRect.width, closeTo(behaviorRect.width, .5));
    expect(detailsRect.left, greaterThan(conditionsRect.left));
    expect(conditionsRect.left, greaterThan(behaviorRect.left));
    expect(detailsRect.right, closeTo(354, 1));
    expect(behaviorRect.left, closeTo(6, 1));

    await tester.tap(conditionsTab);
    await tester.pumpAndSettle();
    expect(find.text('ظروف الدخول'), findsOneWidget);
    expect(find.text('بيانات'), findsOneWidget);
    expect(find.text('سلوك'), findsOneWidget);
    expect(
      find.byKey(const ValueKey('reverse-signal-category-trigger')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('trade-entry-identifiers-row')),
      findsNothing,
    );

    await tester.tap(behaviorTab);
    await tester.pumpAndSettle();
    expect(find.text('سلوك التداول'), findsOneWidget);
    expect(find.text('بيانات'), findsOneWidget);
    expect(find.text('ظروف'), findsOneWidget);
    expect(find.text('القرارات'), findsOneWidget);
    expect(find.text('الالتزام'), findsOneWidget);
    expect(find.text('أسباب عدم الدخول'), findsOneWidget);
    final decisionsTab = find.byKey(
      const ValueKey('trade-behavior-section-tab-decisions'),
    );
    final commitmentTab = find.byKey(
      const ValueKey('trade-behavior-section-tab-commitment'),
    );
    final noEntryTab = find.byKey(
      const ValueKey('trade-behavior-section-tab-no-entry'),
    );
    final decisionsRect = tester.getRect(decisionsTab);
    final commitmentRect = tester.getRect(commitmentTab);
    final noEntryRect = tester.getRect(noEntryTab);
    expect(decisionsRect.top, closeTo(commitmentRect.top, .5));
    expect(commitmentRect.top, closeTo(noEntryRect.top, .5));
    expect(decisionsRect.width, closeTo(commitmentRect.width, .5));
    expect(commitmentRect.width, closeTo(noEntryRect.width, .5));
    expect(decisionsRect.left, greaterThan(commitmentRect.left));
    expect(commitmentRect.left, greaterThan(noEntryRect.left));
    expect(
      (tester.widget<AnimatedContainer>(find.byKey(
        const ValueKey('trade-form-section-tab-surface-details'),
      )).decoration! as BoxDecoration).color,
      TradeDetailPalette.dataSurfaceDark,
    );
    expect(
      (tester.widget<AnimatedContainer>(find.byKey(
        const ValueKey('trade-form-section-tab-surface-conditions'),
      )).decoration! as BoxDecoration).color,
      TradeDetailPalette.entryConditionsPanelDark,
    );
    expect(
      (tester.widget<AnimatedContainer>(find.byKey(
        const ValueKey('trade-form-section-tab-surface-behavior'),
      )).decoration! as BoxDecoration).color,
      TradeDetailPalette.reviewOuterDark,
    );
    expect(
      (tester.widget<AnimatedContainer>(find.byKey(
        const ValueKey('trade-behavior-section-tab-surface-decisions'),
      )).decoration! as BoxDecoration).color,
      TradeDetailPalette.reviewDecisionDark,
    );
    expect(
      (tester.widget<AnimatedContainer>(find.byKey(
        const ValueKey('trade-behavior-section-tab-surface-commitment'),
      )).decoration! as BoxDecoration).color,
      TradeDetailPalette.reviewCommitmentDark,
    );
    expect(
      (tester.widget<AnimatedContainer>(find.byKey(
        const ValueKey('trade-behavior-section-tab-surface-no-entry'),
      )).decoration! as BoxDecoration).color,
      TradeDetailPalette.reviewNoEntryDark,
    );

    // The Decisions panel remains visible while switching away and back.
    expect(find.byKey(const ValueKey('trade-decision-zones')), findsOneWidget);
    await tester.ensureVisible(detailsTab);
    await tester.tap(detailsTab);
    await tester.pumpAndSettle();
    await tester.ensureVisible(behaviorTab);
    await tester.tap(behaviorTab);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('trade-decision-zones')),
      findsOneWidget,
      reason: 'the expanded Decisions section remains expanded after tab navigation',
    );
  });

  testWidgets('bounce area groups liquidity and trendline choices and resolves Zone S/D from the direction', (tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () => Navigator.of(context).push<Trade>(
                    MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                  ),
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');

    final bounceHeader = find.byKey(const ValueKey('bounce-zone-category-trigger'));
    final addBounce = find.byKey(const ValueKey('add-bounce-zone-setup'));

    // «سحب سيولة» → popup with the two liquidity choices → timeframe list.
    await tester.ensureVisible(bounceHeader);
    await tester.tap(bounceHeader);
    await tester.pumpAndSettle();
    await tester.tap(find.text('سحب سيولة'));
    await tester.pumpAndSettle();
    expect(find.text('سيولة داخلية'), findsOneWidget);
    expect(find.text('سيولة خارجية'), findsOneWidget);
    expect(find.text('اختيار الفريم الزمني'), findsNothing);
    await tester.tap(find.text('سيولة داخلية'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(
      find.text('ظروف الدخول · منطقة الارتداد · سحب سيولة داخلية'),
      findsOneWidget,
    );
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('سحب سيولة داخلية 15MIN'), findsOneWidget);

    // «إرتداد من Trendline» → Breakout choice.
    await tester.ensureVisible(addBounce);
    await tester.tap(find.descendant(of: addBounce, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('إرتداد من Trendline'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Trend Line Touch 3-4 Breakout'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('30MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('إرتداد من Trend Line Touch 3-4 Breakout 30MIN'), findsOneWidget);

    // «ارتداد من Zone S/D» → timeframe list directly; BUY shows Supply Zone.
    await tester.ensureVisible(addBounce);
    await tester.tap(find.descendant(of: addBounce, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ارتداد من Zone S/D'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget,
        reason: 'Zone S/D continues straight to the timeframe list');
    expect(
      find.text('ظروف الدخول · منطقة الارتداد · ارتداد من Supply Zone'),
      findsOneWidget,
    );
    await tester.tap(find.text('5MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('ارتداد من Supply Zone 5MIN'), findsOneWidget);

    // The direction selector lives in Trade Details; return to Entry
    // Conditions afterwards to verify its updated semantic label.
    await _selectTradeFormTab(tester, 'details');
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');
    expect(find.text('ارتداد من Demand Zone 5MIN'), findsOneWidget);
    expect(find.text('ارتداد من Supply Zone 5MIN'), findsNothing);
    expect(find.text('سحب سيولة داخلية 15MIN'), findsOneWidget);
    expect(find.text('إرتداد من Trend Line Touch 3-4 Breakout 30MIN'), findsOneWidget);
  });

  testWidgets('opposing signals offer two negative-close rows with an optional Trendline popup', (tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: FilledButton(
                  onPressed: () => Navigator.of(context).push<Trade>(
                    MaterialPageRoute(builder: (_) => const TradeFormScreen()),
                  ),
                  child: const Text('فتح النموذج'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('فتح النموذج'));
    await tester.pumpAndSettle();

    final directionSelector = find.byKey(const ValueKey('trade-direction-selector'));
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-buy')));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');

    final reverseHeader = find.byKey(const ValueKey('reverse-signal-category-trigger'));
    final addReverse = find.byKey(const ValueKey('add-reverse-signal-setup'));

    // The two new rows join the existing four.
    await tester.ensureVisible(reverseHeader);
    await tester.tap(reverseHeader);
    await tester.pumpAndSettle();
    expect(find.text('إغلاق سلبي فوق المنطقة'), findsOneWidget);
    expect(find.text('إغلاق سلبي داخل المنطقة'), findsOneWidget);
    expect(find.text('S/R عكسي'), findsOneWidget);
    expect(find.text('ذيل شمعة طويل عكسي'), findsOneWidget);

    // Row + Trendline choice → «… معا إغلاق تحت Trendline 15MIN».
    await tester.tap(find.text('إغلاق سلبي داخل المنطقة'));
    await tester.pumpAndSettle();
    expect(find.text('فوق Trendline'), findsOneWidget);
    expect(find.text('تحت Trendline'), findsOneWidget);
    expect(find.text('اختيار الفريم الزمني'), findsNothing,
        reason: 'the Trendline popup comes before the timeframe list');
    await tester.tap(find.text('تحت Trendline'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    expect(
      find.text(
        'ظروف الدخول · إشارات عكسية · إغلاق سلبي داخل المنطقة معا إغلاق تحت Trendline',
      ),
      findsOneWidget,
    );
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(
      find.text('إغلاق سلبي داخل المنطقة معا إغلاق تحت Trendline 15MIN'),
      findsOneWidget,
    );

    // Row only (the popup is skipped with «متابعة») → «… 15MIN».
    await tester.ensureVisible(addReverse);
    await tester.tap(find.descendant(of: addReverse, matching: find.byIcon(Icons.keyboard_arrow_down_rounded)));
    await tester.pumpAndSettle();
    await tester.tap(find.text('إغلاق سلبي فوق المنطقة'));
    await tester.pumpAndSettle();
    expect(find.text('فوق Trendline'), findsOneWidget);
    expect(find.text('تحت Trendline'), findsOneWidget);
    await tester.tap(find.text('متابعة'));
    await tester.pumpAndSettle();
    expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
    await tester.tap(find.text('15MIN').last);
    await tester.pumpAndSettle();
    expect(find.text('إغلاق سلبي فوق المنطقة 15MIN'), findsOneWidget);
    expect(
      find.text('إغلاق سلبي داخل المنطقة معا إغلاق تحت Trendline 15MIN'),
      findsOneWidget,
    );

    // The qualifier is direction-independent: SELL keeps both labels.
    await _selectTradeFormTab(tester, 'details');
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('trade-direction-option-sell')));
    await tester.pumpAndSettle();
    await _selectTradeFormTab(tester, 'conditions');
    expect(find.text('إغلاق سلبي فوق المنطقة 15MIN'), findsOneWidget);
    expect(
      find.text('إغلاق سلبي داخل المنطقة معا إغلاق تحت Trendline 15MIN'),
      findsOneWidget,
    );
  });

  testWidgets('requires a trade direction before selecting an opposing signal', (tester) async {
    tester.view.setLogicalSize(const Size(360, 800));
    tester.view.devicePixelRatio = 1;
    await tester.pumpWidget(
      AppScope(
        controller: app,
        child: MaterialApp(
          theme: buildAppTheme(Brightness.dark),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          home: const TradeFormScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final directionSelector = find.byKey(
      const ValueKey('trade-direction-selector'),
    );
    final marketSelector = find.byKey(const ValueKey('trade-market-input'));
    final moodSelector = find.byKey(const ValueKey('trade-mood-dropdown'));
    final addEntry = find.byKey(const ValueKey('add-entry-setup'));
    final addConfirmation = find.byKey(
      const ValueKey('add-confirmation-setup'),
    );
    final anchorSelector = find.byKey(
      const ValueKey('trade-anchor-selector'),
    );
    final reverseSelector = find.byKey(
      const ValueKey('reverse-signal-category-trigger'),
    );
    final bounceSelector = find.byKey(
      const ValueKey('bounce-zone-category-trigger'),
    );
    final dateButton = find.byKey(
      const ValueKey('trade-date-time-picker-button'),
    );

    expect(tester.widget<InkWell>(directionSelector).onTap, isNotNull);
    expect(tester.widget<InkWell>(marketSelector).onTap, isNull);
    expect(tester.widget<InkWell>(moodSelector).onTap, isNull);
    expect(tester.widget<InkWell>(addEntry).onTap, isNull);
    expect(tester.widget<InkWell>(addConfirmation).onTap, isNull);
    expect(
      tester.widget<InkWell>(find.descendant(
        of: anchorSelector,
        matching: find.byType(InkWell),
      )).onTap,
      isNull,
    );
    expect(tester.widget<OutlinedButton>(dateButton).onPressed, isNull);
    final resultInput = find.byKey(const ValueKey('trade-result-input'));
    expect(tester.widget<TextFormField>(resultInput).readOnly, isTrue);
    await tester.ensureVisible(resultInput);
    await tester.tap(resultInput);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsOneWidget,
        reason: 'the sign selector remains available before trade direction is chosen');
    expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsOneWidget);
    expect(find.byType(Dialog), findsNothing);

    // Trading-behavior rows are also locked, while their section headings can
    // still expand without changing any recorded selection.
    await _selectTradeFormTab(tester, 'behavior');
    await tester.ensureVisible(find.text('القرارات'));
    await tester.tap(find.text('القرارات'));
    await tester.pumpAndSettle();
    final reviewRow = find.byKey(const ValueKey('review-enteredEarly'));
    expect(tester.widget<InkWell>(reviewRow).onTap, isNull);

    await tester.ensureVisible(find.text('أسباب عدم الدخول'));
    await tester.tap(find.text('أسباب عدم الدخول'));
    await tester.pumpAndSettle();
    final noEntryRow = find.byKey(
      const ValueKey('no-entry-fearRepeatLossAfterLoss'),
    );
    expect(tester.widget<InkWell>(noEntryRow).onTap, isNull);

    // Verify the Entry Conditions controls independently.
    await _selectTradeFormTab(tester, 'conditions');
    expect(tester.widget<InkWell>(reverseSelector).onTap, isNull);
    expect(tester.widget<InkWell>(bounceSelector).onTap, isNull);

    // Selecting a side unlocks the trade-detail, entry-condition, and
    // trading-behavior controls without disabling Result & Risk at any point.
    await _selectTradeFormTab(tester, 'details');
    await tester.ensureVisible(directionSelector);
    await tester.tap(directionSelector);
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(const ValueKey('trade-direction-option-buy')),
    );
    await tester.pumpAndSettle();
    expect(tester.widget<InkWell>(marketSelector).onTap, isNotNull);
    expect(tester.widget<InkWell>(moodSelector).onTap, isNotNull);
    expect(tester.widget<InkWell>(addEntry).onTap, isNotNull);
    expect(tester.widget<InkWell>(addConfirmation).onTap, isNotNull);
    expect(tester.widget<OutlinedButton>(dateButton).onPressed, isNotNull);

    await _selectTradeFormTab(tester, 'conditions');
    expect(tester.widget<InkWell>(reverseSelector).onTap, isNotNull);
    expect(tester.widget<InkWell>(bounceSelector).onTap, isNotNull);

    await _selectTradeFormTab(tester, 'behavior');
    expect(tester.widget<InkWell>(reviewRow).onTap, isNotNull);
    expect(tester.widget<InkWell>(noEntryRow).onTap, isNotNull);
  });

  testWidgets(
    'a generic no-entry reason stays unlinked until a selected opposing signal is long-pressed',
    (tester) async {
      tester.view.setLogicalSize(const Size(360, 800));
      tester.view.devicePixelRatio = 1;
      await tester.pumpWidget(
        AppScope(
          controller: app,
          child: MaterialApp(
            theme: buildAppTheme(Brightness.dark),
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar'), Locale('en')],
            localizationsDelegates: GlobalMaterialLocalizations.delegates,
            home: const TradeFormScreen(),
          ),
        ),
      );
      await tester.pumpAndSettle();

      // Trade-behavior selections are locked until the user sets BUY/SELL.
      final directionSelector = find.byKey(
        const ValueKey('trade-direction-selector'),
      );
      await _selectTradeFormTab(tester, 'details');
      await tester.ensureVisible(directionSelector);
      await tester.tap(directionSelector);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trade-direction-option-buy')),
      );
      await tester.pumpAndSettle();
      await _selectTradeFormTab(tester, 'conditions');

      final reverseSurfaceFinder =
          find.byKey(const ValueKey('reverse-signal-category-surface'));
      await tester.scrollUntilVisible(reverseSurfaceFinder, 160);
      await tester.pumpAndSettle();
      final reverseSurfaceBefore =
          tester.widget<Container>(reverseSurfaceFinder);
      final entryConditionsSection = find.byKey(
        const ValueKey('entry-conditions-section-card'),
      );
      final entryConditionsBefore = tester.widget<Container>(
        entryConditionsSection,
      ).decoration as BoxDecoration;
      expect(
        (entryConditionsBefore.gradient as LinearGradient).colors,
        const [
          Color(0xFF1B3948),
          Color(0xFF162F3D),
          Color(0xFF122936),
          Color(0xFF0E202B),
        ],
      );
      final reverseInputFinder = find.descendant(
        of: reverseSurfaceFinder,
        matching: find.byType(InputDecorator),
      );
      final conditionTokens = TdTokens.of(tester.element(reverseInputFinder));
      // Both inner fields carry the same tint as their timeframe list popup
      // (accent blended over surface2), not the previous neutral grey.
      final reverseConditionFill = Color.alphaBlend(
        const Color(0xFF6E9FB6).withValues(alpha: .14),
        conditionTokens.surface2,
      );
      final bounceConditionFill = Color.alphaBlend(
        const Color(0xFF78AFC3).withValues(alpha: .14),
        conditionTokens.surface2,
      );
      expect(reverseConditionFill, isNot(conditionTokens.surface2));
      expect(bounceConditionFill, isNot(conditionTokens.surface2));

      expect(reverseSurfaceBefore.decoration, isNull,
          reason: 'the category is a single input field rather than a nested category card');
      expect(
        tester.widget<InputDecorator>(reverseInputFinder).decoration.fillColor,
        reverseConditionFill,
      );
      expect(
        tester.widget<InputDecorator>(find.descendant(
          of: find.byKey(const ValueKey('bounce-zone-category-surface')),
          matching: find.byType(InputDecorator),
        )).decoration.fillColor,
        bounceConditionFill,
        reason: 'Bounce area inner colour matches the Entry Conditions timeframe list tint',
      );
      expect(
        find.byKey(const ValueKey('no-entry-reverse-signal-connector')),
        findsNothing,
      );

      // The three Decisions zones sit side by side as equal rectangles.
      await _selectTradeFormTab(tester, 'behavior');
      await tester.ensureVisible(find.text('القرارات'));
      await tester.tap(find.text('القرارات'));
      await tester.pumpAndSettle();
      final zoneTabs = <String, String>{
        'violations': 'مخالفات التنفيذ',
        'analysis': 'جودة تحليل',
        'risk': 'إدارة المخاطرة',
      };
      final tabRects = <Rect>[];
      for (final entry in zoneTabs.entries) {
        final tab = find.byKey(ValueKey('decision-zone-tab-${entry.key}'));
        expect(tab, findsOneWidget);
        expect(
          find.descendant(of: tab, matching: find.text(entry.value)),
          findsOneWidget,
        );
        tabRects.add(tester.getRect(tab));
      }
      expect(tabRects[0].width, closeTo(tabRects[1].width, .5));
      expect(tabRects[1].width, closeTo(tabRects[2].width, .5));
      expect(tabRects[0].top, closeTo(tabRects[2].top, .5),
          reason: 'the three zones share one row');
      final reviewOption = find.byKey(const ValueKey('review-enteredEarly'));
      final reviewOptionLabel = tester.widget<Text>(
        find.descendant(of: reviewOption, matching: find.byType(Text)),
      );
      expect(reviewOptionLabel.style!.fontSize, 14.5);
      await tester.tap(find.text('القرارات'));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('أسباب عدم الدخول'));
      await tester.tap(find.text('أسباب عدم الدخول'));
      await tester.pumpAndSettle();
      final noEntryOption =
          find.byKey(const ValueKey('no-entry-fearRepeatLossAfterLoss'));
      final noEntryLabel = tester.widget<Text>(
        find.descendant(of: noEntryOption, matching: find.byType(Text)),
      );
      expect(noEntryLabel.style!.fontSize, 14.5);
      await _selectTradeFormTab(tester, 'behavior');
      await tester.ensureVisible(noEntryOption);
      await tester.tap(noEntryOption);
      await tester.pumpAndSettle();
      await _selectTradeFormTab(tester, 'conditions');

      final entryConditionsAfter = tester.widget<Container>(
        entryConditionsSection,
      ).decoration as BoxDecoration;
      expect(
        (entryConditionsAfter.gradient as LinearGradient).colors,
        const [
          Color(0xFF1B3948),
          Color(0xFF162F3D),
          Color(0xFF122936),
          Color(0xFF0E202B),
        ],
        reason: 'a generic no-entry reason must not recolor Entry Conditions or imply a direct opposing-signal link',
      );
      expect(
        entryConditionsAfter.border!.top.color,
        isNot(const Color(0xFF7863C4).withValues(alpha: .17)),
      );

      final reverseSurfaceAfter =
          tester.widget<Container>(reverseSurfaceFinder);
      expect(reverseSurfaceAfter.decoration, isNull);
      expect(
        tester.widget<InputDecorator>(reverseInputFinder).decoration.fillColor,
        reverseConditionFill,
      );
      final bounceSurfaceFinder =
          find.byKey(const ValueKey('bounce-zone-category-surface'));
      final bounceInputFinder = find.descendant(
        of: bounceSurfaceFinder,
        matching: find.byType(InputDecorator),
      );
      expect(
        tester.widget<InputDecorator>(bounceInputFinder).decoration.fillColor,
        bounceConditionFill,
        reason: 'Bounce area field must keep its tinted surface regardless of signal accent',
      );
      expect(
        find.byKey(const ValueKey('no-entry-reverse-signal-connector')),
        findsNothing,
        reason: 'the separated tabs no longer draw a cross-panel side rail',
      );

      // The selected no-entry reason retains its contextual picker tint
      // without changing the separated section panels' link state.
      final activeDirectionSelector = find.byKey(
        const ValueKey('trade-direction-selector'),
      );
      await _selectTradeFormTab(tester, 'details');
      expect(
        tester.widget<InkWell>(activeDirectionSelector).onTap,
        isNotNull,
      );
      await _selectTradeFormTab(tester, 'conditions');

      // The picker keeps its established contextual tone; the Conditions
      // panel remains teal/unlinked until the practical long-press.
      final reverseHeader = find.byKey(
        const ValueKey('reverse-signal-category-trigger'),
      );
      await tester.ensureVisible(reverseHeader);
      await tester.tap(reverseHeader);
      await tester.pumpAndSettle();
      final reverseChoiceDialog = find.byKey(
        const ValueKey('trade-centered-choice-single-choice'),
      );
      final dialogWidget = tester.widget<Dialog>(reverseChoiceDialog);
      final dialogTokens = TdTokens.of(tester.element(reverseChoiceDialog));
      expect(
        dialogWidget.backgroundColor,
        Color.alphaBlend(
          const Color(0xFFB69AF0).withValues(alpha: .14),
          dialogTokens.surface2,
        ),
      );
      final dialogShape = dialogWidget.shape as RoundedRectangleBorder;
      expect(
        dialogShape.side.color,
        const Color(0xFFB69AF0).withValues(alpha: .17),
      );
      final reverseChoiceTile = tester.widget<ListTile>(
        find.descendant(
          of: reverseChoiceDialog,
          matching: find.byType(ListTile),
        ).first,
      );
      expect(
        reverseChoiceTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
      );
      await tester.tap(find.text('S/R عكسي'));
      await tester.pumpAndSettle();
      final reverseTimeframeDialog = find.byKey(
        const ValueKey('trade-centered-choice-single-choice'),
      );
      expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
      expect(
        find.text('ظروف الدخول · إشارات عكسية · Support عكسي'),
        findsOneWidget,
      );
      final reverseTimeframeDialogWidget = tester.widget<Dialog>(
        reverseTimeframeDialog,
      );
      final reverseTimeframeTokens = TdTokens.of(
        tester.element(reverseTimeframeDialog),
      );
      expect(
        reverseTimeframeDialogWidget.backgroundColor,
        Color.alphaBlend(
          const Color(0xFFB69AF0).withValues(alpha: .14),
          reverseTimeframeTokens.surface2,
        ),
        reason: 'the picker retains its established no-entry semantic surface',
      );
      final reverseTimeframeShape =
          reverseTimeframeDialogWidget.shape as RoundedRectangleBorder;
      expect(
        reverseTimeframeShape.side.color,
        const Color(0xFFB69AF0).withValues(alpha: .17),
      );
      final reverseTimeframeTile = tester.widget<ListTile>(
        find.descendant(
          of: reverseTimeframeDialog,
          matching: find.byType(ListTile),
        ).first,
      );
      expect(
        reverseTimeframeTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
        reason: 'the picker retains its established no-entry semantic tint',
      );
      await tester.tap(find.text('30MIN').last);
      await tester.pumpAndSettle();
      expect(
        find.text('Support عكسي 30MIN'),
        findsOneWidget,
        reason: 'a Buy trade must show the reversed support role',
      );

      await _selectTradeFormTab(tester, 'details');
      await tester.ensureVisible(directionSelector);
      await tester.tap(directionSelector);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trade-direction-option-sell')),
      );
      await tester.pumpAndSettle();
      await _selectTradeFormTab(tester, 'conditions');
      expect(
        find.text('Resistan عكسي 30MIN'),
        findsOneWidget,
        reason: 'a Sell trade must show the reversed resistance role',
      );

      await _selectTradeFormTab(tester, 'details');
      await tester.ensureVisible(directionSelector);
      await tester.tap(directionSelector);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trade-direction-option-buy')),
      );
      await tester.pumpAndSettle();
      await _selectTradeFormTab(tester, 'conditions');
      expect(
        find.text('Support عكسي 30MIN'),
        findsOneWidget,
        reason: 'switching back to Buy must restore the reversed support label',
      );

      // A generic no-entry reason alone does not activate the practical-link
      // purple state; editing an opposing signal keeps its normal blue-grey tone.
      await _selectTradeFormTab(tester, 'conditions');
      final bounceZoneSurface = find.byKey(
        const ValueKey('bounce-zone-category-surface'),
      );
      final bounceZoneInput = find.descendant(
        of: bounceZoneSurface,
        matching: find.byType(InputDecorator),
      );
      final bounceZoneOriginalFill = tester
          .widget<InputDecorator>(bounceZoneInput)
          .decoration
          .fillColor;

      final selectedReverseSetup = find.byKey(
        const ValueKey('entry-condition-reverseSr-30MIN--false'),
      );
      await tester.ensureVisible(selectedReverseSetup);
      await tester.tap(selectedReverseSetup);
      await tester.pumpAndSettle();
      final selectedReverseTileFinder = find.descendant(
        of: find.byKey(const ValueKey('trade-centered-choice-single-choice')),
        matching: find.byWidgetPredicate(
          (widget) => widget is ListTile && widget.selected,
        ),
      );
      expect(selectedReverseTileFinder, findsOneWidget);
      final selectedReverseTile = tester.widget<ListTile>(
        selectedReverseTileFinder,
      );
      expect(selectedReverseTile.selected, isTrue);
      expect(
        selectedReverseTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
      );
      await tester.tap(selectedReverseTileFinder);
      await tester.pumpAndSettle();
      final editTimeframeDialog = find.byKey(
        const ValueKey('trade-centered-choice-single-choice'),
      );
      expect(find.text('اختيار الفريم الزمني'), findsOneWidget);
      expect(
        find.text('ظروف الدخول · إشارات عكسية · Support عكسي'),
        findsOneWidget,
      );
      final editTimeframeTile = tester.widget<ListTile>(
        find.descendant(
          of: editTimeframeDialog,
          matching: find.byWidgetPredicate(
            (widget) => widget is ListTile && widget.selected,
          ),
        ),
      );
      expect(editTimeframeTile.selected, isTrue);
      expect(
        editTimeframeTile.selectedTileColor,
        const Color(0xFFB69AF0).withValues(alpha: .16),
        reason: 'editing an opposing signal retains the existing contextual semantic tint',
      );
      final editTimeframeDialogWidget = tester.widget<Dialog>(
        editTimeframeDialog,
      );
      expect(
        editTimeframeDialogWidget.backgroundColor,
        Color.alphaBlend(
          const Color(0xFFB69AF0).withValues(alpha: .14),
          TdTokens.of(tester.element(editTimeframeDialog)).surface2,
        ),
      );
      await tester.tapAt(const Offset(6, 6));
      await tester.pumpAndSettle();

      // A long-press on a selected opposing signal marks it as a practical
      // no-entry reason independently of the psychological no-entry list.
      final reverseSignalLabel = find.byKey(
        const ValueKey('entry-condition-label-reverseSr-30MIN--false'),
      );
      await tester.ensureVisible(reverseSignalLabel);
      await tester.longPress(reverseSignalLabel);
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('practical-no-entry-link-reverseSr-30MIN')),
        findsOneWidget,
      );
      final entryConditionsAfterLongPress = tester.widget<Container>(
        entryConditionsSection,
      ).decoration as BoxDecoration;
      expect(
        (entryConditionsAfterLongPress.gradient as LinearGradient).colors,
        const [
          Color(0xFF312A57),
          Color(0xFF2B2549),
          Color(0xFF241F3E),
          Color(0xFF1D1933),
        ],
        reason: 'the Entry Conditions section turns purple only after long-pressing a selected opposing signal',
      );
      expect(
        find.byKey(const ValueKey('no-entry-reverse-signal-connector')),
        findsNothing,
        reason: 'the link remains represented by the original violet section palette across the separate tabs',
      );
      final linkedReverseInput = tester.widget<InputDecorator>(
        find.descendant(
          of: reverseSurfaceFinder,
          matching: find.byType(InputDecorator),
        ),
      );
      expect(
        linkedReverseInput.decoration.fillColor,
        TradeDetailPalette.linkedEntryConditionsFieldDark,
        reason: 'a long-pressed opposing signal gives its inner field the same muted purple surface as saved trades',
      );
      final linkedReverseBorder =
          linkedReverseInput.decoration.enabledBorder as OutlineInputBorder;
      expect(
        linkedReverseBorder.borderSide.color,
        TradeDetailPalette.linkedEntryConditionsFieldEdge.withValues(
          alpha: .18,
        ),
        reason: 'the practical-link field uses the restrained violet edge from the saved-trade palette',
      );

      expect(
        tester.widget<InputDecorator>(bounceZoneInput).decoration.fillColor,
        bounceZoneOriginalFill,
        reason: 'linking an opposing signal must not recolor the Bounce area inner field',
      );
      expect(
        (tester.widget<InputDecorator>(bounceZoneInput).decoration.enabledBorder
                as OutlineInputBorder)
            .borderSide.color,
        isNot(TradeDetailPalette.linkedEntryConditionsFieldEdge.withValues(alpha: .18)),
        reason: 'Bounce area retains its original blue outline when Opposing signals turns violet',
      );
      expect(
        tester.widget<TextFormField>(
          find.byKey(const ValueKey('trade-result-input')),
        ).controller!.text,
        isEmpty,
        reason: 'marking a reverse signal as a practical no-entry reason clears any realized P/L amount',
      );
      expect(find.byKey(const ValueKey('trade-result-sign-indicator')), findsNothing);
      expect(find.byKey(const ValueKey('trade-result-sign-positive')), findsNothing);
      expect(find.byKey(const ValueKey('trade-result-sign-negative')), findsNothing);

      // A practical opposing-signal reason makes the trade a missed setup
      // automatically; only the would-be result is asked for in the pill menu.
      final outcomePill = find.byKey(const ValueKey('trade-outcome-pill'));
      await tester.ensureVisible(outcomePill);
      expect(
        tester.widget<Text>(find.byKey(const ValueKey('trade-outcome-pill-title'))).data,
        'ضائعة',
      );
      await tester.tap(outcomePill);
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('trade-outcome-option-missedWin')),
          findsOneWidget);
      expect(find.byKey(const ValueKey('trade-outcome-option-missedLoss')),
          findsOneWidget);
      expect(find.byKey(const ValueKey('trade-outcome-option-balanced')),
          findsNothing,
          reason: 'a practical opposing-signal reason restricts the outcome to Missed');
      expect(find.byKey(const ValueKey('trade-outcome-option-atEntry')),
          findsNothing);
      await tester.tap(
        find.byKey(const ValueKey('trade-outcome-option-missedWin')),
      );
      await tester.pumpAndSettle();

      await _selectTradeFormTab(tester, 'behavior');
      await tester.ensureVisible(noEntryOption);
      await tester.tap(noEntryOption);
      await tester.pumpAndSettle();
      await _selectTradeFormTab(tester, 'conditions');
      final practicalOnlyEntryConditions = tester.widget<Container>(
        entryConditionsSection,
      ).decoration as BoxDecoration;
      expect(
        (practicalOnlyEntryConditions.gradient as LinearGradient).colors,
        const [
          Color(0xFF312A57),
          Color(0xFF2B2549),
          Color(0xFF241F3E),
          Color(0xFF1D1933),
        ],
        reason: 'the practical opposing signal must keep Entry Conditions purple after psychological reasons are cleared',
      );

      // Long-pressing the same selected signal again removes the practical
      // link; only then should the section return to teal.
      await tester.longPress(reverseSignalLabel);
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('practical-no-entry-link-reverseSr-30MIN')),
        findsNothing,
      );
      final reverseInputAfterRemoval = find.descendant(
        of: reverseSurfaceFinder,
        matching: find.byType(InputDecorator),
      );
      expect(
        tester.widget<InputDecorator>(reverseInputAfterRemoval).decoration.fillColor,
        reverseConditionFill,
        reason: 'removing the no-entry reason must restore the accent only, never recolor the field interior',
      );
      final entryConditionsAfterRemoval = tester.widget<Container>(
        entryConditionsSection,
      ).decoration as BoxDecoration;
      expect(
        (entryConditionsAfterRemoval.gradient as LinearGradient).colors.first,
        const Color(0xFF1B3948),
        reason: 'the Entry Conditions card must return to its original teal palette when the final no-entry reason is removed',
      );
      await tester.ensureVisible(reverseHeader);
      await tester.tap(reverseHeader);
      await tester.pumpAndSettle();
      final unlinkedDialog = find.byType(Dialog);
      final unlinkedDialogTokens = TdTokens.of(tester.element(unlinkedDialog));
      expect(
        tester.widget<Dialog>(unlinkedDialog).backgroundColor,
        Color.alphaBlend(
          const Color(0xFF6E9FB6).withValues(alpha: .14),
          unlinkedDialogTokens.surface2,
        ),
        reason: 'after unlinking, the opposing-signals menu returns to its standard blue-grey tone',
      );
      await tester.tapAt(const Offset(6, 6));
      await tester.pumpAndSettle();
    },
  );

  test('practical opposing-signal links persist in trade JSON and count as missed evidence', () {
    const practicalSignal = TradeEntryConditionSetup(
      optionKey: 'reverseSr',
      timeframe: '30MIN',
    );
    final trade = Trade(
      id: 'practical-link',
      accountId: 'conditions-account',
      market: 'EURUSD',
      reason: 'BREAKOUT',
      result: 0,
      riskPercent: 0,
      side: TradeSide.buy,
      confirmation: '',
      sequence: '',
      mood: 'moodUnknown',
      tradedAt: DateTime(2026, 11, 21),
      reverseSignalSetups: const [practicalSignal],
      practicalNoEntryReverseSignalSetups: const [practicalSignal],
    );

    expect(trade.hasPracticalNoEntryReason, isTrue);
    expect(trade.hasNoEntryEntryConditionLink, isTrue);
    expect(trade.effectiveClassification, TradeClassification.missed);

    final restored = Trade.fromJson(trade.toJson());
    expect(restored.practicalNoEntryReverseSignalSetups, const [practicalSignal]);
    expect(restored.hasPracticalNoEntryReason, isTrue);
    expect(restored.effectiveClassification, TradeClassification.missed);
    expect(restored.withStrategyAdherence(StrategyAdherence.followed)
        .hasPracticalNoEntryReason, isTrue);

    final legacy = Map<String, dynamic>.from(trade.toJson())
      ..remove('practicalNoEntryReverseSignalSetups');
    final restoredLegacy = Trade.fromJson(legacy);
    expect(restoredLegacy.practicalNoEntryReverseSignalSetups, isEmpty);
    expect(restoredLegacy.hasPracticalNoEntryReason, isFalse);
  });

  test('negative-close setups keep their Trendline qualifier through JSON and equality', () {
    const withRelation = TradeEntryConditionSetup(
      optionKey: 'negativeCloseInsideZone',
      timeframe: '15MIN',
      closeRelation: 'belowTrendline',
    );
    const without = TradeEntryConditionSetup(
      optionKey: 'negativeCloseInsideZone',
      timeframe: '15MIN',
    );
    expect(withRelation.toJson()['closeRelation'], 'belowTrendline');
    expect(without.toJson().containsKey('closeRelation'), isFalse,
        reason: 'older records and qualifier-less setups store no extra key');
    final restored = TradeEntryConditionSetup.fromJson(
      Map<String, dynamic>.from(withRelation.toJson()),
    );
    expect(restored, withRelation);
    expect(restored.hashCode, withRelation.hashCode);
    expect(withRelation == without, isFalse);
    expect(
      TradeEntryConditionSetup.fromJson({
        'optionKey': 'negativeCloseAboveZone',
        'timeframe': '5MIN',
        'closeRelation': 'sideways',
      }).closeRelation,
      isNull,
      reason: 'unknown qualifier values are ignored',
    );
  });

  test('new conditions remain backward compatible with existing trade JSON', () {
    final legacy = <String, dynamic>{
      'id': 'legacy',
      'accountId': 'conditions-account',
      'market': 'EURUSD',
      'reason': 'SBR',
      'result': 5,
      'riskPercent': .5,
      'side': 'buy',
      'confirmation': 'confirmBearishEngulfing',
      'sequence': '',
      'mood': 'moodCalm',
      'tradedAt': DateTime(2025, 1, 2).toIso8601String(),
    };
    final restored = Trade.fromJson(legacy);
    expect(restored.reverseSignalSetups, isEmpty);
    expect(restored.bounceZoneSetups, isEmpty);
    expect(restored.anchor, isNull);
    expect(restored.effectiveAnchors, isEmpty);
    expect(restored.anchorTimeframes, isEmpty);
  });
}
