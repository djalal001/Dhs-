#!/usr/bin/env python3
"""Static regression checks for live guided trade-entry reconciliation."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
TESTS = (ROOT / 'test/entry_conditions_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/release-arm64.yml').read_text(encoding='utf-8')
BUILD_INFO = (ROOT / 'BUILD_INFO_AR.md').read_text(encoding='utf-8')
RELEASE_NOTES = (ROOT / 'RELEASE_NOTES_AR.md').read_text(encoding='utf-8')

checks: list[tuple[str, bool]] = []


def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))


def method_body(signature: str, next_signature: str) -> str:
    if signature not in FORM or next_signature not in FORM:
        return ''
    return FORM.split(signature, 1)[1].split(next_signature, 1)[0]


check('version is 1.7.125+181', 'version: 1.7.125+181' in PUBSPEC)
check('ARM64 APK artifact uses build 181', 'traderdesk-1.7.125-build181-arm64-v8a-release' in WORKFLOW)
check('Dart symbols artifact uses build 181', 'traderdesk-1.7.125-build181-arm64-dart-symbols' in WORKFLOW)
check('build information identifies 1.7.125+181', '1.7.125+181' in BUILD_INFO and 'UPDATE_REPORT_1.7.125+181.md' in BUILD_INFO)
check('release notes identify 1.7.125+181', '1.7.125+181' in RELEASE_NOTES)

# Guidance is new-trade-only, but remains active until the form is disposed.
check('guided monitoring has a persistent active flag', 'bool _guidedEntryActive = false;' in FORM)
check('manual opt-out state has been removed', '_guidedEntryOptedOut' not in FORM and '_cancelGuidedEntryForManualEdit' not in FORM)
check('only new trades without a no-entry link can start guidance', 'widget.trade == null && !_hasEntryConditionsNoEntryLink' in FORM)
check('live resolver checks result validity', '_resultValidator(_result.text) != null' in FORM and 'return _AutoEntryStep.result;' in FORM)
check('positive result requires a valid expected loss', '_resultSign == 1 && !_hasValidGuidedExpectedLoss' in FORM)
check('direction is the first missing choice when unset', 'if (_side == null) return _AutoEntryStep.direction;' in FORM)
check('market is the first missing choice after direction', 'if (_symbol == null || _symbol!.trim().isEmpty)' in FORM)
check('mindset is missing until a real mood is selected', 'if (!_hasRecordedMindset) return _AutoEntryStep.mindset;' in FORM)
check('reconciliation is centralized on a post-frame revision guard', 'void _reconcileGuidedEntryAfterChange(' in FORM and '_guidedReconciliationRevision' in FORM and 'revision != _guidedReconciliationRevision' in FORM)

# Manual changes to selectors re-evaluate the complete required-field sequence.
direction_handler = method_body('void _handleDirectionSelected(TradeSide value)', 'Future<void> _openAutoMarketPopup()')
market_handler = method_body('void _handleMarketSelected(String value)', 'Future<void> _openAutoMindsetDialog()')
mindset_handler = method_body('Future<void> _showMindsetMultiSelect()', 'String? _resultValidator')
check('Direction selection triggers full live reconciliation', '_reconcileGuidedEntryAfterChange()' in direction_handler)
check('Market selection triggers full live reconciliation', '_reconcileGuidedEntryAfterChange()' in market_handler and '_symbol = value' in market_handler)
check('opening a completed Mindset no longer cancels monitoring', '_cancelGuidedEntryForManualEdit' not in mindset_handler and 'final keepGuidedDraft = _guidedEntryActive' in mindset_handler)
check('Mindset edits retain unconfirmed selections during guided monitoring', '_guidedMindsetDraft = {...draft};' in mindset_handler)
check('empty Mindset stays pending without immediate self-reopening', 'deferIfMindsetRemainsEmpty: true' in mindset_handler)
check('committed Mindset selection triggers reconciliation', '_reconcileGuidedEntryAfterChange(' in mindset_handler)
check('completing the first pass does not turn monitoring off', '_guidedEntryActive = false' not in method_body('Future<void> _advanceGuidedEntry()', 'Future<void> _prepareAutoPopup'))
check('no-entry linking cleanly disables this result-guidance path', '_guidedEntryActive = false;' in method_body('void _enforceMissedOnlyOutcome()', 'void _selectResultSign'))
check('result editing re-targets Result while typing', 'if (_guidedEntryActive) _autoEntryStep = _AutoEntryStep.result;' in method_body('void _handleResultChanged(String value)', 'void _handleExpectedLossChanged'))
check('expected-loss editing re-targets Expected Loss on winning trades', '_resultSign == 1' in method_body('void _handleExpectedLossChanged(String _)', '// The onEditingComplete / onFieldSubmitted callbacks'))
check('Result and Expected Loss keep explicit IME Done handlers', 'onEditingComplete: _handleResultEditingComplete' in FORM and 'onEditingComplete: _handleExpectedLossEditingComplete' in FORM)
check('read-only computed fields stay outside focus traversal', 'canRequestFocus: false' in FORM and 'skipTraversal: true' in FORM and 'descendantsAreFocusable: false' in FORM)

# Regression tests exercise the user's exact scenario and later edits to Result.
check('widget test reproduces clearing Mindset then changing Market', 'live guidance detects cleared Mindset after a later Market edit' in TESTS)
check('widget test asserts Mindset reopens after the Market edit', 'changing Market after Mindset was cleared must reopen the first incomplete field' in TESTS)
check('widget test verifies changed Result routes back to Expected Loss', 'changing the result later routes back to Expected Loss' in TESTS)
check('dismiss/reopen overlay behavior remains covered', 'guided flow resumes after Direction, Market, and Mindset overlays are dismissed' in TESTS)
check('pre-guidance manual selections are still skipped', 'guided flow skips Direction and Market when they are already complete' in TESTS)
check('saved-trade editing remains manual', 'manual edits of an existing direction and market do not auto-advance' in TESTS)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    raise SystemExit(1)
