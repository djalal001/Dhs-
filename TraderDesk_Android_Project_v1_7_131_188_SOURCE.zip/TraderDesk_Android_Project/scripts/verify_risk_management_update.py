#!/usr/bin/env python3
"""Focused source-level checks for TraderDesk 1.7.126+182 risk choices."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(name: str, passed: bool) -> None:
    checks.append((name, bool(passed)))

pubspec = read("pubspec.yaml")
catalog = read("lib/domain/trade_entry_catalog.dart")
strings = read("lib/l10n/app_strings.dart")
widget_test = read("test/trade_decision_zones_test.dart")
catalog_test = read("test/trade_entry_catalog_test.dart")
workflow = read(".github/workflows/release-arm64.yml")
release_notes = read("RELEASE_NOTES_AR.md")
build_info = read("BUILD_INFO_AR.md")

check("version is 1.7.126+182", "version: 1.7.126+182" in pubspec)
check("ARM64 APK artifact uses build 182", "traderdesk-1.7.126-build182-arm64-v8a-release" in workflow)
check("Dart symbols artifact uses build 182", "traderdesk-1.7.126-build182-arm64-dart-symbols" in workflow)

risk_start = catalog.index("id: 'risk'")
risk_end = catalog.index("\n    ],", risk_start)
risk_block = catalog[risk_start:risk_end]
keys = [
    "stopLossIncreasedForLiquiditySafety",
    "stopLossReducedForNegativeClose",
    "partialSizeAwaitingDeepCorrection",
    "partialExitNegativeCloseAgainstDirection",
    "highMomentumReducedSizeForRiskManagement",
]
for key in keys:
    check(f"risk catalog retains/offers {key}", f"TradeEntryOption('{key}'" in risk_block)

labels = [
    "إبعاد وقف الخسارة إلى منطقة أمان أبعد قليلًا — زخم عالٍ",
    "تقريب وقف الخسارة إلى أقرب منطقة أمان — إغلاق سلبي لا يدعم اتجاه الصفقة",
    "إغلاق جزء من الصفقة بسبب إغلاق سلبي لا يدعم الاتجاه",
    "زخم عالٍ — لم أفتح الحجم الكامل ليتوافق وقف الخسارة مع إدارة رأس المال",
]
for label in labels:
    check(f"catalog includes requested Arabic wording: {label}", label in risk_block)

for key in keys[-2:]:
    check(f"Arabic and English app string entries exist for {key}", strings.count(f"'{key}':") == 2)

check("old risk phrases are absent from active Dart source/tests", not any(
    phrase in catalog + strings + widget_test + catalog_test
    for phrase in (
        "زيادة المخاطرة لسبب منطقي: سيولة عالية",
        "تقليل المخاطرة لسبب منطقي: إغلاق سلبي",
        "Increased risk for a logical reason",
        "Reduced risk for a logical reason",
    )
))
check("widget tests cover both added risk options", all(
    key in widget_test for key in keys[-2:]
))
check("catalog tests verify risk labels and language mapping", all(
    token in catalog_test for token in ("risk management uses the revised stop-loss reasons", *keys[-2:])
))
check("behavior catalog test expects 28 options", "hasLength(28)" in catalog_test)
check("release notes include 1.7.126+182", "1.7.126+182" in release_notes[:800])
check("build info includes 1.7.126+182", "1.7.126+182" in build_info[:800])

failed = [name for name, passed in checks if not passed]
for name, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
print(f"\nResult: {len(checks) - len(failed)}/{len(checks)} passed")
if failed:
    print("Failed checks:")
    for name in failed:
        print(f"- {name}")
    sys.exit(1)
