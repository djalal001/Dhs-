# تقرير تحديث TraderDesk — 1.7.129+185

- الإصدار السابق: `1.7.128+184`. الجديد: `1.7.129+185`.
- تغيير عنوان المستطيل من «أسباب الخروج» إلى «سبب الخروج» (الإنجليزية: Exit reason). عنوان التعادل «قرار الاحتفاظ» دون تغيير.
- عكس ظهور `Trend Line Touch 3 Breakout`: BUY ← `Trend Line Touch 3 Breakout Buy`، SELL ← `Trend Line Touch 3 Breakout Sell`.
- المفاتيح المحفوظة القديمة لم تتغير. لم تُشغَّل اختبارات Flutter (لا SDK في البيئة).
