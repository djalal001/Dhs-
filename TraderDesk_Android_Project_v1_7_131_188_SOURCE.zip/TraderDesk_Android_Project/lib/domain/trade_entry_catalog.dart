import '../models/trade.dart';

class TradeEntryOption {
  const TradeEntryOption(this.key, this.ar, this.en);
  final String key;
  final String ar;
  final String en;
}

class TradeReviewGroup {
  const TradeReviewGroup({required this.id, required this.titleAr, required this.titleEn, required this.options, this.noteAr, this.noteEn});

  /// Stable zone id used by the Decisions area: `violations`, `analysis`, `risk`.
  final String id;
  final String titleAr;
  final String titleEn;
  final String? noteAr;
  final String? noteEn;
  final List<TradeEntryOption> options;
}

const tradeEntryTimeframes = <String>['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H'];

/// An anchor can be saved with several timeframes. They live in the existing
/// anchorTimeframes map as one comma-separated string (older single-timeframe
/// records are simply a string with one entry), ordered like the picker.
List<String> splitAnchorTimeframes(String? raw) {
  if (raw == null || raw.trim().isEmpty) return const <String>[];
  final frames = raw
      .split(',')
      .map((frame) => frame.trim())
      .where((frame) => frame.isNotEmpty)
      .toSet()
      .toList();
  int order(String frame) {
    final index = tradeEntryTimeframes.indexOf(frame);
    return index < 0 ? tradeEntryTimeframes.length : index;
  }

  frames.sort((a, b) => order(a).compareTo(order(b)));
  return frames;
}

/// Inverse of [splitAnchorTimeframes]; null when there is no timeframe.
String? joinAnchorTimeframes(Iterable<String> frames) {
  final cleaned = splitAnchorTimeframes(frames.join(','));
  return cleaned.isEmpty ? null : cleaned.join(',');
}

/// Formats the selected/saved Entry Conditions label. Direction-aware
/// reverse-signal labels are resolved from the trade side in one shared place.
/// Keep timeframes adjacent to their descriptions, without decorative dots.
String formatTradeEntryConditionSetupLabel({
  required TradeEntryConditionSetup setup,
  required String optionLabel,
  required bool arabic,
  TradeSide? side,
}) {
  const reverseSignalKeys = {
    'reverseSr',
    'reverseSdZone',
    'reverseHns',
    'reverseLongCandleWick',
    'negativeCloseAgainstDirection',
    'strongRejectionWickAgainstDirection',
  };
  if (reverseSignalKeys.contains(setup.optionKey)) {
    final label = tradeReverseSignalDisplayLabel(
      optionKey: setup.optionKey,
      arabic: arabic,
      side: side,
    );
    return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';
  }

  // Negative-close choices of the Opposing signals area. With the optional
  // Trendline qualifier the label reads
  // «إغلاق سلبي داخل المنطقة معا إغلاق تحت Trendline 15MIN»; without it,
  // «إغلاق سلبي فوق المنطقة 15MIN». The timeframe always comes last.
  if (tradeNegativeCloseKeys.contains(setup.optionKey)) {
    final base = tradeReverseSignalDisplayLabel(
      optionKey: setup.optionKey,
      arabic: arabic,
      side: side,
    );
    final relation = tradeNegativeCloseRelationPhrase(
      setup.closeRelation,
      arabic: arabic,
    );
    final label = relation == null
        ? base
        : arabic
            ? '$base $tradeNegativeCloseJoinerAr $relation'
            : '$base with $relation';
    return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';
  }

  // Legacy combined Trendline + Supply Zone records (no longer offered by the
  // Bounce area picker) keep their original two-timeframe presentation.
  if (setup.optionKey == 'bounceFromTrendlineAndSupplyZone') {
    final prefix = arabic ? 'ارتداد من' : 'Bounce from';
    return '$prefix Trend Line ${setup.timeframe} - Supply Zone ${setup.secondaryTimeframe ?? '—'}';
  }

  // Bounce area · Zone S/D resolves to the concrete zone from the trade
  // direction at display time: BUY shows Supply Zone and SELL shows Demand
  // Zone, followed directly by the selected timeframe.
  if (setup.optionKey == 'bounceFromZoneSd') {
    final prefix = arabic ? 'ارتداد من' : 'Bounce from';
    final zone = switch (side) {
      TradeSide.buy => 'Supply Zone',
      TradeSide.sell => 'Demand Zone',
      null => 'Zone S/D',
    };
    final label = '$prefix $zone';
    return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';
  }

  // S/R bounce chips use the selected trade direction as an English market
  // term inside the Arabic label. The optional 2 Touch choice remains stored
  // as a boolean for compatibility, while its chip caption is "Touch 2".
  // Keep the order stable: direction, Touch 2 (when selected), timeframe.
  if (setup.optionKey == 'bounceFromSrZone') {
    final directionalLabel = side == null
        ? optionLabel
        : arabic
            ? (side == TradeSide.buy
                ? 'ارتداد من Support'
                : 'ارتداد من Resistan')
            : (side == TradeSide.buy
                ? 'Bounce from Support'
                : 'Bounce from Resistan');
    final suffix = [
      if (setup.touch2) 'Touch 2',
      if (setup.timeframe.isNotEmpty) setup.timeframe,
    ].join(' ');
    if (suffix.isEmpty) return directionalLabel;
    return '$directionalLabel $suffix';
  }

  return setup.timeframe.isEmpty ? optionLabel : '$optionLabel ${setup.timeframe}';
}

const tradeEntryReasons = <TradeEntryOption>[
  // One direction-aware Breakout choice replaces the separate SBR/RBS rows.
  TradeEntryOption('directionalBreakout', 'BREAKOUT', 'BREAKOUT'),
  // SFR/RFS share one row; BUY resolves to RFS and SELL resolves to SFR.
  TradeEntryOption('directionalSfrRfs', 'SFR / RFS', 'SFR / RFS'),
  // Direction selects the concrete Trendline Touch 3 scenario after choice.
  TradeEntryOption(
    'directionalTrendlineTouch3',
    'Trendline Touch 3',
    'Trendline Touch 3',
  ),
  // Breakout uses the opposite-side Trendline scenario by specification.
  TradeEntryOption(
    'directionalTrendlineTouch3Breakout',
    'Trend Line Touch 3 Breakout',
    'Trend Line Touch 3 Breakout',
  ),
  TradeEntryOption('HNS', 'HNS', 'HNS'),
  TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D'),
];

/// Returns the selected key for the entry-reason picker. Legacy SBR/RBS,
/// SFR/RFS and separate Trendline options migrate to their direction-aware
/// semantic row when edited. Their historical stored values remain readable.
String tradeEntryReasonSelectionKey(String reason) {
  final base = tradeEntryBaseReason(reason);
  if (base == 'SBR' ||
      base == 'RBS' ||
      base == 'BREAKOUT' ||
      base == 'directionalBreakout') {
    return 'directionalBreakout';
  }
  if (base == 'SFR' ||
      base == 'RFS' ||
      base == 'SFR / RFS' ||
      base == 'directionalSfrRfs') {
    return 'directionalSfrRfs';
  }
  if ({
    'Trend Line SELL',
    'Trend Line BUY',
    'Trendline Sell 3 Touch',
    'Trendline Buy 3 Touch',
    'Trendline Touch 3 Sell',
    'Trendline Touch 3 Buy',
    'Trendline Touch 3',
    'directionalTrendlineTouch3',
  }.contains(base)) {
    return 'directionalTrendlineTouch3';
  }
  if ({
    'Trend Line BREAKOUT SELL',
    'Trend Line BREAKOUT BUY',
    'Trend Line Touch 3 Sell Breakout',
    'Trend Line Touch 3 Buy Breakout',
    'Trend Line Touch 3 Breakout',
    'directionalTrendlineTouch3Breakout',
  }.contains(base)) {
    return 'directionalTrendlineTouch3Breakout';
  }
  if (base == 'Supply Zone' || base == 'Zone S/D' || base == 'zoneSd') {
    return 'zoneSd';
  }
  return base;
}

/// Formats entry reasons for every user-facing surface. New semantic choices
/// resolve from the saved trade side. Legacy concrete keys remain readable so
/// historical trades are not silently reinterpreted until they are edited.
String formatTradeEntryReasonLabel({
  required String reason,
  TradeSide? side,
}) {
  switch (reason) {
    case 'directionalBreakout':
    case 'BREAKOUT':
      if (side == TradeSide.buy) return 'RBS';
      if (side == TradeSide.sell) return 'SBR';
      return 'BREAKOUT';
    case 'directionalBreakout Touch 2':
      final breakoutLabel = side == TradeSide.buy
          ? 'RBS'
          : side == TradeSide.sell
              ? 'SBR'
              : 'BREAKOUT';
      return '$breakoutLabel Touch 2';
    case 'directionalSfrRfs':
      if (side == TradeSide.buy) return 'RFS';
      if (side == TradeSide.sell) return 'SFR';
      return 'SFR / RFS';
    case 'directionalTrendlineTouch3':
      if (side == TradeSide.buy) return 'Trendline Touch 3 Buy';
      if (side == TradeSide.sell) return 'Trendline Touch 3 Sell';
      return 'Trendline Touch 3';
    case 'directionalTrendlineTouch3Breakout':
      if (side == TradeSide.buy) return 'Trend Line Touch 3 Sell Breakout';
      if (side == TradeSide.sell) return 'Trend Line Touch 3 Buy Breakout';
      return 'Trend Line Touch 3 Breakout';
    case 'Trend Line SELL':
    case 'Trendline Sell 3 Touch':
      return 'Trendline Touch 3 Sell';
    case 'Trend Line BUY':
    case 'Trendline Buy 3 Touch':
      return 'Trendline Touch 3 Buy';
    case 'Trendline Touch 3 Sell':
      return 'Trendline Touch 3 Sell';
    case 'Trendline Touch 3 Buy':
      return 'Trendline Touch 3 Buy';
    case 'Trend Line BREAKOUT SELL':
    case 'Trend Line Touch 3 Sell Breakout':
      return 'Trend Line Touch 3 Sell Breakout';
    case 'Trend Line BREAKOUT BUY':
    case 'Trend Line Touch 3 Buy Breakout':
      return 'Trend Line Touch 3 Buy Breakout';
    case 'SFR':
      return 'SFR';
    case 'RFS':
      return 'RFS';
    case 'zoneSd':
    case 'Zone S/D':
      if (side == TradeSide.buy) return 'Demand Zone';
      if (side == TradeSide.sell) return 'Supply Zone';
      return 'Zone S/D';
    default:
      // Old saved `Supply Zone` values remain historical fixed-zone records.
      return reason;
  }
}

/// Legacy Touch 2 records for SBR/RBS remain readable and editable. The
/// single BREAKOUT picker now exposes the same optional Touch 2 detail, stored
/// under a direction-neutral semantic reason so its label follows BUY/SELL.
/// S/R bounce Touch 2 remains stored separately on TradeEntryConditionSetup.touch2.
const tradeEntryTouch2EligibleReasons = <String>{'SBR', 'RBS'};

String tradeEntryBaseReason(String reason) {
  if (reason == 'directionalBreakout Touch 2') return 'directionalBreakout';
  for (final base in tradeEntryTouch2EligibleReasons) {
    if (reason == '$base Touch 2') return base;
  }
  return reason;
}

bool tradeEntryUsesTouch2(String reason) =>
    reason == 'directionalBreakout Touch 2' ||
    tradeEntryTouch2EligibleReasons.any((base) => reason == '$base Touch 2');

String tradeEntryReasonWithTouch2(String baseReason, bool touch2) {
  if (baseReason == 'directionalBreakout') {
    return touch2 ? 'directionalBreakout Touch 2' : 'directionalBreakout';
  }
  return touch2 && tradeEntryTouch2EligibleReasons.contains(baseReason)
      ? '$baseReason Touch 2'
      : baseReason;
}

const tradeConfirmationOptions = <TradeEntryOption>[
  TradeEntryOption('confirmEngulfing', 'Engulfing', 'Engulfing'),
  TradeEntryOption('confirmHns', 'HNS', 'HNS'),
  TradeEntryOption('confirmBreakoutPullback', 'Breakout–Pullback', 'Breakout–Pullback'),
  TradeEntryOption('confirmEveningStar', 'Evening Star', 'Evening Star'),
  TradeEntryOption('confirmRejectKeyLevel', 'Reject ᴷᵉʸ ᴸᵉᵛᵉˡ', 'Reject Key Level'),
  TradeEntryOption('__custom__', 'مخصص', 'Custom'),
];

/// Exit reasons (win / loss) and hold decision (break-even) share one list.
/// Each row is a direction-neutral semantic choice shown by its abbreviation;
/// the concrete element is resolved from the trade side after selection
/// (see [formatTradeExitReasonLabel]), exactly like the entry-reason list.
const tradeExitReasonOptions = <TradeEntryOption>[
  TradeEntryOption('exitDirectionalSbrRbs', 'SBR - RBS', 'SBR - RBS'),
  TradeEntryOption('exitDirectionalRfsSfr', 'RFS - SFR', 'RFS - SFR'),
  TradeEntryOption(
    'exitDirectionalTrendlineTouch3',
    'Trend Line Touch 3',
    'Trend Line Touch 3',
  ),
  TradeEntryOption(
    'exitDirectionalTrendlineTouch3Breakout',
    'Trend Line Touch 3 Breakout',
    'Trend Line Touch 3 Breakout',
  ),
  TradeEntryOption('exitZoneSd', 'Zone S/D', 'Zone S/D'),
  TradeEntryOption('exitHns', 'HNS', 'HNS'),
];

/// Concrete keys saved by versions before 1.7.128. They are no longer offered
/// but stay readable, and map to the semantic rows above when edited.
const tradeLegacyExitReasonOptions = <TradeEntryOption>[
  TradeEntryOption('exitSbr', 'SBR', 'SBR'),
  TradeEntryOption('exitRbs', 'RBS', 'RBS'),
  TradeEntryOption('exitSfr', 'SFR', 'SFR'),
  TradeEntryOption('exitRfs', 'RFS', 'RFS'),
  TradeEntryOption('exitSupplyZone', 'Supply Zone', 'Supply Zone'),
  TradeEntryOption('exitDemandZone', 'Demand Zone', 'Demand Zone'),
  TradeEntryOption('exitTrendlineTouch3SellBreakout', 'Trend Line Touch 3 Sell Breakout', 'Trend Line Touch 3 Sell Breakout'),
  TradeEntryOption('exitTrendlineTouch3BuyBreakout', 'Trend Line Touch 3 Buy Breakout', 'Trend Line Touch 3 Buy Breakout'),
  TradeEntryOption('exitTrendlineTouch3Buy', 'Trendline Touch 3 Buy', 'Trendline Touch 3 Buy'),
  TradeEntryOption('exitTrendlineTouch3Sell', 'Trendline Touch 3 Sell', 'Trendline Touch 3 Sell'),
];

/// Picker row selected when editing a saved exit reason (legacy keys migrate).
String tradeExitReasonSelectionKey(String type) {
  switch (type) {
    case 'exitSbr':
    case 'exitRbs':
      return 'exitDirectionalSbrRbs';
    case 'exitSfr':
    case 'exitRfs':
      return 'exitDirectionalRfsSfr';
    case 'exitTrendlineTouch3Buy':
    case 'exitTrendlineTouch3Sell':
      return 'exitDirectionalTrendlineTouch3';
    case 'exitTrendlineTouch3BuyBreakout':
    case 'exitTrendlineTouch3SellBreakout':
      return 'exitDirectionalTrendlineTouch3Breakout';
    case 'exitSupplyZone':
    case 'exitDemandZone':
      return 'exitZoneSd';
    default:
      return type;
  }
}

/// Title of the dynamic exit rectangle for a result classification, or null
/// when the result does not call for it (missed / not yet chosen).
String? tradeExitSectionTitle(TradeClassification? classification, {required bool arabic}) =>
    switch (classification) {
      TradeClassification.win || TradeClassification.loss =>
        arabic ? 'سبب الخروج' : 'Exit reason',
      TradeClassification.breakEven =>
        arabic ? 'قرار الاحتفاظ' : 'Hold decision',
      _ => null,
    };

/// Display label of a saved exit reason. Semantic rows resolve to the concrete
/// element from the trade direction (BUY / SELL), per the elements table:
/// SBR - RBS → BUY SBR / SELL RBS; RFS - SFR → BUY SFR / SELL RFS;
/// Trend Line Touch 3 → BUY «Sell» / SELL «Buy»; its Breakout → BUY «Breakout
/// Buy» / SELL «Breakout Sell» (same side as the trade); Zone S/D → BUY Supply / SELL Demand.
/// Without a direction the abbreviation is shown. Legacy concrete keys keep
/// their original label.
String tradeExitReasonLabel(
  String type, {
  required bool arabic,
  TradeSide? side,
}) {
  switch (type) {
    case 'exitDirectionalSbrRbs':
      return switch (side) {
        TradeSide.buy => 'SBR',
        TradeSide.sell => 'RBS',
        null => 'SBR - RBS',
      };
    case 'exitDirectionalRfsSfr':
      return switch (side) {
        TradeSide.buy => 'SFR',
        TradeSide.sell => 'RFS',
        null => 'RFS - SFR',
      };
    case 'exitDirectionalTrendlineTouch3':
      return switch (side) {
        TradeSide.buy => 'Trend Line Touch 3 Sell',
        TradeSide.sell => 'Trend Line Touch 3 Buy',
        null => 'Trend Line Touch 3',
      };
    case 'exitDirectionalTrendlineTouch3Breakout':
      return switch (side) {
        TradeSide.buy => 'Trend Line Touch 3 Breakout Buy',
        TradeSide.sell => 'Trend Line Touch 3 Breakout Sell',
        null => 'Trend Line Touch 3 Breakout',
      };
    case 'exitZoneSd':
      return switch (side) {
        TradeSide.buy => 'Supply Zone',
        TradeSide.sell => 'Demand Zone',
        null => 'Zone S/D',
      };
  }
  for (final option in [
    ...tradeExitReasonOptions,
    ...tradeLegacyExitReasonOptions,
  ]) {
    if (option.key == type) return arabic ? option.ar : option.en;
  }
  return type;
}

/// Legacy Bullish/Bearish confirmation records map to the new single picker
/// row when edited. Their saved values remain unchanged until the user edits.
String tradeConfirmationSelectionKey(String type) {
  if (type == 'confirmBullishEngulfing' ||
      type == 'confirmBearishEngulfing' ||
      type == 'Bullish Engulfing' ||
      type == 'Bullish engulfing' ||
      type == 'bullish engulfing' ||
      type == 'Bearish engulfing' ||
      type == 'bearish engulfing' ||
      type == 'Bearish Engulfing' ||
      type == 'Engulfing') {
    return 'confirmEngulfing';
  }
  return type;
}

/// Converts the semantic Engulfing choice to the concrete candle pattern
/// using the current trade direction. Historical concrete labels are
/// canonicalized for display without changing their stored meaning.
String tradeConfirmationDisplayKey({
  required String type,
  required TradeSide? side,
}) {
  if (type == 'confirmBullishEngulfing' ||
      type == 'Bullish Engulfing' ||
      type == 'Bullish engulfing' ||
      type == 'bullish engulfing') {
    return 'confirmBullishEngulfing';
  }
  if (type == 'confirmBearishEngulfing' ||
      type == 'Bearish engulfing' ||
      type == 'bearish engulfing' ||
      type == 'Bearish Engulfing') {
    return 'confirmBearishEngulfing';
  }
  if (type == 'confirmEngulfing' || type == 'Engulfing') {
    if (side == TradeSide.buy) return 'confirmBullishEngulfing';
    if (side == TradeSide.sell) return 'confirmBearishEngulfing';
    return 'confirmEngulfing';
  }
  return type;
}

/// The four choices shown when the user opens the Opposing Signals selector.
/// S/R and S-D are semantic groups: their saved category is interpreted using
/// the selected trade side, so changing Buy/Sell updates the displayed
/// opposing reference without rewriting the stored setup.
const tradeReverseSignalOptions = <TradeEntryOption>[
  TradeEntryOption('reverseSr', 'S/R عكسي', 'Reverse S/R'),
  TradeEntryOption('reverseSdZone', 'S - D Zone عكسي', 'Reverse S - D Zone'),
  TradeEntryOption('reverseHns', 'HNS عكسي', 'Reverse HNS'),
  TradeEntryOption(
    'reverseLongCandleWick',
    'ذيل شمعة طويل عكسي',
    'Opposing long candle wick',
  ),
  // Each of the two negative-close rows opens a small popup with the optional
  // Trendline qualifier (see [tradeNegativeCloseTrendlineOptions]).
  TradeEntryOption(
    tradeNegativeCloseAboveZoneKey,
    'إغلاق سلبي فوق المنطقة',
    'Negative close above the zone',
  ),
  TradeEntryOption(
    tradeNegativeCloseInsideZoneKey,
    'إغلاق سلبي داخل المنطقة',
    'Negative close inside the zone',
  ),
];

const tradeNegativeCloseAboveZoneKey = 'negativeCloseAboveZone';
const tradeNegativeCloseInsideZoneKey = 'negativeCloseInsideZone';
const tradeNegativeCloseKeys = <String>{
  tradeNegativeCloseAboveZoneKey,
  tradeNegativeCloseInsideZoneKey,
};

/// Stored values of [TradeEntryConditionSetup.closeRelation].
const tradeCloseAboveTrendlineKey = 'aboveTrendline';
const tradeCloseBelowTrendlineKey = 'belowTrendline';

/// Joins a negative-close label to its Trendline qualifier in Arabic.
const tradeNegativeCloseJoinerAr = 'معا';

/// Popup choices shown after picking one of the two negative-close rows.
/// The popup also offers a «متابعة» row (no qualifier), so the qualifier stays
/// optional.
const tradeNegativeCloseTrendlineOptions = <TradeEntryOption>[
  TradeEntryOption(tradeCloseAboveTrendlineKey, 'فوق Trendline', 'Above Trendline'),
  TradeEntryOption(tradeCloseBelowTrendlineKey, 'تحت Trendline', 'Below Trendline'),
];

/// «إغلاق فوق Trendline» / «إغلاق تحت Trendline», or null without qualifier.
String? tradeNegativeCloseRelationPhrase(
  String? closeRelation, {
  required bool arabic,
}) {
  switch (closeRelation) {
    case tradeCloseAboveTrendlineKey:
      return arabic ? 'إغلاق فوق Trendline' : 'a close above the Trendline';
    case tradeCloseBelowTrendlineKey:
      return arabic ? 'إغلاق تحت Trendline' : 'a close below the Trendline';
    default:
      return null;
  }
}

/// Resolves the concrete reversed S/R or S-D reference from its semantic
/// category and trade direction. For S/R role reversal, a former resistance
/// that flips polarity is displayed as Support for Buy, while a former
/// support that flips polarity is displayed as Resistance for Sell. The
/// S-D Zone mapping follows the separately specified application convention.
/// Legacy keys remain readable for old saved trades.
String tradeReverseSignalDisplayLabel({
  required String optionKey,
  required bool arabic,
  TradeSide? side,
}) {
  switch (optionKey) {
    case 'reverseSr':
      if (side == TradeSide.buy) {
        return arabic ? 'Support عكسي' : 'Reverse Support';
      }
      if (side == TradeSide.sell) {
        return arabic ? 'Resistan عكسي' : 'Reverse Resistan';
      }
      return arabic ? 'S/R عكسي' : 'Reverse S/R';
    case 'reverseSdZone':
      if (side == TradeSide.buy) return 'Supply Zone';
      if (side == TradeSide.sell) return 'Demand Zone';
      return arabic ? 'S - D Zone عكسي' : 'Reverse S - D Zone';
    case 'reverseHns':
      return arabic ? 'HNS عكسي' : 'Reverse HNS';
    case 'reverseLongCandleWick':
      return arabic ? 'ذيل شمعة طويل عكسي' : 'Opposing long candle wick';
    case tradeNegativeCloseAboveZoneKey:
      return arabic ? 'إغلاق سلبي فوق المنطقة' : 'Negative close above the zone';
    case tradeNegativeCloseInsideZoneKey:
      return arabic ? 'إغلاق سلبي داخل المنطقة' : 'Negative close inside the zone';
    // Preserve the meaning of records saved before this catalog revision.
    case 'negativeCloseAgainstDirection':
      return arabic
          ? 'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول'
          : 'Negative close before the bounce did not support the trade direction';
    case 'strongRejectionWickAgainstDirection':
      return arabic
          ? 'نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة'
          : 'Strong rejection pattern with a long wick against the trade direction';
    default:
      return optionKey;
  }
}

/// Top-level choices of the Bounce area picker. «سحب سيولة» and
/// «إرتداد من Trendline» are menu rows only: each opens a small popup with its
/// concrete choices (see [tradeBounceZoneSubOptions]) before the timeframe
/// picker, and the menu keys themselves are never stored on a trade.
const tradeBounceZoneOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromSrZone', 'ارتداد من منطقة S/R', 'Bounce from an S/R zone'),
  TradeEntryOption(tradeLiquiditySweepMenuKey, 'سحب سيولة', 'Liquidity sweep'),
  TradeEntryOption(tradeTrendlineBounceMenuKey, 'إرتداد من Trendline', 'Bounce from a Trendline'),
  TradeEntryOption('bounceFromZoneSd', 'ارتداد من Zone S/D', 'Bounce from Zone S/D'),
];

const tradeLiquiditySweepMenuKey = 'liquiditySweepMenu';
const tradeTrendlineBounceMenuKey = 'trendlineBounceMenu';

/// Popup choices behind the «سحب سيولة» row. The stored keys are the original
/// liquidity-sweep keys, so previously saved trades keep their meaning.
const tradeLiquiditySweepOptions = <TradeEntryOption>[
  TradeEntryOption('internalLiquiditySweep', 'سيولة داخلية', 'Internal liquidity'),
  TradeEntryOption('majorStructureLiquiditySweep', 'سيولة خارجية', 'External liquidity'),
];

/// Popup choices behind the «إرتداد من Trendline» row.
const tradeTrendlineBounceOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromTrendlineTouch34', 'Trendline Touch 3-4', 'Trendline Touch 3-4'),
  TradeEntryOption('bounceFromTrendlineTouch34Breakout', 'Trend Line Touch 3-4 Breakout', 'Trend Line Touch 3-4 Breakout'),
];

/// Every key a saved Bounce area setup can carry, with the label shown on the
/// field chip and in saved-trade details. Includes legacy keys so older
/// records stay readable after the picker was reorganised.
const tradeBounceZoneLabelOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromSrZone', 'ارتداد من منطقة S/R', 'Bounce from an S/R zone'),
  TradeEntryOption('internalLiquiditySweep', 'سحب سيولة داخلية', 'Internal liquidity sweep'),
  TradeEntryOption('majorStructureLiquiditySweep', 'سحب سيولة خارجية', 'External liquidity sweep'),
  TradeEntryOption('bounceFromTrendlineTouch34', 'إرتداد من Trendline Touch 3-4', 'Bounce from Trendline Touch 3-4'),
  TradeEntryOption('bounceFromTrendlineTouch34Breakout', 'إرتداد من Trend Line Touch 3-4 Breakout', 'Bounce from Trend Line Touch 3-4 Breakout'),
  TradeEntryOption('bounceFromZoneSd', 'ارتداد من Zone S/D', 'Bounce from Zone S/D'),
  // Legacy records.
  TradeEntryOption('bounceFromTrendline', 'إرتداد من Trendline', 'Bounce from a Trendline'),
  TradeEntryOption('bounceFromTrendlineAndSupplyZone', 'ارتداد من ترند لاين و Supply Zone', 'Bounce from a trendline and Supply Zone'),
];

/// The concrete choices behind a Bounce area menu row, or null when the row
/// continues straight to the timeframe picker.
List<TradeEntryOption>? tradeBounceZoneSubOptions(String menuKey) {
  if (menuKey == tradeLiquiditySweepMenuKey) return tradeLiquiditySweepOptions;
  if (menuKey == tradeTrendlineBounceMenuKey) {
    return tradeTrendlineBounceOptions;
  }
  return null;
}

/// Maps a stored setup key to the picker row that should appear selected when
/// the setup is edited. Keys that are not part of a grouped menu map to
/// themselves, so Opposing signals and the S/R bounce are unaffected.
String tradeBounceZoneMenuKey(String optionKey) {
  switch (optionKey) {
    case 'internalLiquiditySweep':
    case 'majorStructureLiquiditySweep':
      return tradeLiquiditySweepMenuKey;
    case 'bounceFromTrendline':
    case 'bounceFromTrendlineTouch34':
    case 'bounceFromTrendlineTouch34Breakout':
      return tradeTrendlineBounceMenuKey;
    default:
      return optionKey;
  }
}

/// Formats an anchor label consistently in forms and saved-trade details.
/// The new Zone S/D option resolves to the concrete zone from trade direction;
/// legacy `supplyZone`/`demandZone` records retain their historical labels.
String formatTradeAnchorLabel({
  required String anchorKey,
  required bool arabic,
  TradeSide? side,
}) {
  switch (anchorKey) {
    case 'zoneSd':
    case 'Zone S/D':
      if (side == TradeSide.buy) return 'Demand Zone';
      if (side == TradeSide.sell) return 'Supply Zone';
      return 'Zone S/D';
    case 'base':
      return switch (side) {
        TradeSide.buy => 'Base Buy',
        TradeSide.sell => 'Base Sell',
        null => 'Base',
      };
    case 'engulfing':
    case 'Engulfing':
      return switch (side) {
        TradeSide.buy => 'Bullish Engulfing',
        TradeSide.sell => 'Bearish Engulfing',
        null => 'Engulfing',
      };
    case 'bullishEngulfing':
    case 'Bullish engulfing':
    case 'bullish engulfing':
    case 'Bullish Engulfing':
      return 'Bullish Engulfing';
    case 'bearishEngulfing':
    case 'Bearish engulfing':
    case 'bearish engulfing':
    case 'Bearish Engulfing':
      return 'Bearish Engulfing';
    case 'supplyZone':
      return 'Supply Zone';
    case 'demandZone':
      return 'Demand Zone';
    default:
      final option = tradeAnchorOptions
          .where((item) => item.key == anchorKey)
          .firstOrNull;
      return option == null ? anchorKey : (arabic ? option.ar : option.en);
  }
}

/// Optional price reference selected for a trade's entry context.
/// Values are stored by key so their presentation can evolve independently.
const tradeAnchorOptions = <TradeEntryOption>[
  TradeEntryOption('keyLevel', 'Key Level', 'Key Level'),
  TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D'),
  TradeEntryOption('engulfing', 'Engulfing', 'Engulfing'),
  TradeEntryOption('base', 'Base', 'Base'),
];

const tradeMoodOptions = <TradeEntryOption>[
  TradeEntryOption('moodUnknown', 'غير مسجلة', 'Not recorded'),
  TradeEntryOption('moodCalm', 'هادئ', 'Calm'),
  TradeEntryOption('moodConfident', 'واثق', 'Confident'),
  TradeEntryOption('moodAnxious', 'قلق', 'Anxious'),
  TradeEntryOption('moodImpulsive', 'مندفع', 'Impulsive'),
  TradeEntryOption('moodTired', 'متعب', 'Tired'),
  TradeEntryOption('moodUnsureAnalysis', 'غير واثق من التحليل', 'Unsure about the analysis'),
];

/// Decisions area, three zones shown side by side in the trade form:
/// violations · analysis quality · risk management.
const tradeReviewGroups = <TradeReviewGroup>[
  TradeReviewGroup(
    id: 'violations',
    titleAr: 'مخالفات التنفيذ',
    titleEn: 'Execution violations',
    options: [
      TradeEntryOption('enteredEarly', 'دخول مبكر', 'Early entry'),
      TradeEntryOption('lateEntry', 'دخول متأخر', 'Late entry'),
      TradeEntryOption('hesitationPartialSize', 'لم أفتح الحجم الكامل بسبب تردد', 'Did not open the full size due to hesitation'),
      TradeEntryOption('stopLossReducedWithoutReason', 'تغيير وقف الخسارة لتقليل المخاطرة بلا سبب', 'Moved the stop loss to reduce risk for no reason'),
      TradeEntryOption('stopLossIncreasedWithoutReason', 'تغيير وقف الخسارة لزيادة المخاطرة بلا سبب', 'Moved the stop loss to increase risk for no reason'),
      TradeEntryOption('exitedEarlyBecauseFearOfLosingProfit', 'خروج مبكر خوفًا من ضياع الأرباح', 'Early exit out of fear of losing profit'),
    ],
  ),
  TradeReviewGroup(
    id: 'analysis',
    titleAr: 'جودة تحليل',
    titleEn: 'Analysis quality',
    noteAr: 'لم أنتبه لوجود',
    noteEn: 'Did not notice',
    options: [
      TradeEntryOption('missedRbs', 'RBS', 'RBS'),
      TradeEntryOption('missedRbsTouch2', 'RBS Touch 2', 'RBS Touch 2'),
      TradeEntryOption('missedRfs', 'RFS', 'RFS'),
      TradeEntryOption('missedSbr', 'SBR', 'SBR'),
      TradeEntryOption('missedSbrTouch2', 'SBR Touch 2', 'SBR Touch 2'),
      TradeEntryOption('missedSfr', 'SFR', 'SFR'),
      TradeEntryOption('missedZoneSupply', 'Zone Supply', 'Zone Supply'),
      TradeEntryOption('missedZoneDemand', 'Zone Demand', 'Zone Demand'),
      TradeEntryOption('missedTrendlineTouch3Sell', 'Trendline Touch 3 Sell', 'Trendline Touch 3 Sell'),
      TradeEntryOption('missedTrendlineTouch3Buy', 'Trendline Touch 3 Buy', 'Trendline Touch 3 Buy'),
      TradeEntryOption('missedTrendlineTouch3SellBreakout', 'Trend Line Touch 3 Sell Breakout', 'Trend Line Touch 3 Sell Breakout'),
      TradeEntryOption('missedTrendlineTouch3BuyBreakout', 'Trend Line Touch 3 Buy Breakout', 'Trend Line Touch 3 Buy Breakout'),
    ],
  ),
  TradeReviewGroup(
    id: 'risk',
    titleAr: 'إدارة المخاطرة',
    titleEn: 'Risk management',
    options: [
      TradeEntryOption('stopLossIncreasedForLiquiditySafety', 'إبعاد وقف الخسارة إلى منطقة أمان أبعد قليلًا — زخم عالٍ', 'Move the stop loss farther away to a slightly more distant safety area — high momentum'),
      TradeEntryOption('stopLossReducedForNegativeClose', 'تقريب وقف الخسارة إلى أقرب منطقة أمان — إغلاق سلبي لا يدعم اتجاه الصفقة', 'Move the stop loss closer to the nearest safety area — a negative close does not support the trade direction'),
      TradeEntryOption('partialSizeAwaitingDeepCorrection', 'لم أفتح الحجم الكامل انتظارًا لتصحيح أعمق لمنطقة الدخول', 'Did not open full size while waiting for a deeper retracement into the entry zone'),
      TradeEntryOption('partialExitNegativeCloseAgainstDirection', 'إغلاق جزء من الصفقة بسبب إغلاق سلبي لا يدعم الاتجاه', 'Closed part of the position because a negative close did not support the direction'),
      TradeEntryOption('highMomentumReducedSizeForRiskManagement', 'زخم عالٍ — لم أفتح الحجم الكامل ليتوافق وقف الخسارة مع إدارة رأس المال', 'High momentum — did not open the full position size so the stop loss would align with risk management'),
    ],
  ),
];

/// Analysis-quality rows exactly as laid out in the form (3 · 3 · 2 · 1 · 1 · 1 · 1).
const tradeAnalysisRowLayout = <List<String>>[
  ['missedRbs', 'missedRbsTouch2', 'missedRfs'],
  ['missedSbr', 'missedSbrTouch2', 'missedSfr'],
  ['missedZoneSupply', 'missedZoneDemand'],
  ['missedTrendlineTouch3Sell'],
  ['missedTrendlineTouch3Buy'],
  ['missedTrendlineTouch3SellBreakout'],
  ['missedTrendlineTouch3BuyBreakout'],
];

/// Sentence shown in place of the collapsed analysis list. One selection reads
/// "لم أنتبه لوجود" + item; several read "لم أنتبه لوجود سيناريو" + items.
String tradeAnalysisMissedSentence({required int count, required bool arabic}) {
  if (arabic) return count > 1 ? 'لم أنتبه لوجود سيناريو' : 'لم أنتبه لوجود';
  return count > 1 ? 'Did not notice a scenario with' : 'Did not notice';
}

/// Labels of decision keys saved by earlier versions. They are never offered in
/// the form any more; they exist only so saved trades and backups keep a
/// readable label instead of a raw key.
const tradeLegacyReviewOptions = <TradeEntryOption>[
  TradeEntryOption('missedHigherTimeframeBounceArea', 'لم أنتبه لمنطقة ارتداد في الفريم الأكبر', 'Missed a higher-timeframe bounce area'),
  TradeEntryOption('missedLowerTimeframeBounceArea', 'لم أنتبه لمنطقة ارتداد في الفريم الأصغر', 'Missed a lower-timeframe bounce area'),
  TradeEntryOption('missedTrendlineFromCandleWicks', 'لم أنتبه لاحتمالية رسم الترند لاين من ذيول الشموع', 'Missed the possibility of drawing the trendline from candle wicks'),
  TradeEntryOption('noBreakoutPositiveClose', 'الكسر والإغلاق الإيجابي ضعيفان', 'Breakout and positive close lacked strength'),
  TradeEntryOption('noTrendlineSupportsEntryZone', 'لا يوجد ترند لاين يدعم منطقة الدخول', 'No trendline supported the entry zone'),
  TradeEntryOption('missedHigherTimeframeTrendlineIntegration', 'لم أدمج ترند 1h–4h في تحليلي', 'Did not include the 1h–4h trend in the analysis'),
];

/// Commitment items that cannot coexist with a recorded mistake. Once any
/// «مخالفات التنفيذ» or «جودة تحليل» item is chosen, «التزمت بالخطة كاملة» and
/// «التزمت بشروط الدخول رغم الخوف من الخسارة» can no longer be selected.
const tradeCommitmentExclusiveKeys = <String>{
  'fullPlanCompliance',
  'enteredDespiteFear',
};

/// Keys of the zones that record an execution or analysis mistake.
final tradeExecutionFlawKeys = <String>{
  for (final group in tradeReviewGroups)
    if (group.id == 'violations' || group.id == 'analysis')
      for (final option in group.options) option.key,
};

const tradeCommitmentOptions = <TradeEntryOption>[
  TradeEntryOption('breakevenStopToEntry', 'التزمت بخطة نقل وقف الخسارة إلى نقطة الدخول وخرجت بتعادل', 'Moved the stop to entry as planned and exited breakeven'),
  TradeEntryOption('manualExitNearTarget', 'خرجت يدويًا وفق الخطة عند اقتراب السعر من الهدف', 'Exited manually as planned when price approached the target'),
  TradeEntryOption('autoExitAtTarget', 'خرجت تلقائيًا وفق الخطة عند بلوغ الهدف', 'Exited automatically as planned at the defined target'),
  TradeEntryOption('enteredDespiteFear', 'التزمت بشروط الدخول رغم الخوف من الخسارة', 'Followed the entry conditions despite feeling fear of loss'),
  TradeEntryOption('fullPlanCompliance', 'التزمت بالخطة كاملة', 'Followed the complete plan without deviation'),
];

/// «أسباب نفسية»: the psychological half of the no-entry reasons. Keys are the
/// original ones, so saved trades keep their meaning; only the wording changed.
const tradeNoEntryPsychologicalOptions = <TradeEntryOption>[
  TradeEntryOption('fearRepeatLossAfterLoss', 'خوف من تكرار الخسارة بعد خسارة سابقة', 'Fear of repeating a loss after a previous loss'),
  TradeEntryOption('fearGivingBackProfit', 'خوف من خسارة الأرباح بعد صفقة رابحة', 'Fear of giving back profit after a winning trade'),
  TradeEntryOption('fearLossNoHistory', 'خوف من الخسارة دون وجود ربح أو خسارة سابقة', 'Fear of loss without a prior win or loss'),
  TradeEntryOption('hesitationUnclearScenario', 'تردد بسبب عدم وضوح السيناريو', 'Hesitation because the scenario was unclear'),
  TradeEntryOption(
    'waitedDeeperRetestDespiteConfirmation',
    'خوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة',
    'Fear of a deep correction because the entry confirmation was far from the zone',
  ),
];

/// «أسباب هيكلية»: structural reasons (market structure, not feelings). New
/// keys are prefixed `noEntry…` so they can never collide with the legacy
/// analysis-quality keys that share part of the wording.
const tradeNoEntryStructuralOptions = <TradeEntryOption>[
  TradeEntryOption('noEntryWeakBreakoutClose', 'كسر وإغلاق إيجابي ضعيف', 'Weak breakout and positive close'),
  TradeEntryOption('noEntryNoTrendlineSupport', 'لا يوجد Trendline يدعم منطقة دخول', 'No trendline supporting an entry zone'),
  TradeEntryOption('noEntryNearbyRejectionZone', 'وجود منطقة اعتراض قريبة من تأكيد دخول', 'A nearby rejection zone close to the entry confirmation'),
  // Wording corrected in 1.7.109; the storage key is unchanged so saved trades
  // keep their meaning and simply show the corrected text.
  TradeEntryOption('noEntryLiquidityOvershootReturn', 'زخم عالي تجاوز سعر منطقة دخول قليلا وعاد اليها بدون إغلاق', 'High momentum: price slightly overshot the entry zone and returned to it without a close'),
  TradeEntryOption('noEntryHighMomentumLowerTimeframe', 'زخم مرتفع على الفريم الاصغر', 'High momentum on the lower timeframe'),
];

/// The two no-entry sections shown side by side in the trade form. Ids are the
/// stable zone ids used by the widget keys and the saved-trade detail.
const tradeNoEntryGroups = <TradeReviewGroup>[
  TradeReviewGroup(
    id: 'psychological',
    titleAr: 'أسباب نفسية',
    titleEn: 'Psychological',
    options: tradeNoEntryPsychologicalOptions,
  ),
  TradeReviewGroup(
    id: 'structural',
    titleAr: 'أسباب هيكلية',
    titleEn: 'Structural',
    options: tradeNoEntryStructuralOptions,
  ),
];

/// Every selectable no-entry reason (both sections), psychological first.
const tradeNoEntryOptions = <TradeEntryOption>[
  ...tradeNoEntryPsychologicalOptions,
  ...tradeNoEntryStructuralOptions,
];

String tradeEntryLabel(String key, {required bool arabic}) {
  for (final option in [...tradeEntryReasons, ...tradeConfirmationOptions, ...tradeExitReasonOptions, ...tradeLegacyExitReasonOptions, ...tradeMoodOptions, ...tradeCommitmentOptions, ...tradeNoEntryOptions, ...tradeReviewGroups.expand((group) => group.options), ...tradeLegacyReviewOptions]) {
    if (option.key == key) return arabic ? option.ar : option.en;
  }
  return key;
}
