import 'package:flutter/material.dart';

/// Artwork copied from the matching Windows Trader Labs decision catalog.
/// Keep one compact visual per decision key so labels and artwork never drift.
const decisionOptionEmojiAssets = <String, String>{
  'enteredEarly': 'assets/emojis/decisions/decision-enteredEarly.gif',
  'hesitationPartialSize':
      'assets/emojis/decisions/decision-hesitationPartialSize.gif',
  'lateEntry': 'assets/emojis/decisions/decision-lateEntry.gif',
  'stopLossReducedWithoutReason':
      'assets/emojis/decisions/decision-stopLossReducedWithoutReason.png',
  'stopLossIncreasedWithoutReason':
      'assets/emojis/decisions/decision-stopLossIncreasedWithoutReason.png',
  'exitedEarlyBecauseFearOfLosingProfit':
      'assets/emojis/decisions/decision-exitedEarlyBecauseFearOfLosingProfit.gif',
  'missedHigherTimeframeBounceArea':
      'assets/emojis/decisions/decision-missedHigherTimeframeBounceArea.gif',
  'missedLowerTimeframeBounceArea':
      'assets/emojis/decisions/decision-missedLowerTimeframeBounceArea.gif',
  'missedTrendlineFromCandleWicks':
      'assets/emojis/decisions/decision-missedTrendlineFromCandleWicks.gif',
  'noBreakoutPositiveClose':
      'assets/emojis/decisions/decision-noBreakoutPositiveClose.gif',
  'noTrendlineSupportsEntryZone':
      'assets/emojis/decisions/decision-noTrendlineSupportsEntryZone.png',
  'missedHigherTimeframeTrendlineIntegration':
      'assets/emojis/decisions/decision-missedHigherTimeframeTrendlineIntegration.png',
  'stopLossIncreasedForLiquiditySafety':
      'assets/emojis/decisions/decision-stopLossIncreasedForLiquiditySafety.png',
  'stopLossReducedForNegativeClose':
      'assets/emojis/decisions/decision-stopLossReducedForNegativeClose.png',
  'partialSizeAwaitingDeepCorrection':
      'assets/emojis/decisions/decision-partialSizeAwaitingDeepCorrection.png',
};

class DecisionOptionEmoji extends StatelessWidget {
  const DecisionOptionEmoji({super.key, required this.optionKey});

  final String optionKey;

  static const double size = 28;

  @override
  Widget build(BuildContext context) {
    final asset = decisionOptionEmojiAssets[optionKey];
    if (asset == null) return const SizedBox.shrink();

    return ExcludeSemantics(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(7),
        child: Image.asset(
          asset,
          width: size,
          height: size,
          fit: BoxFit.contain,
          filterQuality: FilterQuality.medium,
          gaplessPlayback: true,
        ),
      ),
    );
  }
}
