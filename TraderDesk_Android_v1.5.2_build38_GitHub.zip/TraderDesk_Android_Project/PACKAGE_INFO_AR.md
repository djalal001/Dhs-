# معلومات الحزمة — TraderDesk Android 1.5.2+38

هذه الحزمة تحتوي على مصدر مشروع Flutter الكامل.

- الإصدار: `1.5.2+38`.
- مجلد المشروع: `TraderDesk_Android_Project/` عند استخراج الحزمة.
- تفاصيل هذا الإصدار: `BUILD_INFO_AR.md` و`RELEASE_NOTES_AR.md`.
- هذه الحزمة مصدر مشروع وليست APK.
- لم تتوفر Flutter/Dart SDK في بيئة التحرير، لذلك لم يمكن تشغيل analyzer أو الاختبارات أو بناء APK.
