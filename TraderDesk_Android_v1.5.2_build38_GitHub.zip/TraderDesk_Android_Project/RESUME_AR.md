# متابعة المشروع الحالي — TraderDesk 1.5.1+37

رقم الإصدار الحالي `1.5.1+37`. هذه النسخة تنقل واجهة «إضافة صفقة» من Trader Labs على Windows إلى تطبيق Android.

- نموذج المصدر: `TraderLabs_v4.3.2_RejectKeyLevel.html` (منطقة `tradeEntryDialog`).
- شاشة Android: `lib/screens/trade_form_screen.dart`.
- كتالوج الحقول والقوائم: `lib/domain/trade_entry_catalog.dart`.
- حقول التخزين الجديدة: `Trade.executionReviewKeys` و`Trade.noEntryReasons`.
- رموز القرارات الخمسة عشر: `lib/widgets/decision_option_emoji.dart` و`assets/emojis/decisions/`.
- تفاصيل التغيير: `RELEASE_NOTES_AR.md`.
- معلومات التحقق وحدود بيئة البناء: `BUILD_INFO_AR.md`.

أكمل من هذه النسخة مع المحافظة على قراءة بيانات JSON السابقة؛ لا تحذف أو تعِد تسمية حقول `executionJournal` و`sequence` و`notes` القديمة دون ترحيل صريح. قبل بناء APK، شغّل `flutter pub get` ثم `flutter analyze` و`flutter test`، وبعد نجاحها ابنِ `flutter build apk --release`. إعداد توقيع Android في Gradle ما زال يستخدم debug للتجارب فقط ويجب استبداله بتوقيع إصدار خاص قبل النشر.
