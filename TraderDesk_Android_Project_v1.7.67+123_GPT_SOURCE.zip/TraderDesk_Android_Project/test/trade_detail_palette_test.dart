import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/theme/app_theme.dart';
import 'package:trader_desk/theme/trade_detail_palette.dart';

void main() {
  test(
    'Model 3 dark palette preserves light mode',
    () {
      expect(
        TradeDetailPalette.dataLabelTone(Brightness.dark),
        const Color(0xFFA8B8C9),
      );
      expect(
        TradeDetailPalette.dataLabelTone(Brightness.light),
        const Color(0xFF355F86),
      );
      expect(
        TradeDetailPalette.dataToneFor(Brightness.dark),
        const Color(0xFF76AEE8),
      );
      expect(
        TradeDetailPalette.dataToneFor(Brightness.light),
        const Color(0xFF8AB4D9),
      );
      final foregroundLuminance = const Color(0xFFA8B8C9).computeLuminance();
      expect(
        TradeDetailPalette.dataValueTone(Brightness.dark),
        const Color(0xFFE7EDF4),
      );
      expect(TradeDetailPalette.dataValueTone(Brightness.light), isNull);
      final backgroundLuminance = const Color(0xFF152B48).computeLuminance();
      final lighter = foregroundLuminance > backgroundLuminance
          ? foregroundLuminance
          : backgroundLuminance;
      final darker = foregroundLuminance > backgroundLuminance
          ? backgroundLuminance
          : foregroundLuminance;
      expect((lighter + .05) / (darker + .05), greaterThan(7.0));

      final chipForeground = const Color(0xFFE7EDF4).computeLuminance();
      final chipBackground = const Color(0xFF182F4C).computeLuminance();
      final chipLighter = chipForeground > chipBackground
          ? chipForeground
          : chipBackground;
      final chipDarker = chipForeground > chipBackground
          ? chipBackground
          : chipForeground;
      expect((chipLighter + .05) / (chipDarker + .05), greaterThan(7.0));

      final cardLuminance = const Color(0xFF172E4D).computeLuminance();
      final fieldLuminance = const Color(0xFF152B48).computeLuminance();
      final chipLuminance = const Color(0xFF182F4C).computeLuminance();
      expect((cardLuminance - fieldLuminance).abs(), lessThan(0.005));
      expect((fieldLuminance - chipLuminance).abs(), lessThan(0.005));
    },
  );

  test('saved trade data panel uses the exact approved Model 3 surfaces', () {
    expect(TradeDetailPalette.dataSurfaceDark, const Color(0xFF172E4D));
    expect(TradeDetailPalette.dataPanelBorderDark, const Color(0xFF29415E));
    expect(TradeDetailPalette.dataPanelIconSurfaceDark, const Color(0xFF203D60));
    expect(TradeDetailPalette.dataFieldDark, const Color(0xFF152B48));
    expect(TradeDetailPalette.dataFieldEdgeDark, const Color(0xFF152B48));
    expect(TradeDetailPalette.dataChipDark, const Color(0xFF182F4C));
    expect(TradeDetailPalette.dataChipEdgeDark, const Color(0xFF182F4C));
    expect(TradeDetailPalette.dataValueToneDark, const Color(0xFFE7EDF4));
  });

  test('Entry Conditions retains its previous dark field palette', () {
    expect(
      TradeDetailPalette.entryConditionsFieldDark,
      const Color(0xFF243140),
    );
    expect(
      TradeDetailPalette.entryConditionsFieldEdge,
      const Color(0xFF425569),
    );
  });

  test('trade review panel preserves the original 1.7.17+73 colors', () {
    expect(TradeDetailPalette.reviewTone, const Color(0xFFB7A6F2));
    expect(TradeDetailPalette.reviewOuterDark, const Color(0xFF292B36));
    expect(TradeDetailPalette.reviewDecisionDark, const Color(0xFF242526));
    expect(TradeDetailPalette.reviewCommitmentDark, const Color(0xFF172F2F));
    expect(TradeDetailPalette.reviewNoEntryDark, const Color(0xFF2A2635));
    expect(TradeDetailPalette.reviewDecisionOptionDark, const Color(0xFF383638));
    expect(TradeDetailPalette.reviewCommitmentOptionDark, const Color(0xFF203B39));
    expect(TradeDetailPalette.reviewNoEntryOptionDark, const Color(0xFF373047));
  });

  test('dark theme uses a restrained graphite ramp rather than pure black', () {
    final tokens = TdTokens.forBrightness(Brightness.dark);
    expect(tokens.bgBase, const Color(0xFF0B0D10));
    expect(tokens.surface1, const Color(0xFF101418));
    expect(tokens.surface2, const Color(0xFF151A20));
    expect(tokens.surface3, const Color(0xFF1B2128));
    expect(tokens.inset, const Color(0xFF0D1115));
    expect(tokens.bgBase, isNot(const Color(0xFF000000)));
    expect(tokens.surface1.computeLuminance(), greaterThan(tokens.bgBase.computeLuminance()));
    expect(tokens.surface2.computeLuminance(), greaterThan(tokens.surface1.computeLuminance()));
    expect(tokens.surface3.computeLuminance(), greaterThan(tokens.surface2.computeLuminance()));
  });
}
