import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';

// Flutter plays GIF/WebP files at the frame durations stored in the files and
// has no playback-speed control, so the tempo of every emoji list (review form,
// trade details, execution journal) is decided by the assets themselves.
// These guards keep that tempo calm and identical across all lists. To change
// the speed, run `python3 scripts/retime_emoji_animations.py --factor <x>` and
// update the constants below to the new minimums.
const _minGifFrameMs = 80;
const _minWebpFrameMs = 240;
const _minLoopMs = 2500;

class _Timing {
  _Timing(this.path, this.frameMs, this.loopCount);

  final String path;
  final List<int> frameMs;
  final int? loopCount;

  int get minFrameMs => frameMs.reduce(math.min);
  int get totalMs => frameMs.fold(0, (sum, value) => sum + value);
}

_Timing _parseGif(String path, Uint8List d) {
  final header = String.fromCharCodes(d.sublist(0, 6));
  if (header != 'GIF87a' && header != 'GIF89a') {
    throw FormatException('$path is not a GIF');
  }
  var pos = 13;
  final flags = d[10];
  if ((flags & 0x80) != 0) pos += 3 * (1 << ((flags & 7) + 1));
  final frameMs = <int>[];
  int? loop;
  while (pos < d.length) {
    final block = d[pos];
    if (block == 0x3B) break;
    if (block == 0x21) {
      final label = d[pos + 1];
      if (label == 0xF9) {
        frameMs.add((d[pos + 4] | (d[pos + 5] << 8)) * 10);
      }
      if (label == 0xFF &&
          String.fromCharCodes(d.sublist(pos + 3, pos + 14)) ==
              'NETSCAPE2.0') {
        loop = d[pos + 16] | (d[pos + 17] << 8);
      }
      pos += 2;
      while (d[pos] != 0) {
        pos += d[pos] + 1;
      }
      pos += 1;
    } else if (block == 0x2C) {
      final local = d[pos + 9];
      pos += 10;
      if ((local & 0x80) != 0) pos += 3 * (1 << ((local & 7) + 1));
      pos += 1;
      while (d[pos] != 0) {
        pos += d[pos] + 1;
      }
      pos += 1;
    } else {
      throw FormatException('$path: unknown GIF block $block');
    }
  }
  return _Timing(path, frameMs, loop);
}

_Timing _parseWebp(String path, Uint8List d) {
  if (String.fromCharCodes(d.sublist(0, 4)) != 'RIFF' ||
      String.fromCharCodes(d.sublist(8, 12)) != 'WEBP') {
    throw FormatException('$path is not a WebP');
  }
  final view = ByteData.sublistView(d);
  var pos = 12;
  final frameMs = <int>[];
  int? loop;
  while (pos + 8 <= d.length) {
    final tag = String.fromCharCodes(d.sublist(pos, pos + 4));
    final size = view.getUint32(pos + 4, Endian.little);
    if (tag == 'ANIM') loop = view.getUint16(pos + 8 + 4, Endian.little);
    if (tag == 'ANMF') {
      final o = pos + 8 + 12;
      frameMs.add(d[o] | (d[o + 1] << 8) | (d[o + 2] << 16));
    }
    pos += 8 + size + (size & 1);
  }
  return _Timing(path, frameMs, loop);
}

List<_Timing> _loadTimings(String extension) {
  final files = Directory('assets/emojis')
      .listSync(recursive: true)
      .whereType<File>()
      .where((file) => file.path.toLowerCase().endsWith(extension))
      .toList()
    ..sort((a, b) => a.path.compareTo(b.path));
  return [
    for (final file in files)
      extension == '.gif'
          ? _parseGif(file.path, file.readAsBytesSync())
          : _parseWebp(file.path, file.readAsBytesSync()),
  ];
}

void main() {
  final gifs = _loadTimings('.gif');
  final webps = _loadTimings('.webp');

  test('the animated emoji assets are discovered', () {
    expect(gifs, isNotEmpty);
    expect(webps, isNotEmpty);
    for (final timing in [...gifs, ...webps]) {
      expect(timing.frameMs.length, greaterThan(1), reason: timing.path);
    }
  });

  test('no GIF emoji runs faster than the calm tempo', () {
    for (final timing in gifs) {
      expect(
        timing.minFrameMs,
        greaterThanOrEqualTo(_minGifFrameMs),
        reason: '${timing.path} is too fast; see scripts/retime_emoji_animations.py',
      );
    }
  });

  test('no WebP emoji runs faster than the calm tempo', () {
    for (final timing in webps) {
      expect(
        timing.minFrameMs,
        greaterThanOrEqualTo(_minWebpFrameMs),
        reason: '${timing.path} is too fast; see scripts/retime_emoji_animations.py',
      );
    }
  });

  test('every emoji loop lasts at least two and a half seconds', () {
    for (final timing in [...gifs, ...webps]) {
      expect(
        timing.totalMs,
        greaterThanOrEqualTo(_minLoopMs),
        reason: timing.path,
      );
    }
  });

  test('all GIF emojis share one cadence, so every list moves alike', () {
    final cadences = gifs.map((timing) => timing.minFrameMs).toSet();
    expect(cadences, hasLength(1), reason: 'GIF cadences: $cadences');
    final webpCadences = webps.map((timing) => timing.minFrameMs).toSet();
    expect(webpCadences, hasLength(1), reason: 'WebP cadences: $webpCadences');
  });

  test('emoji animations loop forever', () {
    for (final timing in [...gifs, ...webps]) {
      expect(timing.loopCount, 0, reason: timing.path);
    }
  });
}
