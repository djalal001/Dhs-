#!/usr/bin/env python3
"""Static regression checks for the approved wording cleanup in 1.7.77+133."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / 'lib/domain/trade_entry_catalog.dart').read_text(encoding='utf-8')
STRINGS = (ROOT / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8')
FORM = (ROOT / 'lib/screens/trade_form_screen.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks = []
def has(label, condition):
    checks.append((label, bool(condition)))

# Catalog keys must remain unchanged while their display strings are refined.
expected_catalog = {
    "TradeEntryOption('__custom__', 'مخصص', 'Custom')": '__custom__',
    "TradeEntryOption('internalLiquiditySweep', 'سحب سيولة من منطقة داخلية', 'Liquidity sweep from an internal area')": 'internalLiquiditySweep',
    "TradeEntryOption('majorStructureLiquiditySweep', 'سحب سيولة من هيكل رئيسي', 'Liquidity sweep from a major structure')": 'majorStructureLiquiditySweep',
    "titleAr: 'الدخول وإدارة المخاطرة'": 'review group title',
    "titleEn: 'Entry & risk management'": 'review group English title',
    "'لم أفتح الحجم الكامل بسبب التردد'": 'hesitation wording',
    "'غيّرت وقف الخسارة لتقليل المخاطرة دون مبرر'": 'reduced stop wording',
    "'غيّرت وقف الخسارة لزيادة المخاطرة دون مبرر'": 'increased stop wording',
    "'خرجت مبكرًا خوفًا من ضياع الأرباح قبل الهدف'": 'early exit wording',
    "'الكسر والإغلاق الإيجابي ضعيفان'": 'weak breakout wording',
    "'لم أدمج ترند 1h–4h في تحليلي'": 'higher timeframe wording',
    "'خرجت يدويًا وفق الخطة عند اقتراب السعر من الهدف'": 'manual target wording',
    "'خرجت تلقائيًا وفق الخطة عند بلوغ الهدف'": 'automatic target wording',
    "'التزمت بشروط الدخول رغم الخوف من الخسارة'": 'entry despite fear wording',
    "'التزمت بالخطة كاملة'": 'full plan wording',
    "'الخوف من تكرار الخسارة بعد خسارة سابقة'": 'repeat loss wording',
}
for literal, label in expected_catalog.items():
    has(f'catalog contains approved {label}', literal in CATALOG)

for old in [
    'مخصص — اكتب النوع', 'سحب السعر للسيولة من منطقة داخلية',
    'سحب السعر للسيولة من هيكل أساسي', 'قرارات الدخول وإدارة المخاطرة',
    'بسبب التردد لم أفتح صفقة بالحجم الكامل.',
    'تغيير وقف الخسارة لتقليل المخاطرة دون سبب منطقي.',
    'تغيير وقف الخسارة لزيادة المخاطرة دون سبب منطقي.',
    'لم أحترم الهدف، خرجت مبكرًا بسبب خوف ضياع الأرباح.',
    'الكسر والإغلاق الإيجابي منخفض القوة.',
    'لم أدمج ترند الفريم الأكبر (1h–4h) مع تحليلي.',
    'خرجت يدويًا وفق الخطة عندما وصل السعر إلى شبه الهدف.',
    'خرجت تلقائيًا وفق الخطة عندما وصل السعر إلى الهدف المحدد.',
    'التزمت بشروط الدخول رغم شعوري بالخوف من الخسارة.',
    'التزمت بالخطة كاملة دون مخالفة.',
    'الخوف من تكرار خسارة سابقة.',
]:
    has(f'old catalog wording removed: {old}', old not in CATALOG)

for literal in [
    "'sequence': 'سلوك التنفيذ'", "'notes': 'ملاحظات سبب الدخول'",
    "'exportBackupFile': 'تصدير نسخة JSON'", "'restoreBackupFile': 'استعادة نسخة JSON'",
    "'customConfirmation': 'مخصص'", "'sequence': 'Execution behavior'",
    "'notes': 'Entry reason notes'", "'exportBackupFile': 'Export JSON backup'",
    "'restoreBackupFile': 'Restore JSON backup'", "'customConfirmation': 'Custom'",
]:
    has(f'translation present: {literal}', literal in STRINGS)

has('section title uses سلوك التداول', "title: _copy('سلوك التداول', 'Trading behavior')" in FORM)
has('version updated', 'version: 1.7.77+133' in PUBSPEC)
has('workflow updated', 'TraderDesk 1.7.77+133' in WORKFLOW and 'traderdesk-1.7.77-build133' in WORKFLOW)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed), file=sys.stderr)
    raise SystemExit(1)
