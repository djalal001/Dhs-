#!/usr/bin/env python3
"""Static regression checks for TraderDesk Base-anchor and shared timeframe-header behavior."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = (ROOT / "lib/domain/trade_entry_catalog.dart").read_text(encoding="utf-8")
FORM = (ROOT / "lib/screens/trade_form_screen.dart").read_text(encoding="utf-8")
MODEL = (ROOT / "lib/models/trade.dart").read_text(encoding="utf-8")
TRADES = (ROOT / "lib/screens/trades_screen.dart").read_text(encoding="utf-8")
WIDGET_TEST = (ROOT / "test/entry_conditions_test.dart").read_text(encoding="utf-8")
CATALOG_TEST = (ROOT / "test/trade_entry_catalog_test.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

# One Base option only; all existing anchor choices stay present.
anchor_block = CATALOG.split("const tradeAnchorOptions", 1)[1].split("const tradeMoodOptions", 1)[0]
base_lines = [line for line in anchor_block.splitlines() if "TradeEntryOption('base'" in line]
check("anchor catalog contains exactly one Base option", len(base_lines) == 1)
check("Base is presented as Base in both locales", "TradeEntryOption('base', 'Base', 'Base')" in anchor_block)
check("the five existing anchors remain unchanged", all(key in anchor_block for key in ["'keyLevel'", "'supplyZone'", "'demandZone'", "'bullishEngulfing'", "'bearishEngulfing'"]))

# Anchor context is routed through the common timeframe heading.
helper = FORM.split("String _anchorTimeframeContextLabel", 1)[1].split("Future<void> _pickAnchors", 1)[0]
check("all timeframe pickers use the common Arabic/English heading", "_copy('اختيار الفريم الزمني', 'Select timeframe')" in FORM)
check("anchor context helper identifies the Anchor section and its selected item", "_copy('الارتكاز', 'Anchor')" in helper and "_anchorSelectionLabel(anchorKey)" in helper)
anchor_flow = FORM.split("Future<void> _pickAnchors", 1)[1].split("void _removeAnchor", 1)[0]
check("new and legacy-missing anchor selections both pass contextual labels", anchor_flow.count("_anchorTimeframeContextLabel(option.key)") >= 2)
check("editing anchor timeframe also passes a contextual label", "contextLabel: _anchorTimeframeContextLabel(anchorKey)" in FORM)
selection_helper = FORM.split("String _anchorSelectionLabel", 1)[1].split("String _anchorTimeframeContextLabel", 1)[0]
check("selected Base label is Base Buy when BUY is selected", "TradeSide.buy => 'Base Buy'" in selection_helper)
check("selected Base label is Base Sell when SELL is selected", "TradeSide.sell => 'Base Sell'" in selection_helper)
check("selected Base label remains neutral when no direction is chosen", "null => 'Base'" in selection_helper)
check("selected anchor field uses the direction-aware label helper", "final label = _anchorSelectionLabel(anchorKey)" in FORM)

# Existing UI and data model remain in use.
check("timeframe choices remain the existing eight-frame catalog", "tradeEntryTimeframes" in CATALOG and "['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H']" in CATALOG)
check("the original centered choice dialog and row ListTile rendering remain", "_showCenteredTradeChoiceDialog<String>(" in FORM and "ListTile(" in FORM and "Dialog(" in anchor_flow)
check("anchor/timeframe pairs continue using the existing map", "final Map<String, String> anchorTimeframes" in MODEL and "'anchorTimeframes': anchorTimeframes" in MODEL and "_anchorTimeframes[option.key] = timeframe" in FORM)
check("saved trade details still resolve anchor label and timeframe from catalog/map", "tradeAnchorOptions" in TRADES and "trade.anchorTimeframes[key]" in TRADES)
check("widget test covers Base Buy and Base Sell context labels", "الارتكاز · Base Buy" in WIDGET_TEST and "الارتكاز · Base Sell" in WIDGET_TEST)
check("widget test covers saved Base timeframe value", "'base': '4H'" in WIDGET_TEST and "Base Sell 4H" in WIDGET_TEST and "Base Buy 1H" in WIDGET_TEST and "Base Sell 1H" in WIDGET_TEST and "Base Buy 4H" in WIDGET_TEST)
check("catalog test asserts Base and six unique options", "Base" in CATALOG_TEST and "toSet().length, 6" in CATALOG_TEST)
check("Base key and timeframe are tested through JSON round-trip", "Base anchor and timeframe round-trip" in CATALOG_TEST and "Trade.fromJson(original.toJson())" in CATALOG_TEST)

# Release metadata.
check("pubspec version is 1.7.77+133", "version: 1.7.77+133" in PUBSPEC)
check("workflow name matches 1.7.77+133", "TraderDesk 1.7.77+133" in WORKFLOW)
check("release artifact IDs match build 133", "traderdesk-1.7.77-build133-arm64-v8a-release" in WORKFLOW and "traderdesk-1.7.77-build133-arm64-dart-symbols" in WORKFLOW)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    print("Failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
