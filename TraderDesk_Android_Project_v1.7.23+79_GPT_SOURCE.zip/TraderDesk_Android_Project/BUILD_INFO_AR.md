# معلومات البناء والتسليم — TraderDesk 1.7.23+79

- رقم الإصدار: `1.7.23`؛ رقم البناء: `79`.
- اسم الحزمة: `com.traderdesk.trader_desk`.
- نوع التسليم: مشروع Flutter كامل بصيغة ZIP، وليس APK.
- يستخدم سير عمل GitHub Actions إصدار Flutter المثبت في إعدادات workflow لبناء ARM64 Release.
- يشغّل `scripts/build_release_apk.sh` بناء AOT Release لمنصة `android-arm64` بعد `flutter clean` و`flutter pub get`، ثم يتحقق من بنية APK عبر `scripts/verify_arm64_apk.sh`.
- لم يتوفر Flutter/Dart SDK في بيئة التحرير؛ لم يُشغّل `flutter analyze` أو `flutter test` أو بناء APK. يجب تشغيل GitHub Actions أو البناء في بيئة Flutter مجهزة قبل اعتماد APK.
