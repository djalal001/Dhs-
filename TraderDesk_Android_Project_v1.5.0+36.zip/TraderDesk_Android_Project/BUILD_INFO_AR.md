# معلومات البناء والتسليم — TraderDesk 1.5.0+36

- رقم الإصدار: 1.5.0؛ رقم البناء: 36؛ اسم الحزمة: `com.traderdesk.trader_desk`.
- نوع التسليم: مشروع Flutter كامل في ملف ZIP؛ لا يوجد APK ضمن هذه الحزمة.
- الميزات الرئيسية: ترحيل نموذج إضافة الصفقة من واجهة Windows، مع الحقول والقوائم متعددة التحديد، والفريم المرتبط بكل سبب/تأكيد، وحساب المخاطرة وR، وسجل القرارات والالتزام وأسباب عدم الدخول، وثلاث صور مرتبطة بالصفقة.
- توافق البيانات: الحقلان `executionReviewKeys` و`noEntryReasons` اختياريان عند القراءة؛ ملفات الصفقات السابقة التي لا تحتويهما تُقرأ بقوائم فارغة. بقيت حقول `executionJournal` و`sequence` و`notes` السابقة كما هي للحفاظ على السجلات القائمة.
- الملفات التي تم تحديثها: `lib/screens/trade_form_screen.dart`، `lib/models/trade.dart`، `lib/domain/trade_entry_catalog.dart`، `lib/domain/trade_csv_exporter.dart`، `lib/screens/trades_screen.dart`، `lib/l10n/app_strings.dart`، واختبارات التخزين والنموذج، بالإضافة إلى بيانات الإصدار والتوثيق.
- تم إجراء فحص ساكن مبدئي للملفات المعدلة ومراجعة اتساق أسماء الحقول؛ لم يتوفر Flutter/Dart SDK في بيئة التحرير، ولذلك لم يمكن تشغيل `flutter analyze` أو `flutter test` أو بناء APK.
- لم يتم إجراء اختبار تثبيت على جهاز Android فعلي.
- لم تتم إضافة اعتماديات Flutter جديدة.
