import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';

void main() {
  test('exit section title follows the result classification', () {
    expect(tradeExitSectionTitle(TradeClassification.win, arabic: true), 'أسباب الخروج');
    expect(tradeExitSectionTitle(TradeClassification.loss, arabic: true), 'أسباب الخروج');
    expect(tradeExitSectionTitle(TradeClassification.breakEven, arabic: true), 'قرار الاحتفاظ');
    expect(tradeExitSectionTitle(TradeClassification.missed, arabic: true), isNull);
    expect(tradeExitSectionTitle(null, arabic: true), isNull);
  });

  test('exit reason list holds the eleven requested options in order', () {
    expect(
      tradeExitReasonOptions.map((o) => o.en).toList(),
      [
        'HNS', 'SBR', 'RBS', 'SFR', 'RFS', 'Supply Zone', 'Demand Zone',
        'Trend Line Touch 3 Sell Breakout', 'Trend Line Touch 3 Buy Breakout',
        'Trendline Touch 3 Buy', 'Trendline Touch 3 Sell',
      ],
    );
  });

  test('exit reasons survive JSON round trip and default to empty', () {
    final trade = Trade(
      id: '1', accountId: 'a', market: 'NQ', reason: 'HNS', result: 10,
      riskPercent: 1, side: TradeSide.buy, confirmation: '', sequence: '',
      mood: 'moodUnknown', tradedAt: DateTime(2026, 1, 1),
      exitReasonSetups: const [
        TradeConfirmationSetup(type: 'exitHns', timeframe: '5MIN'),
      ],
    );
    final decoded = Trade.fromJson(trade.toJson());
    expect(decoded.exitReasonSetups, trade.exitReasonSetups);
    final legacy = Map<String, dynamic>.from(trade.toJson())..remove('exitReasonSetups');
    expect(Trade.fromJson(legacy).exitReasonSetups, isEmpty);
  });
}
