import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/data/local_store.dart';
import 'package:trader_desk/main.dart';
import 'package:trader_desk/models/trade.dart';
import 'package:trader_desk/models/trading_account.dart';
import 'package:trader_desk/state/app_controller.dart';

void main() {
  late Directory temp;
  late AppController app;
  late TradingAccount account;

  setUp(() async {
    temp = await Directory.systemTemp.createTemp(
      'trader_desk_trades_filter_',
    );
    app = await AppController.create(
      store: LocalStore(documentsDirectory: () async => temp),
    );
    account = TradingAccount(
      id: 'trades-filter-account',
      name: 'Filter account',
      type: AccountType.demo,
      startingBalance: 10000,
      currency: 'USD',
      createdAt: DateTime(2024, 1, 1),
    );
    app.accounts = [account];
    app.selectedAccountId = account.id;
    app.trades = [
      _trade(id: 'winner', result: 25),
      _trade(id: 'loser', result: -12),
      // A saved setup with a no-entry reason belongs to the missed filter,
      // irrespective of any legacy result amount on the record.
      _trade(
        id: 'missed',
        result: 7,
        noEntryReasons: const ['fearLossNoHistory'],
      ),
    ];
  });

  tearDown(() async {
    app.dispose();
    if (await temp.exists()) await temp.delete(recursive: true);
  });

  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(390, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }

  Future<void> openTrades(WidgetTester tester) async {
    await tester.pumpWidget(TraderDeskApp(controller: app));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الصفقات').last);
    await tester.pumpAndSettle();
  }

  testWidgets('missed filter shows saved setups marked with no-entry reasons', (
    tester,
  ) async {
    usePhoneViewport(tester);
    await openTrades(tester);

    expect(find.byKey(const ValueKey('trades-filter-all')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-wins')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-losses')), findsOneWidget);
    expect(find.byKey(const ValueKey('trades-filter-missed')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('trades-filter-missed')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-missed')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-winner')), findsNothing);
    expect(find.byKey(const ValueKey('trade-summary-loser')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('trades-filter-wins')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-winner')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('trades-filter-losses')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('trade-summary-loser')), findsOneWidget);
    expect(find.byKey(const ValueKey('trade-summary-missed')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'missed period selector filters only missed records by selected range',
    (tester) async {
      usePhoneViewport(tester);
      final today = DateTime.now();
      app.trades = [
        _trade(
          id: 'recent-missed',
          result: 4,
          noEntryReasons: const ['fearLossNoHistory'],
          tradedAt: today.subtract(const Duration(days: 2)),
        ),
        _trade(
          id: 'old-missed',
          result: -2,
          noEntryReasons: const ['hesitation'],
          tradedAt: DateTime(2020, 1, 3),
        ),
        _trade(id: 'normal-win', result: 12, tradedAt: today),
      ];
      await openTrades(tester);

      final periodMenu = find.byKey(
        const ValueKey('trades-missed-period-menu'),
      );
      await tester.ensureVisible(periodMenu);
      await tester.pumpAndSettle();
      await tester.tap(periodMenu);
      await tester.pumpAndSettle();
      for (final period in ['all', 'week', 'month', 'year', 'custom']) {
        expect(
          find.byKey(ValueKey('trades-missed-period-$period')),
          findsOneWidget,
        );
      }

      // Selecting a period also activates the Missed category.
      await tester.tap(
        find.byKey(const ValueKey('trades-missed-period-week')),
      );
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('trades-filter-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-recent-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-missed')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-normal-win')),
        findsNothing,
      );

      // Switching back to All in the period menu shows every missed record,
      // but it never leaks executed trades into the missed category.
      await tester.ensureVisible(periodMenu);
      await tester.tap(periodMenu);
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('trades-missed-period-all')),
      );
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('trade-summary-recent-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-old-missed')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('trade-summary-normal-win')),
        findsNothing,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'floating add button becomes clearer while scrolling and fades at rest',
    (tester) async {
      usePhoneViewport(tester);
      app.trades = List.generate(
        24,
        (index) => _trade(
          id: 'scroll-$index',
          result: index.isEven ? 10 : -5,
        ),
      );
      await openTrades(tester);

      final button = find.byKey(const ValueKey('trades-add-floating'));
      final opacity = find.byKey(
        const ValueKey('trades-add-floating-opacity'),
      );
      expect(button, findsOneWidget);
      expect(find.byKey(const ValueKey('trades-list')), findsOneWidget);
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.30);

      await tester.drag(
        find.byKey(const ValueKey('trades-list')),
        const Offset(0, -380),
      );
      await tester.pump();
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.96);

      await tester.pump(const Duration(milliseconds: 800));
      await tester.pump(const Duration(milliseconds: 200));
      expect(tester.widget<AnimatedOpacity>(opacity).opacity, 0.30);
      final listRect = tester.getRect(
        find.byKey(const ValueKey('trades-list')),
      );
      final navRect = tester.getRect(
        find.byKey(const ValueKey('td-bottom-navigation')),
      );
      final fabRect = tester.getRect(button);
      expect(listRect.bottom, closeTo(navRect.top, 1));
      expect(fabRect.left, lessThan(listRect.left + 60));
      expect(fabRect.bottom, lessThanOrEqualTo(listRect.bottom));
      expect(tester.takeException(), isNull);
    },
  );
}

Trade _trade({
  required String id,
  required double result,
  List<String> noEntryReasons = const [],
  DateTime? tradedAt,
}) => Trade(
  id: id,
  accountId: 'trades-filter-account',
  market: 'EURUSD',
  reason: 'Breakout',
  result: result,
  riskPercent: 0.25,
  side: TradeSide.buy,
  confirmation: 'confirmTechnical',
  sequence: '',
  mood: 'moodCalm',
  tradedAt: tradedAt ?? DateTime(2024, 1, 1),
  noEntryReasons: noEntryReasons,
);
