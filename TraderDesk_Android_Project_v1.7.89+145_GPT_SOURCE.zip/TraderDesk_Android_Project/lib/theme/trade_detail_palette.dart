import 'package:flutter/material.dart';

/// Colors for saved trade details. The dark data panel follows the approved
/// Model 4 blue palette with a slightly clearer, still restrained surface
/// separation; light mode and adjacent panels keep their own tones.
abstract final class TradeDetailPalette {
  static const dataToneDark = Color(0xFF76AEE8);
  static const dataToneLight = Color(0xFF8AB4D9);
  static Color dataToneFor(Brightness brightness) =>
      brightness == Brightness.dark ? dataToneDark : dataToneLight;

  static Color dataLabelTone(Brightness brightness) =>
      brightness == Brightness.dark
          ? const Color(0xFFA8B8C9)
          : const Color(0xFF355F86);

  static const dataSurfaceDark = Color(0xFF172E4D);
  static const dataPanelBorderDark = Color(0xFF29415E);
  static const dataPanelIconSurfaceDark = Color(0xFF203D60);
  static const dataFieldDark = Color(0xFF142A46);
  // The field border intentionally matches its fill to avoid a hard outline.
  static const dataFieldEdgeDark = Color(0xFF142A46);
  static const dataChipDark = Color(0xFF19314E);
  // Chip borders match their fill so selected values blend into the field.
  static const dataChipEdgeDark = Color(0xFF19314E);
  static const dataValueToneDark = Color(0xFFE7EDF4);
  static Color? dataValueTone(Brightness brightness) =>
      brightness == Brightness.dark ? dataValueToneDark : null;

  /// Entry Conditions surfaces remain unchanged; their outlines are deliberately softer.
  static const entryConditionsFieldDark = Color(0xFF243140);
  static const entryConditionsFieldEdge = Color(0xFF344653);
  /// Muted violet surfaces used when an opposing signal is marked as a
  /// practical reason for not entering. Kept separate from the teal default.
  static const linkedEntryConditionsFieldDark = Color(0xFF332D42);
  static const linkedEntryConditionsFieldEdge = Color(0xFF453B56);
  static const linkedEntryConditionsChipDark = Color(0xFF3B334B);
  static const linkedEntryConditionsPanelBorderDark = Color(0xFF4B425B);
  static const linkedEntryConditionsPanelDividerDark = Color(0xFF41384F);

  /// Shared accent of the saved Entry Conditions panel and its two headings.
  static const entryConditionsTone = Color(0xFF78AFC3);

  static Color entryConditionsLabelTone(Brightness brightness) =>
      brightness == Brightness.dark
          ? entryConditionsTone
          : const Color(0xFF356B7F);

  static const reviewTone = Color(0xFFB7A6F2);
  static const decisionTone = Color(0xFFC6A071);
  static const commitmentTone = Color(0xFF55C99A);
  static const noEntryTone = Color(0xFFB69AF0);
  static const reviewOuterDark = Color(0xFF292B36);
  static const reviewDecisionDark = Color(0xFF242526);
  static const reviewCommitmentDark = Color(0xFF172F2F);
  static const reviewNoEntryDark = Color(0xFF2A2635);
  static const reviewDecisionOptionDark = Color(0xFF383638);
  static const reviewCommitmentOptionDark = Color(0xFF203B39);
  static const reviewNoEntryOptionDark = Color(0xFF373047);
}
