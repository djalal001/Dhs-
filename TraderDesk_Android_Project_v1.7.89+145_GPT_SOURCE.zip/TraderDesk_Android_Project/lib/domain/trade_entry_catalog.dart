import '../models/trade.dart';

class TradeEntryOption {
  const TradeEntryOption(this.key, this.ar, this.en);
  final String key;
  final String ar;
  final String en;
}

class TradeReviewGroup {
  const TradeReviewGroup({required this.titleAr, required this.titleEn, required this.options, this.noteAr, this.noteEn});
  final String titleAr;
  final String titleEn;
  final String? noteAr;
  final String? noteEn;
  final List<TradeEntryOption> options;
}

const tradeEntryTimeframes = <String>['1MIN', '2MIN', '3MIN', '5MIN', '15MIN', '30MIN', '1H', '4H'];

/// Formats the selected/saved Entry Conditions label. Direction-aware
/// reverse-signal labels are resolved from the trade side in one shared place.
/// Keep timeframes adjacent to their descriptions, without decorative dots.
String formatTradeEntryConditionSetupLabel({
  required TradeEntryConditionSetup setup,
  required String optionLabel,
  required bool arabic,
  TradeSide? side,
}) {
  const reverseSignalKeys = {
    'reverseSr',
    'reverseSdZone',
    'reverseHns',
    'reverseLongCandleWick',
    'negativeCloseAgainstDirection',
    'strongRejectionWickAgainstDirection',
  };
  if (reverseSignalKeys.contains(setup.optionKey)) {
    final label = tradeReverseSignalDisplayLabel(
      optionKey: setup.optionKey,
      arabic: arabic,
      side: side,
    );
    return setup.timeframe.isEmpty ? label : '$label ${setup.timeframe}';
  }

  if (setup.optionKey == 'bounceFromTrendlineAndSupplyZone') {
    final prefix = arabic ? 'ارتداد من' : 'Bounce from';
    return '$prefix Trend Line ${setup.timeframe} - Supply Zone ${setup.secondaryTimeframe ?? '—'}';
  }

  // S/R bounce chips use the selected trade direction as an English market
  // term inside the Arabic label. The optional 2 Touch choice remains stored
  // as a boolean for compatibility, while its chip caption is "Touch 2".
  // Keep the order stable: direction, Touch 2 (when selected), timeframe.
  if (setup.optionKey == 'bounceFromSrZone') {
    final directionalLabel = side == null
        ? optionLabel
        : arabic
            ? (side == TradeSide.buy
                ? 'ارتداد من Support'
                : 'ارتداد من Resistan')
            : (side == TradeSide.buy
                ? 'Bounce from Support'
                : 'Bounce from Resistan');
    final suffix = [
      if (setup.touch2) 'Touch 2',
      if (setup.timeframe.isNotEmpty) setup.timeframe,
    ].join(' ');
    if (suffix.isEmpty) return directionalLabel;
    return '$directionalLabel $suffix';
  }

  return setup.timeframe.isEmpty ? optionLabel : '$optionLabel ${setup.timeframe}';
}

const tradeEntryReasons = <TradeEntryOption>[
  // One direction-aware Breakout choice replaces the separate SBR/RBS rows.
  TradeEntryOption('directionalBreakout', 'BREAKOUT', 'BREAKOUT'),
  // SFR/RFS share one row; BUY resolves to RFS and SELL resolves to SFR.
  TradeEntryOption('directionalSfrRfs', 'SFR / RFS', 'SFR / RFS'),
  // Direction selects the concrete Trendline Touch 3 scenario after choice.
  TradeEntryOption(
    'directionalTrendlineTouch3',
    'Trendline Touch 3',
    'Trendline Touch 3',
  ),
  // Breakout uses the opposite-side Trendline scenario by specification.
  TradeEntryOption(
    'directionalTrendlineTouch3Breakout',
    'Trend Line Touch 3 Breakout',
    'Trend Line Touch 3 Breakout',
  ),
  TradeEntryOption('HNS', 'HNS', 'HNS'),
  TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D'),
];

/// Returns the selected key for the entry-reason picker. Legacy SBR/RBS,
/// SFR/RFS and separate Trendline options migrate to their direction-aware
/// semantic row when edited. Their historical stored values remain readable.
String tradeEntryReasonSelectionKey(String reason) {
  final base = tradeEntryBaseReason(reason);
  if (base == 'SBR' ||
      base == 'RBS' ||
      base == 'BREAKOUT' ||
      base == 'directionalBreakout') {
    return 'directionalBreakout';
  }
  if (base == 'SFR' ||
      base == 'RFS' ||
      base == 'SFR / RFS' ||
      base == 'directionalSfrRfs') {
    return 'directionalSfrRfs';
  }
  if ({
    'Trend Line SELL',
    'Trend Line BUY',
    'Trendline Sell 3 Touch',
    'Trendline Buy 3 Touch',
    'Trendline Touch 3 Sell',
    'Trendline Touch 3 Buy',
    'Trendline Touch 3',
    'directionalTrendlineTouch3',
  }.contains(base)) {
    return 'directionalTrendlineTouch3';
  }
  if ({
    'Trend Line BREAKOUT SELL',
    'Trend Line BREAKOUT BUY',
    'Trend Line Touch 3 Sell Breakout',
    'Trend Line Touch 3 Buy Breakout',
    'Trend Line Touch 3 Breakout',
    'directionalTrendlineTouch3Breakout',
  }.contains(base)) {
    return 'directionalTrendlineTouch3Breakout';
  }
  if (base == 'Supply Zone' || base == 'Zone S/D' || base == 'zoneSd') {
    return 'zoneSd';
  }
  return base;
}

/// Formats entry reasons for every user-facing surface. New semantic choices
/// resolve from the saved trade side. Legacy concrete keys remain readable so
/// historical trades are not silently reinterpreted until they are edited.
String formatTradeEntryReasonLabel({
  required String reason,
  TradeSide? side,
}) {
  switch (reason) {
    case 'directionalBreakout':
    case 'BREAKOUT':
      if (side == TradeSide.buy) return 'RBS';
      if (side == TradeSide.sell) return 'SBR';
      return 'BREAKOUT';
    case 'directionalBreakout Touch 2':
      final breakoutLabel = side == TradeSide.buy
          ? 'RBS'
          : side == TradeSide.sell
              ? 'SBR'
              : 'BREAKOUT';
      return '$breakoutLabel Touch 2';
    case 'directionalSfrRfs':
      if (side == TradeSide.buy) return 'RFS';
      if (side == TradeSide.sell) return 'SFR';
      return 'SFR / RFS';
    case 'directionalTrendlineTouch3':
      if (side == TradeSide.buy) return 'Trendline Touch 3 Buy';
      if (side == TradeSide.sell) return 'Trendline Touch 3 Sell';
      return 'Trendline Touch 3';
    case 'directionalTrendlineTouch3Breakout':
      if (side == TradeSide.buy) return 'Trend Line Touch 3 Sell Breakout';
      if (side == TradeSide.sell) return 'Trend Line Touch 3 Buy Breakout';
      return 'Trend Line Touch 3 Breakout';
    case 'Trend Line SELL':
    case 'Trendline Sell 3 Touch':
      return 'Trendline Touch 3 Sell';
    case 'Trend Line BUY':
    case 'Trendline Buy 3 Touch':
      return 'Trendline Touch 3 Buy';
    case 'Trendline Touch 3 Sell':
      return 'Trendline Touch 3 Sell';
    case 'Trendline Touch 3 Buy':
      return 'Trendline Touch 3 Buy';
    case 'Trend Line BREAKOUT SELL':
    case 'Trend Line Touch 3 Sell Breakout':
      return 'Trend Line Touch 3 Sell Breakout';
    case 'Trend Line BREAKOUT BUY':
    case 'Trend Line Touch 3 Buy Breakout':
      return 'Trend Line Touch 3 Buy Breakout';
    case 'SFR':
      return 'SFR';
    case 'RFS':
      return 'RFS';
    case 'zoneSd':
    case 'Zone S/D':
      if (side == TradeSide.buy) return 'Demand Zone';
      if (side == TradeSide.sell) return 'Supply Zone';
      return 'Zone S/D';
    default:
      // Old saved `Supply Zone` values remain historical fixed-zone records.
      return reason;
  }
}

/// Legacy Touch 2 records for SBR/RBS remain readable and editable. The
/// single BREAKOUT picker now exposes the same optional Touch 2 detail, stored
/// under a direction-neutral semantic reason so its label follows BUY/SELL.
/// S/R bounce Touch 2 remains stored separately on TradeEntryConditionSetup.touch2.
const tradeEntryTouch2EligibleReasons = <String>{'SBR', 'RBS'};

String tradeEntryBaseReason(String reason) {
  if (reason == 'directionalBreakout Touch 2') return 'directionalBreakout';
  for (final base in tradeEntryTouch2EligibleReasons) {
    if (reason == '$base Touch 2') return base;
  }
  return reason;
}

bool tradeEntryUsesTouch2(String reason) =>
    reason == 'directionalBreakout Touch 2' ||
    tradeEntryTouch2EligibleReasons.any((base) => reason == '$base Touch 2');

String tradeEntryReasonWithTouch2(String baseReason, bool touch2) {
  if (baseReason == 'directionalBreakout') {
    return touch2 ? 'directionalBreakout Touch 2' : 'directionalBreakout';
  }
  return touch2 && tradeEntryTouch2EligibleReasons.contains(baseReason)
      ? '$baseReason Touch 2'
      : baseReason;
}

const tradeConfirmationOptions = <TradeEntryOption>[
  TradeEntryOption('confirmEngulfing', 'Engulfing', 'Engulfing'),
  TradeEntryOption('confirmHns', 'HNS', 'HNS'),
  TradeEntryOption('confirmBreakoutPullback', 'Breakout–Pullback', 'Breakout–Pullback'),
  TradeEntryOption('confirmEveningStar', 'Evening Star', 'Evening Star'),
  TradeEntryOption('confirmRejectKeyLevel', 'Reject ᴷᵉʸ ᴸᵉᵛᵉˡ', 'Reject Key Level'),
  TradeEntryOption('__custom__', 'مخصص', 'Custom'),
];

/// Legacy Bullish/Bearish confirmation records map to the new single picker
/// row when edited. Their saved values remain unchanged until the user edits.
String tradeConfirmationSelectionKey(String type) {
  if (type == 'confirmBullishEngulfing' ||
      type == 'confirmBearishEngulfing' ||
      type == 'Bullish Engulfing' ||
      type == 'Bearish engulfing' ||
      type == 'Bearish Engulfing' ||
      type == 'Engulfing') {
    return 'confirmEngulfing';
  }
  return type;
}

/// Converts the semantic Engulfing choice to the concrete candle pattern
/// using the current trade direction. Historical concrete values are kept
/// readable as they were originally recorded.
String tradeConfirmationDisplayKey({
  required String type,
  required TradeSide? side,
}) {
  if (type == 'confirmEngulfing' || type == 'Engulfing') {
    if (side == TradeSide.buy) return 'confirmBullishEngulfing';
    if (side == TradeSide.sell) return 'confirmBearishEngulfing';
    return 'confirmEngulfing';
  }
  return type;
}

/// The four choices shown when the user opens the Opposing Signals selector.
/// S/R and S-D are semantic groups: their saved category is interpreted using
/// the selected trade side, so changing Buy/Sell updates the displayed
/// opposing reference without rewriting the stored setup.
const tradeReverseSignalOptions = <TradeEntryOption>[
  TradeEntryOption('reverseSr', 'S/R عكسي', 'Reverse S/R'),
  TradeEntryOption('reverseSdZone', 'S - D Zone عكسي', 'Reverse S - D Zone'),
  TradeEntryOption('reverseHns', 'HNS عكسي', 'Reverse HNS'),
  TradeEntryOption(
    'reverseLongCandleWick',
    'ذيل شمعة طويل عكسي',
    'Opposing long candle wick',
  ),
];

/// Resolves the concrete reversed S/R or S-D reference from its semantic
/// category and trade direction. For S/R role reversal, a former resistance
/// that flips polarity is displayed as Support for Buy, while a former
/// support that flips polarity is displayed as Resistance for Sell. The
/// S-D Zone mapping follows the separately specified application convention.
/// Legacy keys remain readable for old saved trades.
String tradeReverseSignalDisplayLabel({
  required String optionKey,
  required bool arabic,
  TradeSide? side,
}) {
  switch (optionKey) {
    case 'reverseSr':
      if (side == TradeSide.buy) {
        return arabic ? 'Support عكسي' : 'Reverse Support';
      }
      if (side == TradeSide.sell) {
        return arabic ? 'Resistan عكسي' : 'Reverse Resistan';
      }
      return arabic ? 'S/R عكسي' : 'Reverse S/R';
    case 'reverseSdZone':
      if (side == TradeSide.buy) return 'Supply Zone';
      if (side == TradeSide.sell) return 'Demand Zone';
      return arabic ? 'S - D Zone عكسي' : 'Reverse S - D Zone';
    case 'reverseHns':
      return arabic ? 'HNS عكسي' : 'Reverse HNS';
    case 'reverseLongCandleWick':
      return arabic ? 'ذيل شمعة طويل عكسي' : 'Opposing long candle wick';
    // Preserve the meaning of records saved before this catalog revision.
    case 'negativeCloseAgainstDirection':
      return arabic
          ? 'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول'
          : 'Negative close before the bounce did not support the trade direction';
    case 'strongRejectionWickAgainstDirection':
      return arabic
          ? 'نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة'
          : 'Strong rejection pattern with a long wick against the trade direction';
    default:
      return optionKey;
  }
}

const tradeBounceZoneOptions = <TradeEntryOption>[
  TradeEntryOption('bounceFromSrZone', 'ارتداد من منطقة S/R', 'Bounce from an S/R zone'),
  TradeEntryOption('internalLiquiditySweep', 'سحب سيولة داخلي', 'Internal liquidity sweep'),
  TradeEntryOption('majorStructureLiquiditySweep', 'سحب السيولة خارجي', 'External liquidity sweep'),
  TradeEntryOption('bounceFromTrendline', 'ارتداد من ترند لاين', 'Bounce from a trendline'),
  TradeEntryOption('bounceFromTrendlineAndSupplyZone', 'ارتداد من ترند لاين و Supply Zone', 'Bounce from a trendline and Supply Zone'),
];

/// Formats an anchor label consistently in forms and saved-trade details.
/// The new Zone S/D option resolves to the concrete zone from trade direction;
/// legacy `supplyZone`/`demandZone` records retain their historical labels.
String formatTradeAnchorLabel({
  required String anchorKey,
  required bool arabic,
  TradeSide? side,
}) {
  switch (anchorKey) {
    case 'zoneSd':
    case 'Zone S/D':
      if (side == TradeSide.buy) return 'Demand Zone';
      if (side == TradeSide.sell) return 'Supply Zone';
      return 'Zone S/D';
    case 'base':
      return switch (side) {
        TradeSide.buy => 'Base Buy',
        TradeSide.sell => 'Base Sell',
        null => 'Base',
      };
    case 'engulfing':
      return switch (side) {
        TradeSide.buy => 'Bullish Engulfing',
        TradeSide.sell => 'Bearish engulfing',
        null => 'Engulfing',
      };
    case 'bullishEngulfing':
      return 'Bullish Engulfing';
    case 'bearishEngulfing':
      return 'Bearish engulfing';
    case 'supplyZone':
      return 'Supply Zone';
    case 'demandZone':
      return 'Demand Zone';
    default:
      final option = tradeAnchorOptions
          .where((item) => item.key == anchorKey)
          .firstOrNull;
      return option == null ? anchorKey : (arabic ? option.ar : option.en);
  }
}

/// Optional price reference selected for a trade's entry context.
/// Values are stored by key so their presentation can evolve independently.
const tradeAnchorOptions = <TradeEntryOption>[
  TradeEntryOption('keyLevel', 'Key Level', 'Key Level'),
  TradeEntryOption('zoneSd', 'Zone S/D', 'Zone S/D'),
  TradeEntryOption('engulfing', 'Engulfing', 'Engulfing'),
  TradeEntryOption('base', 'Base', 'Base'),
];

const tradeMoodOptions = <TradeEntryOption>[
  TradeEntryOption('moodUnknown', 'غير مسجلة', 'Not recorded'),
  TradeEntryOption('moodCalm', 'هادئ', 'Calm'),
  TradeEntryOption('moodConfident', 'واثق', 'Confident'),
  TradeEntryOption('moodAnxious', 'قلق', 'Anxious'),
  TradeEntryOption('moodImpulsive', 'مندفع', 'Impulsive'),
  TradeEntryOption('moodTired', 'متعب', 'Tired'),
  TradeEntryOption('moodUnsureAnalysis', 'غير واثق من التحليل', 'Unsure about the analysis'),
];

const tradeReviewGroups = <TradeReviewGroup>[
  TradeReviewGroup(
    titleAr: 'مخالفات التنفيذ',
    titleEn: 'Execution violations',
    options: [
      TradeEntryOption('enteredEarly', 'دخلت مبكرًا', 'Entered early'),
      TradeEntryOption('hesitationPartialSize', 'لم أفتح الحجم الكامل بسبب التردد', 'I hesitated and did not open the full position size'),
      TradeEntryOption('lateEntry', 'دخلت متأخرًا', 'Entered late'),
      TradeEntryOption('stopLossReducedWithoutReason', 'غيّرت وقف الخسارة لتقليل المخاطرة دون مبرر', 'Reduced stop-loss risk without a logical reason'),
      TradeEntryOption('stopLossIncreasedWithoutReason', 'غيّرت وقف الخسارة لزيادة المخاطرة دون مبرر', 'Increased stop-loss risk without a logical reason'),
      TradeEntryOption('exitedEarlyBecauseFearOfLosingProfit', 'خرجت مبكرًا خوفًا من ضياع الأرباح قبل الهدف', 'Exited early out of fear of giving back profit'),
    ],
  ),
  TradeReviewGroup(
    titleAr: 'جودة التحليل والإعداد',
    titleEn: 'Analysis & setup quality',
    options: [
      TradeEntryOption('missedHigherTimeframeBounceArea', 'لم أنتبه لمنطقة ارتداد في الفريم الأكبر', 'Missed a higher-timeframe bounce area'),
      TradeEntryOption('missedLowerTimeframeBounceArea', 'لم أنتبه لمنطقة ارتداد في الفريم الأصغر', 'Missed a lower-timeframe bounce area'),
      TradeEntryOption('missedTrendlineFromCandleWicks', 'لم أنتبه لاحتمالية رسم الترند لاين من ذيول الشموع', 'Missed the possibility of drawing the trendline from candle wicks'),
      TradeEntryOption('noBreakoutPositiveClose', 'الكسر والإغلاق الإيجابي ضعيفان', 'Breakout and positive close lacked strength'),
      TradeEntryOption('noTrendlineSupportsEntryZone', 'لا يوجد ترند لاين يدعم منطقة الدخول', 'No trendline supported the entry zone'),
      TradeEntryOption('missedHigherTimeframeTrendlineIntegration', 'لم أدمج ترند 1h–4h في تحليلي', 'Did not include the 1h–4h trend in the analysis'),
    ],
  ),
  TradeReviewGroup(
    titleAr: 'الدخول وإدارة المخاطرة',
    titleEn: 'Entry & risk management',
    options: [
      TradeEntryOption('stopLossIncreasedForLiquiditySafety', 'زيادة المخاطرة لسبب منطقي: سيولة عالية مع وجود منطقة أمان أبعد قليلًا', 'Increased risk for a logical reason: high liquidity with a safer area slightly farther away'),
      TradeEntryOption('stopLossReducedForNegativeClose', 'تقليل المخاطرة لسبب منطقي: إغلاق سلبي لا يدعم اتجاه الصفقة', 'Reduced risk for a logical reason: a negative close did not support the trade direction'),
      TradeEntryOption('partialSizeAwaitingDeepCorrection', 'لم أفتح الحجم الكامل انتظارًا لتصحيح أعمق لمنطقة الدخول', 'Did not open full size while waiting for a deeper retracement into the entry zone'),
    ],
  ),
];

const tradeCommitmentOptions = <TradeEntryOption>[
  TradeEntryOption('breakevenStopToEntry', 'التزمت بخطة نقل وقف الخسارة إلى نقطة الدخول وخرجت بتعادل', 'Moved the stop to entry as planned and exited breakeven'),
  TradeEntryOption('manualExitNearTarget', 'خرجت يدويًا وفق الخطة عند اقتراب السعر من الهدف', 'Exited manually as planned when price approached the target'),
  TradeEntryOption('autoExitAtTarget', 'خرجت تلقائيًا وفق الخطة عند بلوغ الهدف', 'Exited automatically as planned at the defined target'),
  TradeEntryOption('enteredDespiteFear', 'التزمت بشروط الدخول رغم الخوف من الخسارة', 'Followed the entry conditions despite feeling fear of loss'),
  TradeEntryOption('fullPlanCompliance', 'التزمت بالخطة كاملة', 'Followed the complete plan without deviation'),
];

const tradeNoEntryOptions = <TradeEntryOption>[
  TradeEntryOption('fearRepeatLossAfterLoss', 'الخوف من تكرار الخسارة بعد خسارة سابقة', 'Fear of repeating a loss after a previous loss'),
  TradeEntryOption('fearGivingBackProfit', 'الخوف من خسارة الأرباح بعد صفقة رابحة.', 'Fear of giving back profit after a winning trade.'),
  TradeEntryOption('fearLossNoHistory', 'الخوف من الخسارة دون وجود ربح أو خسارة سابقة.', 'Fear of loss without a prior win or loss.'),
  TradeEntryOption('hesitationUnclearScenario', 'التردد بسبب عدم وضوح السيناريو.', 'Hesitation because the scenario was unclear.'),
  TradeEntryOption(
    'waitedDeeperRetestDespiteConfirmation',
    'الخوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة.',
    'Fear of a deep correction because the entry confirmation was far from the zone.',
  ),
];

String tradeEntryLabel(String key, {required bool arabic}) {
  for (final option in [...tradeEntryReasons, ...tradeConfirmationOptions, ...tradeMoodOptions, ...tradeCommitmentOptions, ...tradeNoEntryOptions, ...tradeReviewGroups.expand((group) => group.options)]) {
    if (option.key == key) return arabic ? option.ar : option.en;
  }
  return key;
}
