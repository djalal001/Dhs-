import 'package:flutter_test/flutter_test.dart';
import 'package:trader_desk/domain/trade_entry_catalog.dart';
import 'package:trader_desk/models/trade.dart';

void main() {
  test('opposing-signal selector exposes the four requested categories', () {
    expect(
      tradeReverseSignalOptions.map((option) => option.key).toList(),
      ['reverseSr', 'reverseSdZone', 'reverseHns', 'reverseLongCandleWick'],
    );
    expect(
      tradeReverseSignalOptions.map((option) => option.ar).toList(),
      ['S/R عكسي', 'S - D Zone عكسي', 'HNS عكسي', 'ذيل شمعة طويل عكسي'],
    );
  });

  test(
    'reverse S/R role reversal and S-D categories resolve from trade direction',
    () {
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.buy,
        ),
        'Support عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Resistan عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSdZone',
          arabic: true,
          side: TradeSide.buy,
        ),
        'Supply Zone',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSdZone',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Demand Zone',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.buy,
        ),
        'Reverse Support',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.sell,
        ),
        'Reverse Resistan',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseHns',
          arabic: true,
          side: TradeSide.buy,
        ),
        'HNS عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseLongCandleWick',
          arabic: true,
          side: TradeSide.sell,
        ),
        'ذيل شمعة طويل عكسي',
      );
    },
  );

  test('legacy opposing-signal records remain readable', () {
    expect(
      tradeReverseSignalDisplayLabel(
        optionKey: 'negativeCloseAgainstDirection', arabic: true,
      ),
      'إغلاق سلبي لا يدعم الصفقة قبل الارتداد من منطقة الدخول',
    );
    expect(
      tradeReverseSignalDisplayLabel(
        optionKey: 'strongRejectionWickAgainstDirection', arabic: true,
      ),
      'نموذج رفض قوي بذيل طويل لا يدعم اتجاه الصفقة',
    );
  });

  test('updates the no-entry reason text without changing its saved key', () {
    final option = tradeNoEntryOptions.singleWhere(
      (item) => item.key == 'waitedDeeperRetestDespiteConfirmation',
    );
    expect(
      option.ar,
      'الخوف من تصحيح عميق بسبب بُعد تأكيد الدخول عن المنطقة.',
    );
    expect(
      option.en,
      'Fear of a deep correction because the entry confirmation was far from the zone.',
    );
  });

  test('updates repeat-loss wording without changing the saved key', () {
    final option = tradeNoEntryOptions.singleWhere(
      (item) => item.key == 'fearRepeatLossAfterLoss',
    );
    expect(option.ar, 'الخوف من تكرار الخسارة بعد خسارة سابقة');
    expect(option.en, 'Fear of repeating a loss after a previous loss');
  });

  test('the 20 trading-behavior options have no terminal periods', () {
    final behaviorOptions = [
      ...tradeReviewGroups.expand((group) => group.options),
      ...tradeCommitmentOptions,
    ];
    expect(behaviorOptions, hasLength(20));
    for (final option in behaviorOptions) {
      expect(option.ar.endsWith('.'), isFalse, reason: option.key);
      expect(option.en.endsWith('.'), isFalse, reason: option.key);
    }
  });

  test('consolidates SFR/RFS into one direction-aware selection', () {
    final option = tradeEntryReasons.singleWhere(
      (item) => item.key == 'directionalSfrRfs',
    );
    expect(option.en, 'SFR / RFS');
    expect(option.ar, 'SFR / RFS');
    expect(tradeEntryReasonSelectionKey('RFS'), 'directionalSfrRfs');
    expect(tradeEntryReasonSelectionKey('SFR'), 'directionalSfrRfs');
    expect(
      formatTradeEntryReasonLabel(
        reason: 'directionalSfrRfs',
        side: TradeSide.buy,
      ),
      'RFS',
    );
    expect(
      formatTradeEntryReasonLabel(
        reason: 'directionalSfrRfs',
        side: TradeSide.sell,
      ),
      'SFR',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'directionalSfrRfs'),
      'SFR / RFS',
    );
    // Historical rows keep their original selected meaning until edited.
    expect(formatTradeEntryReasonLabel(reason: 'RFS', side: TradeSide.sell), 'RFS');
    expect(formatTradeEntryReasonLabel(reason: 'SFR', side: TradeSide.buy), 'SFR');
  });

  test('consolidates Trendline Touch 3 and resolves its label from direction', () {
    final keys = tradeEntryReasons.map((item) => item.key).toSet();
    expect(keys, contains('directionalTrendlineTouch3'));
    expect(keys, isNot(contains('Trend Line BUY')));
    expect(keys, isNot(contains('Trend Line SELL')));
    final option = tradeEntryReasons.singleWhere(
      (item) => item.key == 'directionalTrendlineTouch3',
    );
    expect(option.en, 'Trendline Touch 3');
    expect(tradeEntryReasonSelectionKey('Trend Line BUY'), 'directionalTrendlineTouch3');
    expect(tradeEntryReasonSelectionKey('Trend Line SELL'), 'directionalTrendlineTouch3');
    expect(tradeEntryReasonSelectionKey('Trendline Buy 3 Touch'), 'directionalTrendlineTouch3');
    expect(tradeEntryReasonSelectionKey('Trendline Sell 3 Touch'), 'directionalTrendlineTouch3');
    expect(
      formatTradeEntryReasonLabel(
        reason: 'directionalTrendlineTouch3',
        side: TradeSide.buy,
      ),
      'Trendline Touch 3 Buy',
    );
    expect(
      formatTradeEntryReasonLabel(
        reason: 'directionalTrendlineTouch3',
        side: TradeSide.sell,
      ),
      'Trendline Touch 3 Sell',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'directionalTrendlineTouch3'),
      'Trendline Touch 3',
    );
    // Old saved labels are normalized to the requested word order.
    expect(formatTradeEntryReasonLabel(reason: 'Trend Line BUY'), 'Trendline Touch 3 Buy');
    expect(formatTradeEntryReasonLabel(reason: 'Trend Line SELL'), 'Trendline Touch 3 Sell');
  });

  test('consolidates Trendline Touch 3 Breakout with inverse direction labels', () {
    final option = tradeEntryReasons.singleWhere(
      (item) => item.key == 'directionalTrendlineTouch3Breakout',
    );
    expect(option.en, 'Trend Line Touch 3 Breakout');
    expect(
      tradeEntryReasonSelectionKey('Trend Line BREAKOUT BUY'),
      'directionalTrendlineTouch3Breakout',
    );
    expect(
      tradeEntryReasonSelectionKey('Trend Line BREAKOUT SELL'),
      'directionalTrendlineTouch3Breakout',
    );
    expect(
      formatTradeEntryReasonLabel(
        reason: 'directionalTrendlineTouch3Breakout',
        side: TradeSide.buy,
      ),
      'Trend Line Touch 3 Sell Breakout',
    );
    expect(
      formatTradeEntryReasonLabel(
        reason: 'directionalTrendlineTouch3Breakout',
        side: TradeSide.sell,
      ),
      'Trend Line Touch 3 Buy Breakout',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'directionalTrendlineTouch3Breakout'),
      'Trend Line Touch 3 Breakout',
    );
  });

  test('Zone S/D is direction-aware and retains legacy Supply Zone records', () {
    final zoneOption = tradeEntryReasons.singleWhere(
      (option) => option.key == 'zoneSd',
    );
    expect(zoneOption.ar, 'Zone S/D');
    expect(zoneOption.en, 'Zone S/D');
    expect(
      tradeEntryReasons.any((option) => option.key == 'Supply Zone'),
      isFalse,
    );
    expect(tradeEntryReasonSelectionKey('Supply Zone'), 'zoneSd');
    expect(tradeEntryReasonSelectionKey('zoneSd'), 'zoneSd');
    expect(
      formatTradeEntryReasonLabel(reason: 'zoneSd', side: TradeSide.buy),
      'Demand Zone',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'zoneSd', side: TradeSide.sell),
      'Supply Zone',
    );
    expect(
      formatTradeEntryReasonLabel(reason: 'zoneSd'),
      'Zone S/D',
    );
    // Existing records which literally stored Supply Zone keep their
    // historical fixed label until the trader edits that entry.
    expect(
      formatTradeEntryReasonLabel(reason: 'Supply Zone', side: TradeSide.buy),
      'Supply Zone',
    );
    const setup = TradeEntrySetup(reason: 'zoneSd', timeframe: '15MIN');
    expect(TradeEntrySetup.fromJson(setup.toJson()), setup);
  });

  test('uses one direction-aware BREAKOUT row instead of separate SBR/RBS rows', () {
    final keys = tradeEntryReasons.map((option) => option.key).toSet();

    expect(
      keys,
      containsAll([
        'directionalBreakout',
        'directionalSfrRfs',
        'directionalTrendlineTouch3',
        'directionalTrendlineTouch3Breakout',
      ]),
    );
    expect(keys, isNot(contains('RFS')));
    expect(keys, isNot(contains('SFR')));
    expect(keys, isNot(contains('SBR')));
    expect(keys, isNot(contains('RBS')));
    expect(tradeEntryReasons.singleWhere((item) => item.key == 'directionalBreakout').en, 'BREAKOUT');
    expect(tradeEntryReasonSelectionKey('SBR'), 'directionalBreakout');
    expect(tradeEntryReasonSelectionKey('RBS'), 'directionalBreakout');
    expect(tradeEntryReasonSelectionKey('SBR Touch 2'), 'directionalBreakout');
    expect(tradeEntryReasonSelectionKey('RBS Touch 2'), 'directionalBreakout');
    expect(formatTradeEntryReasonLabel(reason: 'SBR'), 'SBR',
        reason: 'legacy saved SBR records preserve their historical label');
    expect(formatTradeEntryReasonLabel(reason: 'RBS'), 'RBS',
        reason: 'legacy saved RBS records preserve their historical label');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout', side: TradeSide.buy), 'RBS');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout', side: TradeSide.sell), 'SBR');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout'), 'BREAKOUT');
    expect(tradeEntryBaseReason('directionalBreakout Touch 2'), 'directionalBreakout');
    expect(tradeEntryUsesTouch2('directionalBreakout Touch 2'), isTrue);
    expect(tradeEntryReasonWithTouch2('directionalBreakout', true), 'directionalBreakout Touch 2');
    expect(tradeEntryReasonWithTouch2('directionalBreakout', false), 'directionalBreakout');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout Touch 2', side: TradeSide.buy), 'RBS Touch 2');
    expect(formatTradeEntryReasonLabel(reason: 'directionalBreakout Touch 2', side: TradeSide.sell), 'SBR Touch 2');
    expect(tradeEntryReasonSelectionKey('directionalBreakout Touch 2'), 'directionalBreakout');
  });

  test('new direction-aware entry reasons round-trip without schema changes', () {
    const setups = [
      TradeEntrySetup(reason: 'directionalSfrRfs', timeframe: '5MIN'),
      TradeEntrySetup(reason: 'directionalTrendlineTouch3', timeframe: '15MIN'),
      TradeEntrySetup(reason: 'directionalTrendlineTouch3Breakout', timeframe: '1H'),
    ];
    for (final setup in setups) {
      expect(TradeEntrySetup.fromJson(setup.toJson()), setup);
    }
  });

  test('uses one direction-aware Engulfing confirmation and keeps legacy labels readable', () {
    final options = tradeConfirmationOptions.map((item) => item.key).toList();
    expect(options, contains('confirmEngulfing'));
    expect(options.where((key) => key == 'confirmBullishEngulfing' || key == 'confirmBearishEngulfing'), isEmpty);
    expect(tradeConfirmationSelectionKey('confirmBullishEngulfing'), 'confirmEngulfing');
    expect(tradeConfirmationSelectionKey('confirmBearishEngulfing'), 'confirmEngulfing');
    expect(tradeConfirmationSelectionKey('Engulfing'), 'confirmEngulfing');
    expect(tradeConfirmationDisplayKey(type: 'confirmEngulfing', side: TradeSide.buy), 'confirmBullishEngulfing');
    expect(tradeConfirmationDisplayKey(type: 'confirmEngulfing', side: TradeSide.sell), 'confirmBearishEngulfing');
    expect(tradeConfirmationDisplayKey(type: 'confirmBullishEngulfing', side: TradeSide.sell), 'confirmBullishEngulfing',
        reason: 'historical concrete confirmations are not rewritten merely by changing the side');
    expect(tradeConfirmationDisplayKey(type: 'confirmBearishEngulfing', side: TradeSide.buy), 'confirmBearishEngulfing');
  });

  test('defines the reverse-signal and bounce-area option lists independently', () {
    expect(tradeReverseSignalOptions.map((item) => item.key), [
      'reverseSr',
      'reverseSdZone',
      'reverseHns',
      'reverseLongCandleWick',
    ]);
    expect(tradeBounceZoneOptions.map((item) => item.key), [
      'bounceFromSrZone',
      'internalLiquiditySweep',
      'majorStructureLiquiditySweep',
      'bounceFromTrendline',
      'bounceFromTrendlineAndSupplyZone',
    ]);
  });

  test('uses the approved concise Arabic and English liquidity labels', () {
    final internal = tradeBounceZoneOptions.singleWhere(
      (item) => item.key == 'internalLiquiditySweep',
    );
    final external = tradeBounceZoneOptions.singleWhere(
      (item) => item.key == 'majorStructureLiquiditySweep',
    );
    expect(internal.ar, 'سحب سيولة داخلي');
    expect(internal.en, 'Internal liquidity sweep');
    expect(external.ar, 'سحب السيولة خارجي');
    expect(external.en, 'External liquidity sweep');
  });

  test('uses one direction-aware Engulfing anchor instead of separate Bullish/Bearish rows', () {
    expect(
      tradeAnchorOptions.map((item) => item.en).toList(),
      ['Key Level', 'Zone S/D', 'Engulfing', 'Base'],
    );
    expect(tradeAnchorOptions.map((item) => item.key).toSet().length, 4);
    expect(tradeAnchorOptions.any((item) => item.key == 'supplyZone' || item.key == 'demandZone'), isFalse);
    expect(formatTradeAnchorLabel(anchorKey: 'zoneSd', arabic: false, side: TradeSide.buy), 'Demand Zone');
    expect(formatTradeAnchorLabel(anchorKey: 'zoneSd', arabic: false, side: TradeSide.sell), 'Supply Zone');
    expect(formatTradeAnchorLabel(anchorKey: 'zoneSd', arabic: false), 'Zone S/D');
    expect(formatTradeAnchorLabel(anchorKey: 'engulfing', arabic: false, side: TradeSide.buy), 'Bullish Engulfing');
    expect(formatTradeAnchorLabel(anchorKey: 'engulfing', arabic: false, side: TradeSide.sell), 'Bearish engulfing');
    expect(formatTradeAnchorLabel(anchorKey: 'engulfing', arabic: false), 'Engulfing');
    expect(formatTradeAnchorLabel(anchorKey: 'bullishEngulfing', arabic: false, side: TradeSide.sell), 'Bullish Engulfing',
        reason: 'legacy concrete anchors remain readable');
    expect(formatTradeAnchorLabel(anchorKey: 'bearishEngulfing', arabic: false, side: TradeSide.buy), 'Bearish engulfing',
        reason: 'legacy concrete anchors remain readable');
    expect(formatTradeAnchorLabel(anchorKey: 'supplyZone', arabic: false, side: TradeSide.buy), 'Supply Zone',
        reason: 'legacy records keep their historical concrete label');
    expect(formatTradeAnchorLabel(anchorKey: 'demandZone', arabic: false, side: TradeSide.sell), 'Demand Zone',
        reason: 'legacy records keep their historical concrete label');
    final base = tradeAnchorOptions.singleWhere((item) => item.key == 'base');
    expect(base.ar, 'Base');
    expect(base.en, 'Base');
  });


  test('Base anchor and timeframe round-trip through the existing trade JSON shape', () {
    final original = Trade(
      id: 'base-anchor-json-test',
      accountId: 'account',
      market: 'NQ',
      reason: 'RFS',
      result: 25,
      riskPercent: 1,
      side: TradeSide.buy,
      confirmation: '',
      sequence: '',
      mood: '',
      tradedAt: DateTime(2026, 1, 1),
      anchors: const ['base'],
      anchorTimeframes: const {'base': '1H'},
    );

    final restored = Trade.fromJson(original.toJson());
    expect(restored.effectiveAnchors, ['base']);
    expect(restored.anchorTimeframes, {'base': '1H'});
  });

  test('new opposing signal categories use the existing setup JSON shape', () {
    for (final key in [
      'reverseSr',
      'reverseSdZone',
      'reverseHns',
      'reverseLongCandleWick',
    ]) {
      final selected = TradeEntryConditionSetup(
        optionKey: key,
        timeframe: '15MIN',
      );
      expect(TradeEntryConditionSetup.fromJson(selected.toJson()), selected);
      expect(selected.toJson().keys, containsAll(['optionKey', 'timeframe']));
    }
  });

  test('reverse labels in saved setup follow the selected direction', () {
    const srSetup = TradeEntryConditionSetup(
      optionKey: 'reverseSr',
      timeframe: '15MIN',
    );
    const sdSetup = TradeEntryConditionSetup(
      optionKey: 'reverseSdZone',
      timeframe: '30MIN',
    );

    expect(
      formatTradeEntryConditionSetupLabel(
        setup: srSetup, optionLabel: 'S/R عكسي', arabic: true, side: TradeSide.buy,
      ),
      'Support عكسي 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: srSetup, optionLabel: 'S/R عكسي', arabic: true, side: TradeSide.sell,
      ),
      'Resistan عكسي 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: sdSetup, optionLabel: 'S - D Zone عكسي', arabic: true, side: TradeSide.buy,
      ),
      'Supply Zone 30MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: sdSetup, optionLabel: 'S - D Zone عكسي', arabic: true, side: TradeSide.sell,
      ),
      'Demand Zone 30MIN',
    );
  });

  test('formats entry-condition labels without separator dots or duplicated names', () {
    const combined = TradeEntryConditionSetup(
      optionKey: 'bounceFromTrendlineAndSupplyZone',
      timeframe: '30MIN',
      secondaryTimeframe: '5MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: combined,
        optionLabel: 'ارتداد من ترند لاين و Supply Zone',
        arabic: true,
      ),
      'ارتداد من Trend Line 30MIN - Supply Zone 5MIN',
    );
    const regular = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regular,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
      ),
      'ارتداد من منطقة S/R 15MIN',
    );
  });

  test('S/R bounce label follows direction only after a side is selected', () {
    const setup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );

    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
      ),
      'ارتداد من منطقة S/R 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من Support 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistan 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'Bounce from an S/R zone',
        arabic: false,
        side: TradeSide.buy,
      ),
      'Bounce from Support 15MIN',
    );
  });

  test('S/R bounce Touch 2 is shown as an optional saved qualifier', () {
    const setup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
      touch2: true,
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistan Touch 2 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: setup,
        optionLabel: 'Bounce from an S/R zone',
        arabic: false,
        side: TradeSide.buy,
      ),
      'Bounce from Support Touch 2 15MIN',
    );
  });

  test('S/R bounce chip uses the exact Support/Resistance Touch timeframe order', () {
    const touchSetup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
      touch2: true,
    );
    const regularSetup = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: touchSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من Support Touch 2 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regularSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.buy,
      ),
      'ارتداد من Support 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: touchSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistan Touch 2 15MIN',
    );
    expect(
      formatTradeEntryConditionSetupLabel(
        setup: regularSetup,
        optionLabel: 'ارتداد من منطقة S/R',
        arabic: true,
        side: TradeSide.sell,
      ),
      'ارتداد من Resistan 15MIN',
    );
  });

  test('S/R Touch 2 survives model JSON and older records default to false', () {
    const selected = TradeEntryConditionSetup(
      optionKey: 'bounceFromSrZone',
      timeframe: '30MIN',
      touch2: true,
    );
    expect(TradeEntryConditionSetup.fromJson(selected.toJson()), selected);
    expect(
      TradeEntryConditionSetup.fromJson({
        'optionKey': 'bounceFromSrZone',
        'timeframe': '30MIN',
      }).touch2,
      isFalse,
    );
  });

  test(
    'entry reason and confirmation labels place timeframe with a plain space',
    () {
      expect(
        const TradeEntrySetup(reason: 'RBS Touch 2', timeframe: '5MIN').label,
        'RBS Touch 2 5MIN',
      );
      expect(
        const TradeConfirmationSetup(
          type: 'Breakout–Pullback',
          timeframe: '15MIN',
        ).label,
        'Breakout–Pullback 15MIN',
      );
    },
  );

  test('Touch 2 qualifier is supported only for SBR and RBS', () {
    expect(tradeEntryTouch2EligibleReasons, {'SBR', 'RBS'});
    expect(tradeEntryBaseReason('SBR Touch 2'), 'SBR');
    expect(tradeEntryBaseReason('RBS Touch 2'), 'RBS');
    expect(tradeEntryUsesTouch2('SBR Touch 2'), isTrue);
    expect(tradeEntryUsesTouch2('RBS'), isFalse);
    expect(tradeEntryReasonWithTouch2('SBR', true), 'SBR Touch 2');
    expect(tradeEntryReasonWithTouch2('RBS', false), 'RBS');
    expect(tradeEntryReasonWithTouch2('RFS', true), 'RFS');
    expect(tradeEntryReasonWithTouch2('SFR', true), 'SFR');
  });
  test(
    'S/R-facing Resistance text uses the approved compact Resistan spelling',
    () {
      const setup = TradeEntryConditionSetup(
        optionKey: 'bounceFromSrZone',
        timeframe: '15MIN',
        touch2: true,
      );
      expect(
        formatTradeEntryConditionSetupLabel(
          setup: setup,
          optionLabel: 'ارتداد من منطقة S/R',
          arabic: true,
          side: TradeSide.sell,
        ),
        'ارتداد من Resistan Touch 2 15MIN',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: true,
          side: TradeSide.sell,
        ),
        'Resistan عكسي',
      );
      expect(
        tradeReverseSignalDisplayLabel(
          optionKey: 'reverseSr',
          arabic: false,
          side: TradeSide.sell,
        ),
        'Reverse Resistan',
      );
    },
  );

  test(
    'capitalized legacy Bearish Engulfing text maps to the semantic confirmation row',
    () {
      expect(tradeConfirmationSelectionKey('Bearish Engulfing'), 'confirmEngulfing');
      expect(tradeConfirmationSelectionKey('Bearish engulfing'), 'confirmEngulfing');
    },
  );

}
