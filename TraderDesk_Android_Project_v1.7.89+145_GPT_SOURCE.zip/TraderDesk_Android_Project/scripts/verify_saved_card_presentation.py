#!/usr/bin/env python3
"""Regression checks for the compact saved-card presentation in 1.7.89+145."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TRADES = (ROOT / 'lib/screens/trades_screen.dart').read_text(encoding='utf-8')
CARD_TEST = (ROOT / 'test/trades_screen_filter_test.dart').read_text(encoding='utf-8')
DETAIL_TEST = (ROOT / 'test/trade_detail_layout_test.dart').read_text(encoding='utf-8')
PUBSPEC = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
WORKFLOW = (ROOT / '.github/workflows/android-build.yml').read_text(encoding='utf-8')

checks = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

summary_start = TRADES.index('class _TradeSummaryCard')
summary_end = TRADES.index('class TradeDetailScreen')
summary = TRADES[summary_start:summary_end]
detail_start = TRADES.index('class TradeDetailScreen')
detail = TRADES[detail_start:]

check('release is 1.7.89+145', 'version: 1.7.89+145' in PUBSPEC)
check('workflow uses release 1.7.89+145/build140', 'TraderDesk 1.7.89+145' in WORKFLOW and 'traderdesk-1.7.89-build145' in WORKFLOW)
check('saved-card direction badge widget has been removed', '_DirectionBadge' not in TRADES)
check('no direction arrow decoration remains in saved-card source', 'Icons.north_east_rounded' not in TRADES and 'Icons.south_east_rounded' not in TRADES)
check('compact card does not render a purple entry-conditions panel', 'trade-summary-linked-entry-conditions-' not in summary)
check('compact card does not render raw entryConditions translation key', "tr(context, 'entryConditions')" not in summary)
check('saved card still opens its normal details action', 'onTap: onOpen' in summary)
check('details keep the side stored and represented in trade data', 'trade.side' in detail and 'TradeSide' in TRADES)
check('detail panel retains Arabic title and localized English translation', "arabic ? 'ظروف الدخول' : 'Entry conditions'" in detail)
check('linked entry conditions auto-expand only after entering details', 'initiallyExpanded: entryConditionsLinkedToNoEntry' in detail)
check('linked detail panel remains violet', 'tone: entryConditionsTone' in detail and 'TradeDetailPalette.reviewNoEntryDark' in detail)
check('widget test rejects direction badges and summary violet surface', 'saved trade summary stays clean' in CARD_TEST and 'findsNothing' in CARD_TEST and 'trade-summary-linked-entry-conditions-practical-entry-card' in CARD_TEST)
check('widget test opens saved card before asserting the purple detail panel', 'await tester.tap(savedCard);' in CARD_TEST and 'trade-detail-entry-conditions-panel-surface' in CARD_TEST)
detail_primary_test = DETAIL_TEST.split("testWidgets('saved trade details preserve", 1)[1].split('testWidgets(', 1)[0]
check('detail layout test expects linked panel content without a second manual expansion', 'await tester.tap(conditionsToggle);' not in detail_primary_test and "expect(find.text('إشارات عكسية'), findsOneWidget)" in detail_primary_test)

for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
print(f"{sum(ok for _, ok in checks)}/{len(checks)} checks passed")
raise SystemExit(0 if all(ok for _, ok in checks) else 1)
